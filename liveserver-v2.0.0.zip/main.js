(()=>{var Ds=Object.defineProperty;var T=(e,t)=>()=>(e&&(t=e(e=0)),t);var fe=(e,t)=>{for(var r in t)Ds(e,r,{get:t[r],enumerable:!0})};var Mt,Fr=T(()=>{Mt={pluginEnabled:!0,port:8080,bindAddress:"127.0.0.1",rootFolder:"",liveReload:!0,openBrowserOnStart:!0,directoryListing:!0,autoShutdownMinutes:0,browserDisplayMode:"inPage",browserSearchEngine:"google",externalSiteMode:"proxy",browserHomeUrl:"",showSideButton:!0,browserOpacity:1,browserOverlay:!1,overlayAutoSave:!0,browserBookmarks:[],browserDevice:{on:!1,id:"responsive",w:390,h:844,zoom:"fit"},enableCors:!0,customHeaders:"",customCharset:"utf-8",bindLocalhostOnly:!0,ipWhitelist:"",basicAuthUser:"",basicAuthPass:"",dependenciesInstalled:!1,chromiumInstalled:!1,acodelsPath:"",showAddressBar:!0}});var Wr={};fe(Wr,{getPluginId:()=>$s,getSettings:()=>A,saveSettingsPatch:()=>js,updateSetting:()=>q});function $s(){return Ur}function A(){var e;try{let t=acode.require("settings"),r=(e=t==null?void 0:t.value)==null?void 0:e[Ur];return(!r||typeof r!="object")&&(r={...Mt},t!=null&&t.value&&(t.value[Ur]=r)),r}catch{return{...Mt}}}function q(e,t){let r=A();r[e]=t;try{acode.require("settings").update(!1)}catch{}try{window.dispatchEvent(new CustomEvent("liveserver-settings",{detail:{key:e,value:t}}))}catch{}}function js(e){let t=A();Object.assign(t,e);try{acode.require("settings").update(!1)}catch{}}var Ur,ne=T(()=>{Fr();Ur="acode.plugin.sugerserver"});function Se(e){return String(e!=null?e:"").replace(/'/g,`'"'"'`)}function Gr(e){let t=String(e||"").trim();return t?/^sh\s+-c\s+/i.test(t)?t:`sh -c '${Se(t)}'`:"sh -c 'true'"}function Rt(e){return String(e||"").split(`
`).filter(t=>!/proot warning:/i.test(t)).join(`
`)}function so(e){if(e==null)return"";if(typeof e=="string")return Rt(e);if(typeof e=="object"){let t=[e.stdout,e.stderr,e.output,e.message].filter(r=>r!=null&&r!=="").map(String);if(t.length)return Rt(t.join(`
`));try{return Rt(JSON.stringify(e))}catch{return Rt(String(e))}}return Rt(String(e))}function Vr(e){try{return btoa(unescape(encodeURIComponent(e)))}catch{let r=new TextEncoder().encode(e),n="";return r.forEach(o=>{n+=String.fromCharCode(o)}),btoa(n)}}function Oe(){try{let e=acode.require("terminal"),t=typeof Executor!="undefined"&&Executor||window.Executor||globalThis.Executor||(e==null?void 0:e.Executor)||null;if(t!=null&&t.execute)return t}catch{}return null}async function j(e,t={}){let r=typeof t=="number"?t:t.timeoutMs||0,n=typeof t=="object"&&t.alpine!==!1,o=Oe();if(!(o!=null&&o.execute))throw console.warn("[LiveServer:exec] no executor",{hasWindow:!!window.Executor,hasGlobal:!!globalThis.Executor,hasTerminal:!!acode.require("terminal")}),new Error("Executor not available. Open Acode Terminal once (or install Executor), then retry.");let i=Gr(e);console.log("[LiveServer:exec] run len=",i.length);let s=async()=>{try{let a=await o.execute(i,n),p=so(a);return console.log("[LiveServer:exec] ok len=",p.length),p}catch(a){let p=so(a)||a&&a.message||String(a);return console.warn("[LiveServer:exec] catch \u2192",String(p).slice(0,240)),p}};return r>0?Promise.race([s(),new Promise(a=>setTimeout(()=>{console.warn("[LiveServer:exec] timeout",r,"ms \u2014 continuing"),a("")},r))]):s()}async function Ve(e,t={}){let r=Vr(String(e||""));return j(`echo '${Se(r)}' | base64 -d | sh`,{timeoutMs:t.timeoutMs||0,alpine:t.alpine!==!1})}async function It(e){try{let t=await j(`command -v ${Se(e)} 2>/dev/null || which ${Se(e)} 2>/dev/null || echo MISS`,{timeoutMs:2e4}),r=String(t||"").trim();return!r||/MISS|not found/i.test(r)?!1:/\//.test(r)||r.split(`
`).some(n=>n.includes("/"))}catch(t){return console.warn("[LiveServer:exec] commandExists",e,(t==null?void 0:t.message)||t),!1}}var nt=T(()=>{});function io(){let e=document.getElementById("ls-deps-picker-css");e&&e.remove();let t=document.createElement("style");t.id="ls-deps-picker-css",t.textContent=`
#ls-deps-picker {
  position: fixed;
  inset: 0;
  z-index: 100005;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background: rgba(0, 0, 0, 0.56);
  backdrop-filter: blur(3px);
  animation: ls-dp-in 0.18s ease-out;
}
@keyframes ls-dp-in {
  from { opacity: 0; }
  to { opacity: 1; }
}
#ls-deps-picker.ls-dp-leaving {
  opacity: 0;
  transition: opacity 0.16s ease;
}
.ls-dp-backdrop {
  position: absolute;
  inset: 0;
}
.ls-dp-card {
  position: relative;
  z-index: 1;
  width: min(440px, 94vw);
  max-height: min(82vh, 580px);
  display: flex;
  flex-direction: column;
  border-radius: 8px;
  background: var(--popup-background-color, var(--secondary-color, #1e1f22));
  color: var(--popup-text-color, var(--primary-text-color, var(--color, #e8eaed)));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.28));
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.52);
  overflow: hidden;
  font-family: inherit;
}

/* ---- Linux Window Titlebar ---- */
.ls-dp-titlebar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.24));
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-title-left {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}
.ls-dp-dots {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex-shrink: 0;
}
.ls-dp-dots span {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  display: inline-block;
}
.ls-dp-dots span:nth-child(1) { background: #ef4444; }
.ls-dp-dots span:nth-child(2) { background: #f59e0b; }
.ls-dp-dots span:nth-child(3) { background: #22c55e; }
.ls-dp-title {
  font-weight: 600;
  font-size: 14px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ls-dp-subbar {
  padding: 8px 16px;
  font-size: 12px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.85;
  background: rgba(128, 128, 128, 0.06);
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.16));
  flex-shrink: 0;
}

/* ---- Body ---- */
.ls-dp-body {
  flex: 1;
  overflow-y: auto;
  padding: 12px 15px;
  min-height: 90px;
}
.ls-dp-checking {
  display: flex;
  align-items: center;
  gap: 10px;
  justify-content: center;
  padding: 26px 8px;
  font-size: 13px;
}
.ls-dp-spinner {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid rgba(128, 128, 128, 0.3);
  border-top-color: var(--active-color, #22c55e);
  animation: ls-spin 0.7s linear infinite;
  flex-shrink: 0;
}
@keyframes ls-spin {
  to { transform: rotate(360deg); }
}

/* ---- Package Rows ---- */
.ls-dp-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 11px;
  border-radius: 6px;
  margin-bottom: 7px;
  background: var(--primary-color, rgba(128, 128, 128, 0.1));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
  cursor: pointer;
  transition: border-color 0.15s ease;
}
.ls-dp-row:last-child {
  margin-bottom: 0;
}
.ls-dp-row.is-present {
  opacity: 0.78;
  cursor: default;
}
.ls-dp-row input[type="checkbox"] {
  width: 1.12rem;
  height: 1.12rem;
  flex-shrink: 0;
  accent-color: var(--active-color, #22c55e);
}
.ls-dp-row-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.ls-dp-name {
  font-weight: 600;
  font-size: 13px;
}
.ls-dp-desc {
  font-size: 11.5px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.75;
  word-break: break-word;
}
.ls-dp-status {
  font-size: 11px;
  flex-shrink: 0;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 4px;
}
.ls-dp-status.ok {
  background: rgba(34, 197, 94, 0.16);
  color: #4ade80;
}
.ls-dp-status.miss {
  background: rgba(239, 68, 68, 0.16);
  color: #f87171;
}
.ls-dp-status.opt {
  background: rgba(128, 128, 128, 0.18);
  color: var(--secondary-text-color, #9aa0a6);
}

/* ---- Linux Installation Progress View ---- */
.ls-dp-progress {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ls-dp-warn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 11px;
  border-radius: 5px;
  background: rgba(245, 158, 11, 0.14);
  border: 1px solid rgba(245, 158, 11, 0.35);
  color: #fbbf24;
  font-size: 12px;
  font-weight: 500;
}
.ls-dp-prog-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  font-size: 12.5px;
}
.ls-dp-progress-info {
  opacity: 0.92;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ls-dp-pct {
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  color: var(--active-color, #22c55e);
  flex-shrink: 0;
}
.ls-dp-progress-track {
  width: 100%;
  height: 8px;
  border-radius: 99px;
  background: var(--primary-color, rgba(128, 128, 128, 0.25));
  overflow: hidden;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
}
.ls-dp-progress-bar {
  height: 100%;
  width: 0%;
  border-radius: 99px;
  background: var(--active-color, #22c55e);
  transition: width 0.28s ease;
}
.ls-dp-link {
  align-self: flex-start;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  color: var(--active-color, #61afef);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  padding: 2px 0;
  font-family: inherit;
}
.ls-dp-log {
  margin: 0;
  max-height: 155px;
  overflow-y: auto;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 11px;
  line-height: 1.4;
  background: #0d1117;
  color: #c9d1d9;
  padding: 10px;
  border-radius: 5px;
  white-space: pre-wrap;
  word-break: break-word;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.25));
}

/* ---- Footer ---- */
.ls-dp-footer {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.18));
  border-top: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-btn {
  border: none;
  border-radius: 5px;
  padding: 8px 14px;
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  background: rgba(128, 128, 128, 0.22);
  color: inherit;
  font-family: inherit;
}
.ls-dp-btn:active {
  opacity: 0.85;
}
.ls-dp-btn.ls-dp-install,
.ls-dp-btn.ls-dp-done {
  background: var(--active-color, #22c55e);
  color: var(--button-text-color, #0b1116);
}
.ls-dp-btn.ls-dp-cancel {
  background: rgba(239, 68, 68, 0.18);
  color: #f87171;
  border: 1px solid rgba(239, 68, 68, 0.38);
}
.ls-dp-empty {
  opacity: 0.7;
  padding: 14px;
  text-align: center;
  font-size: 13px;
}
  `,document.head.appendChild(t)}var ao=T(()=>{});function Ot(e){return String(e!=null?e:"").replace(/&/g,"&").replace(/</g,"<").replace(/>/g,">").replace(/"/g,'"')}function lo(){return!!O}function Xr(){return Ht}function co(){Ht=!1}function po(e={}){io(),qt(!0),Ht=!1;let t=e.title||"Live Server Dependencies",r=e.subtitle||"Checking Alpine Linux packages...",n=Array.isArray(e.items)?e.items.slice():[];return new Promise(o=>{ot=o,O=document.createElement("div"),O.id="ls-deps-picker",O.innerHTML=`
      <div class="ls-dp-backdrop"></div>
      <div class="ls-dp-card" role="dialog" aria-modal="true">
        <div class="ls-dp-titlebar">
          <div class="ls-dp-title-left">
            <span class="ls-dp-dots"><span></span><span></span><span></span></span>
            <div class="ls-dp-title">${Ot(t)}</div>
          </div>
        </div>
        <div class="ls-dp-subbar ls-dp-subtitle">${Ot(r)}</div>

        <div class="ls-dp-body">
          <div class="ls-dp-checking" style="display:${e.checking?"flex":"none"}">
            <span class="ls-dp-spinner"></span>
            <span>Scanning Alpine environment...</span>
          </div>

          <div class="ls-dp-lists" style="display:${e.checking?"none":"block"}"></div>

          <div class="ls-dp-progress" style="display:none">
            <div class="ls-dp-warn">
              <span>\u26A0</span>
              <span>Don't close Acode while packages are installing.</span>
            </div>

            <div class="ls-dp-prog-top">
              <div class="ls-dp-progress-info">Preparing installation...</div>
              <span class="ls-dp-pct">0%</span>
            </div>

            <div class="ls-dp-progress-track">
              <div class="ls-dp-progress-bar" style="width:0%"></div>
            </div>

            <button type="button" class="ls-dp-link ls-dp-toggle-log">
              <span class="ls-dp-arrow">\u25B8</span>
              <span class="ls-dp-more-label">Show more</span>
            </button>
            <pre class="ls-dp-log" style="display:none"></pre>
          </div>
        </div>

        <div class="ls-dp-footer">
          <button type="button" class="ls-dp-btn ls-dp-notnow">Not now</button>
          <button type="button" class="ls-dp-btn ls-dp-cancel" style="display:none">Cancel installation</button>
          <button type="button" class="ls-dp-btn ls-dp-install">Install selected</button>
          <button type="button" class="ls-dp-btn ls-dp-done" style="display:none">Close</button>
        </div>
      </div>`,document.body.appendChild(O);let i=O.querySelector(".ls-dp-lists"),s=O.querySelector(".ls-dp-checking"),a=O.querySelector(".ls-dp-progress"),p=O.querySelector(".ls-dp-progress-bar"),m=O.querySelector(".ls-dp-pct"),d=O.querySelector(".ls-dp-progress-info"),h=O.querySelector(".ls-dp-log"),g=O.querySelector(".ls-dp-install"),l=O.querySelector(".ls-dp-notnow"),f=O.querySelector(".ls-dp-cancel"),E=O.querySelector(".ls-dp-done"),H=O.querySelector(".ls-dp-toggle-log"),b=O.querySelector(".ls-dp-arrow"),k=O.querySelector(".ls-dp-more-label"),y=O.querySelector(".ls-dp-subtitle"),L=O.querySelector(".ls-dp-backdrop");function v(){if(!i)return;let u="";for(let x of n){let U=x.present?'<span class="ls-dp-status ok">installed</span>':x.optional?'<span class="ls-dp-status opt">optional</span>':'<span class="ls-dp-status miss">missing</span>',ie=x.checked!=null?!!x.checked:!x.present&&!x.optional;u+=`<label class="ls-dp-row ${x.present?"is-present":"is-missing"}">
          <input type="checkbox" data-id="${Ot(x.id)}" ${ie?"checked":""} ${x.present?"disabled":""}/>
          <span class="ls-dp-row-main">
            <span class="ls-dp-name">${Ot(x.label)}</span>
            <span class="ls-dp-desc">${Ot(x.desc||"")}</span>
          </span>${U}</label>`}i.innerHTML=u||'<div class="ls-dp-empty">No items</div>'}function M(){let u=[];return O==null||O.querySelectorAll("input[type=checkbox][data-id]:checked:not(:disabled)").forEach(x=>u.push(x.getAttribute("data-id"))),u}function _(u){let x=M(),U=ot;ot=null,qt(!1),U&&U({action:u,selected:x})}function C(){let u=M();if(!u.length){try{acode.require("toast")("Select at least one item",2e3)}catch{}return}Ht=!1,i&&(i.style.display="none"),s&&(s.style.display="none"),a&&(a.style.display="flex"),g&&(g.style.display="none"),l&&(l.style.display="none"),f&&(f.style.display="inline-block"),E&&(E.style.display="none"),p&&(p.style.width="2%"),m&&(m.textContent="2%"),d&&(d.textContent="Initializing package installer..."),h&&(h.textContent=""),y&&(y.textContent="Installing selected packages in Alpine Linux...");let x=ot;ot=null,x&&x({action:"install",selected:u,keepOpen:!0})}g==null||g.addEventListener("click",()=>C()),l==null||l.addEventListener("click",()=>_("notnow")),f==null||f.addEventListener("click",()=>{Ht=!0,d&&(d.textContent="Cancelled"),_("cancel")}),E==null||E.addEventListener("click",()=>_("done")),L==null||L.addEventListener("click",()=>{a&&a.style.display!=="none"&&(f==null?void 0:f.style.display)!=="none"||_("close")}),H==null||H.addEventListener("click",()=>{if(!h)return;let u=h.style.display!=="none";h.style.display=u?"none":"block",b&&(b.textContent=u?"\u25B8":"\u25BE"),k&&(k.textContent=u?"Show more":"Show less"),u||(h.scrollTop=h.scrollHeight)}),O._lsDpUpdate=u=>{if(u.checking===!1&&s&&i&&(s.style.display="none",i.style.display="block"),u.checking===!0&&s&&i&&(s.style.display="flex",i.style.display="none"),u.subtitle!=null&&y&&(y.textContent=u.subtitle),Array.isArray(u.items)&&(n.length=0,u.items.forEach(x=>n.push({...x,checked:x.checked!=null?!!x.checked:!x.present&&!x.optional})),v()),u.progressMode&&(i&&(i.style.display="none"),s&&(s.style.display="none"),a&&(a.style.display="flex"),g&&(g.style.display="none"),l&&(l.style.display="none"),f&&(f.style.display=u.showDone?"none":"inline-block"),E&&(E.style.display=u.showDone?"inline-block":"none")),typeof u.percent=="number"){let x=Math.max(0,Math.min(100,Math.round(u.percent)));p&&(p.style.width=x+"%"),m&&(m.textContent=x+"%")}u.info&&d&&(d.textContent=u.info),u.logAppend&&h&&(h.textContent+=u.logAppend,h.scrollTop=h.scrollHeight),u.logSet!=null&&h&&(h.textContent=u.logSet)},v()})}function me(e){O&&typeof O._lsDpUpdate=="function"&&O._lsDpUpdate(e)}function qt(e){if(!O)return;let t=O;O=null,ot=null;try{t.classList.add("ls-dp-leaving")}catch{}let r=()=>{try{t.remove()}catch{}};e?r():setTimeout(r,180)}var O,ot,Ht,uo=T(()=>{ao();O=null,ot=null,Ht=!1});var Zr={};fe(Zr,{closeChromiumInstallerModal:()=>fr,isChromiumInstallerOpen:()=>Yr,showChromiumInstallerPopup:()=>it});function Ns(e){return String(e!=null?e:"").replace(/&/g,"&").replace(/</g,"<").replace(/>/g,">").replace(/"/g,'"')}function Fs(){if(document.getElementById("ls-chromium-installer-css"))return;let e=document.createElement("style");e.id="ls-chromium-installer-css",e.textContent=`
    .ls-ci-backdrop {
      position: fixed;
      inset: 0;
      z-index: 100010;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
      background: rgba(0, 0, 0, 0.58);
      backdrop-filter: blur(3px);
      animation: ls-ci-fade 0.18s ease-out;
    }
    @keyframes ls-ci-fade {
      from { opacity: 0; }
      to { opacity: 1; }
    }
.ls-ci-window {
  width: min(440px, 94vw);
  max-height: 84vh;
  display: flex;
  flex-direction: column;
  border-radius: 8px;
  background: var(--popup-background-color, var(--secondary-color, #1e1f22));
  color: var(--popup-text-color, var(--primary-text-color, var(--color, #e8eaed)));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.28));
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.52);
  overflow: hidden;
  font-family: inherit;
}

    .ls-ci-titlebar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 12px 16px;
      background: var(--primary-color, rgba(0, 0, 0, 0.25));
      border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
    }
    .ls-ci-title-left {
      display: flex;
      align-items: center;
      gap: 9px;
      min-width: 0;
    }
    .ls-ci-dots {
      display: inline-flex;
      gap: 5px;
      flex-shrink: 0;
    }
    .ls-ci-dots span {
      width: 9px;
      height: 9px;
      border-radius: 50%;
      display: inline-block;
    }
    .ls-ci-dots span:nth-child(1) { background: #ef4444; }
    .ls-ci-dots span:nth-child(2) { background: #f59e0b; }
    .ls-ci-dots span:nth-child(3) { background: #22c55e; }
    .ls-ci-title {
      font-size: 14px;
      font-weight: 600;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .ls-ci-body {
      padding: 14px 16px;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 12px;
      font-size: 13px;
      line-height: 1.45;
    }
    .ls-ci-desc {
      margin: 0;
      opacity: 0.92;
    }
    .ls-ci-pkg-card {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 10px 12px;
      border-radius: 6px;
      background: var(--primary-color, rgba(0, 0, 0, 0.2));
      border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
    }
    .ls-ci-pkg-name {
      font-weight: 600;
      font-size: 13px;
    }
    .ls-ci-pkg-sub {
      font-size: 11.5px;
      opacity: 0.72;
      margin-top: 2px;
    }
    .ls-ci-pkg-size {
      font-size: 11.5px;
      font-weight: 600;
      padding: 3px 8px;
      border-radius: 4px;
      background: rgba(34, 197, 94, 0.16);
      color: #4ade80;
      white-space: nowrap;
    }
    .ls-ci-warn {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 11px;
      border-radius: 5px;
      background: rgba(245, 158, 11, 0.14);
      border: 1px solid rgba(245, 158, 11, 0.35);
      color: #fbbf24;
      font-size: 12px;
      font-weight: 500;
    }
    .ls-ci-prog-wrap {
      display: flex;
      flex-direction: column;
      gap: 7px;
    }
    .ls-ci-prog-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      font-size: 12.5px;
    }
    .ls-ci-step {
      opacity: 0.9;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ls-ci-pct {
      font-weight: 700;
      font-variant-numeric: tabular-nums;
      color: var(--active-color, #22c55e);
      flex-shrink: 0;
    }
    .ls-ci-track {
      width: 100%;
      height: 8px;
      border-radius: 99px;
      background: var(--primary-color, rgba(128, 128, 128, 0.25));
      overflow: hidden;
      border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
    }
    .ls-ci-fill {
      height: 100%;
      width: 0%;
      border-radius: 99px;
      background: linear-gradient(90deg, #16a34a, #22c55e, #4ade80);
      transition: width 0.3s ease;
    }
    .ls-ci-more-toggle {
      align-self: flex-start;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: none;
      border: 0;
      padding: 2px 0;
      color: var(--active-color, #61afef);
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
    }
    .ls-ci-console {
      margin: 0;
      padding: 10px;
      max-height: 150px;
      overflow-y: auto;
      border-radius: 5px;
      background: #0d1117;
      color: #c9d1d9;
      border: 1px solid rgba(128, 128, 128, 0.25);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 11px;
      line-height: 1.4;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .ls-ci-console[hidden] {
      display: none;
    }
    .ls-ci-footer {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: 8px;
      padding: 11px 16px;
      background: var(--primary-color, rgba(0, 0, 0, 0.18));
      border-top: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
    }
    .ls-ci-btn {
      border: 0;
      border-radius: 5px;
      padding: 8px 14px;
      font-size: 12.5px;
      font-weight: 600;
      cursor: pointer;
      font-family: inherit;
    }
    .ls-ci-btn:active { opacity: 0.85; }
    .ls-ci-btn-sec {
      background: rgba(128, 128, 128, 0.22);
      color: inherit;
    }
    .ls-ci-btn-pri {
  background: var(--active-color, #22c55e);
  color: var(--button-text-color, #0b1116);
}
    .ls-ci-btn-danger {
      background: rgba(239, 68, 68, 0.2);
      color: #f87171;
      border: 1px solid rgba(239, 68, 68, 0.4);
    }
  `,document.head.appendChild(e)}function ur(){dr&&(clearInterval(dr),dr=null),pr&&(clearInterval(pr),pr=null)}async function Us(){He=!0,ur();try{await j('pkill -9 -f "apk add" 2>/dev/null || true; pkill -9 -f "pkg install" 2>/dev/null || true; pkill -9 -f "apt-get" 2>/dev/null || true; rm -f /tmp/ls-chromium-install.log 2>/dev/null || true',{timeoutMs:8e3})}catch{}}function fr(){if(ur(),st){try{st.remove()}catch{}st=null}}function Yr(){return!!st}function it(e={}){return st?Promise.resolve(!1):(Fs(),new Promise(t=>{let r=!1,n=_=>{var C,u;if(!r){if(r=!0,fr(),_)try{(C=e.onInstalled)==null||C.call(e)}catch{}else try{(u=e.onDismiss)==null||u.call(e)}catch{}t(!!_)}},o=document.createElement("div");o.className="ls-ci-backdrop";let i=(()=>{try{return e.url?new URL(e.url).hostname:"this website"}catch{return"this website"}})();o.innerHTML=`
      <div class="ls-ci-window" role="dialog" aria-modal="true">
        <div class="ls-ci-titlebar">
          <div class="ls-ci-title-left">
            <span class="ls-ci-dots"><span></span><span></span><span></span></span>
            <span class="ls-ci-title">Chromium Browser Engine</span>
          </div>
        </div>

        <div class="ls-ci-body">
          <!-- Offer View -->
          <div class="ls-ci-offer-view">
            <p class="ls-ci-desc">
              <strong>${Ns(i)}</strong> is taking longer than 10 seconds in lightweight proxy mode. Install <strong>Chromium</strong> in Alpine Linux to render complex JavaScript sites smoothly.
            </p>
            <div class="ls-ci-pkg-card" style="margin-top:10px;">
              <div>
                <div class="ls-ci-pkg-name">chromium + headless fonts</div>
                <div class="ls-ci-pkg-sub">Alpine / Termux package (optional)</div>
              </div>
              <span class="ls-ci-pkg-size">~180 MB</span>
            </div>
          </div>

          <!-- Progress View -->
          <div class="ls-ci-progress-view" hidden>
            <div class="ls-ci-warn">
              <span>\u26A0</span>
              <span>Don't close Acode while Chromium is installing.</span>
            </div>

            <div class="ls-ci-prog-wrap" style="margin-top:10px;">
              <div class="ls-ci-prog-top">
                <span class="ls-ci-step">Preparing Linux environment...</span>
                <span class="ls-ci-pct">0%</span>
              </div>
              <div class="ls-ci-track">
                <div class="ls-ci-fill"></div>
              </div>
            </div>

            <button type="button" class="ls-ci-more-toggle" style="margin-top:10px;">
              <span class="ls-ci-arrow">\u25B8</span>
              <span class="ls-ci-more-label">Show more</span>
            </button>
            <pre class="ls-ci-console" hidden></pre>
          </div>
        </div>

        <div class="ls-ci-footer">
          <button type="button" class="ls-ci-btn ls-ci-btn-sec ls-ci-notnow">Not Now</button>
          <button type="button" class="ls-ci-btn ls-ci-btn-pri ls-ci-install">Install Chromium</button>
          <button type="button" class="ls-ci-btn ls-ci-btn-danger ls-ci-cancel" hidden>Cancel installation</button>
          <button type="button" class="ls-ci-btn ls-ci-btn-pri ls-ci-done" hidden>Reload Page</button>
        </div>
      </div>
    `,document.body.appendChild(o),st=o;let s=o.querySelector(".ls-ci-offer-view"),a=o.querySelector(".ls-ci-progress-view"),p=o.querySelector(".ls-ci-step"),m=o.querySelector(".ls-ci-pct"),d=o.querySelector(".ls-ci-fill"),h=o.querySelector(".ls-ci-more-toggle"),g=o.querySelector(".ls-ci-arrow"),l=o.querySelector(".ls-ci-more-label"),f=o.querySelector(".ls-ci-console"),E=o.querySelector(".ls-ci-notnow"),H=o.querySelector(".ls-ci-install"),b=o.querySelector(".ls-ci-cancel"),k=o.querySelector(".ls-ci-done"),y=0,L=(_,C)=>{y=Math.max(0,Math.min(100,Math.round(_))),m&&(m.textContent=y+"%"),d&&(d.style.width=y+"%"),C&&p&&(p.textContent=C)},v=_=>{f&&(f.textContent+=_,f.scrollTop=f.scrollHeight)};h==null||h.addEventListener("click",()=>{f.hasAttribute("hidden")?(f.removeAttribute("hidden"),g.textContent="\u25BE",l.textContent="Show less",f.scrollTop=f.scrollHeight):(f.setAttribute("hidden",""),g.textContent="\u25B8",l.textContent="Show more")}),E==null||E.addEventListener("click",()=>n(!1)),k==null||k.addEventListener("click",()=>n(!0)),b==null||b.addEventListener("click",async()=>{b.disabled=!0,b.textContent="Cancelling...",L(y,"Cancelling installation..."),v(`
[abort] Terminating package manager process...
`),await Us(),Bt=!1,Kr("Chromium installation cancelled",2e3),n(!1)});async function M(){var _;if(!Bt){if(!((_=Oe())!=null&&_.execute)){Kr("Open Acode Terminal once to initialize Alpine Linux",3500),n(!1);return}Bt=!0,He=!1,s.setAttribute("hidden",""),a.removeAttribute("hidden"),E.setAttribute("hidden",""),H.setAttribute("hidden",""),b.removeAttribute("hidden"),L(4,"Detecting Linux package manager..."),v(`$ Detecting package manager (apk / pkg / apt)...
`);try{let C=await j("if command -v apk >/dev/null 2>&1; then echo APK; elif command -v pkg >/dev/null 2>&1; then echo PKG; elif command -v apt-get >/dev/null 2>&1; then echo APT; else echo NONE; fi",{timeoutMs:1e4});if(He)return;let u=String(C||"").trim();if(u==="NONE"||!u){v(`[error] No supported package manager found.
`),L(0,"Package manager not found"),b.textContent="Close",b.disabled=!1,b.onclick=()=>n(!1),Bt=!1;return}if(L(15,"Updating package repositories..."),u==="APK"){v(`$ apk update
`);let G=await j("apk update 2>&1",{timeoutMs:6e4});v(String(G||"").slice(-1200)+`
`)}else if(u==="PKG"){v(`$ pkg update -y
`);let G=await j("pkg update -y 2>&1",{timeoutMs:6e4});v(String(G||"").slice(-1200)+`
`)}else{v(`$ apt-get update -y
`);let G=await j("apt-get update -y 2>&1",{timeoutMs:6e4});v(String(G||"").slice(-1200)+`
`)}if(He)return;L(28,"Downloading & installing chromium..."),await j(": > /tmp/ls-chromium-install.log",{timeoutMs:5e3});let x=0;dr=setInterval(async()=>{if(!He)try{let G=await j("cat /tmp/ls-chromium-install.log 2>/dev/null || true",{timeoutMs:4e3}),le=String(G||"");if(le.length>x){let be=le.slice(x);x=le.length,v(be);let we=be.split(`
`).map(c=>c.trim()).filter(Boolean).pop();we&&p&&(p.textContent=we.slice(0,48))}}catch{}},1200),pr=setInterval(()=>{if(!He&&y<88){let G=y<55?3:y<75?2:1;L(y+G)}},1400);let U="";if(u==="APK"?(v(`$ apk add --no-cache chromium nss freetype harfbuzz ca-certificates ttf-freefont
`),U=`#!/bin/sh
set +e
apk add --no-cache chromium nss freetype harfbuzz ca-certificates ttf-freefont >> /tmp/ls-chromium-install.log 2>&1
echo "[exit:$?]" >> /tmp/ls-chromium-install.log
`):u==="PKG"?(v(`$ pkg install -y x11-repo && pkg install -y chromium
`),U=`#!/bin/sh
set +e
pkg install -y x11-repo >> /tmp/ls-chromium-install.log 2>&1
pkg install -y chromium >> /tmp/ls-chromium-install.log 2>&1
echo "[exit:$?]" >> /tmp/ls-chromium-install.log
`):(v(`$ apt-get install -y chromium fonts-liberation
`),U=`#!/bin/sh
set +e
DEBIAN_FRONTEND=noninteractive apt-get install -y chromium fonts-liberation >> /tmp/ls-chromium-install.log 2>&1
echo "[exit:$?]" >> /tmp/ls-chromium-install.log
`),await Ve(U,{timeoutMs:0}),ur(),He)return;try{let G=await j("cat /tmp/ls-chromium-install.log 2>/dev/null; rm -f /tmp/ls-chromium-install.log",{timeoutMs:6e3}),le=String(G||"");le.length>x&&v(le.slice(x))}catch{}L(95,"Verifying Chromium binary...");let ie=await j("command -v chromium 2>/dev/null || command -v chromium-browser 2>/dev/null || echo MISS",{timeoutMs:8e3}),ae=String(ie||"").trim(),Ie=!!ae&&!ae.includes("MISS")&&ae.includes("/");q("chromiumInstalled",Ie),Ie?(L(100,"Chromium installed successfully!"),v(`
\u2713 Installed at: ${ae}
`),q("externalSiteMode","chromium"),b.setAttribute("hidden",""),k.removeAttribute("hidden"),Kr("Chromium installed!",2500)):(L(y,"Installation failed \u2014 check details"),v(`
\u2717 Chromium binary not found after install.
`),f.removeAttribute("hidden"),g.textContent="\u25BE",l.textContent="Show less",b.textContent="Close",b.disabled=!1,b.onclick=()=>n(!1))}catch(C){ur(),He||(v(`
[error] ${(C==null?void 0:C.message)||C}
`),L(y,"Installation error"),b.textContent="Close",b.onclick=()=>n(!1))}finally{Bt=!1}}}H==null||H.addEventListener("click",M),e.startImmediately&&M()}))}var Kr,st,Bt,He,dr,pr,at=T(()=>{nt();ne();Kr=acode.require("toast"),st=null,Bt=!1,He=!1,dr=null,pr=null});var zt={};fe(zt,{DEP_CATALOG:()=>Dt,checkDependenciesAction:()=>Ys,ensureLiveServerDeps:()=>vr,isChromiumInstalled:()=>hr,reinstallDependenciesAction:()=>Zs,resetDepsSession:()=>en,resolveAcodelsPath:()=>dt,scanAllDeps:()=>Qr,showDepsPickerFlow:()=>gr,verifyDependencies:()=>lt});async function hr(){try{if(await It("chromium")||await It("chromium-browser"))return!0}catch{}return!1}async function dt(){let e=A();try{let r=await j(`for d in /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do
  [ -f "$d/index.js" ] || continue
  if [ -d "$d/node_modules/express" ]; then echo "FULL:$d"; exit 0; fi
  echo "BARE:$d"
done
exit 0`,{timeoutMs:12e3}),n=String(r||"").split(`
`).map(p=>p.trim()).filter(Boolean),o=n.filter(p=>p.startsWith("FULL:")).map(p=>p.slice(5)),i=n.filter(p=>p.startsWith("BARE:")).map(p=>p.slice(5)),s=p=>p.filter(d=>d&&!d.startsWith("/public")).sort((d,h)=>(h.startsWith("/root")?1:0)-(d.startsWith("/root")?1:0))[0]||p.find(d=>d&&!d.startsWith("/public"))||p[0]||null,a=s(o)||s(i);if(a){try{q("acodelsPath",a)}catch{}return a}}catch(r){console.warn("[LiveServer:deps] probe",(r==null?void 0:r.message)||r)}let t=String(e.acodelsPath||"").trim();if(t&&!t.startsWith("/public")&&!t.includes("com.termux"))return t;try{t&&q("acodelsPath","")}catch{}return"/root/.acode_liveserver/acodels"}async function Gs(e){try{let t=e?Se(e):"''",r=await j("for d in "+t+' /root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do [ -d "$d/node_modules/express" ] && [ -d "$d/node_modules/ws" ] && echo OK && exit 0; done; echo MISS',{timeoutMs:1e4});return String(r).includes("OK")}catch{return!1}}async function Qr(e){qe=e||qe;let t=await It("node"),r=await It("npm"),n=await dt(e),o=t?await Gs(n):!1,i=await hr();return q("chromiumInstalled",i),[{...Dt[0],present:t},{...Dt[1],present:r},{...Dt[2],present:o,path:n},{...Dt[3],present:i}]}async function lt(e){let t=await Qr(e),r=t.filter(n=>n.required!==!1&&!n.present).map(n=>n.id);return{ok:r.length===0,missing:r,all:t}}function Vs(e){return e.map(t=>({id:t.id,label:t.label,desc:t.desc+(t.path?` \u2014 ${t.path}`:""),present:t.present,optional:t.optional===!0,checked:t.optional?!1:!t.present}))}async function Xs(){return Ve(`#!/bin/sh
set +e
echo "[pm] detecting..."
if command -v pkg >/dev/null 2>&1; then
  echo "[pm] termux pkg"
  pkg update -y 2>&1
  pkg install -y nodejs 2>&1 || pkg install -y nodejs-lts 2>&1
elif command -v apk >/dev/null 2>&1; then
  echo "[pm] apk"
  apk update 2>&1
  apk add --no-cache nodejs npm 2>&1
elif command -v apt-get >/dev/null 2>&1; then
  echo "[pm] apt"
  apt-get update -y 2>&1
  apt-get install -y nodejs npm 2>&1
else
  echo "[pm] none found"
  exit 1
fi
node -v 2>&1
npm -v 2>&1
echo "[done] node packages"
`,{timeoutMs:0})}async function Ks(e){let t=`#!/bin/sh
set +e
DIR=${Se(e)}
case "$DIR" in
  '$HOME'/*|$HOME/*) DIR="/root/.acode_liveserver/acodels" ;;
esac
if [ -z "$DIR" ] || echo "$DIR" | grep -q com.termux; then
  DIR="/root/.acode_liveserver/acodels"
fi
mkdir -p "$DIR" 2>&1
cd "$DIR" || { echo "[acodels] cd failed"; exit 1; }
if [ ! -f package.json ]; then
  cat > package.json << 'JSON'
{
  "name": "acodels",
  "version": "1.0.0",
  "main": "index.js",
  "dependencies": {
    "chokidar": "^3.5.3",
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "ws": "^8.11.0"
  }
}
JSON
fi
echo "[acodels] npm install in $DIR"
npm install --omit=dev --no-audit --no-fund 2>&1
echo "[done] acodels"
`;return Ve(t,{timeoutMs:0})}async function gr(e={}){var s,a,p;let t=e.baseUrl||qe||"";if(qe=t,Xe)return Jr("Install already running...",2e3),!1;if(lo()&&!e.force||!e.force&&!e.fromSettings&&ct)return!1;if(!e.force&&!e.fromSettings&&(await lt(t)).ok)return q("dependenciesInstalled",!0),!0;(s=Oe())!=null&&s.execute||Jr("Open Acode Terminal once, then retry Install",3500);let r=po({title:"Live Server Dependencies",subtitle:"Checking...",items:[],checking:!0}),n;try{n=await Qr(t)}catch(m){return me({checking:!1,subtitle:"Check failed \u2014 "+((m==null?void 0:m.message)||m),items:[]}),await r,!1}let o=n.filter(m=>m.required!==!1&&!m.present).length;me({checking:!1,subtitle:o===0?"All required tools present (Chromium is optional)":`${o} required missing \u2014 tick what to install`,items:Vs(n)});let i=await r;if(i.action==="notnow"||i.action==="close"||i.action==="cancel")return ct=!0,!1;if(i.action==="done")return(await lt(t)).ok;if(i.action==="install"&&((a=i.selected)!=null&&a.length)){if(i.selected.length===1&&i.selected[0]==="chromium")return qt(!0),it({startImmediately:!0});if(Xe=!0,co(),!((p=Oe())!=null&&p.execute))return me({progressMode:!0,percent:0,info:"Executor not available",logAppend:`Open Acode Terminal once (Alpine/Termux), then open this dialog again.
`,showDone:!0}),Xe=!1,!1;me({progressMode:!0,percent:5,info:"Preparing...",logAppend:"Selected: "+i.selected.join(", ")+`
`});try{let d=await dt(t);if(i.selected.includes("node")||i.selected.includes("npm")){if(me({percent:15,info:"Installing Node.js / npm...",logAppend:`
=== node / npm ===
`}),Xr())return Xe=!1,!1;let g=await Xs();me({percent:48,logAppend:String(g||"").slice(-2500)+`
`})}if(i.selected.includes("acodels")){if(me({percent:58,info:"Installing backend modules in acodels...",logAppend:`
=== acodels @ ${d} ===
`}),Xr())return Xe=!1,!1;let g=await Ks(d);me({percent:82,logAppend:String(g||"").slice(-3e3)+`
`})}if(i.selected.includes("chromium")){qt(!0),Xe=!1,await it({startImmediately:!0});let g=await lt(t);return q("dependenciesInstalled",g.ok),g.ok}let h=await lt(t);return me({progressMode:!0,percent:100,info:h.ok?"Done \u2014 all required present":"Finished \u2014 still missing: "+h.missing.join(", "),showDone:!0,logAppend:h.ok?`
OK
`:`
Missing: `+h.missing.join(", ")+`
`}),q("dependenciesInstalled",h.ok),h.ok&&(ct=!0,Jr("Dependencies ready",2500)),h.ok}catch(d){return me({progressMode:!0,percent:100,info:"Failed",showDone:!0,logAppend:`
ERROR: `+((d==null?void 0:d.message)||d)+`
`}),!1}finally{Xe=!1}}return!1}async function vr(e={}){let t=e.baseUrl||qe||"";qe=t;try{return!e.force&&ct||!e.force&&mr&&A().dependenciesInstalled===!0?!0:(mr=!0,(await lt(t)).ok?(q("dependenciesInstalled",!0),!0):gr({...e,baseUrl:t}))}catch(r){return console.warn("[LiveServer:deps]",r),!1}}async function Ys(e){return gr({force:!0,fromSettings:!0,baseUrl:e||qe})}async function Zs(e){return await Ws("Reinstall dependencies?","Will run pkg/apk install for Node and npm install in acodels.")?(ct=!1,mr=!1,gr({force:!0,fromSettings:!0,baseUrl:e||qe})):!1}function en(){ct=!1,mr=!1}var Jr,Ws,ct,mr,Xe,qe,Dt,Be=T(()=>{ne();nt();uo();at();Jr=acode.require("toast"),Ws=acode.require("confirm"),ct=!1,mr=!1,Xe=!1,qe="",Dt=[{id:"node",label:"node",desc:"Node.js runtime",required:!0},{id:"npm",label:"npm",desc:"Package manager",required:!0},{id:"acodels",label:"acodels modules",desc:"Backend node_modules (express, ws, chokidar)",required:!0},{id:"chromium",label:"chromium (optional)",desc:"Headless browser for heavy JS websites (~180MB)",required:!1,optional:!0}]});var Js,fo,mo=T(()=>{nt();Js=`/**
 * acodels \u2014 Live Server + Local Reverse Proxy Node backend (ls-proxy-v5, ls-bridge-v1)
 */
const http = require('http');
const https = require('https');
const express = require('express');
const path = require('path');
const fs = require('fs');
const net = require('net');
const zlib = require('zlib');
const { URL } = require('url');
const { Server: WebSocketServer } = require('ws');
const chokidar = require('chokidar');
const { execFile, execSync } = require('child_process');

let BASE_DIR = null;
let jsonData = {};
let erudaEnabled = false;
let consoleType = 'suger';
let zoomEnabled = false;
let liveReloadEnabled = true;
let directoryListing = true;
let fileWatcher = null;
let connectedSockets = [];
let customHeaders = {};
let charset = 'utf-8';
let ipWhitelist = [];
let basicAuth = null;
let lastActivity = Date.now();

const args = process.argv.slice(2);
let currentPort = args[0] ? parseInt(args[0], 10) : 8080;
if (!Number.isFinite(currentPort) || currentPort < 1) currentPort = 8080;
const bindHost = args[1] || '0.0.0.0';

function isPortAvailable(port) {
  return new Promise((resolve) => {
    const tester = net
      .createServer()
      .once('error', () => resolve(false))
      .once('listening', () => tester.close(() => resolve(true)))
      .listen(port, bindHost === '0.0.0.0' ? undefined : bindHost);
  });
}

const webSocketScript = \`
<script>
  (function() {
    try {
      var wsUrl = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
      var ws = new WebSocket(wsUrl);
      ws.onmessage = function (event) {
        if (event.data === 'reload') location.reload();
      };
    } catch (e) {}
  })();
<\/script>\`;

const sugerScript = \`<script src="/dt/suger-dev.js"><\/script>\`;
const erudaRealScript = \`
<script src="/eruda.min.js"><\/script>
<script>if (typeof eruda !== 'undefined') eruda.init();<\/script>
\`;
const inspectorScript = \`<script src="/inspector.js"><\/script>\`;

/* ls-bridge-v1: page <-> Acode browser bridge */
const LS_BRIDGE_JS = \`
(function () {
  var P = window.__lsParent || window.parent;
  if (window.__lsBridge || !P || P === window) return;
  window.__lsBridge = 1;
  function post(m) {
    try { m.ls = 1; P.postMessage(m, '*'); } catch (e) {}
  }
  function currentHref() {
    return window.__LS_PROXY_TARGET__ || location.href;
  }
  function fav() {
    var l = document.querySelector('link[rel~="icon"]');
    if (l && l.href) return l.href;
    try { return new URL('/favicon.ico', currentHref()).href; } catch (e) { return ''; }
  }
  function meta() {
    post({ type: 'meta', href: currentHref(), title: document.title || '', favicon: fav() });
  }
  window.__lsPostMeta = meta;
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(meta, 0);
  window.addEventListener('load', meta);
  window.addEventListener('popstate', function () { setTimeout(meta, 0); });
  window.addEventListener('hashchange', function () { setTimeout(meta, 0); });
  try {
    var t = document.querySelector('title');
    if (t) new MutationObserver(meta).observe(t, { childList: true, characterData: true, subtree: true });
  } catch (e) {}

  var dtOn = false;
  function devtools(d) {
    try {
      if (d.on) {
        if (!window.suger) {
          if (!d.code) { post({ type: 'need-devtools' }); return; }
          var s = document.createElement('script');
          s.textContent = d.code;
          (document.head || document.documentElement).appendChild(s);
        }
        if (window.suger) {
          if (!window.__lsDtInit) { window.__lsDtInit = 1; window.suger.init(); }
          else window.suger.show();
          dtOn = true;
        }
      } else if (window.suger) {
        window.suger.hide();
        dtOn = false;
      }
    } catch (e) {
      post({ type: 'devtools-error', message: String(e && e.message || e) });
    }
    post({ type: 'devtools', on: dtOn });
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.ls !== 1 || e.source !== P) return;
    try {
      if (d.cmd === 'history') history.go(d.dir < 0 ? -1 : 1);
      else if (d.cmd === 'reload') location.reload();
      else if (d.cmd === 'stop') window.stop();
      else if (d.cmd === 'zoom') document.documentElement.style.zoom = String((d.pct || 100) / 100);
      else if (d.cmd === 'print') window.print();
      else if (d.cmd === 'find') post({ type: 'found', ok: !!window.find(d.q, false, !!d.back, true, false, false, false) });
      else if (d.cmd === 'devtools') devtools(d);
      else if (d.cmd === 'ping') meta();
    } catch (err) {}
  });
})();
\`;

const lsBridgeScript = '<script src="/__ls/bridge.js"><\/script>';
const zoomScript = \`
<script src="/zoom-handler.js"><\/script>
<script>try { new ZoomHandler(document.body); } catch (e) {}<\/script>\`;

const app = express();

// Capture raw body for /__proxy while still parsing JSON for /setup
app.use((req, res, next) => {
  if (req.path === '/__proxy' || req.path === '/_proxy') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      req.rawBody = chunks.length ? Buffer.concat(chunks) : null;
      next();
    });
    return;
  }
  express.json({ limit: '2mb' })(req, res, next);
});

// Activity + security middleware
app.use((req, res, next) => {
  lastActivity = Date.now();
  if (ipWhitelist.length) {
    const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (!ipWhitelist.includes(ip) && ip !== '127.0.0.1' && ip !== '::1') {
      return res.status(403).send('Forbidden');
    }
  }
  if (basicAuth && basicAuth.user && !req.path.startsWith('/__proxy')) {
    const hdr = req.headers.authorization || '';
    const ok = (() => {
      if (!hdr.startsWith('Basic ')) return false;
      try {
        const decoded = Buffer.from(hdr.slice(6), 'base64').toString('utf8');
        const i = decoded.indexOf(':');
        const u = decoded.slice(0, i);
        const p = decoded.slice(i + 1);
        return u === basicAuth.user && p === (basicAuth.pass || '');
      } catch (_) {
        return false;
      }
    })();
    if (!ok) {
      res.setHeader('WWW-Authenticate', 'Basic realm="Live Server"');
      return res.status(401).send('Unauthorized');
    }
  }
  Object.keys(customHeaders).forEach((k) => {
    try { res.setHeader(k, customHeaders[k]); } catch (_) {}
  });
  next();
});

// CORS
app.use((req, res, next) => {
  if (jsonData.enableCors !== false) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
  }
  next();
});

app.get('/check', (req, res) => {
  res.status(200).json({
    message: 'Ready',
    key: 'AcodeLiveServer_NodeJS',
    port: currentPort,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    proxy: true,
    proxyVersion: 3,
  });
});

app.get('/status', (req, res) => {
  res.json({
    port: currentPort,
    bind: bindHost,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    directoryListing,
    clients: connectedSockets.length,
    lastActivity,
    uptime: process.uptime(),
    proxy: true,
    proxyVersion: 3,
  });
});

app.post('/reload', (req, res) => {
  broadcastReload();
  res.json({ ok: true, clients: connectedSockets.length });
});

app.patch('/setup', (req, res) => {
  const data = req.body || {};
  if (!data.path) return res.status(400).json({ error: 'Missing path' });

  BASE_DIR = data.path;
  jsonData = data;
  erudaEnabled = data.eruda === true;
  if (data.consoleType) consoleType = data.consoleType;
  zoomEnabled = data.zoom === true;
  liveReloadEnabled = data.liveReload !== false;
  directoryListing = data.directoryListing !== false;

  if (typeof data.charset === 'string' && data.charset) charset = data.charset;
  customHeaders = {};
  if (data.customHeaders && typeof data.customHeaders === 'object') {
    customHeaders = data.customHeaders;
  } else if (typeof data.customHeaders === 'string') {
    String(data.customHeaders).split('\\n').forEach((line) => {
      const i = line.indexOf(':');
      if (i > 0) {
        const k = line.slice(0, i).trim();
        const v = line.slice(i + 1).trim();
        if (k) customHeaders[k] = v;
      }
    });
  }

  ipWhitelist = [];
  if (data.ipWhitelist) {
    const raw = Array.isArray(data.ipWhitelist)
      ? data.ipWhitelist
      : String(data.ipWhitelist).split(/[\\n,]+/);
    ipWhitelist = raw.map((s) => String(s).trim()).filter(Boolean);
  }

  if (data.basicAuthUser) {
    basicAuth = { user: String(data.basicAuthUser), pass: String(data.basicAuthPass || '') };
  } else {
    basicAuth = null;
  }

  if (liveReloadEnabled) startFileWatcher(res);
  else {
    if (fileWatcher) {
      try { fileWatcher.close(); } catch (_) {}
      fileWatcher = null;
    }
    res.status(201).json({ message: 'OK', liveReload: false });
  }
});

app.get('/__ls/bridge.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.send(LS_BRIDGE_JS);
});

// ============================================================================
// LOCAL REVERSE PROXY (/__proxy?url=...)
// ============================================================================

function buildProxyRuntimeScript(targetUrl) {
  let origin = '';
  try { origin = new URL(targetUrl).origin; } catch (_) {}
  return \`<script>
(function() {
  window.__LS_PROXY_TARGET__ = \${JSON.stringify(targetUrl)};
  window.__LS_PROXY_ORIGIN__ = \${JSON.stringify(origin)};
  var proxyBase = location.origin + '/__proxy?url=';

  function unwrapUrl(u) {
    var s = String(u || '');
    var idx = s.indexOf('/__proxy?url=');
    if (idx !== -1) {
      try {
        return decodeURIComponent(s.slice(idx + '/__proxy?url='.length).split('&')[0]);
      } catch (e) {}
    }
    return s;
  }

  function wrapUrl(raw) {
    if (!raw || typeof raw !== 'string') return raw;
    var s = raw.trim();
    if (!s || s.charAt(0) === '#' || s.indexOf('data:') === 0 || s.indexOf('blob:') === 0 || s.indexOf('javascript:') === 0 || s.indexOf('mailto:') === 0 || s.indexOf('tel:') === 0) {
      return raw;
    }
    if (s.indexOf('/__proxy?url=') !== -1 || s.indexOf('/__ls/') === 0 || s.indexOf('/dt/') === 0) {
      return raw;
    }
    try {
      var resolved = new URL(s, window.__LS_PROXY_TARGET__);
      if (resolved.protocol === 'http:' || resolved.protocol === 'https:') {
        return proxyBase + encodeURIComponent(resolved.href);
      }
    } catch (e) {}
    return raw;
  }

  // Prevent proxied Service Workers from hijacking 127.0.0.1
  try {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.register = function() {
        return Promise.resolve({ scope: '/' });
      };
    }
  } catch (e) {}

  // Patch history.pushState / replaceState so SPAs don't throw cross-origin SecurityError
  try {
    var origPush = history.pushState;
    var origReplace = history.replaceState;
    history.pushState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origPush.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
    history.replaceState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origReplace.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
  } catch (e) {}

  // Patch fetch
  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function(input, init) {
      if (typeof input === 'string') {
        input = wrapUrl(input);
      } else if (input && typeof input.url === 'string') {
        try {
          input = new Request(wrapUrl(input.url), input);
        } catch (e) {}
      }
      return origFetch.call(this, input, init);
    };
  }

  // Patch XMLHttpRequest
  if (window.XMLHttpRequest) {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
      var args = Array.prototype.slice.call(arguments);
      if (typeof url === 'string') args[1] = wrapUrl(url);
      return origOpen.apply(this, args);
    };
  }

  // Patch dynamic DOM element URL setters (fixes dynamically injected CSS <link> and <script>)
  function patchProp(Proto, prop) {
    if (!Proto) return;
    var desc = Object.getOwnPropertyDescriptor(Proto, prop);
    if (!desc || !desc.set) return;
    Object.defineProperty(Proto, prop, {
      get: desc.get,
      set: function(val) {
        return desc.set.call(this, typeof val === 'string' ? wrapUrl(val) : val);
      },
      configurable: true
    });
  }
  try {
    patchProp(window.HTMLScriptElement && HTMLScriptElement.prototype, 'src');
    patchProp(window.HTMLLinkElement && HTMLLinkElement.prototype, 'href');
    patchProp(window.HTMLImageElement && HTMLImageElement.prototype, 'src');
    patchProp(window.HTMLIFrameElement && HTMLIFrameElement.prototype, 'src');
    var origSetAttr = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function(name, val) {
      var lower = String(name || '').toLowerCase();
      if ((lower === 'src' || lower === 'href' || lower === 'action') && typeof val === 'string') {
        val = wrapUrl(val);
      }
      return origSetAttr.call(this, name, val);
    };
  } catch (e) {}

  // Intercept anchor clicks
  document.addEventListener('click', function(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0 || href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
    e.preventDefault();
    location.href = wrapUrl(href);
  }, true);

  // Helper to submit forms cleanly without losing ?url= on GET forms (fixes Google Search 404)
  function submitProxiedForm(form) {
    var rawAction = form.getAttribute('action') || window.__LS_PROXY_TARGET__;
    var targetAction = unwrapUrl(rawAction);
    try {
      targetAction = new URL(targetAction, window.__LS_PROXY_TARGET__).href;
    } catch (err) {}

    var method = (form.getAttribute('method') || form.method || 'GET').toUpperCase();
    if (method === 'GET') {
      var u = new URL(targetAction);
      var fd = new FormData(form);
      fd.forEach(function(v, k) {
        if (typeof v === 'string') u.searchParams.append(k, v);
      });
      location.href = proxyBase + encodeURIComponent(u.href);
      return true;
    } else {
      origSetAttr.call(form, 'action', proxyBase + encodeURIComponent(targetAction));
      return false;
    }
  }

  document.addEventListener('submit', function(e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    if (submitProxiedForm(form)) {
      e.preventDefault();
    }
  }, true);

  // Also intercept programmatic form.submit() calls (used by Google Search)
  try {
    var origFormSubmit = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function() {
      if (submitProxiedForm(this)) return;
      return origFormSubmit.apply(this, arguments);
    };
  } catch (e) {}

  window.open = function(url) {
    if (url) location.href = wrapUrl(url);
    return window;
  };
})();
<\/script>\`;
}

function rewriteCssForProxy(css, targetUrl) {
  let out = String(css || '');
  // Rewrite url(...)
  out = out.replace(/url\\(\\s*(["']?)([^"')]+)\\1\\s*\\)/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('data:') ||
      s.startsWith('#') ||
      s.startsWith('blob:') ||
      s.includes('/__proxy?url=')
    ) {
      return match;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return 'url(' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote + ')';
      }
    } catch (_) {}
    return match;
  });

  // Rewrite @import "..." or @import '...'
  out = out.replace(/@import\\s+(["'])([^"']+)\\1/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (!s || s.includes('/__proxy?url=')) return match;
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '@import ' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote;
      }
    } catch (_) {}
    return match;
  });

  return out;
}

function rewriteHtmlForProxy(html, targetUrl) {
  const toProxy = (raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('#') ||
      s.startsWith('data:') ||
      s.startsWith('blob:') ||
      s.startsWith('javascript:') ||
      s.startsWith('mailto:') ||
      s.startsWith('tel:') ||
      s.includes('/__proxy?url=')
    ) {
      return raw;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '/__proxy?url=' + encodeURIComponent(parsed.href);
      }
    } catch (_) {}
    return raw;
  };

  // Rewrite href, src, action, poster attributes
  let out = String(html || '').replace(
    /\\b(href|src|action|poster)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      return attr + '=' + quote + toProxy(val) + quote;
    }
  );

  // Rewrite srcset / imagesrcset
  out = out.replace(
    /\\b(srcset|imagesrcset)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      const rewrittenList = val
        .split(',')
        .map((part) => {
          const trimmed = part.trim();
          if (!trimmed) return part;
          const spaceIdx = trimmed.search(/\\s/);
          if (spaceIdx === -1) return toProxy(trimmed);
          const u = trimmed.slice(0, spaceIdx);
          const descriptor = trimmed.slice(spaceIdx);
          return toProxy(u) + descriptor;
        })
        .join(', ');
      return attr + '=' + quote + rewrittenList + quote;
    }
  );

  // Rewrite inline <style> blocks
  out = out.replace(
    /(<style[^>]*>)([\\s\\S]*?)(<\\/style>)/gi,
    (match, openTag, cssBody, closeTag) => openTag + rewriteCssForProxy(cssBody, targetUrl) + closeTag
  );

  // Strip SRI integrity, CSP nonces, and CSP meta tags
  out = out.replace(/\\s+(?:integrity|nonce)\\s*=\\s*(["'])[^"']*\\1/gi, '');
  out = out.replace(/<meta[^>]+http-equiv\\s*=\\s*["']?Content-Security-Policy["']?[^>]*>/gi, '');

  // Rewrite meta refresh redirects
  out = out.replace(
    /(<meta[^>]+http-equiv\\s*=\\s*["']?refresh["']?[^>]+content\\s*=\\s*["'][^"']*?url=)([^"'>]+)(["'][^>]*>)/gi,
    (match, prefix, urlVal, suffix) => prefix + toProxy(urlVal.trim()) + suffix
  );

  const injectedHead = buildProxyRuntimeScript(targetUrl) + lsBridgeScript;

  if (/<head[^>]*>/i.test(out)) {
    out = out.replace(/<head[^>]*>/i, (m) => m + '\\n' + injectedHead);
  } else if (/<html[^>]*>/i.test(out)) {
    out = out.replace(/<html[^>]*>/i, (m) => m + '<head>' + injectedHead + '</head>');
  } else {
    out = injectedHead + '\\n' + out;
  }

  return out;
}

function decompressBuffer(buf, encoding) {
  const enc = String(encoding || '').toLowerCase();
  try {
    if (enc.includes('gzip')) return zlib.gunzipSync(buf);
    if (enc.includes('br') && typeof zlib.brotliDecompressSync === 'function') {
      return zlib.brotliDecompressSync(buf);
    }
    if (enc.includes('deflate')) return zlib.inflateSync(buf);
  } catch (_) {}
  return buf;
}

function fetchUpstream(targetUrl, method, reqHeaders, bodyBuf, redirectsLeft = 6) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(targetUrl);
    } catch (e) {
      return reject(new Error('Invalid target URL'));
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return reject(new Error('Only HTTP/HTTPS URLs are supported'));
    }

    const client = parsed.protocol === 'https:' ? https : http;
    const upperMethod = (method || 'GET').toUpperCase();
    const headers = {
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
      'Accept':
        reqHeaders['accept'] ||
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': reqHeaders['accept-language'] || 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'Referer': parsed.origin + '/',
    };
    if (upperMethod !== 'GET' && upperMethod !== 'HEAD') {
      headers['Origin'] = parsed.origin;
    }
    if (reqHeaders['content-type']) headers['Content-Type'] = reqHeaders['content-type'];
    if (reqHeaders['cookie']) headers['Cookie'] = reqHeaders['cookie'];
    if (bodyBuf && bodyBuf.length) headers['Content-Length'] = bodyBuf.length;

    const upstreamReq = client.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method: upperMethod,
        headers,
        timeout: 20000,
        rejectUnauthorized: false,
      },
      (upstreamRes) => {
        const status = upstreamRes.statusCode || 200;
        const loc = upstreamRes.headers['location'];
        if ([301, 302, 303, 307, 308].includes(status) && loc && redirectsLeft > 0) {
          upstreamRes.resume();
          const nextUrl = new URL(loc, parsed.href).href;
          const nextMethod =
            status === 303 || ((status === 301 || status === 302) && upperMethod === 'POST')
              ? 'GET'
              : upperMethod;
          return resolve(
            fetchUpstream(
              nextUrl,
              nextMethod,
              reqHeaders,
              nextMethod === 'GET' ? null : bodyBuf,
              redirectsLeft - 1
            )
          );
        }

        const chunks = [];
        upstreamRes.on('data', (c) => chunks.push(c));
        upstreamRes.on('end', () => {
          resolve({
            status,
            headers: upstreamRes.headers,
            body: Buffer.concat(chunks),
            finalUrl: parsed.href,
          });
        });
      }
    );

    upstreamReq.on('timeout', () => {
      upstreamReq.destroy(new Error('Upstream request timed out'));
    });
    upstreamReq.on('error', reject);
    if (bodyBuf && bodyBuf.length) upstreamReq.write(bodyBuf);
    upstreamReq.end();
  });
}

async function handleProxyRequest(req, res, targetUrl) {
  try {
    const bodyBuf = req.rawBody || null;
    const result = await fetchUpstream(targetUrl, req.method, req.headers, bodyBuf);

    const blockedHeaders = new Set([
      'x-frame-options',
      'content-security-policy',
      'content-security-policy-report-only',
      'cross-origin-opener-policy',
      'cross-origin-embedder-policy',
      'cross-origin-resource-policy',
      'content-length',
      'content-encoding',
      'transfer-encoding',
      'connection',
    ]);

    Object.entries(result.headers || {}).forEach(([k, v]) => {
      const lower = k.toLowerCase();
      if (blockedHeaders.has(lower)) return;
      if (lower === 'set-cookie' && Array.isArray(v)) {
        const cleanCookies = v.map((c) =>
          String(c)
            .replace(/;\\s*Domain=[^;]+/gi, '')
            .replace(/;\\s*Secure/gi, '')
            .replace(/SameSite=None/gi, 'SameSite=Lax')
        );
        res.setHeader('Set-Cookie', cleanCookies);
        return;
      }
      try {
        res.setHeader(k, v);
      } catch (_) {}
    });

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-LS-Final-Url', result.finalUrl);

    const contentType = String(result.headers['content-type'] || '');
    const rawBuf = decompressBuffer(result.body, result.headers['content-encoding']);

    if (/text\\/html|application\\/xhtml\\+xml/i.test(contentType)) {
      const htmlText = rawBuf.toString('utf8');
      const rewritten = rewriteHtmlForProxy(htmlText, result.finalUrl);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.status(result.status).send(rewritten);
    }

    if (/text\\/css/i.test(contentType)) {
      const cssText = rawBuf.toString('utf8');
      const rewrittenCss = rewriteCssForProxy(cssText, result.finalUrl);
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
      return res.status(result.status).send(rewrittenCss);
    }

    return res.status(result.status).send(rawBuf);
  } catch (err) {
    const safeUrl = String(targetUrl || '').replace(/</g, '<');
    const safeMsg = String((err && err.message) || err).replace(/</g, '<');
    res.status(502).setHeader('Content-Type', 'text/html; charset=utf-8').send(\`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
      <style>
        body { font-family: system-ui, sans-serif; background: #1e1e1e; color: #e8eaed; padding: 28px 18px; text-align: center; }
        .card { max-width: 420px; margin: 24px auto; padding: 20px; border-radius: 8px; background: #292a2d; border: 1px solid #3c4043; }
        h3 { margin: 0 0 8px; color: #f87171; }
        p { font-size: 13px; color: #9aa0a6; word-break: break-all; }
        button { margin-top: 12px; padding: 8px 16px; border: 0; border-radius: 5px; background: #22c55e; color: #052e16; font-weight: 600; cursor: pointer; }
      </style></head>
      <body>
        <div class="card">
          <h3>Proxy Could Not Load Page</h3>
          <p>\${safeMsg}</p>
          <p>\${safeUrl}</p>
          <button onclick="location.reload()">Retry</button>
        </div>
      </body></html>
    \`);
  }
}

function resolveChromiumBin() {
  const candidates = [
    'chromium-browser',
    'chromium',
    'google-chrome',
    'google-chrome-stable',
    '/usr/bin/chromium-browser',
    '/usr/bin/chromium',
    '/usr/lib/chromium/chromium',
    '/usr/bin/google-chrome',
    '/usr/bin/google-chrome-stable',
  ];
  for (const c of candidates) {
    try {
      if (c.startsWith('/')) {
        if (fs.existsSync(c)) return c;
      } else {
        execSync('command -v ' + c, { stdio: 'ignore' });
        return c;
      }
    } catch (_) {}
  }
  return null;
}

function renderWithHeadlessChromium(targetUrl) {
  return new Promise((resolve, reject) => {
    const bin = resolveChromiumBin();
    if (!bin) {
      return reject(new Error('Chromium binary not found in PATH'));
    }
    const args = [
      '--headless=new',
      '--no-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--disable-software-rasterizer',
      '--disable-extensions',
      '--hide-scrollbars',
      '--mute-audio',
      '--user-agent=Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
      '--virtual-time-budget=8000',
      '--timeout=20000',
      '--dump-dom',
      targetUrl,
    ];
    console.log('[acodels] chromium dump-dom bin=' + bin + ' url=' + targetUrl);
    execFile(bin, args, { maxBuffer: 20 * 1024 * 1024, timeout: 30000 }, (err, stdout, stderr) => {
      if (err && !stdout) {
        console.error('[acodels] chromium fail', err && err.message, String(stderr || '').slice(0, 400));
        return reject(err);
      }
      const html = String(stdout || '');
      console.log('[acodels] chromium ok bytes=' + html.length);
      if (html.length < 50) {
        return reject(new Error('Chromium returned empty DOM'));
      }
      resolve(html);
    });
  });
}

app.all(['/__proxy', '/_proxy'], (req, res) => {
  if (req.query.url) {
    const target = String(req.query.url);
    const engine = String(req.query.engine || '');
    console.log('[acodels] proxy request engine=' + (engine || 'node') + ' url=' + target.slice(0, 180));
    if (engine === 'chromium') {
      // Promise form \u2014 avoids "await outside async" parse errors
      renderWithHeadlessChromium(target)
        .then((domHtml) => {
          const rewritten = rewriteHtmlForProxy(domHtml, target);
          res.setHeader('Content-Type', 'text/html; charset=utf-8');
          res.setHeader('X-LS-Engine', 'chromium');
          return res.status(200).send(rewritten);
        })
        .catch((e) => {
          console.error('[acodels] chromium path failed, fallback node-proxy:', e && e.message);
          res.setHeader('X-LS-Engine', 'node-fallback');
          return handleProxyRequest(req, res, target);
        });
      return;
    }
    res.setHeader('X-LS-Engine', 'node');
    return handleProxyRequest(req, res, target);
  }
  // Fallback when a GET form (like Google Search) strips ?url= and submits ?q=... directly to /__proxy
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (idx !== -1) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const u = new URL('/search', baseTarget);
      Object.entries(req.query || {}).forEach(([k, v]) => {
        if (typeof v === 'string') u.searchParams.set(k, v);
      });
      return handleProxyRequest(req, res, u.href);
    } catch (_) {}
  }
  return res.status(400).send('Missing ?url=');
});

// Referer-based fallback for root-relative assets/APIs requested by proxied pages
app.use((req, res, next) => {
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (
    idx !== -1 &&
    !req.path.startsWith('/__ls/') &&
    !req.path.startsWith('/dt/') &&
    req.path !== '/__proxy' &&
    req.path !== '/_proxy'
  ) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const resolved = new URL(req.originalUrl, baseTarget).href;
      return handleProxyRequest(req, res, resolved);
    } catch (_) {}
  }
  next();
});

// ============================================================================
// LOCAL STATIC LIVE SERVER
// ============================================================================

app.get('/dt/suger-dev.js', (req, res) => {
  const p = path.join(__dirname, 'suger-dev.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/zoom-handler.js', (req, res) => {
  const p = path.join(__dirname, 'zoom-handler.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/inspector.js', (req, res) => {
  const p = path.join(__dirname, 'inspector.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/eruda.min.js', (req, res) => {
  const erudaPath = path.join(__dirname, 'eruda.min.js');
  if (fs.existsSync(erudaPath)) res.sendFile(erudaPath);
  else res.status(404).send('Eruda not found');
});

function injectHtml(html) {
  let injected = html;
  if (liveReloadEnabled) {
    injected = injected.replace(/<\\/body>/i, webSocketScript + '</body>');
    if (!/<\\/body>/i.test(html)) injected = injected + webSocketScript;
  }
  if (erudaEnabled) {
    const extra =
      consoleType === 'eruda' ? erudaRealScript + '\\n' + inspectorScript : sugerScript + '\\n' + inspectorScript;
    injected = injected.replace(/<\\/body>/i, extra + '</body>');
  }
  if (zoomEnabled) {
    injected = injected.replace(/<\\/body>/i, zoomScript + '</body>');
  }
  if (/<\\/body>/i.test(injected)) injected = injected.replace(/<\\/body>/i, lsBridgeScript + '</body>');
  else injected += lsBridgeScript;
  return injected;
}

function sendHtmlFile(res, fullPath) {
  fs.readFile(fullPath, 'utf8', (err, html_content) => {
    if (err) return res.status(404).send('Not found');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(injectHtml(html_content));
  });
}

app.get('/', (req, res) => {
  if (!BASE_DIR) return res.status(400).send('Not configured. PATCH /setup first.');
  const fileName = jsonData.fileName || 'index.html';
  const fullPath = path.join(BASE_DIR, fileName);
  if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    return sendHtmlFile(res, fullPath);
  }
  const indexPath = path.join(BASE_DIR, 'index.html');
  if (fs.existsSync(indexPath)) return sendHtmlFile(res, indexPath);
  if (directoryListing) return listDir(res, BASE_DIR, '/');
  return res.status(404).send('No index.html');
});

function listDir(res, dirPath, urlPath) {
  fs.readdir(dirPath, { withFileTypes: true }, (err, entries) => {
    if (err) return res.status(500).send('Cannot list directory');
    const rows = entries
      .filter((e) => !e.name.startsWith('.'))
      .map((e) => {
        const href = path.posix.join(urlPath, e.name) + (e.isDirectory() ? '/' : '');
        return \`<li><a href="\${href}">\${e.name}\${e.isDirectory() ? '/' : ''}</a></li>\`;
      })
      .join('\\n');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(
      \`<!DOCTYPE html><html><head><meta charset="\${charset}"/><title>Index of \${urlPath}</title></head><body><h1>Index of \${urlPath}</h1><ul>\${rows}</ul></body></html>\`
    );
  });
}

app.use((req, res, next) => {
  if (!BASE_DIR) return next();
  const rel = decodeURIComponent(req.path || '/');
  const full = path.join(BASE_DIR, rel);
  if (!full.startsWith(path.resolve(BASE_DIR))) return res.status(403).end();
  fs.stat(full, (err, st) => {
    if (err) return next();
    if (st.isDirectory()) {
      if (directoryListing) return listDir(res, full, rel.endsWith('/') ? rel : rel + '/');
      const idx = path.join(full, 'index.html');
      if (fs.existsSync(idx)) return sendHtmlFile(res, idx);
      return res.status(404).end();
    }
    if (/\\.html?$/i.test(full)) return sendHtmlFile(res, full);
    res.sendFile(full, (e) => {
      if (e) next();
    });
  });
});

app.use(express.static(__dirname));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  connectedSockets.push(ws);
  lastActivity = Date.now();
  ws.on('close', () => {
    connectedSockets = connectedSockets.filter((s) => s !== ws);
  });
});

function broadcastReload() {
  for (const ws of connectedSockets) {
    try {
      ws.send('reload');
    } catch (_) {}
  }
}

function startFileWatcher(res) {
  if (fileWatcher) {
    try { fileWatcher.close(); } catch (_) {}
    fileWatcher = null;
  }
  if (!BASE_DIR || !liveReloadEnabled) {
    if (res) res.status(201).json({ message: 'OK' });
    return;
  }
  fileWatcher = chokidar.watch(BASE_DIR, {
    ignored: /(^|[\\/\\\\])\\.\\./,
    persistent: true,
    ignoreInitial: true,
  });
  fileWatcher.on('change', () => {
    lastActivity = Date.now();
    broadcastReload();
  });
  let responseSent = false;
  const done = (code, body) => {
    if (responseSent || !res) return;
    responseSent = true;
    res.status(code).json(body);
  };
  fileWatcher.on('ready', () => done(201, { message: 'OK', liveReload: true }));
  fileWatcher.on('error', (error) => {
    console.error('Watcher Error:', error.message);
    done(500, { error: error.message });
  });
  setTimeout(() => done(201, { message: 'OK', liveReload: true }), 3000);
}

async function main() {
  const ok = await isPortAvailable(currentPort);
  if (!ok) {
    console.error('[acodels] port busy', currentPort);
    process.exit(1);
  }
  server.listen(currentPort, bindHost, () => {
    console.log('[acodels] listening', bindHost + ':' + currentPort);
  });
}

main();
`,fo=Vr(Js)});async function tn(e){let t=e||"/root/.acode_liveserver/acodels";try{let o=await j("D="+Se(t)+'; if [ ! -f "$D/index.js" ]; then echo NEED; exit 0; fi; if grep -q WebSocket "$D/index.js" 2>/dev/null && grep -q chokidar "$D/index.js" 2>/dev/null && grep -q ls-proxy-v5 "$D/index.js" 2>/dev/null; then echo FULL; else echo NEED; fi',{timeoutMs:8e3});if(String(o).includes("FULL")&&!String(o).includes("NEED"))return!1}catch(o){console.warn("[LiveServer] index check",(o==null?void 0:o.message)||o)}let r=fo,n=["#!/bin/sh","set -e","D="+t.replace(/'/g,""),'mkdir -p "$D"',"echo '"+r+`' | base64 -d > "$D/index.js"`,"echo RESTORED"].join(`
`);try{return await Ve(n,{timeoutMs:0}),!0}catch(o){return console.warn("[LiveServer] restore failed",(o==null?void 0:o.message)||o),!1}}var ho=T(()=>{nt();mo()});function Qs(e){return/\.html?$/i.test(String(e||""))}function Ee(e){return!!(e&&Qs(e.filename||e.name))}function Y(){try{return(editorManager==null?void 0:editorManager.activeFile)||null}catch{return null}}function rn(e){try{return decodeURIComponent(e)}catch{return e}}function go(e){let t=String(e||""),r=t.indexOf(":");if(r<0)return t.startsWith("/")?t:null;let n=t.slice(0,r),o=t.slice(r+1).replace(/^\/+/,""),i=o?"/"+o:"";return n==="primary"?"/sdcard"+i:n==="home"?"/sdcard/Documents"+i:/^[0-9A-F]{4}-[0-9A-F]{4}$/i.test(n)?"/storage/"+n+i:null}function pt(e){if(!e||typeof e!="string")return null;let t=e;if(t.startsWith("content://")){if(t.includes("::")){let n=rn(t.split("::").pop());if(n.startsWith("/"))return n;let o=go(n);if(o)return o}let r=t.indexOf("/document/");if(r>=0){let n=rn(t.slice(r+10).split("?")[0]);if(n.startsWith("/"))return n;let o=go(n);if(o)return o}return null}if(t.startsWith("file://")&&(t=rn(t.replace(/^file:\/\//,""))),t.includes("/data/data/com.termux/files/home"))return t.includes("::")?t.split("::").pop():t;if(t.includes("::")){let r=t.split("::").pop();if(r&&r.startsWith("/"))return r}if(/\/(storage|sdcard|emulated)\//i.test(t)){let r=t.match(/(\/(?:storage|sdcard|emulated)\/[^?#]*)/i);if(r)return r[1]}return t.startsWith("/")?t:null}function nn(e){if(!e)return null;let t=Math.max(e.lastIndexOf("/"),e.lastIndexOf("\\"));return t<=0?e:e.slice(0,t)}var Le=T(()=>{});var ze={};fe(ze,{getServerStatus:()=>D,refreshStatusFromBackend:()=>on,setServerStatus:()=>re});function D(){return{...De}}function re(e){Object.assign(De,e||{});try{window.dispatchEvent(new CustomEvent("liveserver-status",{detail:D()}))}catch{}}async function on(){if(!De.port)return De;try{let e=await fetch(`http://127.0.0.1:${De.port}/status`);if(!e.ok)return re({running:!1,lastError:"status "+e.status}),D();let t=await e.json();re({running:!0,port:t.port||De.port,root:t.root||De.root,fileName:t.fileName||De.fileName})}catch{re({running:!1})}return D()}var De,oe=T(()=>{De={running:!1,port:null,root:null,url:null,fileName:null,bind:null,startedAt:null,lastError:null}});var $t={};fe($t,{getEffectiveRoot:()=>br,pickRootFolder:()=>ri,rootFromSelectedFolder:()=>ni});function br(){let e=A();if(e.rootFolder&&String(e.rootFolder).trim())return String(e.rootFolder).trim();let t=Y(),r=pt((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");return r?nn(r):null}async function ri(){try{let e=A().rootFolder||"",t=Y(),r=nn(pt((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")||"")||"",n=[["active",r?"Use active file folder":"Use active file folder (open a file first)"],["type","Type absolute path\u2026"],["clear","Clear (auto from active HTML)"]];e&&n.unshift(["keep","Keep: "+e]);let o=await ei("Server root folder",n,{hideOnSelect:!0,default:e?"keep":r?"active":"type"});if(o==null)return null;if(o==="keep")return e;if(o==="clear")return q("rootFolder",""),ut("Root: auto (active file folder)",2e3),"";if(o==="active"){if(!r)return ut("Open a file first",2e3),null;q("rootFolder",r),ut("Root: "+r,2500);try{let{getServerStatus:a}=await Promise.resolve().then(()=>(oe(),ze)),{reapplySetup:p,startServer:m}=await Promise.resolve().then(()=>(X(),ee));a().running&&await p()}catch{}return r}let i=await ti("Absolute folder path",e||r||"/data/data/com.termux/files/home","text");if(i==null)return null;let s=String(i).trim();if(!s)return ut("Empty path",1500),null;q("rootFolder",s),ut("Root folder saved",1500);try{let{getServerStatus:a}=await Promise.resolve().then(()=>(oe(),ze)),{reapplySetup:p}=await Promise.resolve().then(()=>(X(),ee));a().running&&await p()}catch{}return s}catch(e){return ut("Could not set root: "+((e==null?void 0:e.message)||e),2500),null}}function ni(){var e,t,r;try{let n=((e=window.fileBrowser)==null?void 0:e.selectedFolder)||((r=(t=window.addedFolder)==null?void 0:t[0])==null?void 0:r.url)||null;if(n)return pt(n)||n}catch{}return null}var ut,ei,ti,ft=T(()=>{ne();Le();ut=acode.require("toast"),ei=acode.require("select"),ti=acode.require("prompt")});function mt(){let e=parseInt(A().port,10);return Number.isFinite(e)&&e>0?e:8080}function jt(e,t){return`http://${t==="0.0.0.0"?"127.0.0.1":t||"127.0.0.1"}:${e}/`}var vo=T(()=>{ne()});function bo(){if(document.getElementById("ls-status-pill-css"))return;let e=document.createElement("style");e.id="ls-status-pill-css",e.textContent=`
    #ls-status-pill {
      position: fixed;
      left: 8px;
      bottom: 8px;
      z-index: 100001;
      max-width: min(82vw, 440px);
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 5px 10px;
      border-radius: 4px;
      background: var(--secondary-color, rgba(28, 30, 34, 0.94));
      color: var(--primary-text-color, var(--color, #e8eaed));
      border: 1px solid var(--border-color, rgba(255, 255, 255, 0.12));
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.45), 0 1px 3px rgba(0, 0, 0, 0.3);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 11px;
      line-height: 1.3;
      pointer-events: none;
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #ls-status-pill.is-visible {
      opacity: 0.96;
      transform: translateY(0);
    }
    .ls-sp-dot {
      width: 7px;
      height: 7px;
      min-width: 7px;
      border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 6px rgba(34, 197, 94, 0.9);
    }
    .ls-sp-dot.is-spin {
      animation: ls-sp-pulse 0.9s ease-in-out infinite alternate;
    }
    @keyframes ls-sp-pulse {
      from { opacity: 0.4; transform: scale(0.85); }
      to { opacity: 1; transform: scale(1.15); }
    }
    .ls-sp-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Global top green progress bar (shown when installing in background) */
    #ls-global-green-loader {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      z-index: 100002;
      overflow: hidden;
      pointer-events: none;
      display: none;
      background: rgba(34, 197, 94, 0.15);
    }
    #ls-global-green-loader.is-active {
      display: block;
    }
    #ls-global-green-loader::before {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      width: 35%;
      background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
      box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
      animation: ls-green-slide 1.15s ease-in-out infinite;
    }
    @keyframes ls-green-slide {
      0% { left: -35%; }
      100% { left: 100%; }
    }
  `,document.head.appendChild(e)}function oi(){return bo(),(!se||!se.isConnected)&&(se=document.createElement("div"),se.id="ls-status-pill",gt=document.createElement("span"),gt.className="ls-sp-dot",ht=document.createElement("span"),ht.className="ls-sp-text",se.append(gt,ht),document.body.appendChild(se)),se}function Ce(e,t={}){bo();let r=!!e,o=!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")||t.force===!0;if(document.body.classList.toggle("ls-green-loading",r&&o),document.querySelectorAll(".ls-browser-shell").forEach(i=>{i.classList.toggle("is-installing",r)}),!o){de&&de.classList.remove("is-active");return}(!de||!de.isConnected)&&(de=document.createElement("div"),de.id="ls-global-green-loader",document.body.appendChild(de)),de.classList.toggle("is-active",r)}function he(e,t={}){if(!!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")&&t.force!==!0){Ft(0);return}clearTimeout(Nt);let n=oi();ht&&(ht.textContent=String(e||"")),gt&&gt.classList.toggle("is-spin",t.spin!==!1),requestAnimationFrame(()=>{n.classList.add("is-visible")}),t.autoHideMs&&t.autoHideMs>0&&(Nt=setTimeout(()=>{Ft(0)},t.autoHideMs))}function Ft(e=0){clearTimeout(Nt);let t=()=>{se&&se.classList.remove("is-visible")};e>0?Nt=setTimeout(t,e):t()}function xo(){clearTimeout(Nt),Ce(!1);try{se==null||se.remove(),de==null||de.remove()}catch{}se=null,ht=null,gt=null,de=null}var se,ht,gt,de,Nt,xr=T(()=>{se=null,ht=null,gt=null,de=null,Nt=null});function R(e,t=18,r=2){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${r}" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var P,Ut=T(()=>{P={back:"M19 12H5M12 19l-7-7 7-7",forward:"M5 12h14M12 5l7 7-7 7",reload:"M21 2v6h-6M3 12a9 9 0 0115-6.7L21 8M3 22v-6h6M21 12a9 9 0 01-15 6.7L3 16",close:"M18 6L6 18M6 6l12 12",plus:"M12 5v14M5 12h14",home:"M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2zM9 22V12h6v10",star:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",lock:"M5 11h14a2 2 0 012 2v7a2 2 0 01-2 2H5a2 2 0 01-2-2v-7a2 2 0 012-2zM7 11V7a5 5 0 0110 0v4",info:"M12 2a10 10 0 100 20 10 10 0 000-20zM12 16v-4M12 8h.01",device:"M7 2h10a2 2 0 012 2v16a2 2 0 01-2 2H7a2 2 0 01-2-2V4a2 2 0 012-2zM12 18h.01",rotate:"M21 12a9 9 0 11-9-9c2.5 0 4.7 1 6.3 2.7L21 8M21 3v5h-5",dots:"M12 5h.01M12 12h.01M12 19h.01",maximize:"M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3",drop:"M12 2.69l5.66 5.66a8 8 0 11-11.31 0z",down:"M6 9l6 6 6-6",up:"M18 15l-6-6-6 6",search:"M11 3a8 8 0 100 16 8 8 0 000-16zM21 21l-4.35-4.35",globe:"M12 2a10 10 0 100 20 10 10 0 000-20zM2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20",minus:"M5 12h14"}});function si(e){let t=String(e||"").trim().match(/^#([0-9a-f]{3,8})$/i),r,n,o;if(t){let i=t[1];i.length===3&&(i=i.split("").map(s=>s+s).join("")),r=parseInt(i.slice(0,2),16),n=parseInt(i.slice(2,4),16),o=parseInt(i.slice(4,6),16)}else{if(t=String(e||"").match(/rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i),!t)return null;r=+t[1],n=+t[2],o=+t[3]}return(.299*r+.587*n+.114*o)/255}function yo(){try{let e=getComputedStyle(document.documentElement),t=e.getPropertyValue("--primary-color")||e.getPropertyValue("--secondary-color"),r=si(t);if(r!=null)return r>.6?"light":"dark"}catch{}return"dark"}var wo=T(()=>{});function ko(){let e=document.getElementById("ls-browser-styles");e&&e.remove();let t=document.createElement("style");t.id="ls-browser-styles",t.textContent=sn,document.head.appendChild(t)}var sn,So=T(()=>{sn=`
:host { display: block; position: relative; height: 100%; width: 100%; }
.ls-browser-shell {
  --ls-frame: #202124; --ls-toolbar: #35363a; --ls-omni: #202124; --ls-text: #e8eaed; --ls-sub: #9aa0a6;
  --ls-hover: rgba(255,255,255,.10); --ls-press: rgba(255,255,255,.16); --ls-line: #3c4043; --ls-accent: #8ab4f8;
  --ls-menu: #292a2d; --ls-stage: #1b1c1e; --ls-active-tab-text: #e8eaed;
  position: absolute; inset: 0; z-index: 1;
  display: flex; flex-direction: column; box-sizing: border-box;
  background: var(--ls-frame); color: var(--ls-text);
  font: 13px/1.3 Roboto, "Noto Sans", "Segoe UI", system-ui, sans-serif;
}
.ls-browser-shell[data-theme="light"] {
  --ls-frame: #dee1e6; --ls-toolbar: #ffffff; --ls-omni: #f1f3f4; --ls-text: #202124; --ls-sub: #5f6368;
  --ls-hover: rgba(0,0,0,.08); --ls-press: rgba(0,0,0,.14); --ls-line: #dadce0; --ls-accent: #1a73e8;
  --ls-menu: #ffffff; --ls-stage: #e8eaed; --ls-active-tab-text: #202124;
}
.ls-browser-shell *, .ls-browser-shell *::before, .ls-browser-shell *::after { box-sizing: border-box; }
.ls-browser-shell button { font: inherit; color: inherit; }
.ls-browser-shell.is-fullscreen { position: fixed; inset: 0; z-index: 99990; }

/* ---- chrome (tab strip + toolbar) */
.ls-chrome { flex-shrink: 0; display: flex; flex-direction: column; background: var(--ls-frame); }
.ls-tabstrip { display: flex; align-items: flex-end; height: 38px; padding: 6px 6px 0 6px; gap: 2px; }
.ls-browser-tabs { display: flex; flex: 0 1 auto; min-width: 0; overflow: hidden; align-items: flex-end; }
.ls-tab {
  position: relative; display: flex; align-items: center; gap: 6px; flex: 0 1 200px; min-width: 36px; max-width: 220px;
  height: 32px; padding: 0 6px 0 10px; border-radius: 3px 3px 0 0; color: var(--ls-sub); cursor: default; user-select: none;
}
.ls-tab:hover { background: var(--ls-hover); }
.ls-tab.is-active { background: var(--ls-toolbar); color: var(--ls-active-tab-text); }
.ls-tab:not(.is-active)::after { content: ""; position: absolute; right: -1px; top: 8px; height: 16px; width: 1px; background: var(--ls-line); }
.ls-tab:hover::after, .ls-tab.is-active::after, .ls-tab:has(+ .ls-tab.is-active)::after { display: none; }
.ls-fav { width: 16px; height: 16px; flex: none; display: inline-flex; align-items: center; justify-content: center; }
.ls-fav img { width: 16px; height: 16px; }
.ls-fav.is-spin { border: 2px solid var(--ls-line); border-top-color: var(--ls-accent); border-radius: 50%; animation: ls-spin .8s linear infinite; }
.ls-tab-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ls-tab-x { width: 18px; height: 18px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; }
.ls-tab-x:hover { background: var(--ls-press); }
.ls-tabstrip .ls-spacer { flex: 1; }
.ls-win { display: flex; align-items: center; align-self: center; gap: 2px; }
.ls-ib {
  width: 32px; height: 32px; flex: none; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub);
  display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
}
.ls-ib:hover { background: var(--ls-hover); }
.ls-ib:active { background: var(--ls-press); }
.ls-ib:disabled { opacity: .4; pointer-events: none; }
.ls-ib.is-on { color: var(--ls-accent); }
.ls-ib.is-on svg { fill: var(--ls-accent); }
.ls-ib.ls-tab-new { width: 28px; height: 28px; margin-left: 2px; align-self: center; }
.ls-ib.ls-win-btn { width: 26px; height: 26px; }

.ls-toolbar { position: relative; display: flex; align-items: center; gap: 2px; height: 40px; padding: 0 6px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); }
.ls-omni { flex: 1; min-width: 0; height: 30px; margin: 0 6px; display: flex; align-items: center; gap: 2px; padding: 0 2px 0 4px; border-radius: 3px; background: var(--ls-omni); }
.ls-omni:focus-within { box-shadow: inset 0 0 0 2px var(--ls-accent); }
.ls-site { width: 24px; height: 24px; flex: none; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; padding: 0; }
.ls-site:hover { background: var(--ls-hover); }
.ls-browser-url { flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent; color: var(--ls-text); font: inherit; font-size: 14px; padding: 0 4px; }
.ls-browser-url::placeholder { color: var(--ls-sub); }
.ls-omni .ls-ib { width: 26px; height: 26px; }
.ls-browser-shell.no-url .ls-omni { visibility: hidden; }
.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }
@keyframes ls-bar { 0% { left: -30%; } 100% { left: 100%; } }
@keyframes ls-spin { to { transform: rotate(360deg); } }

/* ---- external site fallback banner */
.ls-ext-bar {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 5px 10px; background: var(--ls-menu); border-bottom: 1px solid var(--ls-line);
  font-size: 12px; color: var(--ls-sub);
}
.ls-ext-bar[hidden] { display: none; }
.ls-ext-open {
  border: 0; border-radius: 3px; padding: 4px 10px; background: #22c55e;
  color: #052e16; font-weight: 600; font-size: 11.5px; cursor: pointer; white-space: nowrap;
}

/* ---- device toolbar */
.ls-devbar { display: flex; align-items: center; gap: 6px; min-height: 34px; padding: 3px 8px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); overflow-x: auto; scrollbar-width: none; }
.ls-devbar[hidden] { display: none; }
.ls-devbar::-webkit-scrollbar { height: 0; }
.ls-dev-btn { display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 8px; border: 1px solid var(--ls-line); border-radius: 3px; background: transparent; white-space: nowrap; cursor: pointer; }
.ls-dev-btn:hover { background: var(--ls-hover); }
.ls-dev-num { width: 58px; height: 26px; padding: 0 6px; border: 1px solid var(--ls-line); border-radius: 3px; background: var(--ls-omni); color: var(--ls-text); font: inherit; text-align: center; outline: 0; -moz-appearance: textfield; }
.ls-dev-num:focus { border-color: var(--ls-accent); }
.ls-dev-num::-webkit-outer-spin-button, .ls-dev-num::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ls-dev-x { color: var(--ls-sub); }
.ls-dev-spacer { flex: 1; }
.ls-dev-icon { width: 26px; height: 26px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; }
.ls-dev-icon:hover { background: var(--ls-hover); }

/* ---- stage (page area) */
.ls-stage { position: relative; flex: 1; min-height: 0; overflow: hidden; background: #fff; }
.ls-browser-shell.is-device .ls-stage { overflow: auto; display: flex; padding: 12px; background: var(--ls-stage); }
.ls-box { position: relative; width: 100%; height: 100%; }
.ls-browser-shell.is-device .ls-box { flex: none; margin: auto; background: #fff; box-shadow: 0 0 0 1px var(--ls-line), 0 2px 12px rgba(0,0,0,.35); }
.ls-device { position: relative; width: 100%; height: 100%; transform-origin: 0 0; }
.ls-browser-frame { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; background: #fff; }
.ls-hdl { display: none; position: absolute; z-index: 3; background: transparent; touch-action: none; }
.ls-browser-shell.is-device .ls-hdl { display: block; }
.ls-hdl-r { top: 0; bottom: 0; right: -12px; width: 12px; cursor: ew-resize; }
.ls-hdl-b { left: 0; right: 0; bottom: -12px; height: 12px; cursor: ns-resize; }
.ls-hdl-c { right: -12px; bottom: -12px; width: 12px; height: 12px; cursor: nwse-resize; }
.ls-hdl::after { content: ""; position: absolute; background: var(--ls-sub); border-radius: 3px; opacity: .8; }
.ls-hdl-r::after { top: calc(50% - 14px); left: 4px; width: 4px; height: 28px; }
.ls-hdl-b::after { left: calc(50% - 14px); top: 4px; height: 4px; width: 28px; }
.ls-hdl-c::after { left: 4px; top: 4px; width: 4px; height: 4px; border-radius: 50%; }

/* ---- new tab page (Mozilla Firefox style: large Green Fox top-center + search bar + round bookmarks + recent) */
.ls-ntp {
  position: absolute; inset: 0; z-index: 2; display: none; flex-direction: column;
  align-items: center; justify-content: flex-start; gap: 20px; padding: 26px 16px 28px;
  overflow-y: auto; background: var(--ls-toolbar); color: var(--ls-text);
}
.ls-ntp.is-on { display: flex; }
.ls-ntp-hero {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 10px; margin-top: 6px;
}
.ls-ntp-logo {
  width: 92px; height: 92px; object-fit: contain; display: block;
  filter: drop-shadow(0 6px 16px rgba(34, 197, 94, 0.25));
}
.ls-ntp-title {
  font-size: 22px; font-weight: 600; letter-spacing: .3px;
}
.ls-ntp-search {
  width: min(480px, 95%); height: 44px; border-radius: 8px;
  background: var(--ls-omni); border: 1px solid var(--ls-line);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
  display: flex; align-items: center; gap: 8px; padding: 0 6px 0 12px; color: var(--ls-sub);
}
.ls-ntp-search:focus-within {
  border-color: #22c55e;
  box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.28);
}
.ls-ntp-search-ico {
  display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ls-ntp-search input {
  flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent;
  color: var(--ls-text); font: inherit; font-size: 14px;
}
.ls-ntp-search-btn {
  height: 32px; padding: 0 14px; border: 0; border-radius: 6px;
  background: #22c55e; color: #052e16; font-weight: 600; font-size: 12.5px;
  cursor: pointer; flex-shrink: 0;
}
.ls-ntp-search-btn:active { opacity: 0.85; }
.ls-ntp-tiles {
  display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;
  width: min(480px, 100%);
}
.ls-ntp-tile {
  width: 78px; display: flex; flex-direction: column; align-items: center; gap: 6px;
  padding: 8px 4px; border: 0; border-radius: 6px; background: transparent; cursor: pointer;
}
.ls-ntp-tile:hover { background: var(--ls-hover); }
.ls-ntp-dot {
  width: 48px; height: 48px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); color: var(--ls-text);
  display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600;
  overflow: hidden; flex-shrink: 0;
}
.ls-ntp-dot img { width: 24px; height: 24px; border-radius: 50%; object-fit: contain; }
.ls-ntp-name {
  max-width: 74px; font-size: 11.5px; overflow: hidden; text-overflow: ellipsis;
  white-space: nowrap; color: var(--ls-text);
}
.ls-ntp-recent-wrap {
  width: min(480px, 100%); display: flex; flex-direction: column; gap: 6px;
  border-top: 1px solid var(--ls-line); padding-top: 12px;
}
.ls-ntp-sec-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 4px 4px; font-size: 12px; font-weight: 600; color: var(--ls-sub);
}
.ls-ntp-more {
  border: 0; background: transparent; color: #22c55e; font-size: 12px;
  font-weight: 600; cursor: pointer; padding: 2px 6px; border-radius: 3px;
}
.ls-ntp-more:hover { background: var(--ls-hover); }
.ls-ntp-recent-list { display: flex; flex-direction: column; gap: 2px; }
.ls-ntp-recent-row {
  display: flex; align-items: center; gap: 10px; width: 100%; text-align: left;
  padding: 8px 8px; border: 0; border-radius: 4px; background: transparent; cursor: pointer;
}
.ls-ntp-recent-row:hover { background: var(--ls-hover); }
.ls-ntp-recent-ico {
  width: 28px; height: 28px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); display: inline-flex; align-items: center;
  justify-content: center; font-size: 12px; font-weight: 600; flex-shrink: 0;
}
.ls-ntp-recent-meta { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.ls-ntp-recent-title {
  font-size: 13px; color: var(--ls-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-recent-url {
  font-size: 11px; color: var(--ls-sub); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-empty { font-size: 12px; color: var(--ls-sub); padding: 8px 4px; }

/* ---- find bar */
.ls-find { position: absolute; top: 80px; right: 10px; z-index: 40; display: flex; align-items: center; gap: 2px; padding: 4px 6px; background: var(--ls-menu); border: 1px solid var(--ls-line); border-radius: 3px; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
.ls-find[hidden] { display: none; }
.ls-find input { width: 150px; height: 26px; border: 0; border-bottom: 2px solid var(--ls-accent); background: transparent; color: var(--ls-text); outline: 0; font: inherit; padding: 0 4px; }
.ls-find .ls-ib { width: 26px; height: 26px; }

/* ---- overlay preview (page see-through, editor underneath stays usable) */
.ls-browser-shell.is-overlay { pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-tabstrip { display: none; }
.ls-ov-close { display: none !important; }
.ls-browser-shell.is-overlay .ls-ov-close { display: inline-flex !important; }
.ls-browser-shell.is-overlay .ls-chrome { pointer-events: auto; }
.ls-browser-shell.is-overlay .ls-stage { opacity: var(--ls-op, 1); pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-stage * { pointer-events: none; }
.ls-browser-shell.is-overlay .ls-dd-layer, .ls-browser-shell.is-overlay .ls-find { pointer-events: auto; }

/* ---- dropdown menu (desktop style) */
.ls-dd-layer { position: absolute; inset: 0; z-index: 60; }
.ls-dd-backdrop { position: absolute; inset: 0; background: transparent; }
.ls-dd-menu {
  position: absolute; min-width: 220px; max-width: calc(100% - 8px); padding: 6px 0;
  background: var(--ls-menu, #292a2d); color: var(--ls-text, #e8eaed);
  border: 1px solid var(--ls-line, #3c4043); border-radius: 3px;
  box-shadow: 0 4px 16px rgba(0,0,0,.4); font-size: 13px; overflow: auto;
}
.ls-dd-item { display: flex; align-items: center; gap: 8px; min-height: 32px; padding: 6px 14px 6px 8px; cursor: pointer; white-space: nowrap; user-select: none; }
.ls-dd-item:hover, .ls-dd-item.is-active { background: var(--ls-hover, rgba(128,128,128,.22)); }
.ls-dd-item.is-disabled { opacity: .45; pointer-events: none; }
.ls-dd-check { width: 14px; height: 14px; display: inline-flex; flex-shrink: 0; }
.ls-dd-label { flex: 1; }
.ls-dd-arrow { opacity: .7; display: inline-flex; }
.ls-dd-sep { height: 1px; margin: 6px 0; background: var(--ls-line, rgba(128,128,128,.3)); }
.ls-dd-custom { padding: 2px 8px 2px 22px; }
.ls-zoomrow { display: flex; align-items: center; gap: 4px; min-height: 32px; }
.ls-zoomrow .ls-zl { flex: 1; }
.ls-zoomrow .ls-zv { min-width: 44px; text-align: center; }
.ls-zoomrow .ls-ib { width: 26px; height: 26px; color: var(--ls-text); }

/* ---- opacity panel */
.ls-dd-panel { width: 250px; padding: 12px 14px; }
.ls-op-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.ls-op-val { color: var(--ls-accent); font-variant-numeric: tabular-nums; }
.ls-range { -webkit-appearance: none; appearance: none; width: 100%; height: 18px; margin: 0; background: transparent; outline: 0; }
.ls-range::-webkit-slider-runnable-track { height: 4px; border-radius: 3px; background: linear-gradient(to right, var(--ls-accent) var(--ls-fill, 100%), var(--ls-line) var(--ls-fill, 100%)); }
.ls-range::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; margin-top: -6px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-range::-moz-range-track { height: 4px; border-radius: 3px; background: var(--ls-line); }
.ls-range::-moz-range-progress { height: 4px; border-radius: 3px; background: var(--ls-accent); }
.ls-range::-moz-range-thumb { width: 16px; height: 16px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-op-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 12px; cursor: pointer; }
.ls-op-row.is-disabled { opacity: .45; pointer-events: none; }
.ls-op-hint { margin-top: 8px; font-size: 11px; color: var(--ls-sub); }
.ls-switch { position: relative; flex: none; width: 36px; height: 20px; }
.ls-switch::before { content: ""; position: absolute; inset: 0; border-radius: 3px; background: var(--ls-line); transition: background .15s; }
.ls-switch::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 3px; background: var(--ls-text); transition: transform .15s; }
.ls-switch.is-on::before { background: var(--ls-accent); }
.ls-switch.is-on::after { transform: translateX(16px); background: #fff; }

 #ls-deps-picker{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center}
.ls-dp-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.45)}
.ls-dp-card{position:relative;width:min(420px,92vw);max-height:min(72vh,540px);display:flex;flex-direction:column;border-radius:3px;background:var(--secondary-color,#1e1e1e);color:var(--color,#e0e0e0);overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4)}
.ls-dp-header{padding:12px 14px 8px;border-bottom:1px solid rgba(128,128,128,.25)}
.ls-dp-title{font-weight:600}
.ls-dp-subtitle{font-size:.75rem;opacity:.75;margin-top:4px}
.ls-dp-body{flex:1;overflow:auto;padding:8px 12px}
.ls-dp-row{display:flex;align-items:center;gap:10px;padding:8px 6px;border-radius:3px;margin-bottom:4px;background:rgba(128,128,128,.08)}
.ls-dp-status.ok{color:#66bb6a}.ls-dp-status.miss{color:#f48771}
.ls-dp-footer{display:flex;gap:8px;justify-content:flex-end;padding:10px 12px;border-top:1px solid rgba(128,128,128,.25)}
.ls-dp-btn{border:none;border-radius:3px;padding:8px 12px;background:rgba(128,128,128,.2);color:inherit}
.ls-dp-btn.ls-dp-install{background:var(--active-color,#61afef);color:#111;font-weight:600}
.ls-dp-progress-track{height:3px;border-radius:3px;background:rgba(128,128,128,.25);overflow:hidden}
.ls-dp-progress-bar{height:100%;background:var(--active-color,#61afef);transition:width .25s}
.ls-dp-spinner{width:16px;height:16px;border-radius:50%;border:2px solid rgba(128,128,128,.35);border-top-color:var(--active-color,#61afef);animation:ls-spin .7s linear infinite}
@keyframes ls-spin{to{transform:rotate(360deg)}}



.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }

.ls-green-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 3px; overflow: hidden; display: none; background: rgba(34, 197, 94, 0.16); }
.ls-browser-shell.is-installing .ls-green-progress { display: block; }
.ls-green-progress::before {
  content: ""; position: absolute; top: 0; bottom: 0; width: 35%;
  background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
  box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
  animation: ls-bar 1.1s ease-in-out infinite;
}
`});function Lo(e){Eo=e?String(e).endsWith("/")?String(e):e+"/":""}function Co(){return Eo}var Eo,an=T(()=>{Eo=""});async function _o(){if(yr)return yr;let e=Co()+ii;try{let r=await acode.require("fsOperation")(e).readFile("utf8");if(r&&r.length>1e3)return yr=String(r)}catch(t){console.warn("[LiveServer] devtool via fsOperation",t)}try{let t=await fetch(e);if(t.ok){let r=await t.text();if(r.length>1e3)return yr=r}}catch(t){console.warn("[LiveServer] devtool via fetch",t)}return null}var ii,yr,Ao=T(()=>{an();ii="devtool/suger-dev.js",yr=null});var Io={};fe(Io,{activateTab:()=>St,addTab:()=>kt,applyZoom:()=>mn,canGoBack:()=>dn,canGoForward:()=>pn,clearVisited:()=>cn,closeAllTabs:()=>xn,closeTab:()=>Wt,disposeBridge:()=>vn,duplicateActive:()=>bn,findInActive:()=>wn,getActiveTab:()=>B,getTabs:()=>bt,getVisited:()=>Sr,historyActive:()=>Lr,initBridge:()=>gn,isLocalUrl:()=>Ye,navigateActive:()=>je,normalizeUrl:()=>yt,onTabsChange:()=>un,printActive:()=>kn,reloadActive:()=>Er,renderTabStrip:()=>Ln,sendToTab:()=>Ae,setZoomActive:()=>En,stopActive:()=>yn,toDisplayUrl:()=>xt,toggleDevtoolsActive:()=>Sn});function bt(){return Z.slice()}function B(){return Z.find(e=>e.id===_e)||null}function Sr(){return Ke.slice()}function cn(){Ke=[],J()}function dn(){let e=B();return!!(e&&e.historyIndex>0)}function pn(){let e=B();return!!(e&&e.historyIndex<e.history.length-1)}function un(e){return wr.push(e),()=>{wr=wr.filter(t=>t!==e)}}function J(){wr.forEach(e=>{try{e(bt(),B())}catch{}})}function fn(e,t){let r=xt(e);!r||r==="about:blank"||r.startsWith("blob:")||(Ke=Ke.filter(n=>n.url!==r),Ke.unshift({url:r,title:t||r.replace(/^https?:\/\//i,""),ts:Date.now()}),Ke.length>50&&(Ke.length=50))}function Ye(e){let t=xt(e);return/^https?:\/\/(127\.0\.0\.1|localhost|0\.0\.0\.0|192\.168\.|10\.)/i.test(String(t||""))}function xt(e){let t=String(e||"").trim();if(!t)return"about:blank";let r="/__proxy?url=",n=t.indexOf(r);if(n!==-1)try{let o=t.slice(n+r.length).split("&")[0];return decodeURIComponent(o)}catch{}return t}function yt(e){let t=xt(e);if(!t||t==="about:blank")return"about:blank";if(/^(about:|blob:|data:|https?:\/\/)/i.test(t))return t;if(/^(localhost|127\.0\.0\.1|0\.0\.0\.0|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(t))return"http://"+t;if(!/\s/.test(t)&&/^[a-z0-9-]+(\.[a-z0-9-]+)+([/?#].*)?$/i.test(t))return"https://"+t;let r=A().browserSearchEngine||"google",n=encodeURIComponent(t);return r==="duckduckgo"?`https://duckduckgo.com/?q=${n}`:r==="bing"?`https://www.bing.com/search?q=${n}`:r==="brave"?`https://search.brave.com/search?q=${n}`:`https://www.google.com/search?q=${n}`}async function ci(e,t={}){if(!e||e==="about:blank"||e.startsWith("blob:"))return e||"about:blank";if(Ye(e))return e;let r=A().externalSiteMode||"proxy";if(r==="proxy"||r==="chromium"){let n=D(),o=n.running&&n.port?n.port:await _n();if(o){let i=r==="chromium"||!!t.useChromium,s=i?"&engine=chromium":"",a=`http://127.0.0.1:${o}/__proxy?url=${encodeURIComponent(e)}${s}`;try{console.log("[LiveServer] external frame",{mode:r,chromium:i,url:e,frame:a.slice(0,160)})}catch{}return a}}return e}function $e(){kr&&(clearTimeout(kr),kr=null)}function Mo(e,t,r){$e(),!(!e||!t||t==="about:blank"||Ye(t))&&(kr=setTimeout(async()=>{if(!e.loading||e.id!==_e)return;if(A().chromiumInstalled===!0||await hr()){r||(he("Switching slow page to Chromium renderer...",{spin:!0,autoHideMs:3500}),vt(e,t,{pushHistory:!1,useChromium:!0}));return}To||Yr()||it({url:t,onInstalled:()=>{vt(e,t,{pushHistory:!1,useChromium:!0})},onDismiss:()=>{To=!0}})},ai))}function Ae(e,t,r){try{return e.iframe.contentWindow.postMessage({ls:1,cmd:t,...r||{}},"*"),!0}catch{return!1}}function wt(e){var t;try{let r=(t=e.iframe)==null?void 0:t.contentWindow;return r.document,r}catch{return null}}function mn(e){let t=wt(e);if(t)try{t.document.documentElement.style.zoom=String((e.zoom||100)/100);return}catch{}Ae(e,"zoom",{pct:e.zoom||100})}function di(e){return Z.find(t=>{try{return t.iframe.contentWindow===e}catch{return!1}})}function hn(e,t){!e||!t||e.history[e.historyIndex]===t||(e.history=e.history.slice(0,e.historyIndex+1),e.history.push(t),e.historyIndex=e.history.length-1)}function Ro(e){let t=e.data;if(!t||t.ls!==1)return;let r=di(e.source);if(r)if(r.bridge=!0,t.type==="meta"){if($e(),r.loading=!1,t.href&&t.href!=="about:blank"){let n=xt(t.href);n!==r.url&&(r.url=n,hn(r,n))}r.pinTitle||(r.title=String(t.title||r.url.replace(/^https?:\/\//,"")).slice(0,60)),t.favicon&&(r.favicon=t.favicon),(r.zoom||100)!==100&&Ae(r,"zoom",{pct:r.zoom}),fn(r.url,r.title),J()}else t.type==="devtools"?(r.devtools=!!t.on,J()):t.type==="need-devtools"?_o().then(n=>{if(!n)return Po("Suger DevTool file missing (devtool/suger-dev.js). Reinstall the plugin.",3500);Ae(r,"devtools",{on:!0,code:n})}):t.type==="devtools-error"&&Po("DevTool: "+t.message,3e3)}function gn(){window.addEventListener("message",Ro)}function vn(){$e(),window.removeEventListener("message",Ro)}function ln(e,t){!String(t||"").includes("/__proxy?url=")&&(Ye(t)||t==="about:blank"||t.startsWith("blob:"))?e.setAttribute("sandbox","allow-scripts allow-same-origin allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-downloads"):e.removeAttribute("sandbox")}async function vt(e,t,r={}){$e();let n=A().externalSiteMode||"proxy";e.useChromium=n==="chromium"||!!r.useChromium;let o=yt(t);if(r.pushHistory!==!1&&hn(e,o),e.url=o,e.devtools=!1,e.useChromium=!!r.useChromium,o==="about:blank"){e.loading=!1,e.title="New tab",e.favicon=null,ln(e.iframe,"about:blank"),e.iframe.src="about:blank",J();return}e.loading=!0,e.pinTitle||(e.title=o.replace(/^https?:\/\//i,"")),J(),Mo(e,o,e.useChromium);let i=await ci(o,{useChromium:e.useChromium});ln(e.iframe,i),e.iframe.src=i,fn(o,e.title),J()}function kt(e,t,r){let n=li++,o=document.createElement("iframe");o.className="ls-browser-frame",o.setAttribute("allow","fullscreen; clipboard-read; clipboard-write");let i=t?yt(t):"about:blank",s={id:n,url:i,title:r||(i==="about:blank"?"New tab":i.replace(/^https?:\/\//i,"")),iframe:o,loading:i!=="about:blank",favicon:null,zoom:100,pinTitle:!!r,useChromium:!1,history:[i],historyIndex:0};return e.appendChild(o),Z.push(s),Z.forEach(a=>{a.iframe&&(a.iframe.style.display=a.id===n?"block":"none")}),_e=n,o.addEventListener("load",()=>{$e(),s.loading=!1,s.devtools=!1;let a=wt(s);if(a)try{let m=a.__LS_PROXY_TARGET__||xt(a.location.href);m&&m!=="about:blank"&&m!==s.url&&(s.url=m,hn(s,m)),s.pinTitle||(a.document.title?s.title=a.document.title.slice(0,60):s.url!=="about:blank"&&(s.title=s.url.replace(/^https?:\/\//,"")));let d=a.document.querySelector('link[rel~="icon"]');d!=null&&d.href&&(s.favicon=d.href)}catch{}else!s.pinTitle&&s.url!=="about:blank"&&(s.title=s.url.replace(/^https?:\/\//,""));if(!s.favicon&&/^https?:/i.test(s.url))try{s.favicon=new URL("/favicon.ico",s.url).href}catch{}mn(s),fn(s.url,s.title),J()}),i==="about:blank"?(ln(o,"about:blank"),o.src="about:blank",J()):vt(s,i,{pushHistory:!1}),s}function bn(e){let t=B();return t?kt(e,t.url,t.title):null}function St(e){Z.some(t=>t.id===e)&&(_e=e,Z.forEach(t=>{t.iframe&&(t.iframe.style.display=t.id===e?"block":"none")}),J())}function Wt(e){var n;let t=Z.findIndex(o=>o.id===e);if(t<0)return Z.length;let[r]=Z.splice(t,1);r.id===_e&&$e();try{(n=r.iframe)==null||n.remove()}catch{}if(_e===e)if(Z.length){let o=Z[Math.min(t,Z.length-1)];St(o.id)}else _e=null,J();else J();return Z.length}function xn(){$e(),Z.forEach(e=>{var t;try{(t=e.iframe)==null||t.remove()}catch{}}),Z=[],_e=null,J()}function je(e,t={}){let r=B();r!=null&&r.iframe&&vt(r,e,{pushHistory:!0,useChromium:!!t.useChromium})}function Er(){let e=B();if(!(e!=null&&e.iframe))return;if(e.url==="about:blank"){J();return}e.loading=!0,Mo(e,e.url,e.useChromium);let t=wt(e),r=!1;if(t)try{t.location.reload(),r=!0}catch{}!r&&!(e.bridge&&Ae(e,"reload"))&&(e.iframe.src=e.iframe.src),J()}function yn(){$e();let e=B();if(!(e!=null&&e.iframe))return;let t=wt(e);if(t)try{t.stop()}catch{}else Ae(e,"stop");e.loading=!1,J()}function Lr(e){let t=B();if(t){if(e<0&&t.historyIndex>0){t.historyIndex-=1;let r=t.history[t.historyIndex];vt(t,r,{pushHistory:!1});return}if(e>0&&t.historyIndex<t.history.length-1){t.historyIndex+=1;let r=t.history[t.historyIndex];vt(t,r,{pushHistory:!1});return}}}function wn(e,t){var o;let r=B();if(!r||!e)return;let n=wt(r);if(n)try{(o=n.find)==null||o.call(n,e,!1,!!t,!0,!1,!1,!1);return}catch{}Ae(r,"find",{q:e,back:!!t})}function kn(){let e=B();if(!e)return!1;let t=wt(e);if(t)try{return t.print(),!0}catch{}return Ae(e,"print")}function Sn(){let e=B();return!e||!e.bridge?!1:Ae(e,"devtools",{on:!e.devtools})}function En(e){let t=B();return t?(t.zoom=Math.min(500,Math.max(25,Math.round(e))),mn(t),J(),t.zoom):100}function Ln(e){e&&(e.innerHTML="",Z.forEach(t=>{let r=document.createElement("div");r.className="ls-tab"+(t.id===_e?" is-active":"")+(t.loading?" is-loading":""),r.setAttribute("role","tab"),r.title=t.title||"";let n=document.createElement("span");if(n.className="ls-fav",t.loading)n.classList.add("is-spin");else if(t.favicon){let s=document.createElement("img");s.src=t.favicon,s.alt="",s.addEventListener("error",()=>{n.innerHTML=R(P.globe,14)}),n.appendChild(s)}else n.innerHTML=R(P.globe,14);r.appendChild(n);let o=document.createElement("span");o.className="ls-tab-label",o.textContent=t.title||"Tab",r.appendChild(o);let i=document.createElement("span");i.className="ls-tab-x",i.setAttribute("role","button"),i.title="Close tab",i.innerHTML=R(P.close,12),i.addEventListener("click",s=>{s.stopPropagation(),Wt(t.id)}),r.appendChild(i),r.addEventListener("click",()=>St(t.id)),e.appendChild(r)}))}var Po,ai,Z,_e,li,wr,Ke,kr,To,Cn=T(()=>{Ut();Ao();ne();X();oe();Be();at();xr();Po=acode.require("toast"),ai=1e4,Z=[],_e=null,li=1,wr=[],Ke=[],kr=null,To=!1});function Gt(e,t=20){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var An=T(()=>{});function pe(e,t){let r=document.createElement(e);return t&&(r.className=t),r}function Vt(){ge&&ge.close()}function Oo(){return!!ge}function Xt({host:e,anchor:t,items:r,onClose:n}){if(Vt(),!e||!(r!=null&&r.length))return{close(){}};let o=pe("div","ls-dd-layer"),i=pe("div","ls-dd-backdrop");o.appendChild(i),e.appendChild(o);let s=[],a=!1;function p(f){for(;s.length>f;)s.pop().remove()}function m(){if(!a){a=!0,document.removeEventListener("keydown",d,!0);try{o.remove()}catch{}ge&&ge.close===m&&(ge=null);try{n==null||n()}catch{}}}function d(f){f.key==="Escape"&&(f.stopPropagation(),m())}function h(f,E,H){let b=e.getBoundingClientRect(),k=f.offsetWidth,y=f.offsetHeight,L,v;E===0?(v=H.bottom-b.top+2,L=H.right-b.left-k,L<4&&(L=H.left-b.left)):(v=H.top-b.top-4,L=H.right-b.left-2,L+k>b.width-4&&(L=H.left-b.left-k+2)),L+k>b.width-4&&(L=b.width-k-4),L<4&&(L=4);let M=b.height-v-4;y>M&&b.height&&(E>0&&b.height-y-4>0?v=b.height-y-4:f.style.maxHeight=Math.max(M,80)+"px"),v<4&&(v=4),f.style.left=L+"px",f.style.top=v+"px"}function g(f,E,H){p(E);let b=pe("div","ls-dd-menu");return b.setAttribute("role","menu"),b.style.visibility="hidden",f.forEach(k=>{if(k.separator){b.appendChild(pe("div","ls-dd-sep"));return}if(k.render){let C=pe("div","ls-dd-custom");k.render(C,m),b.appendChild(C);return}let y=pe("div","ls-dd-item"+(k.disabled?" is-disabled":""));y.setAttribute("role","menuitem");let L=pe("span","ls-dd-check");k.checked&&(L.innerHTML=Gt(pi,14)),y.appendChild(L);let v=pe("span","ls-dd-label");if(v.textContent=k.label,y.appendChild(v),k.children){let C=pe("span","ls-dd-arrow");C.innerHTML=Gt(ui,14),y.appendChild(C)}let M=()=>{b.querySelectorAll(".ls-dd-item.is-active").forEach(C=>C.classList.remove("is-active")),y.classList.add("is-active"),g(k.children,E+1,y.getBoundingClientRect())},_=()=>{p(E+1),y.classList.remove("is-active")};y.addEventListener("pointerenter",C=>{C.pointerType&&C.pointerType!=="mouse"||(k.children?M():(p(E+1),b.querySelectorAll(".ls-dd-item.is-active").forEach(u=>u.classList.remove("is-active"))))}),y.addEventListener("click",C=>{var u;if(C.stopPropagation(),!k.disabled){if(k.children){y.classList.contains("is-active")&&s.length>E+1?_():M();return}m();try{(u=k.onClick)==null||u.call(k)}catch(x){console.warn("[LiveServer] menu item",x)}}}),b.appendChild(y)}),o.appendChild(b),s.push(b),h(b,E,H),b.style.visibility="",b}i.addEventListener("click",f=>{f.stopPropagation(),m()}),i.addEventListener("contextmenu",f=>{f.preventDefault(),m()}),document.addEventListener("keydown",d,!0);let l=t?t.getBoundingClientRect():e.getBoundingClientRect();return g(r,0,l),ge={close:m},{close:m}}function Ho({host:e,anchor:t,render:r,onClose:n}){if(Vt(),!e)return{close(){}};let o=pe("div","ls-dd-layer"),i=pe("div","ls-dd-backdrop"),s=pe("div","ls-dd-menu ls-dd-panel");o.append(i,s),e.appendChild(o);let a=!1;function p(){if(!a){a=!0,document.removeEventListener("keydown",m,!0);try{o.remove()}catch{}ge&&ge.close===p&&(ge=null);try{n==null||n()}catch{}}}function m(f){f.key==="Escape"&&(f.stopPropagation(),p())}i.addEventListener("click",f=>{f.stopPropagation(),p()}),document.addEventListener("keydown",m,!0),r(s,p);let d=e.getBoundingClientRect(),h=t?t.getBoundingClientRect():d,g=s.offsetWidth,l=h.right-d.left-g;return l>d.width-g-4&&(l=d.width-g-4),l<4&&(l=4),s.style.left=l+"px",s.style.top=h.bottom-d.top+2+"px",ge={close:p},{close:p,panel:s}}var pi,ui,ge,Kt=T(()=>{An();pi="M20 6L9 17l-5-5",ui="M9 18l6-6-6-6",ge=null});async function fi(e){var t;try{if((t=navigator.clipboard)!=null&&t.writeText)await navigator.clipboard.writeText(e);else{let r=document.createElement("textarea");r.value=e,document.body.appendChild(r),r.select(),document.execCommand("copy"),r.remove()}Pn("URL copied",1500)}catch{Pn(e||"No URL",2500)}}async function mi(){let{getServerStatus:e}=await Promise.resolve().then(()=>(oe(),ze)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function qo(e,t=38){return e=String(e||""),e.length>t?e.slice(0,t-1)+"\u2026":e}function hi(e){return{render(t){var m,d;let r=document.createElement("div");r.className="ls-zoomrow";let n=document.createElement("span");n.className="ls-zl",n.textContent="Zoom";let o=document.createElement("button");o.type="button",o.className="ls-ib",o.innerHTML=R(P.minus,14);let i=document.createElement("span");i.className="ls-zv",i.textContent=((d=(m=e.getZoom)==null?void 0:m.call(e))!=null?d:100)+"%";let s=document.createElement("button");s.type="button",s.className="ls-ib",s.innerHTML=R(P.plus,14);let a=document.createElement("button");a.type="button",a.className="ls-ib",a.title="Fullscreen",a.innerHTML=R(P.maximize,14);let p=h=>{var l;let g=(l=e.zoom)==null?void 0:l.call(e,h);g!=null&&(i.textContent=g+"%")};o.addEventListener("click",h=>{h.stopPropagation(),p(-10)}),s.addEventListener("click",h=>{h.stopPropagation(),p(10)}),i.style.cursor="pointer",i.addEventListener("click",h=>{var l;h.stopPropagation();let g=(l=e.zoom)==null?void 0:l.call(e,0,!0);g!=null&&(i.textContent=g+"%")}),a.addEventListener("click",h=>{var g;h.stopPropagation(),(g=e.toggleFullscreen)==null||g.call(e)}),r.append(n,o,i,s,a),t.appendChild(r)}}}function Tn(e,t){var s,a,p,m,d,h,g;let r=((s=e.getVisited)==null?void 0:s.call(e))||[],n=((a=e.getBookmarks)==null?void 0:a.call(e))||[],o=!!((p=e.isBookmarked)!=null&&p.call(e)),i=[{label:"New tab",onClick:()=>{var l;return(l=e.newTab)==null?void 0:l.call(e)}},{label:"Duplicate tab",onClick:()=>{var l;return(l=e.duplicateTab)==null?void 0:l.call(e)}},{separator:!0},{label:"History",children:r.length?[...r.slice(0,15).map(l=>({label:qo(l.title||l.url),onClick:()=>{var f;return(f=e.navigate)==null?void 0:f.call(e,l.url)}})),{separator:!0},{label:"Clear history",onClick:()=>{var l;return(l=e.clearHistory)==null?void 0:l.call(e)}}]:[{label:"No history yet",disabled:!0}]},{label:"Bookmarks",children:[{label:o?"Remove bookmark for this tab":"Bookmark this tab",onClick:()=>{var l;return(l=e.toggleBookmark)==null?void 0:l.call(e)}},...n.length?[{separator:!0}]:[],...n.map(l=>({label:qo(l.title||l.url),onClick:()=>{var f;return(f=e.navigate)==null?void 0:f.call(e,l.url)}}))]},{separator:!0},hi(e),{label:"Print\u2026",onClick:()=>{var l;return(l=e.print)==null?void 0:l.call(e)}},{label:"Find\u2026",onClick:()=>{var l;return(l=e.find)==null?void 0:l.call(e)}},{label:"Developer tools",checked:!!((m=e.isDevtools)!=null&&m.call(e)),onClick:()=>{var l;return(l=e.toggleDevtools)==null?void 0:l.call(e)}},{separator:!0},{label:"More tools",children:[{label:"Device mode (responsive)",checked:!!((d=e.isDeviceMode)!=null&&d.call(e)),onClick:()=>{var l;return(l=e.toggleDeviceMode)==null?void 0:l.call(e)}},{label:"View page source",onClick:()=>{var l;return(l=e.viewSource)==null?void 0:l.call(e)}},{separator:!0},{label:"Open server root",onClick:async()=>{var f;let l=await mi();l?(f=e.navigate)==null||f.call(e,l):Pn("Server not running",2e3)}},{label:"Copy current URL",onClick:()=>{var l;return fi(((l=e.getUrl)==null?void 0:l.call(e))||"")}},{label:"Open in external browser",onClick:()=>{var l;return(l=e.openExternal)==null?void 0:l.call(e)}},{separator:!0},{label:"Close other tabs",onClick:()=>{var l;return(l=e.closeOtherTabs)==null?void 0:l.call(e)}},{label:"Close current tab",onClick:()=>{var l;return(l=e.closeTab)==null?void 0:l.call(e)}}]},{label:"Opacity\u2026",onClick:()=>{var l;return(l=e.openOpacity)==null?void 0:l.call(e)}},{label:"Preview as overlay",checked:!!((h=e.isOverlay)!=null&&h.call(e)),disabled:!((g=e.canOverlay)!=null&&g.call(e)),onClick:()=>{var l;return(l=e.toggleOverlay)==null?void 0:l.call(e)}},{separator:!0},{label:"Settings",onClick:async()=>{let{openSettingsHub:l}=await Promise.resolve().then(()=>(Yt(),Cr));l()}},{label:"Exit",onClick:()=>{var l;return(l=e.closeBrowser)==null?void 0:l.call(e)}}];return Xt({host:t.host,anchor:t.anchor,items:i})}var Pn,Bo=T(()=>{Kt();Ut();Pn=acode.require("toast")});function Ze(e){let t=parseFloat(e);return Number.isFinite(t)?Math.min(Mn,Math.max(_r,Math.round(t*100)/100)):1}function Do(e){return String(Ze(e)).replace(/(\.\d)0$/,"$1")}function zo(e,t,r){let n=document.createElement("div");n.className="ls-op-row"+(r?" is-disabled":"");let o=document.createElement("span");o.textContent=e;let i=document.createElement("span");return i.className="ls-switch"+(t?" is-on":""),n.append(o,i),{r:n,sw:i}}function $o({host:e,anchor:t,get:r,set:n}){return Ho({host:e,anchor:t,render(o){let i=r(),s=document.createElement("div");s.className="ls-op-head";let a=document.createElement("span");a.textContent="Browser opacity";let p=document.createElement("span");p.className="ls-op-val",p.textContent=Do(i.opacity),s.append(a,p);let m=document.createElement("input");m.type="range",m.className="ls-range",m.min=String(_r),m.max=String(Mn),m.step="0.05",m.value=String(Ze(i.opacity));let d=()=>{let f=(m.value-_r)/(Mn-_r)*100;m.style.setProperty("--ls-fill",f+"%")};d(),m.addEventListener("input",()=>{d(),p.textContent=Do(m.value),n({opacity:Ze(m.value)})});let h=zo("Preview as overlay",i.overlay,!i.canOverlay),g=zo("Auto-save while typing",i.autoSave,!1);g.r.style.display=i.overlay?"":"none",h.r.addEventListener("click",()=>{let f=!h.sw.classList.contains("is-on");h.sw.classList.toggle("is-on",f),g.r.style.display=f?"":"none",n({overlay:f})}),g.r.addEventListener("click",()=>{let f=!g.sw.classList.contains("is-on");g.sw.classList.toggle("is-on",f),n({autoSave:f})});let l=document.createElement("div");l.className="ls-op-hint",l.textContent=i.canOverlay?"Overlay: the preview is see-through and you can keep editing underneath.":"Overlay needs the Acode page display mode.",o.append(s,m,h.r,g.r,l)}})}var _r,Mn,jo=T(()=>{Kt();_r=.1,Mn=1});function Pr(e){return Ar.find(t=>t.id===e)||Ar[0]}function Pe(e){let t=Math.round(Number(e));return Number.isFinite(t)?Math.min(gi,Math.max(In,t)):null}function No(e,t,r,n,o){return e!=="fit"?Math.max(.1,Number(e)/100):!n||!o?1:Math.min(1,n/t,o/r)}var Ar,Rn,In,gi,Fo=T(()=>{Ar=[{id:"responsive",name:"Responsive",w:390,h:844},{id:"iphone-se",name:"iPhone SE",w:375,h:667},{id:"iphone-xr",name:"iPhone XR",w:414,h:896},{id:"iphone-12-pro",name:"iPhone 12 Pro",w:390,h:844},{id:"iphone-14-pro-max",name:"iPhone 14 Pro Max",w:430,h:932},{id:"pixel-7",name:"Pixel 7",w:412,h:915},{id:"galaxy-s8-plus",name:"Samsung Galaxy S8+",w:360,h:740},{id:"galaxy-s20-ultra",name:"Samsung Galaxy S20 Ultra",w:412,h:915},{id:"galaxy-fold",name:"Galaxy Fold",w:280,h:653},{id:"surface-duo",name:"Surface Duo",w:540,h:720},{id:"ipad-mini",name:"iPad Mini",w:768,h:1024},{id:"ipad-air",name:"iPad Air",w:820,h:1180},{id:"ipad-pro",name:"iPad Pro",w:1024,h:1366},{id:"surface-pro-7",name:"Surface Pro 7",w:912,h:1368},{id:"nest-hub",name:"Nest Hub",w:1024,h:600},{id:"nest-hub-max",name:"Nest Hub Max",w:1280,h:800},{id:"laptop",name:"Laptop 1366",w:1366,h:768},{id:"desktop",name:"Desktop 1920",w:1920,h:1080}],Rn=["fit",25,50,75,100,125,150,200];In=50,gi=9999});function Te(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.innerHTML=r),n}function Uo({shell:e,stage:t,box:r,device:n,bar:o,onChange:i}){let s={on:!1,id:"responsive",w:390,h:844,zoom:"fit"},a=1,p=null,m=Te("button","ls-dev-btn ls-dev-device");m.type="button";let d=Te("input","ls-dev-num"),h=Te("input","ls-dev-num");[d,h].forEach(u=>{u.type="number",u.min=String(In),u.inputMode="numeric"});let g=Te("span","ls-dev-x","&times;"),l=Te("button","ls-dev-btn ls-dev-zoom");l.type="button";let f=Te("button","ls-dev-icon",R(P.rotate,16));f.type="button",f.title="Rotate";let E=Te("button","ls-dev-icon",R(P.close,16));E.type="button",E.title="Close device mode";let H=Te("span","ls-dev-spacer");o.append(m,d,g,h,l,f,H,E);function b(){try{i==null||i({...s})}catch{}}function k(){return s.zoom==="fit"?"Fit to window ("+Math.round(a*100)+"%)":s.zoom+"%"}function y(){m.innerHTML="<span>"+Pr(s.id).name+"</span>"+R(P.down,12),document.activeElement!==d&&(d.value=String(s.w)),document.activeElement!==h&&(h.value=String(s.h)),l.innerHTML="<span>"+k()+"</span>"+R(P.down,12)}function L(){if(e.classList.toggle("is-device",s.on),o.hidden=!s.on,!s.on){r.style.width="",r.style.height="",n.style.width="",n.style.height="",n.style.transform="";return}let u=t.clientWidth-24,x=t.clientHeight-24;a=No(s.zoom,s.w,s.h,u,x),r.style.width=Math.round(s.w*a)+"px",r.style.height=Math.round(s.h*a)+"px",n.style.width=s.w+"px",n.style.height=s.h+"px",n.style.transform="scale("+a+")",y()}function v(u,x,U){let ie=Pe(u),ae=Pe(x);ie!=null&&(s.w=ie),ae!=null&&(s.h=ae),U||(s.id="responsive"),L(),b()}function M(u){let x=Pr(u);s.id=x.id,s.w=x.w,s.h=x.h,L(),b()}m.addEventListener("click",()=>{Xt({host:e,anchor:m,items:Ar.map(u=>({label:u.id==="responsive"?u.name:u.name+"  "+u.w+" x "+u.h,checked:u.id===s.id,onClick:()=>M(u.id)}))})}),l.addEventListener("click",()=>{Xt({host:e,anchor:l,items:Rn.map(u=>({label:u==="fit"?"Fit to window":u+"%",checked:u===s.zoom,onClick:()=>{s.zoom=u,L(),b()}}))})}),f.addEventListener("click",()=>v(s.h,s.w,!0)),E.addEventListener("click",()=>C.toggle(!1));let _=()=>v(d.value,h.value);[d,h].forEach(u=>{u.addEventListener("change",_),u.addEventListener("keydown",x=>{x.key==="Enter"&&(_(),u.blur())})}),["r","b","c"].forEach(u=>{let x=Te("div","ls-hdl ls-hdl-"+u);r.appendChild(x),x.addEventListener("pointerdown",U=>{U.preventDefault(),U.stopPropagation();let ie=U.clientX,ae=U.clientY,Ie=s.w,G=s.h;try{x.setPointerCapture(U.pointerId)}catch{}n.style.pointerEvents="none";let le=we=>{var V,te;let c=a||1,S=u==="b"?Ie:Ie+(we.clientX-ie)/c,z=u==="r"?G:G+(we.clientY-ae)/c;s.id="responsive",s.w=(V=Pe(S))!=null?V:s.w,s.h=(te=Pe(z))!=null?te:s.h,L()},be=()=>{x.removeEventListener("pointermove",le),x.removeEventListener("pointerup",be),x.removeEventListener("pointercancel",be),n.style.pointerEvents="",b()};x.addEventListener("pointermove",le),x.addEventListener("pointerup",be),x.addEventListener("pointercancel",be)})}),typeof ResizeObserver=="function"&&(p=new ResizeObserver(()=>{s.on&&s.zoom==="fit"&&L()}),p.observe(t));let C={getState:()=>({...s}),getScale:()=>a,isOn:()=>s.on,setState(u){u&&(typeof u.id=="string"&&(s.id=Pr(u.id).id),Pe(u.w)!=null&&(s.w=Pe(u.w)),Pe(u.h)!=null&&(s.h=Pe(u.h)),u.zoom!=null&&(s.zoom=Rn.includes(u.zoom)?u.zoom:"fit"),s.on=!!u.on,L())},toggle(u){return s.on=u==null?!s.on:!!u,L(),b(),s.on},layout:L,destroy(){try{p==null||p.disconnect()}catch{}}};return y(),C}var Wo=T(()=>{Ut();Kt();Fo()});function Zt(e,t){if(!e)return;let r=t==null?!e.classList.contains("is-fullscreen"):!!t;return e.classList.toggle("is-fullscreen",r),document.body.classList.toggle("ls-browser-fs",r),r}function Go(e){return Zt(e,!1)}var Vo=T(()=>{});function Xo(e,t={}){var y,L;let r=acode.require("page"),n=acode.require("actionStack"),o="liveserver-browser-page-"+ ++vi,i=document.createElement("span");i.className="icon arrow_back",i.dataset.action="back",i.style.cssText="pointer-events:auto;cursor:pointer;";let s=r(t.title||"Live Preview",{lead:i}),a=s.body||s,p=s.header||((y=s.querySelector)==null?void 0:y.call(s,"header"));p&&(p.style.display="none"),Object.assign(a.style,{position:"absolute",inset:"0",top:"0",left:"0",right:"0",bottom:"0",width:"auto",height:"auto",padding:"0",margin:"0",overflow:"hidden"}),e.classList.add("is-in-page"),typeof s.appendBody=="function"?s.appendBody(e):a.appendChild(e);let m=!1,d=null,h=()=>{var M;let v=!1;try{v=!!((M=t.onBack)!=null&&M.call(t))}catch{}if(v){try{n.remove(o),n.push({id:o,action:h})}catch{}return}l()};function g(){try{n.remove(o),n.push({id:o,action:h})}catch{}}function l(){if(!m){try{n.remove(o)}catch{}try{s.style.display="none"}catch{}}}function f(){var v;if(!m){try{s.style.display="",s.isConnected||(window.app||document.body).append(s),(v=s.show)==null||v.call(s)}catch{}g()}}function E(v){var M,_,C;if(!m){m=!0;try{window.removeEventListener("resize",k)}catch{}try{n.remove(o)}catch{}try{(M=s.hide)==null||M.call(s)}catch{}try{(_=s.remove)==null||_.call(s)}catch{}if(v)try{(C=t.onClose)==null||C.call(t)}catch{}}}i.onclick=v=>{var M,_;try{(M=v==null?void 0:v.preventDefault)==null||M.call(v),(_=v==null?void 0:v.stopPropagation)==null||_.call(v)}catch{}l()};try{s.onhide=()=>{m||l()}}catch{}(window.app||document.body).append(s);try{getComputedStyle(s).position==="static"&&Object.assign(s.style,{position:"absolute",inset:"0",width:"100%",height:"100%"})}catch{}try{(L=s.show)==null||L.call(s)}catch{}g();let H=()=>{var v,M;try{let _=(v=window.editorManager)==null?void 0:v.container,C=(M=_==null?void 0:_.getBoundingClientRect)==null?void 0:M.call(_);if(C&&C.width>0&&C.height>0)return C}catch{}return{left:0,top:0,width:window.innerWidth,height:window.innerHeight}},b=()=>{let v=H();s.style.left=v.left+"px",s.style.top=v.top+"px",s.style.width=v.width+"px",s.style.height=v.height+"px"},k=()=>{d!=null&&b()};return window.addEventListener("resize",k),{page:s,show:f,minimize:l,setAppearance({overlay:v,opacity:M}){v?(d==null&&(d=s.style.cssText),Object.assign(s.style,{position:"fixed",background:"transparent",pointerEvents:"none",opacity:"1"}),b(),a.style.background="transparent"):(d!=null&&(s.style.cssText=d,d=null),a.style.background="",s.style.opacity=M<1?String(M):"")},close:()=>{window.removeEventListener("resize",k),E(!1)},onFullscreen(){}}}var vi,Ko=T(()=>{vi=0});function xi(){for(let e of["editorFile","EditorFile"])try{let t=acode.require(e);if(typeof t=="function")return t}catch{}return null}async function Yo(e,t={}){var m;let r=xi();if(!r)return null;e.classList.add("is-in-tab");let n=t.title||"Live Preview",o="liveserver-preview-"+Date.now()+"-"+ ++bi,i=null,s=[{type:"custom",content:e,stylesheets:t.css?[t.css]:[],hideQuickTools:!0,id:o,render:!0},{type:"page",content:e,stylesheets:t.css?[t.css]:[],id:o,render:!0}];for(let d of s)try{i=new r(n,d);break}catch(h){console.warn("[LiveServer] EditorFile "+d.type,h),i=null}if(!i)return e.classList.remove("is-in-tab"),null;let a=!1,p=()=>{var d;if(!a){a=!0;try{(d=t.onClose)==null||d.call(t)}catch{}}};try{(m=i.on)==null||m.call(i,"close",p)}catch{}try{i.onclose=p}catch{}return{file:i,show(){var d;if(!a)try{(d=i.makeActive)==null||d.call(i)}catch{}},close(){var d,h;if(!a){a=!0;try{(d=i.remove)==null||d.call(i,!0)}catch{try{(h=i.remove)==null||h.call(i)}catch{}}}},onFullscreen(){},setAppearance(){}}}var bi,Zo=T(()=>{bi=0});var Qo={};fe(Qo,{destroyAcodeWebview:()=>ki,isNativeWebviewSupported:()=>wi,openInAcodeWebview:()=>On});function Jo(e){var t,r,n;try{return(r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open?(window.cordova.InAppBrowser.open(e,"_system"),!0):(n=window.cordova)!=null&&n.exec?(window.cordova.exec(null,null,"System","open-in-browser",[e]),!0):(window.open(e,"_blank","noopener"),!0)}catch{return yi(e,2500),!1}}function wi(){try{let e=acode.require("webview");return!!(e&&typeof e.create=="function")}catch{return!1}}async function On(e,t={}){if(!e||e==="about:blank")return!1;let r=null;try{r=acode.require("webview")}catch{}if(!(r!=null&&r.create))return Jo(e);if(ve)try{return await ve.loadURL(e),await ve.show(),!0}catch{ve=null}try{let n=await r.create({mode:"fullscreen",title:t.title||e.replace(/^https?:\/\//i,""),allowNavigation:!0,allowDownloads:t.allowDownloads!==!1,visible:!0});return ve=n,n.on("closed",()=>{ve===n&&(ve=null)}),await n.loadURL(e),!0}catch(n){return console.warn("[LiveServer] native webview failed, falling back:",n),ve=null,Jo(e)}}async function ki(){if(!ve)return;let e=ve;ve=null;try{await e.destroy()}catch{}}var yi,ve,Hn=T(()=>{yi=acode.require("toast"),ve=null});var Qe={};fe(Qe,{createBrowserShell:()=>Ii,hideBrowser:()=>Ct,openBrowser:()=>Dn,openBrowserMenu:()=>Tn});function os(){return A().browserDisplayMode==="editorTab"?"editorTab":"inPage"}function Ci(e,t){try{return new URL(e).origin===new URL(t).origin}catch{return!1}}function Et(){let e=A().browserBookmarks;return Array.isArray(e)?e:[]}async function _i(){let{getServerStatus:e}=await Promise.resolve().then(()=>(oe(),ze)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function ts(e){var t,r,n;if(!(!e||e==="about:blank"))try{if((r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open){window.cordova.InAppBrowser.open(e,"_system");return}if((n=window.cordova)!=null&&n.exec){window.cordova.exec(null,null,"System","open-in-browser",[e]);return}window.open(e,"_blank","noopener")}catch{ue(e,2500)}}function Ai(){if(!(Lt||typeof editorManager=="undefined"||!(editorManager!=null&&editorManager.on))){Lt=()=>{A().overlayAutoSave!==!1&&(clearTimeout(qn),qn=setTimeout(async()=>{var r;let e=Y(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";if(e&&e.isUnsaved&&(e.uri||e.url)&&Ei.test(t))try{await((r=e.save)==null?void 0:r.call(e))}catch(n){console.warn("[LiveServer] overlay auto-save",n)}},700))};try{editorManager.on("update",Lt)}catch{}}}function ss(){var e;if(clearTimeout(qn),Lt)try{(e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"update",Lt)}catch{}Lt=null}function Mr(){return Je==="page"&&!!A().browserOverlay}function Bn(){var n,o;if(!N)return;let e=A(),t=Ze((n=e.browserOpacity)!=null?n:1),r=Mr();N.classList.toggle("is-overlay",r),N.classList.toggle("no-url",e.showAddressBar===!1),N.style.setProperty("--ls-op",String(t)),Je==="page"?((o=$==null?void 0:$.setAppearance)==null||o.call($,{overlay:r,opacity:t}),N.style.opacity=""):N.style.opacity=t<1?String(t):"",r?Ai():ss(),W==null||W.layout()}function rs(e){if("opacity"in e&&q("browserOpacity",Ze(e.opacity)),"overlay"in e){if(e.overlay&&Je!=="page"){ue("Overlay needs the Acode page display mode",2200);return}q("browserOverlay",!!e.overlay)}"autoSave"in e&&q("overlayAutoSave",!!e.autoSave),Bn()}function Pi(e){var le,be,we;let t=c=>e.querySelector(c),r=t(".ls-browser-tabs"),n=t(".ls-stage"),o=t(".ls-box"),i=t(".ls-device"),s=t(".ls-ntp"),a=t(".ls-back"),p=t(".ls-fwd"),m=t(".ls-browser-url"),d=t(".ls-reload"),h=t(".ls-star"),g=t(".ls-site"),l=t(".ls-menu-btn"),f=t(".ls-op-btn"),E=t(".ls-dev-toggle"),H=t(".ls-find"),b=H.querySelector("input"),k=!1;W=Uo({shell:e,stage:n,box:o,device:i,bar:t(".ls-devbar"),onChange:c=>q("browserDevice",c)});let y=A().browserDevice;y&&typeof y=="object"&&W.setState(y);let L=()=>e.getRootNode().activeElement===m,v=async c=>{if(c==="about:blank"){je("about:blank");return}let S=yt(c);if(!S||S==="about:blank"){je("about:blank");return}if(!Ye(S)){let z=A().externalSiteMode||"proxy";if(z==="acodeWebview"){await On(S);return}if(z==="systemBrowser"){ts(S);return}}je(S)},M=()=>{s.innerHTML="";let c=document.createElement("div");c.className="ls-ntp-hero";let S=document.createElement("img");S.className="ls-ntp-logo",S.src=Si,S.alt="Live Server",S.onerror=()=>{S.style.display="none"},c.appendChild(S);let z=document.createElement("div");z.className="ls-ntp-title",z.textContent="Live Server",c.appendChild(z);let V=document.createElement("div");V.className="ls-ntp-search";let te=document.createElement("span");te.className="ls-ntp-search-ico",te.innerHTML=R(P.search,17);let ke=document.createElement("input");ke.type="text",ke.placeholder="Search or enter web address",ke.setAttribute("spellcheck","false"),ke.setAttribute("autocapitalize","off"),ke.setAttribute("autocomplete","off");let At=document.createElement("button");At.type="button",At.className="ls-ntp-search-btn",At.textContent="Search";let to=()=>{let I=ke.value.trim();if(!I){ke.focus();return}v(I)};ke.addEventListener("keydown",I=>{I.key==="Enter"&&to()}),At.addEventListener("click",to),V.append(te,ke,At);let Pt=document.createElement("div");Pt.className="ls-ntp-tiles";let ro=(I,K,xe,ce)=>{let Q=document.createElement("button");Q.type="button",Q.className="ls-ntp-tile",Q.innerHTML='<span class="ls-ntp-dot"></span><span class="ls-ntp-name"></span>';let jr=Q.querySelector(".ls-ntp-dot");if(ce&&/^https?:/i.test(ce)&&!Ye(ce)){let Ge=document.createElement("img");Ge.src=ce,Ge.alt="",Ge.onerror=()=>{jr.textContent=xe},jr.appendChild(Ge)}else jr.textContent=xe;return Q.querySelector(".ls-ntp-name").textContent=I,Q.addEventListener("click",async()=>{let Ge=typeof K=="function"?await K():K;if(!Ge)return ue("Server not running",2e3);v(Ge)}),Q};Pt.appendChild(ro("Server root",_i,"S",null)),Et().forEach(I=>{var ce;let K=null;try{let Q=new URL(I.url).hostname;Q&&Q!=="127.0.0.1"&&Q!=="localhost"&&(K=`https://www.google.com/s2/favicons?domain=${encodeURIComponent(Q)}&sz=64`)}catch{}let xe=((ce=(I.title||I.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:ce.toUpperCase())||"B";Pt.appendChild(ro(I.title||I.url,I.url,xe,K))});let Tt=document.createElement("button");Tt.type="button",Tt.className="ls-ntp-tile",Tt.innerHTML=`<span class="ls-ntp-dot">${R(P.plus,20)}</span><span class="ls-ntp-name">Add shortcut</span>`,Tt.addEventListener("click",async()=>{let I=acode.require("prompt"),K=await I("Bookmark URL (e.g. https://duckduckgo.com)","https://","text");if(!K)return;let xe=yt(K),ce=await I("Shortcut name",xe.replace(/^https?:\/\//,""),"text")||xe,Q=Et();q("browserBookmarks",[...Q,{title:ce.trim(),url:xe}]),M()}),Pt.appendChild(Tt);let ar=document.createElement("div");ar.className="ls-ntp-recent-wrap";let $r=Sr(),lr=document.createElement("div");lr.className="ls-ntp-sec-head";let no=document.createElement("span");if(no.textContent="Recent",lr.appendChild(no),$r.length>0){let I=document.createElement("button");I.type="button",I.className="ls-ntp-more",I.textContent=k?"Less":"More",I.addEventListener("click",()=>{k=!k,M()}),lr.appendChild(I)}ar.appendChild(lr);let cr=document.createElement("div");cr.className="ls-ntp-recent-list";let oo=k?$r:$r.slice(0,5);if(oo.length)oo.forEach(I=>{var ce;let K=document.createElement("button");K.type="button",K.className="ls-ntp-recent-row";let xe=((ce=(I.title||I.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:ce.toUpperCase())||"W";K.innerHTML=`
          <span class="ls-ntp-recent-ico">${xe}</span>
          <span class="ls-ntp-recent-meta">
            <span class="ls-ntp-recent-title"></span>
            <span class="ls-ntp-recent-url"></span>
          </span>
        `,K.querySelector(".ls-ntp-recent-title").textContent=I.title||I.url,K.querySelector(".ls-ntp-recent-url").textContent=I.url,K.addEventListener("click",()=>v(I.url)),cr.appendChild(K)});else{let I=document.createElement("div");I.className="ls-ntp-empty",I.textContent="No recent pages yet",cr.appendChild(I)}ar.appendChild(cr),s.append(c,V,Pt,ar)},_=()=>{let c=B();Ln(r),m&&!L()&&(m.value=c&&c.url!=="about:blank"?c.url:""),e.classList.toggle("is-loading",!!(c!=null&&c.loading)),e.classList.toggle("is-installing",document.body.classList.contains("ls-green-loading")),d.innerHTML=R(c!=null&&c.loading?P.close:P.reload,18),d.title=c!=null&&c.loading?"Stop loading":"Reload",a&&(a.disabled=!dn()),p&&(p.disabled=!pn());let S=/^https:/i.test((c==null?void 0:c.url)||"");g.innerHTML=R(S?P.lock:P.info,16),g.title=S?"Connection is secure":"Not secure";let z=!!c&&Et().some(te=>te.url===c.url);h.classList.toggle("is-on",z);let V=!c||c.url==="about:blank";V&&M(),s.classList.toggle("is-on",V),bt().length||Ct()};Ne==null||Ne(),Ne=un(_);let C=()=>{var S;let c=Zt(e);(S=$==null?void 0:$.onFullscreen)==null||S.call($,c)},u=()=>{var c;k=!1,kt(i,"about:blank"),St((c=B())==null?void 0:c.id)},x=()=>{k=!1;let c=String(A().browserHomeUrl||"").trim();c?v(c):je("about:blank")},U=(c,S)=>{var z,V;return S>0?(z=es.find(te=>te>c))!=null?z:c:(V=[...es].reverse().find(te=>te<c))!=null?V:c},ie=c=>wn(b.value,c),ae=()=>{let c=B();if(!c||c.url==="about:blank")return ue("Nothing to bookmark",1500);let S=Et(),z=S.some(V=>V.url===c.url);q("browserBookmarks",z?S.filter(V=>V.url!==c.url):[...S,{title:c.title||c.url,url:c.url}]),_(),ue(z?"Bookmark removed":"Bookmarked",1200)},Ie=()=>$o({host:e,anchor:f,get:()=>{var c;return{opacity:Ze((c=A().browserOpacity)!=null?c:1),overlay:Mr(),autoSave:A().overlayAutoSave!==!1,canOverlay:Je==="page"}},set:rs}),G=()=>({newTab:u,duplicateTab:()=>bn(i),closeTab:()=>{let c=B();c&&Wt(c.id)},closeOtherTabs:()=>{let c=B();bt().filter(S=>S.id!==(c==null?void 0:c.id)).forEach(S=>Wt(S.id))},navigate:c=>v(c),getUrl:()=>{var c;return((c=B())==null?void 0:c.url)||""},getVisited:Sr,clearHistory:()=>{cn(),M(),ue("History cleared",1500)},getBookmarks:Et,isBookmarked:()=>{let c=B();return!!c&&Et().some(S=>S.url===c.url)},toggleBookmark:ae,getZoom:()=>{var c,S;return(S=(c=B())==null?void 0:c.zoom)!=null?S:100},zoom:(c,S)=>{let z=B();return z?En(S?100:U(z.zoom||100,c)):100},toggleFullscreen:C,print:()=>{kn()||ue("Cannot print this page",1800)},find:()=>{H.hidden=!1,b.focus(),b.select()},isDevtools:()=>{var c;return!!((c=B())!=null&&c.devtools)},toggleDevtools:()=>{let c=B();if(!c||c.url==="about:blank")return ue("Open a page first",1800);Sn()||ue("DevTools work on pages served by Live Server",3e3)},isDeviceMode:()=>W.isOn(),toggleDeviceMode:()=>W.toggle(),viewSource:async()=>{var S;let c=B();if(!c||!/^https?:/i.test(c.url))return ue("No page source here",1800);try{let z=(S=c.iframe)!=null&&S.src&&c.iframe.src!=="about:blank"?c.iframe.src:c.url,V=await(await fetch(z)).text(),te=URL.createObjectURL(new Blob([V],{type:"text/plain;charset=utf-8"}));kt(i,te,"view-source:"+c.url.replace(/^https?:\/\//,""))}catch(z){ue("Could not load source: "+((z==null?void 0:z.message)||z),2500)}},openExternal:()=>{var S;let c=(S=B())==null?void 0:S.url;c&&c!=="about:blank"&&ts(c)},openOpacity:Ie,isOverlay:Mr,canOverlay:()=>Je==="page",toggleOverlay:()=>rs({overlay:!Mr()}),closeBrowser:()=>Ct()});return(le=t(".ls-tab-new"))==null||le.addEventListener("click",u),e.querySelectorAll(".ls-close-btn, .ls-ov-close").forEach(c=>c.addEventListener("click",()=>Ct())),(be=t(".ls-fs-btn"))==null||be.addEventListener("click",C),a==null||a.addEventListener("click",()=>Lr(-1)),p==null||p.addEventListener("click",()=>Lr(1)),d.addEventListener("click",()=>{var c;return(c=B())!=null&&c.loading?yn():Er()}),(we=t(".ls-home"))==null||we.addEventListener("click",x),h.addEventListener("click",ae),f.addEventListener("click",Ie),E.addEventListener("click",()=>{let c=W.toggle();E.classList.toggle("is-on",c)}),E.classList.toggle("is-on",W.isOn()),l.addEventListener("click",()=>Tn(G(),{host:e,anchor:l})),m.addEventListener("keydown",c=>{c.key==="Enter"&&(v(m.value),m.blur())}),m.addEventListener("focus",()=>m.select()),H.querySelector(".ls-find-prev").addEventListener("click",()=>ie(!0)),H.querySelector(".ls-find-next").addEventListener("click",()=>ie(!1)),H.querySelector(".ls-find-close").addEventListener("click",()=>H.hidden=!0),b.addEventListener("keydown",c=>{c.key==="Enter"&&ie(c.shiftKey),c.key==="Escape"&&(H.hidden=!0)}),e._lsDevice=i,e._sync=_,e}function Ti(){let e=document.createElement("div");return e.className="ls-browser-shell",e.dataset.theme=yo(),e.innerHTML=`
    <div class="ls-chrome">
      <div class="ls-tabstrip">
        <div class="ls-browser-tabs"></div>
        <button type="button" class="ls-ib ls-tab-new" title="New tab">${R(P.plus,16)}</button>
        <span class="ls-spacer"></span>
        <div class="ls-win">
          <button type="button" class="ls-ib ls-win-btn ls-fs-btn" title="Fullscreen">${R(P.maximize,14)}</button>
          <button type="button" class="ls-ib ls-win-btn ls-close-btn" title="Close">${R(P.close,14)}</button>
        </div>
      </div>
      <div class="ls-toolbar">
        <button type="button" class="ls-ib ls-back" title="Back" disabled>${R(P.back,18)}</button>
        <button type="button" class="ls-ib ls-fwd" title="Forward" disabled>${R(P.forward,18)}</button>
        <button type="button" class="ls-ib ls-reload" title="Reload">${R(P.reload,18)}</button>
        <button type="button" class="ls-ib ls-home" title="Home">${R(P.home,18)}</button>
        <div class="ls-omni">
          <button type="button" class="ls-site" title="Site information">${R(P.info,16)}</button>
          <input class="ls-browser-url" type="text" spellcheck="false" autocapitalize="off" autocomplete="off" placeholder="Search or type a URL" />
          <button type="button" class="ls-ib ls-star" title="Bookmark this tab">${R(P.star,16)}</button>
        </div>
        <button type="button" class="ls-ib ls-op-btn" title="Opacity">${R(P.drop,18)}</button>
        <button type="button" class="ls-ib ls-dev-toggle" title="Device mode">${R(P.device,18)}</button>
        <button type="button" class="ls-ib ls-menu-btn" title="Customize and control">${R(P.dots,18,3)}</button>
        <button type="button" class="ls-ib ls-ov-close" title="Close">${R(P.close,16)}</button>
        <div class="ls-progress"></div>
        <div class="ls-green-progress"></div>
      </div>
      <div class="ls-devbar" hidden></div>
    </div>
    <div class="ls-stage">
      <div class="ls-ntp"></div>
      <div class="ls-box"><div class="ls-device"></div></div>
    </div>
    <div class="ls-find" hidden>
      <input type="text" placeholder="Find in page" spellcheck="false" />
      <button type="button" class="ls-ib ls-find-prev" title="Previous">${R(P.up,16)}</button>
      <button type="button" class="ls-ib ls-find-next" title="Next">${R(P.down,16)}</button>
      <button type="button" class="ls-ib ls-find-close" title="Close">${R(P.close,16)}</button>
    </div>
  `,Pi(e)}function Mi(){var t;if(Oo())return Vt(),!0;let e=N==null?void 0:N.querySelector(".ls-find");return e&&!e.hidden?(e.hidden=!0,!0):N!=null&&N.classList.contains("is-fullscreen")?((t=$==null?void 0:$.onFullscreen)==null||t.call($,Zt(N,!1)),!0):!1}function ns(){Tr||Ct({fromHost:!0})}async function Ri(){var e;return N&&$?((e=$.show)==null||e.call($),requestAnimationFrame(()=>W==null?void 0:W.layout()),N):Jt||(Jt=(async()=>{ko();let t=Ti(),r=null;return Je="page",os()==="editorTab"&&(r=await Yo(t,{title:"Live Preview",css:sn,onClose:ns}),r?Je="tab":ue("Editor tab not available, using page",2e3)),r||(r=Xo(t,{title:"Live Preview",onClose:ns,onBack:Mi})),$=r,N=t,gn(),Qt=n=>{var o;Li.includes((o=n==null?void 0:n.detail)==null?void 0:o.key)&&Bn()},window.addEventListener("liveserver-settings",Qt),Bn(),requestAnimationFrame(()=>W==null?void 0:W.layout()),t})().finally(()=>{Jt=null}),Jt)}async function Dn(e,t={}){let r=await Ri(),n=bt();if(n.length>0&&(t.restoreOnly||!e))return;let o=e||"about:blank";if(t.reuse){let s=n.find(a=>Ci(a.url,o));if(s){St(s.id),s.url!==o?je(o):t.forceReload&&Er();return}}let i=B();i&&i.url==="about:blank"&&n.length===1?je(o):kt(r._lsDevice,o)}function Ct(e={}){if(!Tr){Tr=!0;try{Vt(),Ne==null||Ne(),Ne=null,Qt&&window.removeEventListener("liveserver-settings",Qt),Qt=null,ss(),vn();try{W==null||W.destroy()}catch{}W=null,xn(),Go(N);try{N==null||N.remove()}catch{}e.fromHost||$==null||$.close()}finally{$=null,N=null,document.body.classList.remove("ls-browser-fs"),Tr=!1}}}function Ii(e={}){return{open:t=>Dn(t||e.initialUrl),addTab:t=>Dn(t),setFullscreen:t=>Zt(N,t),dispose:Ct,getMode:os}}var ue,Si,es,Ei,Li,N,$,Je,Ne,Jt,Tr,W,Qt,Lt,qn,et=T(()=>{ne();Le();Ut();wo();So();Cn();Bo();Kt();jo();Wo();Vo();Ko();Zo();Hn();ue=acode.require("toast"),Si="https://i.postimg.cc/WpYPQ47b/green-fox.png",es=[25,33,50,67,75,80,90,100,110,125,150,175,200,250,300,400,500],Ei=/\.(html?|css|js|mjs|json|svg|xml|txt|md)$/i,Li=["browserOpacity","browserOverlay","overlayAutoSave","showAddressBar"],N=null,$=null,Je="page",Ne=null,Jt=null,Tr=!1,W=null,Qt=null,Lt=null,qn=null});var ee={};fe(ee,{changePortAndRestart:()=>Di,ensureProxyServer:()=>_n,probeExistingServer:()=>Fn,reapplySetup:()=>zi,refreshStatusFromBackend:()=>on,restartServer:()=>Bi,setProcessBaseUrl:()=>jn,startServer:()=>tr,stopServer:()=>qr});function jn(e){er=e||""}async function Ir(e,t=900){try{let r=new AbortController,n=setTimeout(()=>r.abort(),t),o=await fetch("http://127.0.0.1:"+e+"/check",{signal:r.signal});if(clearTimeout(n),!o||!o.ok)return{alive:!1,proxy:!1};let i=await o.json().catch(()=>({}));return{alive:!0,proxy:(i==null?void 0:i.proxy)===!0}}catch{return{alive:!1,proxy:!1}}}async function ls(e,t=800){return(await Ir(e,t)).alive}async function Oi(e){try{let t=await j("if command -v wget >/dev/null 2>&1; then wget -qO- -T 2 http://127.0.0.1:"+e+"/check 2>/dev/null; elif command -v curl >/dev/null 2>&1; then curl -s --max-time 2 http://127.0.0.1:"+e+"/check 2>/dev/null; else echo NOCLIENT; fi",{timeoutMs:8e3});return/Ready|AcodeLiveServer|"port"/i.test(String(t||""))}catch{return!1}}async function zn(e,t={}){let r=String(parseInt(e,10)||8080);return await ls(r)?!0:t.deep?Oi(r):!1}async function Nn(e){let t=String(parseInt(e,10)||8080);Fe=null;let r=`for pid in $(ps -o pid,args 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; for pid in $(ps 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; pkill -9 -f "node index.js ${t}" 2>/dev/null || true; fuser -k ${t}/tcp 2>/dev/null || true`;try{await j(r,{timeoutMs:12e3})}catch{}for(let n=0;n<10&&await ls(t,400);n++)await new Promise(o=>setTimeout(o,200))}function cs(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=t.match(/^\/storage\/emulated\/0(\/.*)?$/);return r?"/sdcard"+(r[1]||""):t}async function Hi(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=[t],n=t.match(/^\/storage\/emulated\/0(\/.*)?$/);if(n&&r.push("/sdcard"+(n[1]||"")),n=t.match(/^\/sdcard(\/.*)?$/),n&&r.push("/storage/emulated/0"+(n[1]||"")),!/^\/(sdcard|storage)(\/|$)/.test(t))return t;let o=a=>"'"+String(a).replace(/'/g,"'\\''")+"'",i="";try{i=await j("for d in "+r.map(o).join(" ")+'; do [ -d "$d" ] && { echo "OK:$d"; exit 0; }; done; echo NONE',{timeoutMs:1e4})}catch(a){return console.warn("[LiveServer] root probe failed, using path as is",a),t}let s=String(i||"").match(/OK:(.+)/);return s?s[1].trim():/NONE/.test(String(i||""))?null:t}function qi(e){let t={};return String(e||"").split(`
`).forEach(r=>{let n=r.indexOf(":");if(n>0){let o=r.slice(0,n).trim(),i=r.slice(n+1).trim();o&&(t[o]=i)}}),t}function is(){let e=Y(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";return/\.html?$/i.test(t)?t:"index.html"}function as(e){try{let t=Y(),r=pt((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");if(!r||!e)return is();let n=e.replace(/\/+$/,"");if(r.startsWith(n+"/")||r.startsWith(n+"\\"))return r.slice(n.length).replace(/^[/\\]+/,"").replace(/\\/g,"/")}catch{}return is()}async function Or(e,t,r){let n=A(),o={path:t,fileName:r||"index.html",port:e,liveReload:n.liveReload!==!1,directoryListing:n.directoryListing!==!1,enableCors:n.enableCors!==!1,charset:n.customCharset||"utf-8",customHeaders:qi(n.customHeaders),ipWhitelist:n.ipWhitelist||"",basicAuthUser:n.basicAuthUser||"",basicAuthPass:n.basicAuthPass||""};try{let i=await fetch(`http://127.0.0.1:${e}/setup`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)});return!!(i&&(i.ok||i.status===201))}catch(i){return console.warn("[LiveServer] setup",i),!1}}function $n(){Rr&&(clearInterval(Rr),Rr=null)}function Hr(){$n();let e=parseInt(A().autoShutdownMinutes,10)||0;if(e<=0)return;let t=e*60*1e3,r=Date.now();Rr=setInterval(async()=>{let n=D();if(!n.running){$n();return}if(Date.now()-(n.startedAt||r)>t){try{let i=await(await fetch(`http://127.0.0.1:${n.port}/status`)).json();if(i.lastActivity&&Date.now()-i.lastActivity<t)return}catch{}Me("Live Server auto-stopped (inactivity)",2500),qr()}},3e4)}async function Fn(){let e=mt();try{let t=new AbortController,r=setTimeout(()=>t.abort(),1200),n=await fetch(`http://127.0.0.1:${e}/status`,{signal:t.signal});if(clearTimeout(r),!n||!n.ok)return!1;let o=await n.json().catch(()=>({})),i=o.port||e,s=o.fileName||null,a=jt(i,"127.0.0.1"),p=s&&s!=="index.html"?a.replace(/\/$/,"/")+encodeURI(s):a,m=D();if(re({running:!0,port:i,root:o.root||m.root||null,url:p,fileName:s,bind:o.bind||"0.0.0.0",startedAt:m.startedAt||(o.uptime?Date.now()-Math.round(Number(o.uptime)*1e3):Date.now()),lastError:null}),Hr(),!m.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:p,port:i,root:o.root||null,fileName:s}}))}catch{}return!0}catch{return!1}}function ds(e,t){let r=Oe();if(!(r!=null&&r.execute))throw new Error("Executor not available. Open Acode Terminal once, then retry.");let n='ACODIR=""; for d in "'+String(t||"").replace(/"/g,"")+'" /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels; do [ -n "$d" ] || continue; if [ -f "$d/index.js" ] && [ -d "$d/node_modules" ]; then ACODIR="$d"; break; fi; done; [ -z "$ACODIR" ] && { echo acodels_not_found; exit 1; }; cd "$ACODIR" || exit 1; NODE_PATH="$ACODIR/node_modules" exec node index.js '+String(e)+" 0.0.0.0 >liveserver.log 2>&1",o={};Fe=o,r.execute(Gr(n),!0).then(i=>console.log("[LiveServer] node exited",String(i||"").slice(0,200))).catch(i=>console.warn("[LiveServer] node exited",String((i==null?void 0:i.message)||i).slice(0,200))).finally(()=>{if(Fe===o&&(Fe=null,D().running)){re({running:!1,lastError:"server process exited"});try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}}})}async function _n(){let e=mt(),t=await Ir(e);if(t.alive&&t.proxy)return e;if(!await vr({baseUrl:er}))return null;Ce(!0),he(t.alive?`$ Updating backend on :${e} with Reverse Proxy...`:`$ node index.js ${e} (starting local proxy)...`,{spin:!0});try{t.alive&&!t.proxy&&await Nn(e);let n=await dt(er);await tn(n),ds(e,n);let o=!1;for(let d=0;d<35;d++){await new Promise(g=>setTimeout(g,300));let h=await Ir(e,500);if(h.alive&&h.proxy){o=!0;break}if(!Fe)break}if(!o)return he("Proxy server failed to start",{spin:!1,autoHideMs:3e3}),null;let i=D(),s=i.root||br()||"/sdcard",a=cs(s),p=i.fileName||"index.html";await Or(e,a,p);let m=jt(e,"127.0.0.1");re({running:!0,port:e,root:a,url:m,fileName:p,bind:"0.0.0.0",startedAt:Date.now(),lastError:null}),Hr();try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:m,port:e,root:a,fileName:p}}))}catch{}return he(`\u2713 Reverse proxy ready on 127.0.0.1:${e}`,{spin:!1,autoHideMs:2e3}),e}catch(n){return he(`Proxy error: ${(n==null?void 0:n.message)||n}`,{spin:!1,autoHideMs:3500}),null}finally{Ce(!1)}}async function tr(e={}){let t=e.port||mt(),r=e.root||br(),n=A(),o=e.forceDeps?{alive:!1,proxy:!1}:await Ir(t);if(o.alive&&!o.proxy&&(Ce(!0),he(`$ Upgrading Live Server on :${t}...`,{spin:!0}),await Nn(t),Ce(!1),Ft(0),o.alive=!1),o.alive&&o.proxy){let g=D(),l=r||g.root;if(!l)return Me("Set a root folder or open an HTML file",2500),!1;let f=cs(l),E=e.fileName||as(l);(!g.running||g.port!==t||g.root!==f||g.fileName!==E)&&await Or(t,f,E);let b=jt(t,"127.0.0.1"),k=E&&E!=="index.html"?b.replace(/\/$/,"/")+encodeURI(E):b;if(re({running:!0,port:t,root:f,url:k,fileName:E,bind:"0.0.0.0",startedAt:g.startedAt||Date.now(),lastError:null}),Hr(),!g.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:k,port:t,root:f,fileName:E}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:y}=await Promise.resolve().then(()=>(et(),Qe));y(k,{reuse:!0})}catch(y){console.warn("[LiveServer] open browser",y)}return!0}if(!await vr({baseUrl:er,force:!!e.forceDeps}))return!1;if(!r)return Me("Set a root folder or open an HTML file",2500),!1;let s=e.fileName||as(r),a=await Hi(r);if(!a)return re({running:!1,lastError:"root not reachable"}),Me("Folder not reachable from Alpine: "+r+" (allow Acode storage permission)",4500),!1;let p="0.0.0.0";if(!await zn(t,{deep:!0})){Ce(!0),he(`$ node index.js ${t} 0.0.0.0`,{spin:!0});let g=await dt(er);try{await tn(g)}catch(f){console.warn("[LiveServer] ensure index",f)}try{ds(t,g)}catch(f){return Ce(!1),Ft(0),re({running:!1,lastError:String((f==null?void 0:f.message)||f)}),Me("Start failed: "+((f==null?void 0:f.message)||f),3e3),!1}let l=!1;for(let f=0;f<40;f++){if(await new Promise(E=>setTimeout(E,300)),await zn(t)){l=!0;break}if(!Fe)break}if(!l&&Fe&&(l=await zn(t,{deep:!0})),Ce(!1),!l){he("Server failed to start",{spin:!1,autoHideMs:3500});try{let f=await j("tail -n 40 /root/.acode_liveserver/acodels/liveserver.log 2>/dev/null",{timeoutMs:8e3});console.warn("[LiveServer] start failed, log:",f)}catch{}return Me("Server failed to start \u2014 see console log",3500),re({running:!1,lastError:"start failed"}),Fe=null,!1}he(`\u2713 Live Server running on :${t}`,{spin:!1,autoHideMs:2200})}await Or(t,a,s)||console.warn("[LiveServer] /setup patch failed");let d=jt(t,"127.0.0.1"),h=s&&s!=="index.html"?d.replace(/\/$/,"/")+encodeURI(s):d;re({running:!0,port:t,root:a,url:h,fileName:s,bind:p,startedAt:Date.now(),lastError:null}),q("port",t),Hr(),Me("Live on "+h,2500);try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:h,port:t,root:r,fileName:s}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:g}=await Promise.resolve().then(()=>(et(),Qe));g(h,{reuse:!0})}catch(g){console.warn("[LiveServer] open browser",g)}return!0}async function qr(){$n();let t=D().port||mt();await Nn(t),re({running:!1,port:null,url:null,fileName:null,startedAt:null}),Me("Server stopped",1500);try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}return!0}async function Bi(){let e=D(),t=e.root,r=e.fileName;return await qr(),await new Promise(n=>setTimeout(n,350)),tr({root:t||void 0,fileName:r||void 0})}async function Di(){let e=acode.require("prompt"),t=String(mt()),r=await e("Port",t,"number");if(r==null)return!1;let n=parseInt(String(r),10);return!Number.isFinite(n)||n<1||n>65535?(Me("Invalid port",1500),!1):(q("port",n),await qr(),tr({port:n}))}async function zi(){let e=D();return!e.running||!e.port||!e.root?!1:Or(e.port,e.root,e.fileName||"index.html")}var Me,er,Rr,Fe,X=T(()=>{ne();nt();Be();ho();ft();vo();oe();Le();xr();Me=acode.require("toast"),er="",Rr=null,Fe=null});var hs={};fe(hs,{onFileSwitch:()=>Gn,registerSideButton:()=>Wn,setLiveDot:()=>tt,unregisterSideButton:()=>Vn});function ps(){if(document.getElementById("ls-side-dot-css"))return;let e=document.createElement("style");e.id="ls-side-dot-css",e.textContent=`
    .ls-side-live-dot {
      display: inline-block;
      width: 9px;
      height: 9px;
      min-width: 9px;
      border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 6px rgba(34, 197, 94, 0.95);
      margin-right: 6px;
      vertical-align: middle;
      flex-shrink: 0;
    }
    [data-ls-sidebtn="1"][data-live="1"] {
      border-left: 3px solid #22c55e !important;
    }
  `,document.head.appendChild(e)}function us(){var e;return A().showSideButton!==!1&&Ee(Y()||((e=window.editorManager)==null?void 0:e.activeFile))}function fs(){return w?w.$el||w.el||w.root||(w instanceof HTMLElement?w:null):null}function ms(e,t){var o,i,s;if(!e)return!1;e.setAttribute("data-ls-sidebtn","1"),e.setAttribute("data-live",t?"1":"0");let r=!1,n=e.querySelectorAll('.text, .label, .side-button-text, [class*="text"], span, small');for(let a=0;a<n.length;a++){let p=n[a];if(!((o=p.classList)!=null&&o.contains("icon")||(i=p.classList)!=null&&i.contains("ls-side-live-dot"))&&!((s=p.children)!=null&&s.length&&p.querySelector(".icon"))){if(p.textContent="Live Server",t){let m=document.createElement("span");m.className="ls-side-live-dot",m.setAttribute("aria-hidden","true"),p.prepend(m)}r=!0}}if(!r){let a=t?"\u25CF Live Server":"Live Server";e.setAttribute("aria-label",a),e.title=a;for(let p of[...e.childNodes])p.nodeType===3&&p.textContent.trim()&&(p.textContent=a,r=!0)}return r}function Un(e){return{text:e?"\u25CF Live Server":"Live Server",icon:"public",backgroundColor:e?"#14532d":"var(--primary-color, #1e1e1e)",textColor:e?"#86efac":"var(--primary-text-color, #fff)",onclick:()=>Fi()}}function Ni(e){var r,n,o;let t=us();try{(r=w==null?void 0:w.hide)==null||r.call(w)}catch{}w=null;try{w=rr(Un(e));let i=fs();i&&ms(i,e),t?(n=w==null?void 0:w.show)==null||n.call(w):(o=w==null?void 0:w.hide)==null||o.call(w)}catch(i){console.warn("[LiveServer] recreateSideButton",i)}}function tt(e){var r,n;let t=!!e;try{if(ps(),document.body.classList.toggle("ls-server-live",t),!w&&rr&&(w=rr(Un(t))),!w)return;let o=t?"\u25CF Live Server":"Live Server";try{typeof w.setText=="function"&&w.setText(o),"text"in w&&(w.text=o),w.$text&&(w.$text.textContent=o)}catch{}let i=fs();if(!(i?ms(i,t):!1)){Ni(t);return}us()?(r=w.show)==null||r.call(w):(n=w.hide)==null||n.call(w)}catch(o){console.warn("[LiveServer] setLiveDot",o)}}async function Fi(){let t=D().running?["stop","Stop live server"]:["start","Start live server"],r=await $i("Live Server",[t,["restart","Restart server"],["port","Change port"],["root","Select root folder"],["browser","Open browser"],["deps","Check dependencies"],["settings","Settings"]],{hideOnSelect:!0});if(r){try{if(r==="start"){let{startServer:n}=await Promise.resolve().then(()=>(X(),ee));await n()}else if(r==="stop"){let{stopServer:n}=await Promise.resolve().then(()=>(X(),ee));await n()}else if(r==="restart"){let{restartServer:n}=await Promise.resolve().then(()=>(X(),ee));await n()}else if(r==="port"){let{changePortAndRestart:n}=await Promise.resolve().then(()=>(X(),ee));await n()}else if(r==="root"){let{pickRootFolder:n}=await Promise.resolve().then(()=>(ft(),$t));await n()}else if(r==="browser"){let{openBrowser:n}=await Promise.resolve().then(()=>(et(),Qe)),o=D().url||"http://127.0.0.1:"+(D().port||8080)+"/";n(o,{restoreOnly:!0})}else if(r==="deps"){let{checkDependenciesAction:n}=await Promise.resolve().then(()=>(Be(),zt));await n()}else if(r==="settings"){let{openSettingsHub:n}=await Promise.resolve().then(()=>(Yt(),Cr));n()}}catch(n){ji(String((n==null?void 0:n.message)||n),2500)}tt(D().running)}}function Wn(){if(A().showSideButton!==!1){ps();try{let e=D().running;!w&&rr&&(w=rr(Un(e))),tt(e)}catch(e){console.warn("[LiveServer] side button",e)}}}function Gn(){tt(D().running)}function Vn(){var e;try{(e=w==null?void 0:w.hide)==null||e.call(w)}catch{}w=null,document.body.classList.remove("ls-server-live")}var rr,$i,ji,w,Xn=T(()=>{ne();Le();oe();rr=acode.require("sideButton"),$i=acode.require("select"),ji=acode.require("toast"),w=null});function gs(){let e=[];return nr.forEach(t=>{e.includes(t.category)||e.push(t.category)}),e}function We(e){let t=A();return t[e]!==void 0?t[e]:Mt[e]}function vs(e){if(e.checkbox||e.noValue)return"";let t=We(e.key);if(e.select){let n=e.select.find(o=>String(Array.isArray(o)?o[0]:o)===String(t));return n?Array.isArray(n)?n[1]:n:String(t!=null?t:"")}if(e.secret)return t?"\u2022\u2022\u2022\u2022\u2022\u2022":"";let r=t==null?"":String(t);return r.length>28?r.slice(0,27)+"\u2026":r}async function Wi(e){try{if(e==="start")return(await Promise.resolve().then(()=>(X(),ee))).startServer();if(e==="stop")return(await Promise.resolve().then(()=>(X(),ee))).stopServer();if(e==="restart")return(await Promise.resolve().then(()=>(X(),ee))).restartServer();if(e==="open"){let r=(await Promise.resolve().then(()=>(oe(),ze))).getServerStatus();return r.running?(await Promise.resolve().then(()=>(et(),Qe))).openBrowser(r.url||"http://127.0.0.1:"+r.port+"/",{restoreOnly:!0}):Ue("Server is not running",2e3)}if(e==="root")return(await Promise.resolve().then(()=>(ft(),$t))).pickRootFolder();if(e==="status"){let r=(await Promise.resolve().then(()=>(oe(),ze))).getServerStatus();return Ue(r.running?(r.url||"")+" \u2014 port "+r.port:"Not running",3e3)}if(e==="deps")return(await Promise.resolve().then(()=>(Be(),zt))).checkDependenciesAction();if(e==="chromium")return(await Promise.resolve().then(()=>(at(),Zr))).showChromiumInstallerPopup({startImmediately:!1});if(e==="reinstall")return(await Promise.resolve().then(()=>(Be(),zt))).reinstallDependenciesAction()}catch(t){Ue(String((t==null?void 0:t.message)||t),3e3)}}async function or(e,t){if(e==="__action")return await Wi(t),!0;if(e==="__browserAction"){try{t==="clearHistory"?((await Promise.resolve().then(()=>(Cn(),Io))).clearVisited(),Ue("Browser history cleared",1800)):t==="clearBookmarks"&&(q("browserBookmarks",[]),Ue("Bookmarks cleared",1800))}catch(n){Ue(String((n==null?void 0:n.message)||n),2500)}return!0}let r=t;if(e==="port"){let n=parseInt(String(t),10);if(!Number.isFinite(n)||n<1||n>65535)return Ue("Invalid port",1800),!1;r=n}else if(e==="autoShutdownMinutes"){let n=parseInt(String(t),10);if(!Number.isFinite(n)||n<0)return Ue("Invalid number",1800),!1;r=n}else if(e==="browserOpacity"){let n=parseFloat(String(t));r=Number.isFinite(n)?Math.min(1,Math.max(.1,Math.round(n*100)/100)):1}if(q(e,r),e==="externalSiteMode"&&r==="chromium")try{let{isChromiumInstalled:n}=await Promise.resolve().then(()=>(Be(),zt)),o=await n();if(q("chromiumInstalled",o),!o){let{showChromiumInstallerPopup:i}=await Promise.resolve().then(()=>(at(),Zr));i({startImmediately:!1})}}catch{}if(e==="showSideButton")try{let n=await Promise.resolve().then(()=>(Xn(),hs));r===!1?n.unregisterSideButton():n.registerSideButton()}catch{}return!0}function bs(){return{list:nr.map(t=>{let r={key:t.key,text:t.text,category:t.category};return t.info&&(r.info=t.info),t.checkbox?(r.checkbox=!0,r.value=!!We(t.key)):t.select?(r.select=t.select,t.noValue?(r.value="",r.valueText=()=>"Choose\u2026"):r.value=t.asString?String(We(t.key)):We(t.key)):t.prompt&&(r.prompt=t.prompt,t.promptType&&(r.promptType=t.promptType),r.value=We(t.key),t.secret&&(r.valueText=n=>n?"\u2022\u2022\u2022\u2022\u2022\u2022":"")),r}),cb:(t,r)=>{or(t,r)}}}var Ue,Ui,nr,Kn=T(()=>{Fr();ne();Ue=acode.require("toast"),Ui=[["start","Start server"],["stop","Stop server"],["restart","Restart server"],["open","Open browser"],["root","Select root folder"],["status","Show server status"],["deps","Check dependencies"],["chromium","Install Chromium (for heavy sites)"],["reinstall","Reinstall dependencies"]],nr=[{key:"__action",category:"Actions",text:"Run action",info:"Start / stop / open browser / dependencies",select:Ui,noValue:!0},{key:"port",category:"General",text:"Port",info:"Default 8080",prompt:"Port number",promptType:"number"},{key:"bindAddress",category:"General",text:"Bind address",select:[["127.0.0.1","Localhost only (127.0.0.1)"],["0.0.0.0","All interfaces (0.0.0.0)"]]},{key:"rootFolder",category:"General",text:"Root folder",info:"Empty = folder of the active HTML file",prompt:"Absolute folder path",promptType:"text"},{key:"liveReload",category:"General",text:"Live reload on save",checkbox:!0},{key:"openBrowserOnStart",category:"General",text:"Open browser on start",checkbox:!0},{key:"autoShutdownMinutes",category:"General",text:"Auto shutdown (minutes)",info:"0 = off",prompt:"Minutes (0 = off)",promptType:"number"},{key:"browserDisplayMode",category:"Browser",text:"Show browser in",info:"Acode page or editor tab",select:[["inPage","Acode page (default)"],["editorTab","Editor tab"]]},{key:"browserSearchEngine",category:"Browser",text:"Search engine",info:"Used when searching keywords in address bar or New Tab",select:[["google","Google"],["duckduckgo","DuckDuckGo"],["bing","Bing"],["brave","Brave Search"]]},{key:"externalSiteMode",category:"Browser",text:"External websites",info:"Proxy auto-switches to Chromium if slow, or select Chromium directly",select:[["proxy","Local Node.js Reverse Proxy (Default)"],["chromium","Headless Chromium (Always)"],["acodeWebview","Acode Native WebView (Fullscreen)"],["inApp","Direct iframe (without proxy)"],["systemBrowser","Chrome / External system browser"]]},{key:"browserHomeUrl",category:"Browser",text:"Home button URL",info:"Empty = Green Fox Homepage",prompt:"Home URL (leave empty for Green Fox Homepage)",promptType:"text"},{key:"browserOpacity",category:"Browser",text:"Browser opacity",info:"0.1 - 1.0 (page mode)",asString:!0,select:["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1"].map(e=>[e,e])},{key:"browserOverlay",category:"Browser",text:"Preview as overlay",info:"See-through preview over the editor; you can still type in the editor",checkbox:!0},{key:"overlayAutoSave",category:"Browser",text:"Auto-save in overlay mode",info:"Saves the file after you stop typing so the preview updates live",checkbox:!0},{key:"showAddressBar",category:"Browser",text:"Show address bar",checkbox:!0},{key:"showSideButton",category:"Browser",text:"Show side button",checkbox:!0},{key:"__browserAction",category:"Browser",text:"Browser data",info:"Clear recent history or saved bookmarks",select:[["clearHistory","Clear recent history"],["clearBookmarks","Clear all bookmarks"]],noValue:!0},{key:"directoryListing",category:"HTML / static",text:"Enable directory listing",checkbox:!0},{key:"enableCors",category:"HTML / static",text:"Enable CORS",checkbox:!0},{key:"customCharset",category:"HTML / static",text:"Custom charset",prompt:"Charset",promptType:"text"},{key:"customHeaders",category:"HTML / static",text:"Custom response headers",info:'One "Header: value" per line',prompt:"Custom headers",promptType:"textarea"},{key:"bindLocalhostOnly",category:"Security",text:"Prefer localhost bind",checkbox:!0},{key:"ipWhitelist",category:"Security",text:"Client IP whitelist",info:"Comma or newline separated; empty = all",prompt:"IP whitelist",promptType:"textarea"},{key:"basicAuthUser",category:"Security",text:"Basic auth user",prompt:"User name",promptType:"text"},{key:"basicAuthPass",category:"Security",text:"Basic auth password",prompt:"Password",promptType:"text",secret:!0}]});var Cr={};fe(Cr,{openSettingsHub:()=>ta,registerPluginSettings:()=>Es});function Zi(){if(document.getElementById("ls-settings-css"))return;let e=document.createElement("style");e.id="ls-settings-css",e.textContent=Yi,document.head.appendChild(e)}function Re(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.textContent=r),n}function ks(e,t,r,n){let o=Re("div","ls-set-row");o.setAttribute("role","button"),o.tabIndex=0;let i=Re("div","ls-set-main");return i.appendChild(Re("div","ls-set-title",e)),t&&i.appendChild(Re("div","ls-set-info",t)),o.appendChild(i),r&&o.appendChild(r),o.addEventListener("click",n),o}function Ss(){let e=Re("span","ls-set-chev");return e.innerHTML=Gt(Ki,16),e}async function Ji(e,t){let r=We(e.key);if(e.checkbox)return await or(e.key,!r),t();if(e.select){let n=await Vi(e.text,e.select,{hideOnSelect:!0,default:e.noValue?void 0:String(r)});n!=null&&(await or(e.key,n),t());return}if(e.prompt){let n=e.promptType==="number"?"number":e.promptType==="textarea"?"textarea":"text",o=await Xi(e.prompt,r==null?"":String(r),n);o!=null&&(await or(e.key,o),t())}}function Qi(e,t){e.textContent="",gs().forEach(r=>{let n=nr.filter(o=>o.category===r).length;e.appendChild(ks(r,n+" options",Ss(),()=>t(r)))})}function ea(e,t,r){e.textContent="",nr.filter(n=>n.category===t).forEach(n=>{let o=null;if(n.checkbox)o=Re("span","ls-set-switch"+(We(n.key)?" is-on":""));else{o=Re("span"),o.style.cssText="display:flex;align-items:center;gap:6px;min-width:0;max-width:50%";let i=vs(n);i&&o.appendChild(Re("span","ls-set-val",i)),o.appendChild(Ss())}e.appendChild(ks(n.text,n.info,o,()=>Ji(n,r)))})}function ws(e,t,r){var p,m;Zi();let n=document.createElement("span");n.className="icon arrow_back",n.dataset.action="back",n.style.cssText="pointer-events:auto;cursor:pointer;";let o=Gi(e,{lead:n}),i=Re("div","ls-set-body");try{o.appendBody(i)}catch{(p=o.appendChild)==null||p.call(o,i)}let s=()=>t(i,s),a=()=>{var d,h;try{xs.remove(r)}catch{}try{(d=o.hide)==null||d.call(o)}catch{}try{(h=o.remove)==null||h.call(o)}catch{}};n.onclick=d=>{var h,g;try{(h=d==null?void 0:d.preventDefault)==null||h.call(d),(g=d==null?void 0:d.stopPropagation)==null||g.call(d)}catch{}a()};try{xs.push({id:r,action:a})}catch{}s();try{(window.app||document.body).append(o)}catch{document.body.append(o)}try{(m=o.show)==null||m.call(o)}catch{}}function ta(){ws("Live Server",e=>Qi(e,t=>ws(t,(r,n)=>ea(r,t,n),ys+t)),ys+"hub")}function Es(){}var Gi,xs,Vi,Xi,ys,Ki,Yi,Yt=T(()=>{Kn();An();Gi=acode.require("page"),xs=acode.require("actionStack"),Vi=acode.require("select"),Xi=acode.require("prompt"),ys="liveserver-settings-",Ki="M9 18l6-6-6-6",Yi=`
.ls-set-body{height:100%;overflow:auto;padding:4px 0 24px}
.ls-set-row{display:flex;align-items:center;gap:12px;padding:12px 16px;cursor:pointer;border-bottom:1px solid rgba(128,128,128,.15)}
.ls-set-row:active{background:rgba(128,128,128,.14)}
.ls-set-main{flex:1;min-width:0}
.ls-set-title{font-size:15px}
.ls-set-info{font-size:12px;opacity:.65;margin-top:2px}
.ls-set-val{max-width:45%;font-size:12px;opacity:.75;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ls-set-chev{display:inline-flex;opacity:.55;flex-shrink:0}
.ls-set-switch{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0}
.ls-set-switch::before{content:'';position:absolute;inset:0;border-radius:3px;background:rgba(128,128,128,.45);transition:background .15s}
.ls-set-switch::after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:3px;background:#fff;transition:transform .15s}
.ls-set-switch.is-on::before{background:var(--active-color,#61afef)}
.ls-set-switch.is-on::after{transform:translateX(18px)}
`});var Nr={id:"acode.plugin.sugerserver",name:"Live Server",main:"main.js",version:"2.0.0",readme:"readme.md",icon:"icon.png",files:["acodels/","devtool/","icon.png","readme.md"],minVersionCode:290,license:"",changelogs:"changelogs.md",keywords:["Live Server","HTML","HTTP","browser","preview"],price:25,repository:"",author:{name:"Dev.Sourav",email:"devs.sourav@gmail.com",github:"Sou6900"}};Yt();Xn();Le();var Yn=acode.require("toast"),Zn=[];function Ls(){try{let e=acode.require("commands");if(!(e!=null&&e.add))return;let t=(r,n,o)=>{try{e.add({name:r,description:n,exec:o}),Zn.push(r)}catch{}};t("liveserver:run-file","Live Server: Run this file in HTTP server",async()=>{if(!Y())return Yn("Open a file in the editor first",2e3);let{startServer:n}=await Promise.resolve().then(()=>(X(),ee));await n()}),t("liveserver:select-root","Live Server: Select root folder",async()=>{let{pickRootFolder:r}=await Promise.resolve().then(()=>(ft(),$t));await r()}),t("liveserver:run-selected-root","Live Server: Run HTTP server for selected / saved root",async()=>{let{startServer:r}=await Promise.resolve().then(()=>(X(),ee)),{getSettings:n}=await Promise.resolve().then(()=>(ne(),Wr)),{rootFromSelectedFolder:o}=await Promise.resolve().then(()=>(ft(),$t)),i=n().rootFolder||o();if(!i)return Yn("Select a root folder first (command: Select root folder)",3e3);await r({root:i})}),t("liveserver:stop","Live Server: Stop server",async()=>{let{stopServer:r}=await Promise.resolve().then(()=>(X(),ee));await r()}),t("liveserver:restart","Live Server: Restart server",async()=>{let{restartServer:r}=await Promise.resolve().then(()=>(X(),ee));await r()}),t("liveserver:open-browser","Live Server: Open browser",async()=>{let{getServerStatus:r}=await Promise.resolve().then(()=>(oe(),ze)),{openBrowser:n}=await Promise.resolve().then(()=>(et(),Qe)),o=r();if(!o.running)return Yn("Server is not running",2e3);n(o.url||`http://127.0.0.1:${o.port}/`,{restoreOnly:!0})}),t("liveserver:settings","Live Server: Open settings",async()=>{let{openSettingsHub:r}=await Promise.resolve().then(()=>(Yt(),Cr));r()})}catch(e){console.warn("[LiveServer] commands",e)}}function Cs(){try{let e=acode.require("commands");Zn.forEach(t=>{var r;try{(r=e==null?void 0:e.remove)==null||r.call(e,t)}catch{}})}catch{}Zn=[]}an();Le();Le();X();var _s=acode.require("toast"),Jn=!1;async function As(e){var t;if(Jn)return!1;Jn=!0;try{let r=e||Y();if(!Ee(r))return _s("Open an .html / .htm file first",2e3),!1;if(r.isUnsaved&&(r.uri||r.url))try{await((t=r.save)==null?void 0:t.call(r))}catch(n){console.warn("[LiveServer] save before run",n)}return await tr({openBrowser:!0})}catch(r){return _s(String((r==null?void 0:r.message)||r),3e3),!1}finally{Jn=!1}}var F=null,Br=null,Qn=!1;function ra(){if(document.getElementById("ls-run-css"))return;let e=document.createElement("style");e.id="ls-run-css",e.textContent=`
    body.ls-html-file #root > header.tile > [action="run"]:not([data-ls-run]) {
      display: none !important;
    }
  `,document.head.appendChild(e)}var Ps="#root > header.tile";function na(){return document.querySelector(`${Ps} > span.icon.play_arrow[action="run"]`)||document.querySelector('[action="run"]:not([data-ls-run])')}async function oa(e){var t;if(e.preventDefault(),e.stopPropagation(),!Qn){Qn=!0;try{let r=Y()||((t=window.editorManager)==null?void 0:t.activeFile);await As(r)}catch(r){console.error("[LiveServer] runPreview failed:",r);try{acode.require("toast")((r==null?void 0:r.message)||"Failed to launch Live Server")}catch{}}finally{Qn=!1}}}function ye(){var o;ra();let e=Y()||((o=window.editorManager)==null?void 0:o.activeFile),t=Ee(e);if(document.body.classList.toggle("ls-html-file",t),!t){F!=null&&F.isConnected&&F.remove();return}F||(F=document.createElement("span"),F.className="icon play_arrow",F.setAttribute("action","run-live-server"),F.setAttribute("data-ls-run","1"),F.setAttribute("title","Run with Live Server"),F.onclick=oa),F.className="icon play_arrow";let r=na(),n=document.querySelector(Ps);r&&r.parentNode?(F.parentNode!==r.parentNode||F.nextSibling!==r)&&r.parentNode.insertBefore(F,r):n&&!F.isConnected&&n.insertBefore(F,n.lastChild)}function Ts(){ye(),window.editorManager&&(editorManager.off("switch-file",ye),editorManager.off("rename-file",ye),editorManager.on("switch-file",ye),editorManager.on("rename-file",ye)),clearInterval(Br),Br=setInterval(ye,1500)}function Ms(){var e;clearInterval(Br),Br=null,window.editorManager&&(editorManager.off("switch-file",ye),editorManager.off("rename-file",ye));try{F==null||F.remove()}catch{}F=null,document.body.classList.remove("ls-html-file"),(e=document.getElementById("ls-run-css"))==null||e.remove()}Be();X();oe();ne();oe();Le();var _t=null;function Rs(){var e;if(!_t){_t=async t=>{try{if(A().liveReload===!1)return;let r=D();if(!r.running||!r.port)return;await fetch(`http://127.0.0.1:${r.port}/reload`,{method:"POST"}).catch(()=>{}),(Ee(t)||Ee(editorManager==null?void 0:editorManager.activeFile))&&console.log("[LiveServer] reload signal after save")}catch(r){console.warn("[LiveServer] save reload",r)}};try{(e=editorManager==null?void 0:editorManager.on)==null||e.call(editorManager,"save-file",_t)}catch{}}}function Is(){var e;try{_t&&((e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"save-file",_t))}catch{}_t=null}var eo=null;function Os(){eo&&(eo(!1),eo=null)}xr();at();var Hs=["switch-file","rename-file","file-loaded","new-file"],Dr="",sr=null,rt=null,ir=null;async function qs(e){Dr=e||"",jn(Dr),Lo(Dr),en();try{let{getSettings:r,updateSetting:n}=await Promise.resolve().then(()=>(ne(),Wr)),o=r().acodelsPath||"";/^\/public|com\.termux/.test(String(o))&&n("acodelsPath","")}catch{}try{}catch(r){console.warn("[LiveServer] settings",r)}try{Wn()}catch(r){console.warn("[LiveServer] side",r)}try{Ls()}catch(r){console.warn("[LiveServer] commands",r)}try{Rs()}catch(r){console.warn("[LiveServer] liveReload",r)}try{Ts()}catch(r){console.warn("[LiveServer] run button",r)}sr=()=>{Gn(),ye()},Hs.forEach(r=>{var n;try{(n=editorManager==null?void 0:editorManager.on)==null||n.call(editorManager,r,sr)}catch{}}),rt=()=>tt(D().running);try{window.addEventListener("liveserver-status",rt),window.addEventListener("liveserver-started",rt),window.addEventListener("liveserver-stopped",rt)}catch{}let t=async()=>{let r=await Fn();tt(r)};t(),setTimeout(t,1200),setTimeout(sr,400),ir=()=>{document.visibilityState==="visible"&&t()},document.addEventListener("visibilitychange",ir);try{window.addEventListener("liveserver-settings",async()=>{try{let{reapplySetup:r}=await Promise.resolve().then(()=>(X(),ee));D().running&&await r()}catch{}})}catch{}console.log("[LiveServer] v2 init",Dr)}function Bs(){Hs.forEach(e=>{var t;try{sr&&((t=editorManager==null?void 0:editorManager.off)==null||t.call(editorManager,e,sr))}catch{}});try{Ms()}catch{}try{window.removeEventListener("liveserver-status",rt),window.removeEventListener("liveserver-started",rt),window.removeEventListener("liveserver-stopped",rt)}catch{}ir&&(document.removeEventListener("visibilitychange",ir),ir=null),Os(),xo(),Vn(),Cs();try{Is()}catch{}try{Promise.resolve().then(()=>(et(),Qe)).then(e=>{var t;return(t=e.hideBrowser)==null?void 0:t.call(e)})}catch{}try{Promise.resolve().then(()=>(Hn(),Qo)).then(e=>{var t;return(t=e.destroyAcodeWebview)==null?void 0:t.call(e)})}catch{}fr()}Kn();var zr=class{constructor(){this.baseUrl=""}async init(t){var r;this.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await qs(this.baseUrl)}async destroy(){Bs()}};if(window.acode){let e=new zr;acode.setPluginInit(Nr.id,async t=>{var r;e.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await e.init(e.baseUrl)},bs()),acode.setPluginUnmount(Nr.id,()=>{e.destroy()})}var fc=zr;})();
