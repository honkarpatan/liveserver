(()=>{var ei=Object.defineProperty;var C=(e,t)=>()=>(e&&(t=e(e=0)),t);var xe=(e,t)=>{for(var r in t)ei(e,r,{get:t[r],enumerable:!0})};var Pt,Gr=C(()=>{Pt={pluginEnabled:!0,port:8080,bindAddress:"127.0.0.1",rootFolder:"",rootFolderUri:"",lastMirrorRoot:"",liveReload:!0,openBrowserOnStart:!0,directoryListing:!0,autoShutdownMinutes:0,browserDisplayMode:"inPage",browserSearchEngine:"google",externalSiteMode:"proxy",browserHomeUrl:"",showSideButton:!0,sideButtonRunningLabel:"{HOST}:{PORT}",sideButtonOfflineLabel:"Go Live",browserOpacity:1,browserOverlay:!1,overlayAutoSave:!0,browserBookmarks:[],browserDevice:{on:!1,id:"responsive",w:390,h:844,zoom:"fit"},enableCors:!0,customHeaders:"",customCharset:"utf-8",bindLocalhostOnly:!0,ipWhitelist:"",basicAuthUser:"",basicAuthPass:"",dependenciesInstalled:!1,acodelsPath:"",showAddressBar:!0}});var Mt={};xe(Mt,{getPluginId:()=>ri,getSettings:()=>k,saveSettingsPatch:()=>ni,updateSetting:()=>M});function ri(){return Xr}function k(){var e;try{let t=acode.require("settings"),r=(e=t==null?void 0:t.value)==null?void 0:e[Xr];return(!r||typeof r!="object")&&(r={...Pt},t!=null&&t.value&&(t.value[Xr]=r)),r}catch{return{...Pt}}}function M(e,t){let r=k();r[e]=t;try{acode.require("settings").update(!1)}catch{}try{window.dispatchEvent(new CustomEvent("liveserver-settings",{detail:{key:e,value:t}}))}catch{}}function ni(e){let t=k();Object.assign(t,e);try{acode.require("settings").update(!1)}catch{}}var Xr,re=C(()=>{Gr();Xr="acode.plugin.sugerserver"});function Ee(e){return String(e!=null?e:"").replace(/'/g,`'"'"'`)}function Vr(e){let t=String(e||"").trim();return t?/^sh\s+-c\s+/i.test(t)?t:`sh -c '${Ee(t)}'`:"sh -c 'true'"}function Ot(e){return String(e||"").split(`
`).filter(t=>!/proot warning:/i.test(t)).join(`
`)}function lo(e){if(e==null)return"";if(typeof e=="string")return Ot(e);if(typeof e=="object"){let t=[e.stdout,e.stderr,e.output,e.message].filter(r=>r!=null&&r!=="").map(String);if(t.length)return Ot(t.join(`
`));try{return Ot(JSON.stringify(e))}catch{return Ot(String(e))}}return Ot(String(e))}function Yr(e){try{return btoa(unescape(encodeURIComponent(e)))}catch{let r=new TextEncoder().encode(e),n="";return r.forEach(o=>{n+=String.fromCharCode(o)}),btoa(n)}}function lt(){try{let e=acode.require("terminal"),t=typeof Executor!="undefined"&&Executor||window.Executor||globalThis.Executor||(e==null?void 0:e.Executor)||null;if(t!=null&&t.execute)return t}catch{}return null}async function ne(e,t={}){let r=typeof t=="number"?t:t.timeoutMs||0,n=typeof t=="object"&&t.alpine!==!1,o=lt();if(!(o!=null&&o.execute))throw console.warn("[LiveServer:exec] no executor",{hasWindow:!!window.Executor,hasGlobal:!!globalThis.Executor,hasTerminal:!!acode.require("terminal")}),new Error("Executor not available. Open Acode Terminal once (or install Executor), then retry.");let i=Vr(e);console.log("[LiveServer:exec] run len=",i.length);let s=async()=>{try{let d=await o.execute(i,n),f=lo(d);return console.log("[LiveServer:exec] ok len=",f.length),f}catch(d){let f=lo(d)||d&&d.message||String(d);return console.warn("[LiveServer:exec] catch \u2192",String(f).slice(0,240)),f}};return r>0?Promise.race([s(),new Promise(d=>setTimeout(()=>{console.warn("[LiveServer:exec] timeout",r,"ms \u2014 continuing"),d("")},r))]):s()}async function Ht(e,t={}){let r=Yr(String(e||""));return ne(`echo '${Ee(r)}' | base64 -d | sh`,{timeoutMs:t.timeoutMs||0,alpine:t.alpine!==!1})}async function Zr(e){try{let t=await ne(`command -v ${Ee(e)} 2>/dev/null || which ${Ee(e)} 2>/dev/null || echo MISS`,{timeoutMs:2e4}),r=String(t||"").trim();return!r||/MISS|not found/i.test(r)?!1:/\//.test(r)||r.split(`
`).some(n=>n.includes("/"))}catch(t){return console.warn("[LiveServer:exec] commandExists",e,(t==null?void 0:t.message)||t),!1}}var ct=C(()=>{});function co(){let e=document.getElementById("ls-deps-picker-css");e&&e.remove();let t=document.createElement("style");t.id="ls-deps-picker-css",t.textContent=`
#ls-deps-picker {
  position: fixed;
  inset: 0;
  z-index: 100005;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background: rgba(0, 0, 0, 0.56);
  backdrop-filter: blur(3px);
  animation: ls-dp-in 0.18s ease-out;
}
@keyframes ls-dp-in {
  from { opacity: 0; }
  to { opacity: 1; }
}
#ls-deps-picker.ls-dp-leaving {
  opacity: 0;
  transition: opacity 0.16s ease;
}
.ls-dp-backdrop {
  position: absolute;
  inset: 0;
}
.ls-dp-card {
  position: relative;
  z-index: 1;
  width: min(440px, 94vw);
  max-height: min(82vh, 580px);
  display: flex;
  flex-direction: column;
  border-radius: 8px;
  background: var(--popup-background-color, var(--secondary-color, #1e1f22));
  color: var(--popup-text-color, var(--primary-text-color, var(--color, #e8eaed)));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.28));
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.52);
  overflow: hidden;
  font-family: inherit;
}

/* ---- Linux Window Titlebar ---- */
.ls-dp-titlebar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.24));
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-title-left {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}
.ls-dp-dots {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex-shrink: 0;
}
.ls-dp-dots span {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  display: inline-block;
}
.ls-dp-dots span:nth-child(1) { background: #ef4444; }
.ls-dp-dots span:nth-child(2) { background: #f59e0b; }
.ls-dp-dots span:nth-child(3) { background: #22c55e; }
.ls-dp-title {
  font-weight: 600;
  font-size: 14px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ls-dp-subbar {
  padding: 8px 16px;
  font-size: 12px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.85;
  background: rgba(128, 128, 128, 0.06);
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.16));
  flex-shrink: 0;
}

/* ---- Body ---- */
.ls-dp-body {
  flex: 1;
  overflow-y: auto;
  padding: 12px 15px;
  min-height: 90px;
}
.ls-dp-checking {
  display: flex;
  align-items: center;
  gap: 10px;
  justify-content: center;
  padding: 26px 8px;
  font-size: 13px;
}
.ls-dp-spinner {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid rgba(128, 128, 128, 0.3);
  border-top-color: var(--active-color, #22c55e);
  animation: ls-spin 0.7s linear infinite;
  flex-shrink: 0;
}
@keyframes ls-spin {
  to { transform: rotate(360deg); }
}

/* ---- Package Rows ---- */
.ls-dp-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 11px;
  border-radius: 6px;
  margin-bottom: 7px;
  background: var(--primary-color, rgba(128, 128, 128, 0.1));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
  cursor: pointer;
  transition: border-color 0.15s ease;
}
.ls-dp-row:last-child {
  margin-bottom: 0;
}
.ls-dp-row.is-present {
  opacity: 0.78;
  cursor: default;
}
.ls-dp-row input[type="checkbox"] {
  width: 1.12rem;
  height: 1.12rem;
  flex-shrink: 0;
  accent-color: var(--active-color, #22c55e);
}
.ls-dp-row-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.ls-dp-name {
  font-weight: 600;
  font-size: 13px;
}
.ls-dp-desc {
  font-size: 11.5px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.75;
  word-break: break-word;
}
.ls-dp-status {
  font-size: 11px;
  flex-shrink: 0;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 4px;
}
.ls-dp-status.ok {
  background: rgba(34, 197, 94, 0.16);
  color: #4ade80;
}
.ls-dp-status.miss {
  background: rgba(239, 68, 68, 0.16);
  color: #f87171;
}
.ls-dp-status.opt {
  background: rgba(128, 128, 128, 0.18);
  color: var(--secondary-text-color, #9aa0a6);
}

/* ---- Linux Installation Progress View ---- */
.ls-dp-progress {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ls-dp-warn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 11px;
  border-radius: 5px;
  background: rgba(245, 158, 11, 0.14);
  border: 1px solid rgba(245, 158, 11, 0.35);
  color: #fbbf24;
  font-size: 12px;
  font-weight: 500;
}
.ls-dp-prog-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  font-size: 12.5px;
}
.ls-dp-progress-info {
  opacity: 0.92;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ls-dp-pct {
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  color: var(--active-color, #22c55e);
  flex-shrink: 0;
}
.ls-dp-progress-track {
  width: 100%;
  height: 8px;
  border-radius: 99px;
  background: var(--primary-color, rgba(128, 128, 128, 0.25));
  overflow: hidden;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
}
.ls-dp-progress-bar {
  height: 100%;
  width: 0%;
  border-radius: 99px;
  background: var(--active-color, #22c55e);
  transition: width 0.28s ease;
}
.ls-dp-link {
  align-self: flex-start;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  color: var(--active-color, #61afef);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  padding: 2px 0;
  font-family: inherit;
}
.ls-dp-log {
  margin: 0;
  max-height: 155px;
  overflow-y: auto;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 11px;
  line-height: 1.4;
  background: #0d1117;
  color: #c9d1d9;
  padding: 10px;
  border-radius: 5px;
  white-space: pre-wrap;
  word-break: break-word;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.25));
}

/* ---- Footer ---- */
.ls-dp-footer {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.18));
  border-top: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-btn {
  border: none;
  border-radius: 5px;
  padding: 8px 14px;
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  background: rgba(128, 128, 128, 0.22);
  color: inherit;
  font-family: inherit;
}
.ls-dp-btn:active {
  opacity: 0.85;
}
.ls-dp-btn.ls-dp-install,
.ls-dp-btn.ls-dp-done {
  background: var(--active-color, #22c55e);
  color: var(--button-text-color, #0b1116);
}
.ls-dp-btn.ls-dp-cancel {
  background: rgba(239, 68, 68, 0.18);
  color: #f87171;
  border: 1px solid rgba(239, 68, 68, 0.38);
}
.ls-dp-empty {
  opacity: 0.7;
  padding: 14px;
  text-align: center;
  font-size: 13px;
}
  `,document.head.appendChild(t)}var uo=C(()=>{});function Bt(e){return String(e!=null?e:"").replace(/&/g,"&").replace(/</g,"<").replace(/>/g,">").replace(/"/g,'"')}function fo(){return!!O}function Kr(){return Dt}function ho(){Dt=!1}function mo(e={}){co(),po(!0),Dt=!1;let t=e.title||"Live Server Dependencies",r=e.subtitle||"Checking Alpine Linux packages...",n=Array.isArray(e.items)?e.items.slice():[];return new Promise(o=>{dt=o,O=document.createElement("div"),O.id="ls-deps-picker",O.innerHTML=`
      <div class="ls-dp-backdrop"></div>
      <div class="ls-dp-card" role="dialog" aria-modal="true">
        <div class="ls-dp-titlebar">
          <div class="ls-dp-title-left">
            <span class="ls-dp-dots"><span></span><span></span><span></span></span>
            <div class="ls-dp-title">${Bt(t)}</div>
          </div>
        </div>
        <div class="ls-dp-subbar ls-dp-subtitle">${Bt(r)}</div>

        <div class="ls-dp-body">
          <div class="ls-dp-checking" style="display:${e.checking?"flex":"none"}">
            <span class="ls-dp-spinner"></span>
            <span>Scanning Alpine environment...</span>
          </div>

          <div class="ls-dp-lists" style="display:${e.checking?"none":"block"}"></div>

          <div class="ls-dp-progress" style="display:none">
            <div class="ls-dp-warn">
              <span>\u26A0</span>
              <span>Don't close Acode while packages are installing.</span>
            </div>

            <div class="ls-dp-prog-top">
              <div class="ls-dp-progress-info">Preparing installation...</div>
              <span class="ls-dp-pct">0%</span>
            </div>

            <div class="ls-dp-progress-track">
              <div class="ls-dp-progress-bar" style="width:0%"></div>
            </div>

            <button type="button" class="ls-dp-link ls-dp-toggle-log">
              <span class="ls-dp-arrow">\u25B8</span>
              <span class="ls-dp-more-label">Show more</span>
            </button>
            <pre class="ls-dp-log" style="display:none"></pre>
          </div>
        </div>

        <div class="ls-dp-footer">
          <button type="button" class="ls-dp-btn ls-dp-notnow">Not now</button>
          <button type="button" class="ls-dp-btn ls-dp-cancel" style="display:none">Cancel installation</button>
          <button type="button" class="ls-dp-btn ls-dp-install">Install selected</button>
          <button type="button" class="ls-dp-btn ls-dp-done" style="display:none">Close</button>
        </div>
      </div>`,document.body.appendChild(O);let i=O.querySelector(".ls-dp-lists"),s=O.querySelector(".ls-dp-checking"),d=O.querySelector(".ls-dp-progress"),f=O.querySelector(".ls-dp-progress-bar"),l=O.querySelector(".ls-dp-pct"),c=O.querySelector(".ls-dp-progress-info"),p=O.querySelector(".ls-dp-log"),g=O.querySelector(".ls-dp-install"),a=O.querySelector(".ls-dp-notnow"),m=O.querySelector(".ls-dp-cancel"),y=O.querySelector(".ls-dp-done"),q=O.querySelector(".ls-dp-toggle-log"),b=O.querySelector(".ls-dp-arrow"),L=O.querySelector(".ls-dp-more-label"),R=O.querySelector(".ls-dp-subtitle"),_=O.querySelector(".ls-dp-backdrop");function v(){if(!i)return;let h="";for(let x of n){let ee=x.present?'<span class="ls-dp-status ok">installed</span>':x.optional?'<span class="ls-dp-status opt">optional</span>':'<span class="ls-dp-status miss">missing</span>',be=x.checked!=null?!!x.checked:!x.present&&!x.optional;h+=`<label class="ls-dp-row ${x.present?"is-present":"is-missing"}">
          <input type="checkbox" data-id="${Bt(x.id)}" ${be?"checked":""} ${x.present?"disabled":""}/>
          <span class="ls-dp-row-main">
            <span class="ls-dp-name">${Bt(x.label)}</span>
            <span class="ls-dp-desc">${Bt(x.desc||"")}</span>
          </span>${ee}</label>`}i.innerHTML=h||'<div class="ls-dp-empty">No items</div>'}function P(){let h=[];return O==null||O.querySelectorAll("input[type=checkbox][data-id]:checked:not(:disabled)").forEach(x=>h.push(x.getAttribute("data-id"))),h}function I(h){let x=P(),ee=dt;dt=null,po(!1),ee&&ee({action:h,selected:x})}function H(){let h=P();if(!h.length){try{acode.require("toast")("Select at least one item",2e3)}catch{}return}Dt=!1,i&&(i.style.display="none"),s&&(s.style.display="none"),d&&(d.style.display="flex"),g&&(g.style.display="none"),a&&(a.style.display="none"),m&&(m.style.display="inline-block"),y&&(y.style.display="none"),f&&(f.style.width="2%"),l&&(l.textContent="2%"),c&&(c.textContent="Initializing package installer..."),p&&(p.textContent=""),R&&(R.textContent="Installing selected packages in Alpine Linux...");let x=dt;dt=null,x&&x({action:"install",selected:h,keepOpen:!0})}g==null||g.addEventListener("click",()=>H()),a==null||a.addEventListener("click",()=>I("notnow")),m==null||m.addEventListener("click",()=>{Dt=!0,c&&(c.textContent="Cancelled"),I("cancel")}),y==null||y.addEventListener("click",()=>I("done")),_==null||_.addEventListener("click",()=>{d&&d.style.display!=="none"&&(m==null?void 0:m.style.display)!=="none"||I("close")}),q==null||q.addEventListener("click",()=>{if(!p)return;let h=p.style.display!=="none";p.style.display=h?"none":"block",b&&(b.textContent=h?"\u25B8":"\u25BE"),L&&(L.textContent=h?"Show more":"Show less"),h||(p.scrollTop=p.scrollHeight)}),O._lsDpUpdate=h=>{if(h.checking===!1&&s&&i&&(s.style.display="none",i.style.display="block"),h.checking===!0&&s&&i&&(s.style.display="flex",i.style.display="none"),h.subtitle!=null&&R&&(R.textContent=h.subtitle),Array.isArray(h.items)&&(n.length=0,h.items.forEach(x=>n.push({...x,checked:x.checked!=null?!!x.checked:!x.present&&!x.optional})),v()),h.progressMode&&(i&&(i.style.display="none"),s&&(s.style.display="none"),d&&(d.style.display="flex"),g&&(g.style.display="none"),a&&(a.style.display="none"),m&&(m.style.display=h.showDone?"none":"inline-block"),y&&(y.style.display=h.showDone?"inline-block":"none")),typeof h.percent=="number"){let x=Math.max(0,Math.min(100,Math.round(h.percent)));f&&(f.style.width=x+"%"),l&&(l.textContent=x+"%")}h.info&&c&&(c.textContent=h.info),h.logAppend&&p&&(p.textContent+=h.logAppend,p.scrollTop=p.scrollHeight),h.logSet!=null&&p&&(p.textContent=h.logSet)},v()})}function pe(e){O&&typeof O._lsDpUpdate=="function"&&O._lsDpUpdate(e)}function po(e){if(!O)return;let t=O;O=null,dt=null;try{t.classList.add("ls-dp-leaving")}catch{}let r=()=>{try{t.remove()}catch{}};e?r():setTimeout(r,180)}var O,dt,Dt,go=C(()=>{uo();O=null,dt=null,Dt=!1});var pr={};xe(pr,{DEP_CATALOG:()=>lr,checkDependenciesAction:()=>ci,ensureLiveServerDeps:()=>ur,reinstallDependenciesAction:()=>di,resetDepsSession:()=>en,resolveAcodelsPath:()=>ft,scanAllDeps:()=>Qr,showDepsPickerFlow:()=>dr,verifyDependencies:()=>qt});async function ft(){let e=k();try{let r=await ne(`for d in /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do
  [ -f "$d/index.js" ] || continue
  if [ -d "$d/node_modules/express" ]; then echo "FULL:$d"; exit 0; fi
  echo "BARE:$d"
done
exit 0`,{timeoutMs:12e3}),n=String(r||"").split(`
`).map(f=>f.trim()).filter(Boolean),o=n.filter(f=>f.startsWith("FULL:")).map(f=>f.slice(5)),i=n.filter(f=>f.startsWith("BARE:")).map(f=>f.slice(5)),s=f=>f.filter(c=>c&&!c.startsWith("/public")).sort((c,p)=>(p.startsWith("/root")?1:0)-(c.startsWith("/root")?1:0))[0]||f.find(c=>c&&!c.startsWith("/public"))||f[0]||null,d=s(o)||s(i);if(d){try{M("acodelsPath",d)}catch{}return d}}catch(r){console.warn("[LiveServer:deps] probe",(r==null?void 0:r.message)||r)}let t=String(e.acodelsPath||"").trim();if(t&&!t.startsWith("/public")&&!t.includes("com.termux"))return t;try{t&&M("acodelsPath","")}catch{}return"/root/.acode_liveserver/acodels"}async function si(e){try{let t=e?Ee(e):"''",r=await ne("for d in "+t+' /root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do [ -d "$d/node_modules/express" ] && [ -d "$d/node_modules/ws" ] && echo OK && exit 0; done; echo MISS',{timeoutMs:1e4});return String(r).includes("OK")}catch{return!1}}async function Qr(e){Be=e||Be;let t=await Zr("node"),r=await Zr("npm"),n=await ft(e),o=t?await si(n):!1;return[{...lr[0],present:t},{...lr[1],present:r},{...lr[2],present:o,path:n}]}async function qt(e){let t=await Qr(e),r=t.filter(n=>!n.present).map(n=>n.id);return{ok:r.length===0,missing:r,all:t}}function ii(e){return e.map(t=>({id:t.id,label:t.label,desc:t.desc+(t.path?` \u2014 ${t.path}`:""),present:t.present,optional:!1,checked:!t.present}))}async function ai(){return Ht(`#!/bin/sh
set +e
echo "[pm] detecting..."
if command -v pkg >/dev/null 2>&1; then
  echo "[pm] termux pkg"
  pkg update -y 2>&1
  pkg install -y nodejs 2>&1 || pkg install -y nodejs-lts 2>&1
elif command -v apk >/dev/null 2>&1; then
  echo "[pm] apk"
  apk update 2>&1
  apk add --no-cache nodejs npm 2>&1
elif command -v apt-get >/dev/null 2>&1; then
  echo "[pm] apt"
  apt-get update -y 2>&1
  apt-get install -y nodejs npm 2>&1
else
  echo "[pm] none found"
  exit 1
fi
node -v 2>&1
npm -v 2>&1
echo "[done] node packages"
`,{timeoutMs:0})}async function li(e){let t=`#!/bin/sh
set +e
DIR=${Ee(e)}
case "$DIR" in
  '$HOME'/*|$HOME/*) DIR="/root/.acode_liveserver/acodels" ;;
esac
if [ -z "$DIR" ] || echo "$DIR" | grep -q com.termux; then
  DIR="/root/.acode_liveserver/acodels"
fi
mkdir -p "$DIR" 2>&1
cd "$DIR" || { echo "[acodels] cd failed"; exit 1; }
if [ ! -f package.json ]; then
  cat > package.json << 'JSON'
{
  "name": "acodels",
  "version": "1.0.0",
  "main": "index.js",
  "dependencies": {
    "chokidar": "^3.5.3",
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "ws": "^8.11.0"
  }
}
JSON
fi
echo "[acodels] npm install in $DIR"
npm install --omit=dev --no-audit --no-fund 2>&1
echo "[done] acodels"
`;return Ht(t,{timeoutMs:0})}async function dr(e={}){var s,d,f;let t=e.baseUrl||Be||"";if(Be=t,ut)return Jr("Install already running...",2e3),!1;if(fo()&&!e.force||!e.force&&!e.fromSettings&&pt)return!1;if(!e.force&&!e.fromSettings&&(await qt(t)).ok)return M("dependenciesInstalled",!0),!0;(s=lt())!=null&&s.execute||Jr("Open Acode Terminal once, then retry Install",3500);let r=mo({title:"Live Server Dependencies",subtitle:"Checking...",items:[],checking:!0}),n;try{n=await Qr(t)}catch(l){return pe({checking:!1,subtitle:"Check failed \u2014 "+((l==null?void 0:l.message)||l),items:[]}),await r,!1}let o=n.filter(l=>l.required!==!1&&!l.present).length;pe({checking:!1,subtitle:o===0?"All required tools present":`${o} required missing \u2014 tick what to install`,items:ii(n)});let i=await r;if(i.action==="notnow"||i.action==="close"||i.action==="cancel")return pt=!0,!1;if(i.action==="done")return(await qt(t)).ok;if(i.action==="install"&&((d=i.selected)!=null&&d.length)){if(ut=!0,ho(),!((f=lt())!=null&&f.execute))return pe({progressMode:!0,percent:0,info:"Executor not available",logAppend:`Open Acode Terminal once (Alpine/Termux), then open this dialog again.
`,showDone:!0}),ut=!1,!1;pe({progressMode:!0,percent:5,info:"Preparing...",logAppend:"Selected: "+i.selected.join(", ")+`
`});try{let l=await ft(t);if(i.selected.includes("node")||i.selected.includes("npm")){if(pe({percent:15,info:"Installing Node.js / npm...",logAppend:`
=== node / npm ===
`}),Kr())return ut=!1,!1;let p=await ai();pe({percent:48,logAppend:String(p||"").slice(-2500)+`
`})}if(i.selected.includes("acodels")){if(pe({percent:58,info:"Installing backend modules in acodels...",logAppend:`
=== acodels @ ${l} ===
`}),Kr())return ut=!1,!1;let p=await li(l);pe({percent:82,logAppend:String(p||"").slice(-3e3)+`
`})}let c=await qt(t);return pe({progressMode:!0,percent:100,info:c.ok?"Done \u2014 all required present":"Finished \u2014 still missing: "+c.missing.join(", "),showDone:!0,logAppend:c.ok?`
OK
`:`
Missing: `+c.missing.join(", ")+`
`}),M("dependenciesInstalled",c.ok),c.ok&&(pt=!0,Jr("Dependencies ready",2500)),c.ok}catch(l){return pe({progressMode:!0,percent:100,info:"Failed",showDone:!0,logAppend:`
ERROR: `+((l==null?void 0:l.message)||l)+`
`}),!1}finally{ut=!1}}return!1}async function ur(e={}){let t=e.baseUrl||Be||"";Be=t;try{return!e.force&&pt||!e.force&&cr&&k().dependenciesInstalled===!0?!0:(cr=!0,(await qt(t)).ok?(M("dependenciesInstalled",!0),!0):dr({...e,baseUrl:t}))}catch(r){return console.warn("[LiveServer:deps]",r),!1}}async function ci(e){return dr({force:!0,fromSettings:!0,baseUrl:e||Be})}async function di(e){return await oi("Reinstall dependencies?","Will run pkg/apk install for Node and npm install in acodels.")?(pt=!1,cr=!1,dr({force:!0,fromSettings:!0,baseUrl:e||Be})):!1}function en(){pt=!1,cr=!1}var Jr,oi,pt,cr,ut,Be,lr,ht=C(()=>{re();ct();go();Jr=acode.require("toast"),oi=acode.require("confirm"),pt=!1,cr=!1,ut=!1,Be="",lr=[{id:"node",label:"node",desc:"Node.js runtime",required:!0},{id:"npm",label:"npm",desc:"Package manager",required:!0},{id:"acodels",label:"acodels modules",desc:"Backend node_modules (express, ws, chokidar)",required:!0}]});var ui,vo,bo=C(()=>{ct();ui=`/**
 * acodels \u2014 Live Server + Local Reverse Proxy Node backend (ls-proxy-v6, ls-bridge-v1)
 */
const http = require('http');
const https = require('https');
const express = require('express');
const path = require('path');
const fs = require('fs');
const net = require('net');
const zlib = require('zlib');
const { URL } = require('url');
const { Server: WebSocketServer } = require('ws');
const chokidar = require('chokidar');

let BASE_DIR = null;
let jsonData = {};
let erudaEnabled = false;
let consoleType = 'suger';
let zoomEnabled = false;
let liveReloadEnabled = true;
let directoryListing = true;
let fileWatcher = null;
let connectedSockets = [];
let customHeaders = {};
let charset = 'utf-8';
let ipWhitelist = [];
let basicAuth = null;
let lastActivity = Date.now();

const args = process.argv.slice(2);
let currentPort = args[0] ? parseInt(args[0], 10) : 8080;
if (!Number.isFinite(currentPort) || currentPort < 1) currentPort = 8080;
const bindHost = args[1] || '0.0.0.0';

function isPortAvailable(port) {
  return new Promise((resolve) => {
    const tester = net
      .createServer()
      .once('error', () => resolve(false))
      .once('listening', () => tester.close(() => resolve(true)))
      .listen(port, bindHost === '0.0.0.0' ? undefined : bindHost);
  });
}

const webSocketScript = \`
<script>
  (function() {
    try {
      var wsUrl = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
      var ws = new WebSocket(wsUrl);
      ws.onmessage = function (event) {
        if (event.data === 'reload') location.reload();
      };
    } catch (e) {}
  })();
<\/script>\`;

const sugerScript = \`<script src="/dt/suger-dev.js"><\/script>\`;
const erudaRealScript = \`
<script src="/eruda.min.js"><\/script>
<script>if (typeof eruda !== 'undefined') eruda.init();<\/script>
\`;
const inspectorScript = \`<script src="/inspector.js"><\/script>\`;

/* ls-bridge-v1: page <-> Acode browser bridge */
const LS_BRIDGE_JS = \`
(function () {
  var P = window.__lsParent || window.parent;
  if (window.__lsBridge || !P || P === window) return;
  window.__lsBridge = 1;
  function post(m) {
    try { m.ls = 1; P.postMessage(m, '*'); } catch (e) {}
  }
  function currentHref() {
    return window.__LS_PROXY_TARGET__ || location.href;
  }
  function fav() {
    var l = document.querySelector('link[rel~="icon"]');
    if (l && l.href) return l.href;
    try { return new URL('/favicon.ico', currentHref()).href; } catch (e) { return ''; }
  }
  function meta() {
    post({ type: 'meta', href: currentHref(), title: document.title || '', favicon: fav() });
  }
  window.__lsPostMeta = meta;
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(meta, 0);
  window.addEventListener('load', meta);
  window.addEventListener('popstate', function () { setTimeout(meta, 0); });
  window.addEventListener('hashchange', function () { setTimeout(meta, 0); });
  try {
    var t = document.querySelector('title');
    if (t) new MutationObserver(meta).observe(t, { childList: true, characterData: true, subtree: true });
  } catch (e) {}

  var dtOn = false;
  function devtools(d) {
    try {
      if (d.on) {
        if (!window.suger) {
          if (!d.code) { post({ type: 'need-devtools' }); return; }
          var s = document.createElement('script');
          s.textContent = d.code;
          (document.head || document.documentElement).appendChild(s);
        }
        if (window.suger) {
          if (!window.__lsDtInit) { window.__lsDtInit = 1; window.suger.init(); }
          else window.suger.show();
          dtOn = true;
        }
      } else if (window.suger) {
        window.suger.hide();
        dtOn = false;
      }
    } catch (e) {
      post({ type: 'devtools-error', message: String(e && e.message || e) });
    }
    post({ type: 'devtools', on: dtOn });
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.ls !== 1 || e.source !== P) return;
    try {
      if (d.cmd === 'history') history.go(d.dir < 0 ? -1 : 1);
      else if (d.cmd === 'reload') location.reload();
      else if (d.cmd === 'stop') window.stop();
      else if (d.cmd === 'zoom') document.documentElement.style.zoom = String((d.pct || 100) / 100);
      else if (d.cmd === 'print') window.print();
      else if (d.cmd === 'find') post({ type: 'found', ok: !!window.find(d.q, false, !!d.back, true, false, false, false) });
      else if (d.cmd === 'devtools') devtools(d);
      else if (d.cmd === 'ping') meta();
    } catch (err) {}
  });
})();
\`;

const lsBridgeScript = '<script src="/__ls/bridge.js"><\/script>';
const zoomScript = \`
<script src="/zoom-handler.js"><\/script>
<script>try { new ZoomHandler(document.body); } catch (e) {}<\/script>\`;

const app = express();

// Capture raw body for /__proxy while still parsing JSON for /setup
app.use((req, res, next) => {
  if (req.path === '/__proxy' || req.path === '/_proxy') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      req.rawBody = chunks.length ? Buffer.concat(chunks) : null;
      next();
    });
    return;
  }
  express.json({ limit: '2mb' })(req, res, next);
});

// Activity + security middleware
app.use((req, res, next) => {
  lastActivity = Date.now();
  if (ipWhitelist.length) {
    const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (!ipWhitelist.includes(ip) && ip !== '127.0.0.1' && ip !== '::1') {
      return res.status(403).send('Forbidden');
    }
  }
  if (basicAuth && basicAuth.user && !req.path.startsWith('/__proxy')) {
    const hdr = req.headers.authorization || '';
    const ok = (() => {
      if (!hdr.startsWith('Basic ')) return false;
      try {
        const decoded = Buffer.from(hdr.slice(6), 'base64').toString('utf8');
        const i = decoded.indexOf(':');
        const u = decoded.slice(0, i);
        const p = decoded.slice(i + 1);
        return u === basicAuth.user && p === (basicAuth.pass || '');
      } catch (_) {
        return false;
      }
    })();
    if (!ok) {
      res.setHeader('WWW-Authenticate', 'Basic realm="Live Server"');
      return res.status(401).send('Unauthorized');
    }
  }
  Object.keys(customHeaders).forEach((k) => {
    try { res.setHeader(k, customHeaders[k]); } catch (_) {}
  });
  next();
});

// CORS
app.use((req, res, next) => {
  if (jsonData.enableCors !== false) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
  }
  next();
});

app.get('/check', (req, res) => {
  res.status(200).json({
    message: 'Ready',
    key: 'AcodeLiveServer_NodeJS',
    port: currentPort,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    proxy: true,
    proxyVersion: 3,
  });
});

app.get('/status', (req, res) => {
  res.json({
    port: currentPort,
    bind: bindHost,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    directoryListing,
    clients: connectedSockets.length,
    lastActivity,
    uptime: process.uptime(),
    proxy: true,
    proxyVersion: 3,
  });
});

app.post('/reload', (req, res) => {
  broadcastReload();
  res.json({ ok: true, clients: connectedSockets.length });
});

app.patch('/setup', (req, res) => {
  const data = req.body || {};
  if (!data.path) return res.status(400).json({ error: 'Missing path' });

  BASE_DIR = data.path;
  jsonData = data;
  erudaEnabled = data.eruda === true;
  if (data.consoleType) consoleType = data.consoleType;
  zoomEnabled = data.zoom === true;
  liveReloadEnabled = data.liveReload !== false;
  directoryListing = data.directoryListing !== false;

  if (typeof data.charset === 'string' && data.charset) charset = data.charset;
  customHeaders = {};
  if (data.customHeaders && typeof data.customHeaders === 'object') {
    customHeaders = data.customHeaders;
  } else if (typeof data.customHeaders === 'string') {
    String(data.customHeaders).split('\\n').forEach((line) => {
      const i = line.indexOf(':');
      if (i > 0) {
        const k = line.slice(0, i).trim();
        const v = line.slice(i + 1).trim();
        if (k) customHeaders[k] = v;
      }
    });
  }

  ipWhitelist = [];
  if (data.ipWhitelist) {
    const raw = Array.isArray(data.ipWhitelist)
      ? data.ipWhitelist
      : String(data.ipWhitelist).split(/[\\n,]+/);
    ipWhitelist = raw.map((s) => String(s).trim()).filter(Boolean);
  }

  if (data.basicAuthUser) {
    basicAuth = { user: String(data.basicAuthUser), pass: String(data.basicAuthPass || '') };
  } else {
    basicAuth = null;
  }

  if (liveReloadEnabled) startFileWatcher(res);
  else {
    if (fileWatcher) {
      try { fileWatcher.close(); } catch (_) {}
      fileWatcher = null;
    }
    res.status(201).json({ message: 'OK', liveReload: false });
  }
});

app.get('/__ls/bridge.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.send(LS_BRIDGE_JS);
});

// ============================================================================
// LOCAL REVERSE PROXY (/__proxy?url=...)
// ============================================================================

function buildProxyRuntimeScript(targetUrl) {
  let origin = '';
  try { origin = new URL(targetUrl).origin; } catch (_) {}
  return \`<script>
(function() {
  window.__LS_PROXY_TARGET__ = \${JSON.stringify(targetUrl)};
  window.__LS_PROXY_ORIGIN__ = \${JSON.stringify(origin)};
  var proxyBase = location.origin + '/__proxy?url=';

  function unwrapUrl(u) {
    var s = String(u || '');
    var idx = s.indexOf('/__proxy?url=');
    if (idx !== -1) {
      try {
        return decodeURIComponent(s.slice(idx + '/__proxy?url='.length).split('&')[0]);
      } catch (e) {}
    }
    return s;
  }

  function wrapUrl(raw) {
    if (!raw || typeof raw !== 'string') return raw;
    var s = raw.trim();
    if (!s || s.charAt(0) === '#' || s.indexOf('data:') === 0 || s.indexOf('blob:') === 0 || s.indexOf('javascript:') === 0 || s.indexOf('mailto:') === 0 || s.indexOf('tel:') === 0) {
      return raw;
    }
    if (s.indexOf('/__proxy?url=') !== -1 || s.indexOf('/__ls/') === 0 || s.indexOf('/dt/') === 0) {
      return raw;
    }
    try {
      var resolved = new URL(s, window.__LS_PROXY_TARGET__);
      if (resolved.protocol === 'http:' || resolved.protocol === 'https:') {
        return proxyBase + encodeURIComponent(resolved.href);
      }
    } catch (e) {}
    return raw;
  }

  // Prevent proxied Service Workers from hijacking 127.0.0.1
  try {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.register = function() {
        return Promise.resolve({ scope: '/' });
      };
    }
  } catch (e) {}

  // Patch history.pushState / replaceState so SPAs don't throw cross-origin SecurityError
  try {
    var origPush = history.pushState;
    var origReplace = history.replaceState;
    history.pushState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origPush.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
    history.replaceState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origReplace.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
  } catch (e) {}

  // Patch fetch
  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function(input, init) {
      if (typeof input === 'string') {
        input = wrapUrl(input);
      } else if (input && typeof input.url === 'string') {
        try {
          input = new Request(wrapUrl(input.url), input);
        } catch (e) {}
      }
      return origFetch.call(this, input, init);
    };
  }

  // Patch XMLHttpRequest
  if (window.XMLHttpRequest) {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
      var args = Array.prototype.slice.call(arguments);
      if (typeof url === 'string') args[1] = wrapUrl(url);
      return origOpen.apply(this, args);
    };
  }

  // Patch dynamic DOM element URL setters (fixes dynamically injected CSS <link> and <script>)
  function patchProp(Proto, prop) {
    if (!Proto) return;
    var desc = Object.getOwnPropertyDescriptor(Proto, prop);
    if (!desc || !desc.set) return;
    Object.defineProperty(Proto, prop, {
      get: desc.get,
      set: function(val) {
        return desc.set.call(this, typeof val === 'string' ? wrapUrl(val) : val);
      },
      configurable: true
    });
  }
  try {
    patchProp(window.HTMLScriptElement && HTMLScriptElement.prototype, 'src');
    patchProp(window.HTMLLinkElement && HTMLLinkElement.prototype, 'href');
    patchProp(window.HTMLImageElement && HTMLImageElement.prototype, 'src');
    patchProp(window.HTMLIFrameElement && HTMLIFrameElement.prototype, 'src');
    var origSetAttr = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function(name, val) {
      var lower = String(name || '').toLowerCase();
      if ((lower === 'src' || lower === 'href' || lower === 'action') && typeof val === 'string') {
        val = wrapUrl(val);
      }
      return origSetAttr.call(this, name, val);
    };
  } catch (e) {}

  // Intercept anchor clicks
  document.addEventListener('click', function(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0 || href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
    e.preventDefault();
    location.href = wrapUrl(href);
  }, true);

  // Helper to submit forms cleanly without losing ?url= on GET forms (fixes Google Search 404)
  function submitProxiedForm(form) {
    var rawAction = form.getAttribute('action') || window.__LS_PROXY_TARGET__;
    var targetAction = unwrapUrl(rawAction);
    try {
      targetAction = new URL(targetAction, window.__LS_PROXY_TARGET__).href;
    } catch (err) {}

    var method = (form.getAttribute('method') || form.method || 'GET').toUpperCase();
    if (method === 'GET') {
      var u = new URL(targetAction);
      var fd = new FormData(form);
      fd.forEach(function(v, k) {
        if (typeof v === 'string') u.searchParams.append(k, v);
      });
      location.href = proxyBase + encodeURIComponent(u.href);
      return true;
    } else {
      origSetAttr.call(form, 'action', proxyBase + encodeURIComponent(targetAction));
      return false;
    }
  }

  document.addEventListener('submit', function(e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    if (submitProxiedForm(form)) {
      e.preventDefault();
    }
  }, true);

  // Also intercept programmatic form.submit() calls (used by Google Search)
  try {
    var origFormSubmit = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function() {
      if (submitProxiedForm(this)) return;
      return origFormSubmit.apply(this, arguments);
    };
  } catch (e) {}

  window.open = function(url) {
    if (url) location.href = wrapUrl(url);
    return window;
  };
})();
<\/script>\`;
}

function rewriteCssForProxy(css, targetUrl) {
  let out = String(css || '');
  // Rewrite url(...)
  out = out.replace(/url\\(\\s*(["']?)([^"')]+)\\1\\s*\\)/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('data:') ||
      s.startsWith('#') ||
      s.startsWith('blob:') ||
      s.includes('/__proxy?url=')
    ) {
      return match;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return 'url(' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote + ')';
      }
    } catch (_) {}
    return match;
  });

  // Rewrite @import "..." or @import '...'
  out = out.replace(/@import\\s+(["'])([^"']+)\\1/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (!s || s.includes('/__proxy?url=')) return match;
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '@import ' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote;
      }
    } catch (_) {}
    return match;
  });

  return out;
}

function rewriteHtmlForProxy(html, targetUrl) {
  const toProxy = (raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('#') ||
      s.startsWith('data:') ||
      s.startsWith('blob:') ||
      s.startsWith('javascript:') ||
      s.startsWith('mailto:') ||
      s.startsWith('tel:') ||
      s.includes('/__proxy?url=')
    ) {
      return raw;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '/__proxy?url=' + encodeURIComponent(parsed.href);
      }
    } catch (_) {}
    return raw;
  };

  // Rewrite href, src, action, poster attributes
  let out = String(html || '').replace(
    /\\b(href|src|action|poster)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      return attr + '=' + quote + toProxy(val) + quote;
    }
  );

  // Rewrite srcset / imagesrcset
  out = out.replace(
    /\\b(srcset|imagesrcset)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      const rewrittenList = val
        .split(',')
        .map((part) => {
          const trimmed = part.trim();
          if (!trimmed) return part;
          const spaceIdx = trimmed.search(/\\s/);
          if (spaceIdx === -1) return toProxy(trimmed);
          const u = trimmed.slice(0, spaceIdx);
          const descriptor = trimmed.slice(spaceIdx);
          return toProxy(u) + descriptor;
        })
        .join(', ');
      return attr + '=' + quote + rewrittenList + quote;
    }
  );

  // Rewrite inline <style> blocks
  out = out.replace(
    /(<style[^>]*>)([\\s\\S]*?)(<\\/style>)/gi,
    (match, openTag, cssBody, closeTag) => openTag + rewriteCssForProxy(cssBody, targetUrl) + closeTag
  );

  // Strip SRI integrity, CSP nonces, and CSP meta tags
  out = out.replace(/\\s+(?:integrity|nonce)\\s*=\\s*(["'])[^"']*\\1/gi, '');
  out = out.replace(/<meta[^>]+http-equiv\\s*=\\s*["']?Content-Security-Policy["']?[^>]*>/gi, '');

  // Rewrite meta refresh redirects
  out = out.replace(
    /(<meta[^>]+http-equiv\\s*=\\s*["']?refresh["']?[^>]+content\\s*=\\s*["'][^"']*?url=)([^"'>]+)(["'][^>]*>)/gi,
    (match, prefix, urlVal, suffix) => prefix + toProxy(urlVal.trim()) + suffix
  );

  const injectedHead = buildProxyRuntimeScript(targetUrl) + lsBridgeScript;

  if (/<head[^>]*>/i.test(out)) {
    out = out.replace(/<head[^>]*>/i, (m) => m + '\\n' + injectedHead);
  } else if (/<html[^>]*>/i.test(out)) {
    out = out.replace(/<html[^>]*>/i, (m) => m + '<head>' + injectedHead + '</head>');
  } else {
    out = injectedHead + '\\n' + out;
  }

  return out;
}

function decompressBuffer(buf, encoding) {
  const enc = String(encoding || '').toLowerCase();
  try {
    if (enc.includes('gzip')) return zlib.gunzipSync(buf);
    if (enc.includes('br') && typeof zlib.brotliDecompressSync === 'function') {
      return zlib.brotliDecompressSync(buf);
    }
    if (enc.includes('deflate')) return zlib.inflateSync(buf);
  } catch (_) {}
  return buf;
}

function fetchUpstream(targetUrl, method, reqHeaders, bodyBuf, redirectsLeft = 6) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(targetUrl);
    } catch (e) {
      return reject(new Error('Invalid target URL'));
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return reject(new Error('Only HTTP/HTTPS URLs are supported'));
    }

    const client = parsed.protocol === 'https:' ? https : http;
    const upperMethod = (method || 'GET').toUpperCase();
    const headers = {
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
      'Accept':
        reqHeaders['accept'] ||
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': reqHeaders['accept-language'] || 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'Referer': parsed.origin + '/',
    };
    if (upperMethod !== 'GET' && upperMethod !== 'HEAD') {
      headers['Origin'] = parsed.origin;
    }
    if (reqHeaders['content-type']) headers['Content-Type'] = reqHeaders['content-type'];
    if (reqHeaders['cookie']) headers['Cookie'] = reqHeaders['cookie'];
    if (bodyBuf && bodyBuf.length) headers['Content-Length'] = bodyBuf.length;

    const upstreamReq = client.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method: upperMethod,
        headers,
        timeout: 20000,
        rejectUnauthorized: false,
      },
      (upstreamRes) => {
        const status = upstreamRes.statusCode || 200;
        const loc = upstreamRes.headers['location'];
        if ([301, 302, 303, 307, 308].includes(status) && loc && redirectsLeft > 0) {
          upstreamRes.resume();
          const nextUrl = new URL(loc, parsed.href).href;
          const nextMethod =
            status === 303 || ((status === 301 || status === 302) && upperMethod === 'POST')
              ? 'GET'
              : upperMethod;
          return resolve(
            fetchUpstream(
              nextUrl,
              nextMethod,
              reqHeaders,
              nextMethod === 'GET' ? null : bodyBuf,
              redirectsLeft - 1
            )
          );
        }

        const chunks = [];
        upstreamRes.on('data', (c) => chunks.push(c));
        upstreamRes.on('end', () => {
          resolve({
            status,
            headers: upstreamRes.headers,
            body: Buffer.concat(chunks),
            finalUrl: parsed.href,
          });
        });
      }
    );

    upstreamReq.on('timeout', () => {
      upstreamReq.destroy(new Error('Upstream request timed out'));
    });
    upstreamReq.on('error', reject);
    if (bodyBuf && bodyBuf.length) upstreamReq.write(bodyBuf);
    upstreamReq.end();
  });
}

async function handleProxyRequest(req, res, targetUrl) {
  try {
    const bodyBuf = req.rawBody || null;
    const result = await fetchUpstream(targetUrl, req.method, req.headers, bodyBuf);

    const blockedHeaders = new Set([
      'x-frame-options',
      'content-security-policy',
      'content-security-policy-report-only',
      'cross-origin-opener-policy',
      'cross-origin-embedder-policy',
      'cross-origin-resource-policy',
      'content-length',
      'content-encoding',
      'transfer-encoding',
      'connection',
    ]);

    Object.entries(result.headers || {}).forEach(([k, v]) => {
      const lower = k.toLowerCase();
      if (blockedHeaders.has(lower)) return;
      if (lower === 'set-cookie' && Array.isArray(v)) {
        const cleanCookies = v.map((c) =>
          String(c)
            .replace(/;\\s*Domain=[^;]+/gi, '')
            .replace(/;\\s*Secure/gi, '')
            .replace(/SameSite=None/gi, 'SameSite=Lax')
        );
        res.setHeader('Set-Cookie', cleanCookies);
        return;
      }
      try {
        res.setHeader(k, v);
      } catch (_) {}
    });

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-LS-Final-Url', result.finalUrl);

    const contentType = String(result.headers['content-type'] || '');
    const rawBuf = decompressBuffer(result.body, result.headers['content-encoding']);

    if (/text\\/html|application\\/xhtml\\+xml/i.test(contentType)) {
      const htmlText = rawBuf.toString('utf8');
      const rewritten = rewriteHtmlForProxy(htmlText, result.finalUrl);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.status(result.status).send(rewritten);
    }

    if (/text\\/css/i.test(contentType)) {
      const cssText = rawBuf.toString('utf8');
      const rewrittenCss = rewriteCssForProxy(cssText, result.finalUrl);
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
      return res.status(result.status).send(rewrittenCss);
    }

    return res.status(result.status).send(rawBuf);
  } catch (err) {
    const safeUrl = String(targetUrl || '').replace(/</g, '<');
    const safeMsg = String((err && err.message) || err).replace(/</g, '<');
    res.status(502).setHeader('Content-Type', 'text/html; charset=utf-8').send(\`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
      <style>
        body { font-family: system-ui, sans-serif; background: #1e1e1e; color: #e8eaed; padding: 28px 18px; text-align: center; }
        .card { max-width: 420px; margin: 24px auto; padding: 20px; border-radius: 8px; background: #292a2d; border: 1px solid #3c4043; }
        h3 { margin: 0 0 8px; color: #f87171; }
        p { font-size: 13px; color: #9aa0a6; word-break: break-all; }
        button { margin-top: 12px; padding: 8px 16px; border: 0; border-radius: 5px; background: #22c55e; color: #052e16; font-weight: 600; cursor: pointer; }
      </style></head>
      <body>
        <div class="card">
          <h3>Proxy Could Not Load Page</h3>
          <p>\${safeMsg}</p>
          <p>\${safeUrl}</p>
          <button onclick="location.reload()">Retry</button>
        </div>
      </body></html>
    \`);
  }
}

app.all(['/__proxy', '/_proxy'], (req, res) => {
  if (req.query.url) {
    const target = String(req.query.url);
        return handleProxyRequest(req, res, target);
  }
  // Fallback when a GET form (like Google Search) strips ?url= and submits ?q=... directly to /__proxy
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (idx !== -1) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const u = new URL('/search', baseTarget);
      Object.entries(req.query || {}).forEach(([k, v]) => {
        if (typeof v === 'string') u.searchParams.set(k, v);
      });
      return handleProxyRequest(req, res, u.href);
    } catch (_) {}
  }
  return res.status(400).send('Missing ?url=');
});

// Referer-based fallback for root-relative assets/APIs requested by proxied pages
app.use((req, res, next) => {
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (
    idx !== -1 &&
    !req.path.startsWith('/__ls/') &&
    !req.path.startsWith('/dt/') &&
    req.path !== '/__proxy' &&
    req.path !== '/_proxy'
  ) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const resolved = new URL(req.originalUrl, baseTarget).href;
      return handleProxyRequest(req, res, resolved);
    } catch (_) {}
  }
  next();
});

// ============================================================================
// LOCAL STATIC LIVE SERVER
// ============================================================================

app.get('/dt/suger-dev.js', (req, res) => {
  const p = path.join(__dirname, 'suger-dev.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/zoom-handler.js', (req, res) => {
  const p = path.join(__dirname, 'zoom-handler.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/inspector.js', (req, res) => {
  const p = path.join(__dirname, 'inspector.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/eruda.min.js', (req, res) => {
  const erudaPath = path.join(__dirname, 'eruda.min.js');
  if (fs.existsSync(erudaPath)) res.sendFile(erudaPath);
  else res.status(404).send('Eruda not found');
});

function injectHtml(html) {
  let injected = html;
  if (liveReloadEnabled) {
    injected = injected.replace(/<\\/body>/i, webSocketScript + '</body>');
    if (!/<\\/body>/i.test(html)) injected = injected + webSocketScript;
  }
  if (erudaEnabled) {
    const extra =
      consoleType === 'eruda' ? erudaRealScript + '\\n' + inspectorScript : sugerScript + '\\n' + inspectorScript;
    injected = injected.replace(/<\\/body>/i, extra + '</body>');
  }
  if (zoomEnabled) {
    injected = injected.replace(/<\\/body>/i, zoomScript + '</body>');
  }
  if (/<\\/body>/i.test(injected)) injected = injected.replace(/<\\/body>/i, lsBridgeScript + '</body>');
  else injected += lsBridgeScript;
  return injected;
}

function sendHtmlFile(res, fullPath) {
  fs.readFile(fullPath, 'utf8', (err, html_content) => {
    if (err) return res.status(404).send('Not found');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(injectHtml(html_content));
  });
}

app.get('/', (req, res) => {
  if (!BASE_DIR) return res.status(400).send('Not configured. PATCH /setup first.');
  const fileName = jsonData.fileName || 'index.html';
  const fullPath = path.join(BASE_DIR, fileName);
  if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    return sendHtmlFile(res, fullPath);
  }
  const indexPath = path.join(BASE_DIR, 'index.html');
  if (fs.existsSync(indexPath)) return sendHtmlFile(res, indexPath);
  if (directoryListing) return listDir(res, BASE_DIR, '/');
  return res.status(404).send('No index.html');
});

function listDir(res, dirPath, urlPath) {
  fs.readdir(dirPath, { withFileTypes: true }, (err, entries) => {
    if (err) return res.status(500).send('Cannot list directory');
    const rows = entries
      .filter((e) => !e.name.startsWith('.'))
      .map((e) => {
        const href = path.posix.join(urlPath, e.name) + (e.isDirectory() ? '/' : '');
        return \`<li><a href="\${href}">\${e.name}\${e.isDirectory() ? '/' : ''}</a></li>\`;
      })
      .join('\\n');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(
      \`<!DOCTYPE html><html><head><meta charset="\${charset}"/><title>Index of \${urlPath}</title></head><body><h1>Index of \${urlPath}</h1><ul>\${rows}</ul></body></html>\`
    );
  });
}

app.use((req, res, next) => {
  if (!BASE_DIR) return next();
  const rel = decodeURIComponent(req.path || '/');
  const full = path.join(BASE_DIR, rel);
  if (!full.startsWith(path.resolve(BASE_DIR))) return res.status(403).end();
  fs.stat(full, (err, st) => {
    if (err) return next();
    if (st.isDirectory()) {
      if (directoryListing) return listDir(res, full, rel.endsWith('/') ? rel : rel + '/');
      const idx = path.join(full, 'index.html');
      if (fs.existsSync(idx)) return sendHtmlFile(res, idx);
      return res.status(404).end();
    }
    if (/\\.html?$/i.test(full)) return sendHtmlFile(res, full);
    res.sendFile(full, (e) => {
      if (e) next();
    });
  });
});

app.use(express.static(__dirname));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  connectedSockets.push(ws);
  lastActivity = Date.now();
  ws.on('close', () => {
    connectedSockets = connectedSockets.filter((s) => s !== ws);
  });
});

function broadcastReload() {
  for (const ws of connectedSockets) {
    try {
      ws.send('reload');
    } catch (_) {}
  }
}

function startFileWatcher(res) {
  if (fileWatcher) {
    try { fileWatcher.close(); } catch (_) {}
    fileWatcher = null;
  }
  if (!BASE_DIR || !liveReloadEnabled) {
    if (res) res.status(201).json({ message: 'OK' });
    return;
  }
  fileWatcher = chokidar.watch(BASE_DIR, {
    ignored: /(^|[\\/\\\\])\\.\\./,
    persistent: true,
    ignoreInitial: true,
  });
  fileWatcher.on('change', () => {
    lastActivity = Date.now();
    broadcastReload();
  });
  let responseSent = false;
  const done = (code, body) => {
    if (responseSent || !res) return;
    responseSent = true;
    res.status(code).json(body);
  };
  fileWatcher.on('ready', () => done(201, { message: 'OK', liveReload: true }));
  fileWatcher.on('error', (error) => {
    console.error('Watcher Error:', error.message);
    done(500, { error: error.message });
  });
  setTimeout(() => done(201, { message: 'OK', liveReload: true }), 3000);
}

async function main() {
  const ok = await isPortAvailable(currentPort);
  if (!ok) {
    console.error('[acodels] port busy', currentPort);
    process.exit(1);
  }
  server.listen(currentPort, bindHost, () => {
    console.log('[acodels] listening', bindHost + ':' + currentPort);
  });
}

main();
`,vo=Yr(ui)});async function tn(e){let t=e||"/root/.acode_liveserver/acodels";try{let o=await ne("D="+Ee(t)+'; if [ ! -f "$D/index.js" ]; then echo NEED; exit 0; fi; if grep -q WebSocket "$D/index.js" 2>/dev/null && grep -q chokidar "$D/index.js" 2>/dev/null && grep -q ls-proxy-v6 "$D/index.js" 2>/dev/null; then echo FULL; else echo NEED; fi',{timeoutMs:8e3});if(String(o).includes("FULL")&&!String(o).includes("NEED"))return!1}catch(o){console.warn("[LiveServer] index check",(o==null?void 0:o.message)||o)}let r=vo,n=["#!/bin/sh","set -e","D="+t.replace(/'/g,""),'mkdir -p "$D"',"echo '"+r+`' | base64 -d > "$D/index.js"`,"echo RESTORED"].join(`
`);try{return await Ht(n,{timeoutMs:0}),!0}catch(o){return console.warn("[LiveServer] restore failed",(o==null?void 0:o.message)||o),!1}}var yo=C(()=>{ct();bo()});function pi(e){return/\.html?$/i.test(String(e||""))}function Le(e){return!!(e&&pi(e.filename||e.name))}function X(){try{return(editorManager==null?void 0:editorManager.activeFile)||null}catch{return null}}function rn(e){try{return decodeURIComponent(e)}catch{return e}}function xo(e){let t=String(e||""),r=t.indexOf(":");if(r<0)return t.startsWith("/")?t:null;let n=t.slice(0,r),o=t.slice(r+1).replace(/^\/+/,""),i=o?"/"+o:"";return n==="primary"?"/sdcard"+i:n==="home"?"/sdcard/Documents"+i:/^[0-9A-F]{4}-[0-9A-F]{4}$/i.test(n)?"/storage/"+n+i:null}function we(e){if(!e||typeof e!="string")return null;let t=e;if(t.startsWith("content://")){if(t.includes("::")){let n=rn(t.split("::").pop());if(n.startsWith("/"))return n;let o=xo(n);if(o)return o}let r=t.indexOf("/document/");if(r>=0){let n=rn(t.slice(r+10).split("?")[0]);if(n.startsWith("/"))return n;let o=xo(n);if(o)return o}return null}if(t.startsWith("file://")&&(t=rn(t.replace(/^file:\/\//,""))),t.includes("/data/data/com.termux/files/home"))return t.includes("::")?t.split("::").pop():t;if(t.includes("::")){let r=t.split("::").pop();if(r&&r.startsWith("/"))return r}if(/\/(storage|sdcard|emulated)\//i.test(t)){let r=t.match(/(\/(?:storage|sdcard|emulated)\/[^?#]*)/i);if(r)return r[1]}return t.startsWith("/")?t:null}function fe(e){if(!e)return null;let t=Math.max(e.lastIndexOf("/"),e.lastIndexOf("\\"));return t<=0?e:e.slice(0,t)}var Se=C(()=>{});var Ze={};xe(Ze,{browseRootFolder:()=>wo,getEffectiveRoot:()=>fr,getEffectiveRootUri:()=>mi,pickRootFolder:()=>gi,rootFromSelectedFolder:()=>vi});function fr(){let e=k();if(e.rootFolder&&String(e.rootFolder).trim())return String(e.rootFolder).trim();let t=X(),r=we((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");return r?fe(r):null}function mi(){let e=k();if(e.rootFolderUri&&String(e.rootFolderUri).trim())return String(e.rootFolderUri).trim();let t=X(),r=(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"";if(!r)return null;if(r.includes("::"))return r.split("::")[0];let n=we(r);return n?fe(n):null}async function wo(){try{let e=acode.require("fileBrowser");if(!e)return De("File browser not available",2e3),null;let t=await e("folder","Select Live Server root");if(!t)return null;let r=t.url||t.uri||t,n=we(typeof r=="string"?r:(r==null?void 0:r.url)||"")||String(r);M("rootFolder",n);try{M("rootFolderUri",typeof r=="string"?r:(r==null?void 0:r.url)||n)}catch{}return De("Root: "+n,2500),n}catch(e){return De(String((e==null?void 0:e.message)||e),2500),null}}async function gi(){try{let e=k().rootFolder||"",t=X(),r=fe(we((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")||"")||"",n=[["browse","Browse with Acode file browser\u2026"],["active",r?`Use active file folder
${r}`:"Use active file folder"],["type","Type path\u2026"],["clear","Clear (auto from active HTML)"]];e&&n.splice(1,0,["keep",`Keep current
${e}`]);let o=await fi("Select root folder",n,{hideOnSelect:!0});if(!o||o==="keep")return e||null;if(o==="browse")return wo();if(o==="active"){if(!r)return De("Open an HTML file first",2e3),null;M("rootFolder",r);try{M("rootFolderUri",(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")}catch{}return De("Root: "+r,2200),r}if(o==="clear"){M("rootFolder","");try{M("rootFolderUri","")}catch{}return De("Root cleared \u2014 will use active file folder",2200),null}if(o==="type"){let i=await hi("Absolute folder path",e||r||"/sdcard/","text");if(!i)return null;let s=String(i).trim();return M("rootFolder",s),De("Root: "+s,2200),s}return null}catch(e){return De(String((e==null?void 0:e.message)||e),2500),null}}function vi(){var e,t,r;try{let n=((e=window.fileBrowser)==null?void 0:e.selectedFolder)||((r=(t=window.addedFolder)==null?void 0:t[0])==null?void 0:r.url)||null;if(n)return we(n)||n}catch{}return null}var De,fi,hi,qe=C(()=>{re();Se();De=acode.require("toast"),fi=acode.require("select"),hi=acode.require("prompt")});function nn(){try{return acode.require("fsOperation")||window.fsOperation}catch{return window.fsOperation}}function Si(e){let t=0,r=String(e||"");for(let n=0;n<r.length;n++)t=Math.imul(31,t)+r.charCodeAt(n)|0;return"p"+Math.abs(t).toString(36)}function mr(e){return/^(https?:|data:|blob:|\/\/|#|mailto:|tel:)/i.test(String(e||"").trim())}function ki(e){let t=new Set,r=/(?:src|href|data-src|poster)\s*=\s*["']([^"']+)["']/gi,n;for(;n=r.exec(e);)mr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);let o=/url\(\s*['"]?([^'")\s]+)['"]?\s*\)/gi;for(;n=o.exec(e);)mr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);return[...t]}function Ei(e){let t=new Set,r=/url\(\s*['"]?([^'")\s]+)['"]?\s*\)/gi,n;for(;n=r.exec(e);)mr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);let o=/@import\s+['"]([^'"]+)['"]/gi;for(;n=o.exec(e);)mr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);return[...t]}function Li(e,t){if(!t)return null;if(t.startsWith("/"))return t.replace(/^\/+/,"");let r=String(e||"").replace(/\/+$/,""),n=(r?r.split("/"):[]).concat(String(t).split("/")),o=[];for(let i of n)!i||i==="."||(i===".."?o.pop():o.push(i));return o.join("/")}async function gr(e){let t=nn();if(!t)throw new Error("fsOperation missing");try{let r=await t(e).readFile("utf-8");return typeof r=="string"?r:r instanceof ArrayBuffer?new TextDecoder().decode(r):String(r||"")}catch{let n=await t(e).readFile();return typeof n=="string"?n:n instanceof ArrayBuffer?new TextDecoder().decode(n):String(n||"")}}async function Eo(e,t){let r=nn();if(!r)throw new Error("fsOperation missing");let n=fe(e);try{n&&!await r(n).exists()&&await vr(n)}catch{}try{if(await r(e).exists())await r(e).writeFile(t);else{let o=e.slice(e.lastIndexOf("/")+1),i=fe(e);await r(i).createFile(o,t)}}catch{let i=btoa(unescape(encodeURIComponent(t))),s=d=>"'"+String(d).replace(/'/g,"'\\''")+"'";await ne(`mkdir -p ${s(fe(e))} && echo ${s(i)} | base64 -d > ${s(e)}`,{timeoutMs:2e4})}}async function vr(e){let t=nn(),r=n=>"'"+String(n).replace(/'/g,"'\\''")+"'";try{if(t){let n=String(e).split("/").filter(Boolean),o=(e.startsWith("/"),"")}}catch{}await ne(`mkdir -p ${r(e)}`,{timeoutMs:1e4})}function Lo(e,t){if(!e)return null;let r=String(t||"").replace(/^\/+/,"");return e.includes("::")?e:e.startsWith("content://")?null:e.replace(/\/+$/,"")+"/"+r}async function _i(e,t,r){let n=new Map,o=[t.replace(/^\/+/,"")],i=0;for(;o.length&&n.size<yi&&i<wi;){let s=o.shift();if(!s||n.has(s))continue;let d=e.replace(/\/+$/,"")+"/"+s,f=null;try{let g=Lo(r,s)||d;f=await gr(g.startsWith("content:")?g:d)}catch{try{f=await gr(d)}catch(a){console.warn("[LiveServer:mirror] skip",s,(a==null?void 0:a.message)||a),n.set(s,null);continue}}if(f==null){n.set(s,null);continue}if(f.length>xi){console.warn("[LiveServer:mirror] too large",s),n.set(s,null);continue}n.set(s,f),i+=f.length;let l=fe(s)||"",c=s.toLowerCase(),p=[];if(/\.html?$/.test(c))p=ki(f);else if(/\.css$/.test(c))p=Ei(f);else continue;for(let g of p){let a=Li(l,g);a&&!n.has(a)&&!a.includes("..")&&o.push(a)}}return n}function on(){hr&&(clearInterval(hr),hr=null)}async function Ci(e={}){let t=String(e.sourceRoot||"").replace(/\/+$/,"");if(!t)throw new Error("No source root to mirror");let r=String(e.entryRel||"index.html").replace(/^\/+/,""),n=e.sourceRootUri||k().rootFolderUri||"",o=Si(t+"|"+r),i=`${bi}/${o}`;So("Mirroring project to internal storage\u2026",2e3),await vr(i);let s=await _i(t,r,n),d=0;for(let[l,c]of s){if(c==null)continue;let p=i+"/"+l;await vr(fe(p)),await Eo(p,c),d++}if(d===0)throw new Error("Could not read any project files for mirror");let f={};for(let[l,c]of s)c!=null&&(f[l]=c.length+":"+c.slice(0,32));_e={id:o,files:f},Ie={id:o,alpineRoot:i,sourceRoot:t,sourceRootUri:n,entryRel:r};try{M("lastMirrorRoot",i)}catch{}return Ti(),console.log("[LiveServer:mirror] ready",i,"files=",d),So(`Mirrored ${d} file(s) \u2192 internal cache`,2500),i}async function _o(e){var d;if(!Ie)return!1;let{sourceRoot:t,sourceRootUri:r,alpineRoot:n}=Ie,o=t.replace(/\/+$/,"")+"/"+e,i;try{let f=Lo(r,e)||o;i=await gr(f.startsWith("content:")?f:o)}catch{try{i=await gr(o)}catch{return!1}}if(i==null)return!1;let s=i.length+":"+i.slice(0,32);return((d=_e==null?void 0:_e.files)==null?void 0:d[e])===s?!1:(await vr(fe(n+"/"+e)),await Eo(n+"/"+e,i),_e||(_e={id:Ie.id,files:{}}),_e.files[e]=s,console.log("[LiveServer:mirror] updated",e),!0)}function Ti(){var e;if(on(),!!Ie){try{(e=editorManager==null?void 0:editorManager.on)==null||e.call(editorManager,"save-file",ko),document.addEventListener("liveserver-file-saved",ko)}catch{}hr=setInterval(async()=>{if(!Ie||!_e)return;let t=Object.keys(_e.files||{}),r=!1;for(let n of t.slice(0,40))try{await _o(n)&&(r=!0)}catch{}if(r)try{document.dispatchEvent(new CustomEvent("liveserver-mirror-updated"))}catch{}},2500)}}function ko(e){try{if(!Ie)return;let t=(e==null?void 0:e.target)||(e==null?void 0:e.file)||X(),r=(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"",n=we(r);if(!n)return;let o=Ie.sourceRoot;if(!n.startsWith(o))return;let i=n.slice(o.length).replace(/^\/+/,"");i&&_o(i)}catch{}}async function Co(e,t,r){return Ci({sourceRoot:e,entryRel:t,sourceRootUri:r})}var So,bi,yi,xi,wi,hr,_e,Ie,To=C(()=>{re();Se();ct();So=acode.require("toast"),bi="/sdcard/Acode/liveserver_cache",yi=250,xi=2*1024*1024,wi=40*1024*1024,hr=null,_e=null,Ie=null});function mt(){let e=parseInt(k().port,10);return Number.isFinite(e)&&e>0?e:8080}function It(e,t){return`http://${t==="0.0.0.0"?"127.0.0.1":t||"127.0.0.1"}:${e}/`}var Ao=C(()=>{re()});var gt={};xe(gt,{getServerStatus:()=>B,refreshStatusFromBackend:()=>sn,setServerStatus:()=>oe});function B(){return{...$e}}function oe(e){Object.assign($e,e||{});try{window.dispatchEvent(new CustomEvent("liveserver-status",{detail:B()}))}catch{}}async function sn(){if(!$e.port)return $e;try{let e=await fetch(`http://127.0.0.1:${$e.port}/status`);if(!e.ok)return oe({running:!1,lastError:"status "+e.status}),B();let t=await e.json();oe({running:!0,port:t.port||$e.port,root:t.root||$e.root,fileName:t.fileName||$e.fileName})}catch{oe({running:!1})}return B()}var $e,he=C(()=>{$e={running:!1,port:null,root:null,url:null,fileName:null,bind:null,startedAt:null,lastError:null}});function Ro(){if(document.getElementById("ls-status-pill-css"))return;let e=document.createElement("style");e.id="ls-status-pill-css",e.textContent=`
    #ls-status-pill {
      position: fixed;
      left: 8px;
      bottom: 8px;
      z-index: 100001;
      max-width: min(82vw, 440px);
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 5px 10px;
      border-radius: 4px;
      background: var(--secondary-color, rgba(28, 30, 34, 0.94));
      color: var(--primary-text-color, var(--color, #e8eaed));
      border: 1px solid var(--border-color, rgba(255, 255, 255, 0.12));
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.45), 0 1px 3px rgba(0, 0, 0, 0.3);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 11px;
      line-height: 1.3;
      pointer-events: none;
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #ls-status-pill.is-visible {
      opacity: 0.96;
      transform: translateY(0);
    }
    .ls-sp-dot {
      width: 7px;
      height: 7px;
      min-width: 7px;
      border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 6px rgba(34, 197, 94, 0.9);
    }
    .ls-sp-dot.is-spin {
      animation: ls-sp-pulse 0.9s ease-in-out infinite alternate;
    }
    @keyframes ls-sp-pulse {
      from { opacity: 0.4; transform: scale(0.85); }
      to { opacity: 1; transform: scale(1.15); }
    }
    .ls-sp-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Global top green progress bar (shown when installing in background) */
    #ls-global-green-loader {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      z-index: 100002;
      overflow: hidden;
      pointer-events: none;
      display: none;
      background: rgba(34, 197, 94, 0.15);
    }
    #ls-global-green-loader.is-active {
      display: block;
    }
    #ls-global-green-loader::before {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      width: 35%;
      background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
      box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
      animation: ls-green-slide 1.15s ease-in-out infinite;
    }
    @keyframes ls-green-slide {
      0% { left: -35%; }
      100% { left: 100%; }
    }
  `,document.head.appendChild(e)}function Ai(){return Ro(),(!ce||!ce.isConnected)&&(ce=document.createElement("div"),ce.id="ls-status-pill",bt=document.createElement("span"),bt.className="ls-sp-dot",vt=document.createElement("span"),vt.className="ls-sp-text",ce.append(bt,vt),document.body.appendChild(ce)),ce}function Ce(e,t={}){Ro();let r=!!e,o=!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")||t.force===!0;if(document.body.classList.toggle("ls-green-loading",r&&o),document.querySelectorAll(".ls-browser-shell").forEach(i=>{i.classList.toggle("is-installing",r)}),!o){de&&de.classList.remove("is-active");return}(!de||!de.isConnected)&&(de=document.createElement("div"),de.id="ls-global-green-loader",document.body.appendChild(de)),de.classList.toggle("is-active",r)}function Te(e,t={}){if(!!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")&&t.force!==!0){Ft(0);return}clearTimeout($t);let n=Ai();vt&&(vt.textContent=String(e||"")),bt&&bt.classList.toggle("is-spin",t.spin!==!1),requestAnimationFrame(()=>{n.classList.add("is-visible")}),t.autoHideMs&&t.autoHideMs>0&&($t=setTimeout(()=>{Ft(0)},t.autoHideMs))}function Ft(e=0){clearTimeout($t);let t=()=>{ce&&ce.classList.remove("is-visible")};e>0?$t=setTimeout(t,e):t()}function Po(){clearTimeout($t),Ce(!1);try{ce==null||ce.remove(),de==null||de.remove()}catch{}ce=null,vt=null,bt=null,de=null}var ce,vt,bt,de,$t,br=C(()=>{ce=null,vt=null,bt=null,de=null,$t=null});function A(e,t=18,r=2){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${r}" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var T,jt=C(()=>{T={back:"M19 12H5M12 19l-7-7 7-7",forward:"M5 12h14M12 5l7 7-7 7",reload:"M21 2v6h-6M3 12a9 9 0 0115-6.7L21 8M3 22v-6h6M21 12a9 9 0 01-15 6.7L3 16",close:"M18 6L6 18M6 6l12 12",plus:"M12 5v14M5 12h14",home:"M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2zM9 22V12h6v10",star:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",lock:"M5 11h14a2 2 0 012 2v7a2 2 0 01-2 2H5a2 2 0 01-2-2v-7a2 2 0 012-2zM7 11V7a5 5 0 0110 0v4",info:"M12 2a10 10 0 100 20 10 10 0 000-20zM12 16v-4M12 8h.01",device:"M7 2h10a2 2 0 012 2v16a2 2 0 01-2 2H7a2 2 0 01-2-2V4a2 2 0 012-2zM12 18h.01",rotate:"M21 12a9 9 0 11-9-9c2.5 0 4.7 1 6.3 2.7L21 8M21 3v5h-5",dots:"M12 5h.01M12 12h.01M12 19h.01",maximize:"M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3",drop:"M12 2.69l5.66 5.66a8 8 0 11-11.31 0z",down:"M6 9l6 6 6-6",up:"M18 15l-6-6-6 6",search:"M11 3a8 8 0 100 16 8 8 0 000-16zM21 21l-4.35-4.35",globe:"M12 2a10 10 0 100 20 10 10 0 000-20zM2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20",minus:"M5 12h14"}});function Ri(e){let t=String(e||"").trim().match(/^#([0-9a-f]{3,8})$/i),r,n,o;if(t){let i=t[1];i.length===3&&(i=i.split("").map(s=>s+s).join("")),r=parseInt(i.slice(0,2),16),n=parseInt(i.slice(2,4),16),o=parseInt(i.slice(4,6),16)}else{if(t=String(e||"").match(/rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i),!t)return null;r=+t[1],n=+t[2],o=+t[3]}return(.299*r+.587*n+.114*o)/255}function Mo(){try{let e=getComputedStyle(document.documentElement),t=e.getPropertyValue("--primary-color")||e.getPropertyValue("--secondary-color"),r=Ri(t);if(r!=null)return r>.6?"light":"dark"}catch{}return"dark"}var Oo=C(()=>{});function Ho(){let e=document.getElementById("ls-browser-styles");e&&e.remove();let t=document.createElement("style");t.id="ls-browser-styles",t.textContent=an,document.head.appendChild(t)}var an,Bo=C(()=>{an=`
:host { display: block; position: relative; height: 100%; width: 100%; }
.ls-browser-shell {
  --ls-frame: #202124; --ls-toolbar: #35363a; --ls-omni: #202124; --ls-text: #e8eaed; --ls-sub: #9aa0a6;
  --ls-hover: rgba(255,255,255,.10); --ls-press: rgba(255,255,255,.16); --ls-line: #3c4043; --ls-accent: #8ab4f8;
  --ls-menu: #292a2d; --ls-stage: #1b1c1e; --ls-active-tab-text: #e8eaed;
  position: absolute; inset: 0; z-index: 1;
  display: flex; flex-direction: column; box-sizing: border-box;
  background: var(--ls-frame); color: var(--ls-text);
  font: 13px/1.3 Roboto, "Noto Sans", "Segoe UI", system-ui, sans-serif;
}
.ls-browser-shell[data-theme="light"] {
  --ls-frame: #dee1e6; --ls-toolbar: #ffffff; --ls-omni: #f1f3f4; --ls-text: #202124; --ls-sub: #5f6368;
  --ls-hover: rgba(0,0,0,.08); --ls-press: rgba(0,0,0,.14); --ls-line: #dadce0; --ls-accent: #1a73e8;
  --ls-menu: #ffffff; --ls-stage: #e8eaed; --ls-active-tab-text: #202124;
}
.ls-browser-shell *, .ls-browser-shell *::before, .ls-browser-shell *::after { box-sizing: border-box; }
.ls-browser-shell button { font: inherit; color: inherit; }
.ls-browser-shell.is-fullscreen { position: fixed; inset: 0; z-index: 99990; }

/* ---- chrome (tab strip + toolbar) */
.ls-chrome { flex-shrink: 0; display: flex; flex-direction: column; background: var(--ls-frame); }
.ls-tabstrip { display: flex; align-items: flex-end; height: 38px; padding: 6px 6px 0 6px; gap: 2px; }
.ls-browser-tabs { display: flex; flex: 0 1 auto; min-width: 0; overflow: hidden; align-items: flex-end; }
.ls-tab {
  position: relative; display: flex; align-items: center; gap: 6px; flex: 0 1 200px; min-width: 36px; max-width: 220px;
  height: 32px; padding: 0 6px 0 10px; border-radius: 3px 3px 0 0; color: var(--ls-sub); cursor: default; user-select: none;
}
.ls-tab:hover { background: var(--ls-hover); }
.ls-tab.is-active { background: var(--ls-toolbar); color: var(--ls-active-tab-text); }
.ls-tab:not(.is-active)::after { content: ""; position: absolute; right: -1px; top: 8px; height: 16px; width: 1px; background: var(--ls-line); }
.ls-tab:hover::after, .ls-tab.is-active::after, .ls-tab:has(+ .ls-tab.is-active)::after { display: none; }
.ls-fav { width: 16px; height: 16px; flex: none; display: inline-flex; align-items: center; justify-content: center; }
.ls-fav img { width: 16px; height: 16px; }
.ls-fav.is-spin { border: 2px solid var(--ls-line); border-top-color: var(--ls-accent); border-radius: 50%; animation: ls-spin .8s linear infinite; }
.ls-tab-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ls-tab-x { width: 18px; height: 18px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; }
.ls-tab-x:hover { background: var(--ls-press); }
.ls-tabstrip .ls-spacer { flex: 1; }
.ls-win { display: flex; align-items: center; align-self: center; gap: 2px; }
.ls-ib {
  width: 32px; height: 32px; flex: none; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub);
  display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
}
.ls-ib:hover { background: var(--ls-hover); }
.ls-ib:active { background: var(--ls-press); }
.ls-ib:disabled { opacity: .4; pointer-events: none; }
.ls-ib.is-on { color: var(--ls-accent); }
.ls-ib.is-on svg { fill: var(--ls-accent); }
.ls-ib.ls-tab-new { width: 28px; height: 28px; margin-left: 2px; align-self: center; }
.ls-ib.ls-win-btn { width: 26px; height: 26px; }

.ls-toolbar { position: relative; display: flex; align-items: center; gap: 2px; height: 40px; padding: 0 6px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); }
.ls-omni { flex: 1; min-width: 0; height: 30px; margin: 0 6px; display: flex; align-items: center; gap: 2px; padding: 0 2px 0 4px; border-radius: 3px; background: var(--ls-omni); }
.ls-omni:focus-within { box-shadow: inset 0 0 0 2px var(--ls-accent); }
.ls-site { width: 24px; height: 24px; flex: none; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; padding: 0; }
.ls-site:hover { background: var(--ls-hover); }
.ls-browser-url { flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent; color: var(--ls-text); font: inherit; font-size: 14px; padding: 0 4px; }
.ls-browser-url::placeholder { color: var(--ls-sub); }
.ls-omni .ls-ib { width: 26px; height: 26px; }
.ls-browser-shell.no-url .ls-omni { visibility: hidden; }
.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }
@keyframes ls-bar { 0% { left: -30%; } 100% { left: 100%; } }
@keyframes ls-spin { to { transform: rotate(360deg); } }

/* ---- external site fallback banner */
.ls-ext-bar {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 5px 10px; background: var(--ls-menu); border-bottom: 1px solid var(--ls-line);
  font-size: 12px; color: var(--ls-sub);
}
.ls-ext-bar[hidden] { display: none; }
.ls-ext-open {
  border: 0; border-radius: 3px; padding: 4px 10px; background: #22c55e;
  color: #052e16; font-weight: 600; font-size: 11.5px; cursor: pointer; white-space: nowrap;
}

/* ---- device toolbar */
.ls-devbar { display: flex; align-items: center; gap: 6px; min-height: 34px; padding: 3px 8px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); overflow-x: auto; scrollbar-width: none; }
.ls-devbar[hidden] { display: none; }
.ls-devbar::-webkit-scrollbar { height: 0; }
.ls-dev-btn { display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 8px; border: 1px solid var(--ls-line); border-radius: 3px; background: transparent; white-space: nowrap; cursor: pointer; }
.ls-dev-btn:hover { background: var(--ls-hover); }
.ls-dev-num { width: 58px; height: 26px; padding: 0 6px; border: 1px solid var(--ls-line); border-radius: 3px; background: var(--ls-omni); color: var(--ls-text); font: inherit; text-align: center; outline: 0; -moz-appearance: textfield; }
.ls-dev-num:focus { border-color: var(--ls-accent); }
.ls-dev-num::-webkit-outer-spin-button, .ls-dev-num::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ls-dev-x { color: var(--ls-sub); }
.ls-dev-spacer { flex: 1; }
.ls-dev-icon { width: 26px; height: 26px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; }
.ls-dev-icon:hover { background: var(--ls-hover); }

/* ---- stage (page area) */
.ls-stage { position: relative; flex: 1; min-height: 0; overflow: hidden; background: #fff; }
.ls-browser-shell.is-device .ls-stage { overflow: auto; display: flex; padding: 12px; background: var(--ls-stage); }
.ls-box { position: relative; width: 100%; height: 100%; }
.ls-browser-shell.is-device .ls-box { flex: none; margin: auto; background: #fff; box-shadow: 0 0 0 1px var(--ls-line), 0 2px 12px rgba(0,0,0,.35); }
.ls-device { position: relative; width: 100%; height: 100%; transform-origin: 0 0; }
.ls-browser-frame { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; background: #fff; }
.ls-hdl { display: none; position: absolute; z-index: 3; background: transparent; touch-action: none; }
.ls-browser-shell.is-device .ls-hdl { display: block; }
.ls-hdl-r { top: 0; bottom: 0; right: -12px; width: 12px; cursor: ew-resize; }
.ls-hdl-b { left: 0; right: 0; bottom: -12px; height: 12px; cursor: ns-resize; }
.ls-hdl-c { right: -12px; bottom: -12px; width: 12px; height: 12px; cursor: nwse-resize; }
.ls-hdl::after { content: ""; position: absolute; background: var(--ls-sub); border-radius: 3px; opacity: .8; }
.ls-hdl-r::after { top: calc(50% - 14px); left: 4px; width: 4px; height: 28px; }
.ls-hdl-b::after { left: calc(50% - 14px); top: 4px; height: 4px; width: 28px; }
.ls-hdl-c::after { left: 4px; top: 4px; width: 4px; height: 4px; border-radius: 50%; }

/* ---- new tab page (Mozilla Firefox style: large Green Fox top-center + search bar + round bookmarks + recent) */
.ls-ntp {
  position: absolute; inset: 0; z-index: 2; display: none; flex-direction: column;
  align-items: center; justify-content: flex-start; gap: 20px; padding: 26px 16px 28px;
  overflow-y: auto; background: var(--ls-toolbar); color: var(--ls-text);
}
.ls-ntp.is-on { display: flex; }
.ls-ntp-hero {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 10px; margin-top: 6px;
}
.ls-ntp-logo {
  width: 92px; height: 92px; object-fit: contain; display: block;
  filter: drop-shadow(0 6px 16px rgba(34, 197, 94, 0.25));
}
.ls-ntp-title {
  font-size: 22px; font-weight: 600; letter-spacing: .3px;
}
.ls-ntp-search {
  width: min(480px, 95%); height: 44px; border-radius: 8px;
  background: var(--ls-omni); border: 1px solid var(--ls-line);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
  display: flex; align-items: center; gap: 8px; padding: 0 6px 0 12px; color: var(--ls-sub);
}
.ls-ntp-search:focus-within {
  border-color: #22c55e;
  box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.28);
}
.ls-ntp-search-ico {
  display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ls-ntp-search input {
  flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent;
  color: var(--ls-text); font: inherit; font-size: 14px;
}
.ls-ntp-search-btn {
  height: 32px; padding: 0 14px; border: 0; border-radius: 6px;
  background: #22c55e; color: #052e16; font-weight: 600; font-size: 12.5px;
  cursor: pointer; flex-shrink: 0;
}
.ls-ntp-search-btn:active { opacity: 0.85; }
.ls-ntp-tiles {
  display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;
  width: min(480px, 100%);
}
.ls-ntp-tile {
  width: 78px; display: flex; flex-direction: column; align-items: center; gap: 6px;
  padding: 8px 4px; border: 0; border-radius: 6px; background: transparent; cursor: pointer;
}
.ls-ntp-tile:hover { background: var(--ls-hover); }
.ls-ntp-dot {
  width: 48px; height: 48px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); color: var(--ls-text);
  display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600;
  overflow: hidden; flex-shrink: 0;
}
.ls-ntp-dot img { width: 24px; height: 24px; border-radius: 50%; object-fit: contain; }
.ls-ntp-name {
  max-width: 74px; font-size: 11.5px; overflow: hidden; text-overflow: ellipsis;
  white-space: nowrap; color: var(--ls-text);
}
.ls-ntp-recent-wrap {
  width: min(480px, 100%); display: flex; flex-direction: column; gap: 6px;
  border-top: 1px solid var(--ls-line); padding-top: 12px;
}
.ls-ntp-sec-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 4px 4px; font-size: 12px; font-weight: 600; color: var(--ls-sub);
}
.ls-ntp-more {
  border: 0; background: transparent; color: #22c55e; font-size: 12px;
  font-weight: 600; cursor: pointer; padding: 2px 6px; border-radius: 3px;
}
.ls-ntp-more:hover { background: var(--ls-hover); }
.ls-ntp-recent-list { display: flex; flex-direction: column; gap: 2px; }
.ls-ntp-recent-row {
  display: flex; align-items: center; gap: 10px; width: 100%; text-align: left;
  padding: 8px 8px; border: 0; border-radius: 4px; background: transparent; cursor: pointer;
}
.ls-ntp-recent-row:hover { background: var(--ls-hover); }
.ls-ntp-recent-ico {
  width: 28px; height: 28px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); display: inline-flex; align-items: center;
  justify-content: center; font-size: 12px; font-weight: 600; flex-shrink: 0;
}
.ls-ntp-recent-meta { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.ls-ntp-recent-title {
  font-size: 13px; color: var(--ls-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-recent-url {
  font-size: 11px; color: var(--ls-sub); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-empty { font-size: 12px; color: var(--ls-sub); padding: 8px 4px; }

/* ---- find bar */
.ls-find { position: absolute; top: 80px; right: 10px; z-index: 40; display: flex; align-items: center; gap: 2px; padding: 4px 6px; background: var(--ls-menu); border: 1px solid var(--ls-line); border-radius: 3px; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
.ls-find[hidden] { display: none; }
.ls-find input { width: 150px; height: 26px; border: 0; border-bottom: 2px solid var(--ls-accent); background: transparent; color: var(--ls-text); outline: 0; font: inherit; padding: 0 4px; }
.ls-find .ls-ib { width: 26px; height: 26px; }

/* ---- overlay preview (page see-through, editor underneath stays usable) */
.ls-browser-shell.is-overlay { pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-tabstrip { display: none; }
.ls-ov-close { display: none !important; }
.ls-browser-shell.is-overlay .ls-ov-close { display: inline-flex !important; }
.ls-browser-shell.is-overlay .ls-chrome { pointer-events: auto; }
.ls-browser-shell.is-overlay .ls-stage { opacity: var(--ls-op, 1); pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-stage * { pointer-events: none; }
.ls-browser-shell.is-overlay .ls-dd-layer, .ls-browser-shell.is-overlay .ls-find { pointer-events: auto; }

/* ---- dropdown menu (desktop style) */
.ls-dd-layer { position: absolute; inset: 0; z-index: 60; }
.ls-dd-backdrop { position: absolute; inset: 0; background: transparent; }
.ls-dd-menu {
  position: absolute; min-width: 220px; max-width: calc(100% - 8px); padding: 6px 0;
  background: var(--ls-menu, #292a2d); color: var(--ls-text, #e8eaed);
  border: 1px solid var(--ls-line, #3c4043); border-radius: 3px;
  box-shadow: 0 4px 16px rgba(0,0,0,.4); font-size: 13px; overflow: auto;
}
.ls-dd-item { display: flex; align-items: center; gap: 8px; min-height: 32px; padding: 6px 14px 6px 8px; cursor: pointer; white-space: nowrap; user-select: none; }
.ls-dd-item:hover, .ls-dd-item.is-active { background: var(--ls-hover, rgba(128,128,128,.22)); }
.ls-dd-item.is-disabled { opacity: .45; pointer-events: none; }
.ls-dd-check { width: 14px; height: 14px; display: inline-flex; flex-shrink: 0; }
.ls-dd-label { flex: 1; }
.ls-dd-arrow { opacity: .7; display: inline-flex; }
.ls-dd-sep { height: 1px; margin: 6px 0; background: var(--ls-line, rgba(128,128,128,.3)); }
.ls-dd-custom { padding: 2px 8px 2px 22px; }
.ls-zoomrow { display: flex; align-items: center; gap: 4px; min-height: 32px; }
.ls-zoomrow .ls-zl { flex: 1; }
.ls-zoomrow .ls-zv { min-width: 44px; text-align: center; }
.ls-zoomrow .ls-ib { width: 26px; height: 26px; color: var(--ls-text); }

/* ---- opacity panel */
.ls-dd-panel { width: 250px; padding: 12px 14px; }
.ls-op-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.ls-op-val { color: var(--ls-accent); font-variant-numeric: tabular-nums; }
.ls-range { -webkit-appearance: none; appearance: none; width: 100%; height: 18px; margin: 0; background: transparent; outline: 0; }
.ls-range::-webkit-slider-runnable-track { height: 4px; border-radius: 3px; background: linear-gradient(to right, var(--ls-accent) var(--ls-fill, 100%), var(--ls-line) var(--ls-fill, 100%)); }
.ls-range::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; margin-top: -6px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-range::-moz-range-track { height: 4px; border-radius: 3px; background: var(--ls-line); }
.ls-range::-moz-range-progress { height: 4px; border-radius: 3px; background: var(--ls-accent); }
.ls-range::-moz-range-thumb { width: 16px; height: 16px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-op-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 12px; cursor: pointer; }
.ls-op-row.is-disabled { opacity: .45; pointer-events: none; }
.ls-op-hint { margin-top: 8px; font-size: 11px; color: var(--ls-sub); }
.ls-switch { position: relative; flex: none; width: 36px; height: 20px; }
.ls-switch::before { content: ""; position: absolute; inset: 0; border-radius: 3px; background: var(--ls-line); transition: background .15s; }
.ls-switch::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 3px; background: var(--ls-text); transition: transform .15s; }
.ls-switch.is-on::before { background: var(--ls-accent); }
.ls-switch.is-on::after { transform: translateX(16px); background: #fff; }

 #ls-deps-picker{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center}
.ls-dp-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.45)}
.ls-dp-card{position:relative;width:min(420px,92vw);max-height:min(72vh,540px);display:flex;flex-direction:column;border-radius:3px;background:var(--secondary-color,#1e1e1e);color:var(--color,#e0e0e0);overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4)}
.ls-dp-header{padding:12px 14px 8px;border-bottom:1px solid rgba(128,128,128,.25)}
.ls-dp-title{font-weight:600}
.ls-dp-subtitle{font-size:.75rem;opacity:.75;margin-top:4px}
.ls-dp-body{flex:1;overflow:auto;padding:8px 12px}
.ls-dp-row{display:flex;align-items:center;gap:10px;padding:8px 6px;border-radius:3px;margin-bottom:4px;background:rgba(128,128,128,.08)}
.ls-dp-status.ok{color:#66bb6a}.ls-dp-status.miss{color:#f48771}
.ls-dp-footer{display:flex;gap:8px;justify-content:flex-end;padding:10px 12px;border-top:1px solid rgba(128,128,128,.25)}
.ls-dp-btn{border:none;border-radius:3px;padding:8px 12px;background:rgba(128,128,128,.2);color:inherit}
.ls-dp-btn.ls-dp-install{background:var(--active-color,#61afef);color:#111;font-weight:600}
.ls-dp-progress-track{height:3px;border-radius:3px;background:rgba(128,128,128,.25);overflow:hidden}
.ls-dp-progress-bar{height:100%;background:var(--active-color,#61afef);transition:width .25s}
.ls-dp-spinner{width:16px;height:16px;border-radius:50%;border:2px solid rgba(128,128,128,.35);border-top-color:var(--active-color,#61afef);animation:ls-spin .7s linear infinite}
@keyframes ls-spin{to{transform:rotate(360deg)}}



.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }

.ls-green-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 3px; overflow: hidden; display: none; background: rgba(34, 197, 94, 0.16); }
.ls-browser-shell.is-installing .ls-green-progress { display: block; }
.ls-green-progress::before {
  content: ""; position: absolute; top: 0; bottom: 0; width: 35%;
  background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
  box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
  animation: ls-bar 1.1s ease-in-out infinite;
}
`});function qo(e){Do=e?String(e).endsWith("/")?String(e):e+"/":""}function Io(){return Do}var Do,ln=C(()=>{Do=""});async function $o(){if(yr)return yr;let e=Io()+Pi;try{let r=await acode.require("fsOperation")(e).readFile("utf8");if(r&&r.length>1e3)return yr=String(r)}catch(t){console.warn("[LiveServer] devtool via fsOperation",t)}try{let t=await fetch(e);if(t.ok){let r=await t.text();if(r.length>1e3)return yr=r}}catch(t){console.warn("[LiveServer] devtool via fetch",t)}return null}var Pi,yr,Fo=C(()=>{ln();Pi="devtool/suger-dev.js",yr=null});var xr,jo=C(()=>{xr=class{constructor(t){this.element=t,this.element&&(this.scroller=this.element.parentNode,this.finalScale=1,this.offsetX=0,this.offsetY=0,this.tempScale=1,this.tempOffsetX=0,this.tempOffsetY=0,this.panning=!1,this.isPanningContent=!1,this.initialDistance=0,this.panStart=null,this.pageOrigin=null,this.handleTouchStart=this.handleTouchStart.bind(this),this.handleTouchMove=this.handleTouchMove.bind(this),this.handleTouchEnd=this.handleTouchEnd.bind(this),this.handleDoubleTap=this.handleDoubleTap.bind(this),this.setupZoomEvents())}setupZoomEvents(){let t=()=>{this.element.style.touchAction=this.finalScale>1?"none":"auto"};t(),this.element.style.transformOrigin="0 0",this.element.addEventListener("touchstart",this.handleTouchStart),this.element.addEventListener("touchmove",this.handleTouchMove),this.element.addEventListener("touchend",r=>{this.handleTouchEnd(r),t()}),this.element.addEventListener("touchcancel",this.handleTouchEnd),this.element.addEventListener("dblclick",this.handleDoubleTap)}destroy(){this.element.removeEventListener("touchstart",this.handleTouchStart),this.element.removeEventListener("touchmove",this.handleTouchMove),this.element.removeEventListener("touchend",this.handleTouchEnd),this.element.removeEventListener("touchcancel",this.handleTouchEnd),this.element.removeEventListener("dblclick",this.handleDoubleTap)}getDistance(t,r){let n=t.clientX-r.clientX,o=t.clientY-r.clientY;return Math.sqrt(n*n+o*o)}getPageCoordinates(t){var l,c;if((!this.scroller||!this.scroller.getBoundingClientRect)&&(this.scroller=this.element.parentNode,!this.scroller||!this.scroller.getBoundingClientRect))return console.error("ZoomHandler Error: Cannot find scroller parent element."),null;let r=this.scroller.getBoundingClientRect(),n=this.scroller.scrollLeft,o=this.scroller.scrollTop,i=(t[0].clientX+(((l=t[1])==null?void 0:l.clientX)||t[0].clientX))/t.length,s=(t[0].clientY+(((c=t[1])==null?void 0:c.clientY)||t[0].clientY))/t.length,d=i-r.left,f=s-r.top;return{x:d+n,y:f+o}}handleTouchStart(t){if(t.touches.length===2){if(t.preventDefault(),this.pageOrigin=this.getPageCoordinates(t.touches),!this.pageOrigin)return;this.panning=!0,this.initialDistance=this.getDistance(t.touches[0],t.touches[1])}else if(t.touches.length===1&&this.finalScale>1){let r=this.getPageCoordinates(t.touches);if(!r)return;this.isPanningContent=!0,this.panStart={x:r.x-this.offsetX,y:r.y-this.offsetY}}}handleTouchMove(t){let r=t.currentTarget;if(this.panning&&t.touches.length===2){t.preventDefault();let o=this.getDistance(t.touches[0],t.touches[1])/this.initialDistance;this.tempScale=this.finalScale*o,this.tempScale=Math.max(.5,Math.min(this.tempScale,5));let i=this.tempScale/this.finalScale;this.tempOffsetX=this.pageOrigin.x*(1-i)+this.offsetX*i,this.tempOffsetY=this.pageOrigin.y*(1-i)+this.offsetY*i,r.style.transform=`translate(${this.tempOffsetX}px, ${this.tempOffsetY}px) scale(${this.tempScale})`}else if(this.isPanningContent&&t.touches.length===1&&this.finalScale>1){t.preventDefault();let n=this.getPageCoordinates(t.touches);if(!n)return;this.tempOffsetX=n.x-this.panStart.x,this.tempOffsetY=n.y-this.panStart.y,r.style.transform=`translate(${this.tempOffsetX}px, ${this.tempOffsetY}px) scale(${this.finalScale})`}}handleTouchEnd(t){this.panning&&(this.panning=!1,this.finalScale=this.tempScale,this.offsetX=this.tempOffsetX,this.offsetY=this.tempOffsetY,this.pageOrigin=null),this.isPanningContent&&(this.isPanningContent=!1,this.offsetX=this.tempOffsetX,this.offsetY=this.tempOffsetY)}handleDoubleTap(t){let r=t.currentTarget;this.finalScale=1,this.tempScale=1,this.offsetX=0,this.offsetY=0,this.tempOffsetX=0,this.tempOffsetY=0,r.style.transition="transform 0.25s ease",r.style.transformOrigin="0 0",r.style.transform="translate(0,0) scale(1)",setTimeout(()=>{r.style.transition=""},300)}}});var Wo={};xe(Wo,{activateTab:()=>Et,addSourceTab:()=>Tn,addTab:()=>kt,applyZoom:()=>gn,canGoBack:()=>pn,canGoForward:()=>fn,clearVisited:()=>un,closeAllTabs:()=>wn,closeTab:()=>zt,disposeBridge:()=>yn,duplicateActive:()=>xn,findInActive:()=>kn,getActiveTab:()=>D,getTabs:()=>yt,getVisited:()=>kr,historyActive:()=>Lr,initBridge:()=>bn,isLocalUrl:()=>xt,navigateActive:()=>ze,normalizeUrl:()=>Je,onTabsChange:()=>hn,printActive:()=>En,reloadActive:()=>Er,renderTabStrip:()=>Cn,sendToTab:()=>Ae,setZoomActive:()=>_n,stopActive:()=>Sn,toDisplayUrl:()=>wt,toggleDevtoolsActive:()=>Ln});function yt(){return Z.slice()}function D(){return Z.find(e=>e.id===Fe)||null}function kr(){return Ke.slice()}function un(){Ke=[],K()}function pn(){let e=D();return!!(e&&e.historyIndex>0)}function fn(){let e=D();return!!(e&&e.historyIndex<e.history.length-1)}function hn(e){return wr.push(e),()=>{wr=wr.filter(t=>t!==e)}}function K(){wr.forEach(e=>{try{e(yt(),D())}catch{}})}function mn(e,t){let r=wt(e);!r||r==="about:blank"||r.startsWith("blob:")||(Ke=Ke.filter(n=>n.url!==r),Ke.unshift({url:r,title:t||r.replace(/^https?:\/\//i,""),ts:Date.now()}),Ke.length>50&&(Ke.length=50))}function xt(e){let t=wt(e);return/^https?:\/\/(127\.0\.0\.1|localhost|0\.0\.0\.0|192\.168\.|10\.)/i.test(String(t||""))}function wt(e){let t=String(e||"").trim();if(!t)return"about:blank";let r="/__proxy?url=",n=t.indexOf(r);if(n!==-1)try{let o=t.slice(n+r.length).split("&")[0];return decodeURIComponent(o)}catch{}return t}function Je(e){let t=wt(e);if(!t||t==="about:blank")return"about:blank";if(/^(about:|blob:|data:|https?:\/\/)/i.test(t))return t;if(/^(localhost|127\.0\.0\.1|0\.0\.0\.0|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(t))return"http://"+t;if(!/\s/.test(t)&&/^[a-z0-9-]+(\.[a-z0-9-]+)+([/?#].*)?$/i.test(t))return"https://"+t;let r=k().browserSearchEngine||"google",n=encodeURIComponent(t);return r==="duckduckgo"?`https://duckduckgo.com/?q=${n}`:r==="bing"?`https://www.bing.com/search?q=${n}`:r==="brave"?`https://search.brave.com/search?q=${n}`:`https://www.google.com/search?q=${n}`}async function Oi(e,t={}){if(!e||e==="about:blank"||e.startsWith("blob:"))return e||"about:blank";if(xt(e))return e;if((k().externalSiteMode||"proxy")==="proxy"){let n=B(),o=n.running&&n.port?n.port:await Rn();if(o)return`http://127.0.0.1:${o}/__proxy?url=${encodeURIComponent(e)}`}return e}function je(){cn&&(clearTimeout(cn),cn=null)}function Uo(e,t,r){je()}function Ae(e,t,r){try{return e.iframe.contentWindow.postMessage({ls:1,cmd:t,...r||{}},"*"),!0}catch{return!1}}function St(e){var t;try{let r=(t=e.iframe)==null?void 0:t.contentWindow;return r.document,r}catch{return null}}function gn(e){if(!e)return;let t=e.zoom||100,r=t/100;try{e.iframe&&(e.iframe.style.zoom=String(r),e.iframe.style.transformOrigin="0 0")}catch{}let n=St(e);if(n)try{n.document.documentElement.style.zoom=String(r)}catch{}Ae(e,"zoom",{pct:t})}function Hi(e){return Z.find(t=>{try{return t.iframe.contentWindow===e}catch{return!1}})}function vn(e,t){!e||!t||e.history[e.historyIndex]===t||(e.history=e.history.slice(0,e.historyIndex+1),e.history.push(t),e.historyIndex=e.history.length-1)}function No(e){let t=e.data;if(!t||t.ls!==1)return;let r=Hi(e.source);if(r)if(r.bridge=!0,t.type==="meta"){if(je(),r.loading=!1,t.href&&t.href!=="about:blank"){let n=wt(t.href);n!==r.url&&(r.url=n,vn(r,n))}r.pinTitle||(r.title=String(t.title||r.url.replace(/^https?:\/\//,"")).slice(0,60)),t.favicon&&(r.favicon=t.favicon),(r.zoom||100)!==100&&Ae(r,"zoom",{pct:r.zoom}),mn(r.url,r.title),K()}else t.type==="devtools"?(r.devtools=!!t.on,K()):t.type==="need-devtools"?$o().then(n=>{if(!n)return zo("Suger DevTool file missing (devtool/suger-dev.js). Reinstall the plugin.",3500);Ae(r,"devtools",{on:!0,code:n})}):t.type==="devtools-error"&&zo("DevTool: "+t.message,3e3)}function bn(){window.addEventListener("message",No)}function yn(){je(),window.removeEventListener("message",No)}function dn(e,t){!String(t||"").includes("/__proxy?url=")&&(xt(t)||t==="about:blank"||t.startsWith("blob:"))?e.setAttribute("sandbox","allow-scripts allow-same-origin allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-downloads"):e.removeAttribute("sandbox")}async function Sr(e,t,r={}){je();let n=k().externalSiteMode||"proxy";e.useChromium=!1;let o=Je(t);if(r.pushHistory!==!1&&vn(e,o),e.url=o,e.devtools=!1,e.useChromium=!1,o==="about:blank"){e.loading=!1,e.title="New tab",e.favicon=null,dn(e.iframe,"about:blank"),e.iframe.src="about:blank",K();return}e.loading=!0,e.pinTitle||(e.title=o.replace(/^https?:\/\//i,"")),K(),Uo(e,o,e.useChromium);let i=await Oi(o,{useChromium:e.useChromium});dn(e.iframe,i),e.iframe.src=i,mn(o,e.title),K()}function kt(e,t,r){var d,f;let n=Mi++,o=document.createElement("iframe");o.className="ls-browser-frame",o.setAttribute("allow","fullscreen; clipboard-read; clipboard-write");let i=t?Je(t):"about:blank",s={id:n,url:i,title:r||(i==="about:blank"?"New tab":i.replace(/^https?:\/\//i,"")),iframe:o,loading:i!=="about:blank",favicon:null,zoom:100,pinTitle:!!r,useChromium:!1,history:[i],historyIndex:0};e.appendChild(o);try{(f=(d=s.zoomHandler)==null?void 0:d.destroy)==null||f.call(d),s.zoomHandler=new xr(o)}catch(l){console.warn("[LiveServer] ZoomHandler",l)}return Z.push(s),Z.forEach(l=>{l.iframe&&(l.iframe.style.display=l.id===n?"block":"none")}),Fe=n,o.addEventListener("load",()=>{je(),s.loading=!1,s.devtools=!1;let l=St(s);if(l)try{let p=l.__LS_PROXY_TARGET__||wt(l.location.href);p&&p!=="about:blank"&&p!==s.url&&(s.url=p,vn(s,p)),s.pinTitle||(l.document.title?s.title=l.document.title.slice(0,60):s.url!=="about:blank"&&(s.title=s.url.replace(/^https?:\/\//,"")));let g=l.document.querySelector('link[rel~="icon"]');g!=null&&g.href&&(s.favicon=g.href)}catch{}else!s.pinTitle&&s.url!=="about:blank"&&(s.title=s.url.replace(/^https?:\/\//,""));if(!s.favicon&&/^https?:/i.test(s.url))try{s.favicon=new URL("/favicon.ico",s.url).href}catch{}gn(s),mn(s.url,s.title),K()}),i==="about:blank"?(dn(o,"about:blank"),o.src="about:blank",K()):Sr(s,i,{pushHistory:!1}),s}function xn(e){let t=D();return t?kt(e,t.url,t.title):null}function Et(e){Z.some(t=>t.id===e)&&(Fe=e,Z.forEach(t=>{t.iframe&&(t.iframe.style.display=t.id===e?"block":"none")}),K())}function zt(e){var n;let t=Z.findIndex(o=>o.id===e);if(t<0)return Z.length;let[r]=Z.splice(t,1);r.id===Fe&&je();try{(n=r.iframe)==null||n.remove()}catch{}if(Fe===e)if(Z.length){let o=Z[Math.min(t,Z.length-1)];Et(o.id)}else Fe=null,K();else K();return Z.length}function wn(){je(),Z.forEach(e=>{var t;try{(t=e.iframe)==null||t.remove()}catch{}}),Z=[],Fe=null,K()}function ze(e,t={}){let r=D();r!=null&&r.iframe&&Sr(r,e,{pushHistory:!0,useChromium:!1})}function Er(){let e=D();if(!(e!=null&&e.iframe))return;if(e.url==="about:blank"){K();return}e.loading=!0,Uo(e,e.url,e.useChromium);let t=St(e),r=!1;if(t)try{t.location.reload(),r=!0}catch{}!r&&!(e.bridge&&Ae(e,"reload"))&&(e.iframe.src=e.iframe.src),K()}function Sn(){je();let e=D();if(!(e!=null&&e.iframe))return;let t=St(e);if(t)try{t.stop()}catch{}else Ae(e,"stop");e.loading=!1,K()}function Lr(e){let t=D();if(t){if(e<0&&t.historyIndex>0){t.historyIndex-=1;let r=t.history[t.historyIndex];Sr(t,r,{pushHistory:!1});return}if(e>0&&t.historyIndex<t.history.length-1){t.historyIndex+=1;let r=t.history[t.historyIndex];Sr(t,r,{pushHistory:!1});return}}}function kn(e,t){var o;let r=D();if(!r||!e)return;let n=St(r);if(n)try{(o=n.find)==null||o.call(n,e,!1,!!t,!0,!1,!1,!1);return}catch{}Ae(r,"find",{q:e,back:!!t})}function En(){let e=D();if(!e)return!1;let t=St(e);if(t)try{return t.print(),!0}catch{}return Ae(e,"print")}function Ln(){let e=D();return!e||!e.bridge?!1:Ae(e,"devtools",{on:!e.devtools})}function _n(e){let t=D();return t?(t.zoom=Math.min(500,Math.max(25,Math.round(e))),gn(t),K(),t.zoom):100}function Cn(e){e&&(e.innerHTML="",Z.forEach(t=>{let r=document.createElement("div");r.className="ls-tab"+(t.id===Fe?" is-active":"")+(t.loading?" is-loading":""),r.setAttribute("role","tab"),r.title=t.title||"";let n=document.createElement("span");if(n.className="ls-fav",t.loading)n.classList.add("is-spin");else if(t.favicon){let s=document.createElement("img");s.src=t.favicon,s.alt="",s.addEventListener("error",()=>{n.innerHTML=A(T.globe,14)}),n.appendChild(s)}else n.innerHTML=A(T.globe,14);r.appendChild(n);let o=document.createElement("span");o.className="ls-tab-label",o.textContent=t.title||"Tab",r.appendChild(o);let i=document.createElement("span");i.className="ls-tab-x",i.setAttribute("role","button"),i.title="Close tab",i.innerHTML=A(T.close,12),i.addEventListener("click",s=>{s.stopPropagation(),zt(t.id)}),r.appendChild(i),r.addEventListener("click",()=>Et(t.id)),e.appendChild(r)}))}function Tn(e,t,r){let n=kt(e,"about:blank",t||"view-source");n.pinTitle=!0,n.loading=!1,n.url=t||"view-source";try{n.iframe.removeAttribute("sandbox")}catch{}try{n.iframe.srcdoc=r}catch{let i=new Blob([r],{type:"text/html;charset=utf-8"});n.iframe.src=URL.createObjectURL(i)}return n.loading=!1,K(),n}var zo,Z,Fe,Mi,wr,Ke,cn,An=C(()=>{jt();Fo();re();J();he();br();jo();zo=acode.require("toast"),Z=[],Fe=null,Mi=1,wr=[],Ke=[],cn=null});function Ut(e,t=20){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var Pn=C(()=>{});function ue(e,t){let r=document.createElement(e);return t&&(r.className=t),r}function Nt(){me&&me.close()}function Go(){return!!me}function Wt({host:e,anchor:t,items:r,onClose:n}){if(Nt(),!e||!(r!=null&&r.length))return{close(){}};let o=ue("div","ls-dd-layer"),i=ue("div","ls-dd-backdrop");o.appendChild(i),e.appendChild(o);let s=[],d=!1;function f(m){for(;s.length>m;)s.pop().remove()}function l(){if(!d){d=!0,document.removeEventListener("keydown",c,!0);try{o.remove()}catch{}me&&me.close===l&&(me=null);try{n==null||n()}catch{}}}function c(m){m.key==="Escape"&&(m.stopPropagation(),l())}function p(m,y,q){let b=e.getBoundingClientRect(),L=m.offsetWidth,R=m.offsetHeight,_,v;y===0?(v=q.bottom-b.top+2,_=q.right-b.left-L,_<4&&(_=q.left-b.left)):(v=q.top-b.top-4,_=q.right-b.left-2,_+L>b.width-4&&(_=q.left-b.left-L+2)),_+L>b.width-4&&(_=b.width-L-4),_<4&&(_=4);let P=b.height-v-4;R>P&&b.height&&(y>0&&b.height-R-4>0?v=b.height-R-4:m.style.maxHeight=Math.max(P,80)+"px"),v<4&&(v=4),m.style.left=_+"px",m.style.top=v+"px"}function g(m,y,q){f(y);let b=ue("div","ls-dd-menu");return b.setAttribute("role","menu"),b.style.visibility="hidden",m.forEach(L=>{if(L.separator){b.appendChild(ue("div","ls-dd-sep"));return}if(L.render){let H=ue("div","ls-dd-custom");L.render(H,l),b.appendChild(H);return}let R=ue("div","ls-dd-item"+(L.disabled?" is-disabled":""));R.setAttribute("role","menuitem");let _=ue("span","ls-dd-check");L.checked&&(_.innerHTML=Ut(Bi,14)),R.appendChild(_);let v=ue("span","ls-dd-label");if(v.textContent=L.label,R.appendChild(v),L.children){let H=ue("span","ls-dd-arrow");H.innerHTML=Ut(Di,14),R.appendChild(H)}let P=()=>{b.querySelectorAll(".ls-dd-item.is-active").forEach(H=>H.classList.remove("is-active")),R.classList.add("is-active"),g(L.children,y+1,R.getBoundingClientRect())},I=()=>{f(y+1),R.classList.remove("is-active")};R.addEventListener("pointerenter",H=>{H.pointerType&&H.pointerType!=="mouse"||(L.children?P():(f(y+1),b.querySelectorAll(".ls-dd-item.is-active").forEach(h=>h.classList.remove("is-active"))))}),R.addEventListener("click",H=>{var h;if(H.stopPropagation(),!L.disabled){if(L.children){R.classList.contains("is-active")&&s.length>y+1?I():P();return}l();try{(h=L.onClick)==null||h.call(L)}catch(x){console.warn("[LiveServer] menu item",x)}}}),b.appendChild(R)}),o.appendChild(b),s.push(b),p(b,y,q),b.style.visibility="",b}i.addEventListener("click",m=>{m.stopPropagation(),l()}),i.addEventListener("contextmenu",m=>{m.preventDefault(),l()}),document.addEventListener("keydown",c,!0);let a=t?t.getBoundingClientRect():e.getBoundingClientRect();return g(r,0,a),me={close:l},{close:l}}function Xo({host:e,anchor:t,render:r,onClose:n}){if(Nt(),!e)return{close(){}};let o=ue("div","ls-dd-layer"),i=ue("div","ls-dd-backdrop"),s=ue("div","ls-dd-menu ls-dd-panel");o.append(i,s),e.appendChild(o);let d=!1;function f(){if(!d){d=!0,document.removeEventListener("keydown",l,!0);try{o.remove()}catch{}me&&me.close===f&&(me=null);try{n==null||n()}catch{}}}function l(m){m.key==="Escape"&&(m.stopPropagation(),f())}i.addEventListener("click",m=>{m.stopPropagation(),f()}),document.addEventListener("keydown",l,!0),r(s,f);let c=e.getBoundingClientRect(),p=t?t.getBoundingClientRect():c,g=s.offsetWidth,a=p.right-c.left-g;return a>c.width-g-4&&(a=c.width-g-4),a<4&&(a=4),s.style.left=a+"px",s.style.top=p.bottom-c.top+2+"px",me={close:f},{close:f,panel:s}}var Bi,Di,me,Gt=C(()=>{Pn();Bi="M20 6L9 17l-5-5",Di="M9 18l6-6-6-6",me=null});async function qi(e){var t;try{if((t=navigator.clipboard)!=null&&t.writeText)await navigator.clipboard.writeText(e);else{let r=document.createElement("textarea");r.value=e,document.body.appendChild(r),r.select(),document.execCommand("copy"),r.remove()}Mn("URL copied",1500)}catch{Mn(e||"No URL",2500)}}async function Ii(){let{getServerStatus:e}=await Promise.resolve().then(()=>(he(),gt)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function Vo(e,t=38){return e=String(e||""),e.length>t?e.slice(0,t-1)+"\u2026":e}function $i(e){return{render(t){var l,c;let r=document.createElement("div");r.className="ls-zoomrow";let n=document.createElement("span");n.className="ls-zl",n.textContent="Zoom";let o=document.createElement("button");o.type="button",o.className="ls-ib",o.innerHTML=A(T.minus,14);let i=document.createElement("span");i.className="ls-zv",i.textContent=((c=(l=e.getZoom)==null?void 0:l.call(e))!=null?c:100)+"%";let s=document.createElement("button");s.type="button",s.className="ls-ib",s.innerHTML=A(T.plus,14);let d=document.createElement("button");d.type="button",d.className="ls-ib",d.title="Fullscreen",d.innerHTML=A(T.maximize,14);let f=p=>{var a;let g=(a=e.zoom)==null?void 0:a.call(e,p);g!=null&&(i.textContent=g+"%")};o.addEventListener("click",p=>{p.stopPropagation(),f(-10)}),s.addEventListener("click",p=>{p.stopPropagation(),f(10)}),i.style.cursor="pointer",i.addEventListener("click",p=>{var a;p.stopPropagation();let g=(a=e.zoom)==null?void 0:a.call(e,0,!0);g!=null&&(i.textContent=g+"%")}),d.addEventListener("click",p=>{var g;p.stopPropagation(),(g=e.toggleFullscreen)==null||g.call(e)}),r.append(n,o,i,s,d),t.appendChild(r)}}}function On(e,t){var s,d,f,l,c,p,g;let r=((s=e.getVisited)==null?void 0:s.call(e))||[],n=((d=e.getBookmarks)==null?void 0:d.call(e))||[],o=!!((f=e.isBookmarked)!=null&&f.call(e)),i=[{label:"New tab",onClick:()=>{var a;return(a=e.newTab)==null?void 0:a.call(e)}},{label:"Duplicate tab",onClick:()=>{var a;return(a=e.duplicateTab)==null?void 0:a.call(e)}},{separator:!0},{label:"History",children:r.length?[...r.slice(0,15).map(a=>({label:Vo(a.title||a.url),onClick:()=>{var m;return(m=e.navigate)==null?void 0:m.call(e,a.url)}})),{separator:!0},{label:"Clear history",onClick:()=>{var a;return(a=e.clearHistory)==null?void 0:a.call(e)}}]:[{label:"No history yet",disabled:!0}]},{label:"Bookmarks",children:[{label:o?"Remove bookmark for this tab":"Bookmark this tab",onClick:()=>{var a;return(a=e.toggleBookmark)==null?void 0:a.call(e)}},...n.length?[{separator:!0}]:[],...n.map(a=>({label:Vo(a.title||a.url),onClick:()=>{var m;return(m=e.navigate)==null?void 0:m.call(e,a.url)}}))]},{separator:!0},$i(e),{label:"Print\u2026",onClick:()=>{var a;return(a=e.print)==null?void 0:a.call(e)}},{label:"Find\u2026",onClick:()=>{var a;return(a=e.find)==null?void 0:a.call(e)}},{label:"Developer tools",checked:!!((l=e.isDevtools)!=null&&l.call(e)),onClick:()=>{var a;return(a=e.toggleDevtools)==null?void 0:a.call(e)}},{separator:!0},{label:"More tools",children:[{label:"Device mode (responsive)",checked:!!((c=e.isDeviceMode)!=null&&c.call(e)),onClick:()=>{var a;return(a=e.toggleDeviceMode)==null?void 0:a.call(e)}},{label:"View page source",onClick:()=>{var a;return(a=e.viewSource)==null?void 0:a.call(e)}},{separator:!0},{label:"Zoom in",onClick:()=>{var a;return(a=e.zoom)==null?void 0:a.call(e,10)}},{label:"Zoom out",onClick:()=>{var a;return(a=e.zoom)==null?void 0:a.call(e,-10)}},{label:"Reset zoom",onClick:()=>{var a;return(a=e.zoom)==null?void 0:a.call(e,0,!0)}},{separator:!0},{label:"Open server root",onClick:async()=>{var m;let a=await Ii();a?(m=e.navigate)==null||m.call(e,a):Mn("Server not running",2e3)}},{label:"Copy current URL",onClick:()=>{var a;return qi(((a=e.getUrl)==null?void 0:a.call(e))||"")}},{label:"Open in external browser",onClick:()=>{var a;return(a=e.openExternal)==null?void 0:a.call(e)}},{separator:!0},{label:"Close other tabs",onClick:()=>{var a;return(a=e.closeOtherTabs)==null?void 0:a.call(e)}},{label:"Close current tab",onClick:()=>{var a;return(a=e.closeTab)==null?void 0:a.call(e)}}]},{label:"Opacity\u2026",onClick:()=>{var a;return(a=e.openOpacity)==null?void 0:a.call(e)}},{label:"Preview as overlay",checked:!!((p=e.isOverlay)!=null&&p.call(e)),disabled:!((g=e.canOverlay)!=null&&g.call(e)),onClick:()=>{var a;return(a=e.toggleOverlay)==null?void 0:a.call(e)}},{separator:!0},{label:"Settings",onClick:async()=>{let{openSettingsHub:a}=await Promise.resolve().then(()=>(Xt(),_r));a()}},{label:"Exit",onClick:()=>{var a;return(a=e.closeBrowser)==null?void 0:a.call(e)}}];return Wt({host:t.host,anchor:t.anchor,items:i})}var Mn,Yo=C(()=>{Gt();jt();Mn=acode.require("toast")});function Qe(e){let t=parseFloat(e);return Number.isFinite(t)?Math.min(Hn,Math.max(Cr,Math.round(t*100)/100)):1}function Zo(e){return String(Qe(e)).replace(/(\.\d)0$/,"$1")}function Ko(e,t,r){let n=document.createElement("div");n.className="ls-op-row"+(r?" is-disabled":"");let o=document.createElement("span");o.textContent=e;let i=document.createElement("span");return i.className="ls-switch"+(t?" is-on":""),n.append(o,i),{r:n,sw:i}}function Jo({host:e,anchor:t,get:r,set:n}){return Xo({host:e,anchor:t,render(o){let i=r(),s=document.createElement("div");s.className="ls-op-head";let d=document.createElement("span");d.textContent="Browser opacity";let f=document.createElement("span");f.className="ls-op-val",f.textContent=Zo(i.opacity),s.append(d,f);let l=document.createElement("input");l.type="range",l.className="ls-range",l.min=String(Cr),l.max=String(Hn),l.step="0.05",l.value=String(Qe(i.opacity));let c=()=>{let m=(l.value-Cr)/(Hn-Cr)*100;l.style.setProperty("--ls-fill",m+"%")};c(),l.addEventListener("input",()=>{c(),f.textContent=Zo(l.value),n({opacity:Qe(l.value)})});let p=Ko("Preview as overlay",i.overlay,!i.canOverlay),g=Ko("Auto-save while typing",i.autoSave,!1);g.r.style.display=i.overlay?"":"none",p.r.addEventListener("click",()=>{let m=!p.sw.classList.contains("is-on");p.sw.classList.toggle("is-on",m),g.r.style.display=m?"":"none",n({overlay:m})}),g.r.addEventListener("click",()=>{let m=!g.sw.classList.contains("is-on");g.sw.classList.toggle("is-on",m),n({autoSave:m})});let a=document.createElement("div");a.className="ls-op-hint",a.textContent=i.canOverlay?"Overlay: the preview is see-through and you can keep editing underneath.":"Overlay needs the Acode page display mode.",o.append(s,l,p.r,g.r,a)}})}var Cr,Hn,Qo=C(()=>{Gt();Cr=.1,Hn=1});function Ar(e){return Tr.find(t=>t.id===e)||Tr[0]}function Re(e){let t=Math.round(Number(e));return Number.isFinite(t)?Math.min(Fi,Math.max(Dn,t)):null}function es(e,t,r,n,o){return e!=="fit"?Math.max(.1,Number(e)/100):!n||!o?1:Math.min(1,n/t,o/r)}var Tr,Bn,Dn,Fi,ts=C(()=>{Tr=[{id:"responsive",name:"Responsive",w:390,h:844},{id:"iphone-se",name:"iPhone SE",w:375,h:667},{id:"iphone-xr",name:"iPhone XR",w:414,h:896},{id:"iphone-12-pro",name:"iPhone 12 Pro",w:390,h:844},{id:"iphone-14-pro-max",name:"iPhone 14 Pro Max",w:430,h:932},{id:"pixel-7",name:"Pixel 7",w:412,h:915},{id:"galaxy-s8-plus",name:"Samsung Galaxy S8+",w:360,h:740},{id:"galaxy-s20-ultra",name:"Samsung Galaxy S20 Ultra",w:412,h:915},{id:"galaxy-fold",name:"Galaxy Fold",w:280,h:653},{id:"surface-duo",name:"Surface Duo",w:540,h:720},{id:"ipad-mini",name:"iPad Mini",w:768,h:1024},{id:"ipad-air",name:"iPad Air",w:820,h:1180},{id:"ipad-pro",name:"iPad Pro",w:1024,h:1366},{id:"surface-pro-7",name:"Surface Pro 7",w:912,h:1368},{id:"nest-hub",name:"Nest Hub",w:1024,h:600},{id:"nest-hub-max",name:"Nest Hub Max",w:1280,h:800},{id:"laptop",name:"Laptop 1366",w:1366,h:768},{id:"desktop",name:"Desktop 1920",w:1920,h:1080}],Bn=["fit",25,50,75,100,125,150,200];Dn=50,Fi=9999});function Pe(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.innerHTML=r),n}function rs({shell:e,stage:t,box:r,device:n,bar:o,onChange:i}){let s={on:!1,id:"responsive",w:390,h:844,zoom:"fit"},d=1,f=null,l=Pe("button","ls-dev-btn ls-dev-device");l.type="button";let c=Pe("input","ls-dev-num"),p=Pe("input","ls-dev-num");[c,p].forEach(h=>{h.type="number",h.min=String(Dn),h.inputMode="numeric"});let g=Pe("span","ls-dev-x","&times;"),a=Pe("button","ls-dev-btn ls-dev-zoom");a.type="button";let m=Pe("button","ls-dev-icon",A(T.rotate,16));m.type="button",m.title="Rotate";let y=Pe("button","ls-dev-icon",A(T.close,16));y.type="button",y.title="Close device mode";let q=Pe("span","ls-dev-spacer");o.append(l,c,g,p,a,m,q,y);function b(){try{i==null||i({...s})}catch{}}function L(){return s.zoom==="fit"?"Fit to window ("+Math.round(d*100)+"%)":s.zoom+"%"}function R(){l.innerHTML="<span>"+Ar(s.id).name+"</span>"+A(T.down,12),document.activeElement!==c&&(c.value=String(s.w)),document.activeElement!==p&&(p.value=String(s.h)),a.innerHTML="<span>"+L()+"</span>"+A(T.down,12)}function _(){if(e.classList.toggle("is-device",s.on),o.hidden=!s.on,!s.on){r.style.width="",r.style.height="",n.style.width="",n.style.height="",n.style.transform="";return}let h=t.clientWidth-24,x=t.clientHeight-24;d=es(s.zoom,s.w,s.h,h,x),r.style.width=Math.round(s.w*d)+"px",r.style.height=Math.round(s.h*d)+"px",n.style.width=s.w+"px",n.style.height=s.h+"px",n.style.transform="scale("+d+")",R()}function v(h,x,ee){let be=Re(h),Xe=Re(x);be!=null&&(s.w=be),Xe!=null&&(s.h=Xe),ee||(s.id="responsive"),_(),b()}function P(h){let x=Ar(h);s.id=x.id,s.w=x.w,s.h=x.h,_(),b()}l.addEventListener("click",()=>{Wt({host:e,anchor:l,items:Tr.map(h=>({label:h.id==="responsive"?h.name:h.name+"  "+h.w+" x "+h.h,checked:h.id===s.id,onClick:()=>P(h.id)}))})}),a.addEventListener("click",()=>{Wt({host:e,anchor:a,items:Bn.map(h=>({label:h==="fit"?"Fit to window":h+"%",checked:h===s.zoom,onClick:()=>{s.zoom=h,_(),b()}}))})}),m.addEventListener("click",()=>v(s.h,s.w,!0)),y.addEventListener("click",()=>H.toggle(!1));let I=()=>v(c.value,p.value);[c,p].forEach(h=>{h.addEventListener("change",I),h.addEventListener("keydown",x=>{x.key==="Enter"&&(I(),h.blur())})}),["r","b","c"].forEach(h=>{let x=Pe("div","ls-hdl ls-hdl-"+h);r.appendChild(x),x.addEventListener("pointerdown",ee=>{ee.preventDefault(),ee.stopPropagation();let be=ee.clientX,Xe=ee.clientY,Tt=s.w,or=s.h;try{x.setPointerCapture(ee.pointerId)}catch{}n.style.pointerEvents="none";let At=it=>{var V,ie;let u=d||1,w=h==="b"?Tt:Tt+(it.clientX-be)/u,U=h==="r"?or:or+(it.clientY-Xe)/u;s.id="responsive",s.w=(V=Re(w))!=null?V:s.w,s.h=(ie=Re(U))!=null?ie:s.h,_()},Ve=()=>{x.removeEventListener("pointermove",At),x.removeEventListener("pointerup",Ve),x.removeEventListener("pointercancel",Ve),n.style.pointerEvents="",b()};x.addEventListener("pointermove",At),x.addEventListener("pointerup",Ve),x.addEventListener("pointercancel",Ve)})}),typeof ResizeObserver=="function"&&(f=new ResizeObserver(()=>{s.on&&s.zoom==="fit"&&_()}),f.observe(t));let H={getState:()=>({...s}),getScale:()=>d,isOn:()=>s.on,setState(h){h&&(typeof h.id=="string"&&(s.id=Ar(h.id).id),Re(h.w)!=null&&(s.w=Re(h.w)),Re(h.h)!=null&&(s.h=Re(h.h)),h.zoom!=null&&(s.zoom=Bn.includes(h.zoom)?h.zoom:"fit"),s.on=!!h.on,_())},toggle(h){return s.on=h==null?!s.on:!!h,_(),b(),s.on},layout:_,destroy(){try{f==null||f.disconnect()}catch{}}};return R(),H}var ns=C(()=>{jt();Gt();ts()});function Vt(e,t){if(!e)return;let r=t==null?!e.classList.contains("is-fullscreen"):!!t;return e.classList.toggle("is-fullscreen",r),document.body.classList.toggle("ls-browser-fs",r),r}function os(e){return Vt(e,!1)}var ss=C(()=>{});function is(e,t={}){var R,_;let r=acode.require("page"),n=acode.require("actionStack"),o="liveserver-browser-page-"+ ++ji,i=document.createElement("span");i.className="icon arrow_back",i.dataset.action="back",i.style.cssText="pointer-events:auto;cursor:pointer;";let s=r(t.title||"Live Preview",{lead:i}),d=s.body||s,f=s.header||((R=s.querySelector)==null?void 0:R.call(s,"header"));f&&(f.style.display="none"),Object.assign(d.style,{position:"absolute",inset:"0",top:"0",left:"0",right:"0",bottom:"0",width:"auto",height:"auto",padding:"0",margin:"0",overflow:"hidden"}),e.classList.add("is-in-page"),typeof s.appendBody=="function"?s.appendBody(e):d.appendChild(e);let l=!1,c=null,p=()=>{var P;let v=!1;try{v=!!((P=t.onBack)!=null&&P.call(t))}catch{}if(v){try{n.remove(o),n.push({id:o,action:p})}catch{}return}a()};function g(){try{n.remove(o),n.push({id:o,action:p})}catch{}}function a(){if(!l){try{n.remove(o)}catch{}try{s.style.display="none"}catch{}}}function m(){var v;if(!l){try{s.style.display="",s.isConnected||(window.app||document.body).append(s),(v=s.show)==null||v.call(s)}catch{}g()}}function y(v){var P,I,H;if(!l){l=!0;try{window.removeEventListener("resize",L)}catch{}try{n.remove(o)}catch{}try{(P=s.hide)==null||P.call(s)}catch{}try{(I=s.remove)==null||I.call(s)}catch{}if(v)try{(H=t.onClose)==null||H.call(t)}catch{}}}i.onclick=v=>{var P,I;try{(P=v==null?void 0:v.preventDefault)==null||P.call(v),(I=v==null?void 0:v.stopPropagation)==null||I.call(v)}catch{}a()};try{s.onhide=()=>{l||a()}}catch{}(window.app||document.body).append(s);try{getComputedStyle(s).position==="static"&&Object.assign(s.style,{position:"absolute",inset:"0",width:"100%",height:"100%"})}catch{}try{(_=s.show)==null||_.call(s)}catch{}g();let q=()=>{var v,P;try{let I=(v=window.editorManager)==null?void 0:v.container,H=(P=I==null?void 0:I.getBoundingClientRect)==null?void 0:P.call(I);if(H&&H.width>0&&H.height>0)return H}catch{}return{left:0,top:0,width:window.innerWidth,height:window.innerHeight}},b=()=>{let v=q();s.style.left=v.left+"px",s.style.top=v.top+"px",s.style.width=v.width+"px",s.style.height=v.height+"px"},L=()=>{c!=null&&b()};return window.addEventListener("resize",L),{page:s,show:m,minimize:a,setAppearance({overlay:v,opacity:P}){v?(c==null&&(c=s.style.cssText),Object.assign(s.style,{position:"fixed",background:"transparent",pointerEvents:"none",opacity:"1"}),b(),d.style.background="transparent"):(c!=null&&(s.style.cssText=c,c=null),d.style.background="",s.style.opacity=P<1?String(P):"")},close:()=>{window.removeEventListener("resize",L),y(!1)},onFullscreen(){}}}var ji,as=C(()=>{ji=0});function Ui(){for(let e of["editorFile","EditorFile"])try{let t=acode.require(e);if(typeof t=="function")return t}catch{}return null}async function ls(e,t={}){var l;let r=Ui();if(!r)return null;e.classList.add("is-in-tab");let n=t.title||"Live Preview",o="liveserver-preview-"+Date.now()+"-"+ ++zi,i=null,s=[{type:"custom",content:e,stylesheets:t.css?[t.css]:[],hideQuickTools:!0,id:o,render:!0},{type:"page",content:e,stylesheets:t.css?[t.css]:[],id:o,render:!0}];for(let c of s)try{i=new r(n,c);break}catch(p){console.warn("[LiveServer] EditorFile "+c.type,p),i=null}if(!i)return e.classList.remove("is-in-tab"),null;let d=!1,f=()=>{var c;if(!d){d=!0;try{(c=t.onClose)==null||c.call(t)}catch{}}};try{(l=i.on)==null||l.call(i,"close",f)}catch{}try{i.onclose=f}catch{}return{file:i,show(){var c;if(!d)try{(c=i.makeActive)==null||c.call(i)}catch{}},close(){var c,p;if(!d){d=!0;try{(c=i.remove)==null||c.call(i,!0)}catch{try{(p=i.remove)==null||p.call(i)}catch{}}}},onFullscreen(){},setAppearance(){}}}var zi,cs=C(()=>{zi=0});var us={};xe(us,{destroyAcodeWebview:()=>Gi,isNativeWebviewSupported:()=>Wi,openInAcodeWebview:()=>qn});function ds(e){var t,r,n;try{return(r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open?(window.cordova.InAppBrowser.open(e,"_system"),!0):(n=window.cordova)!=null&&n.exec?(window.cordova.exec(null,null,"System","open-in-browser",[e]),!0):(window.open(e,"_blank","noopener"),!0)}catch{return Ni(e,2500),!1}}function Wi(){try{let e=acode.require("webview");return!!(e&&typeof e.create=="function")}catch{return!1}}async function qn(e,t={}){if(!e||e==="about:blank")return!1;let r=null;try{r=acode.require("webview")}catch{}if(!(r!=null&&r.create))return ds(e);if(ge)try{return await ge.loadURL(e),await ge.show(),!0}catch{ge=null}try{let n=await r.create({mode:"fullscreen",title:t.title||e.replace(/^https?:\/\//i,""),allowNavigation:!0,allowDownloads:t.allowDownloads!==!1,visible:!0});return ge=n,n.on("closed",()=>{ge===n&&(ge=null)}),await n.loadURL(e),!0}catch(n){return console.warn("[LiveServer] native webview failed, falling back:",n),ge=null,ds(e)}}async function Gi(){if(!ge)return;let e=ge;ge=null;try{await e.destroy()}catch{}}var Ni,ge,In=C(()=>{Ni=acode.require("toast"),ge=null});var rt={};xe(rt,{createBrowserShell:()=>na,hideBrowser:()=>_t,openBrowser:()=>jn,openBrowserMenu:()=>On});function gs(){return k().browserDisplayMode==="editorTab"?"editorTab":"inPage"}function Zi(e,t){try{return new URL(e).origin===new URL(t).origin}catch{return!1}}function et(){let e=k().browserBookmarks;return Array.isArray(e)?e:[]}async function Ki(){let{getServerStatus:e}=await Promise.resolve().then(()=>(he(),gt)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function fs(e){var t,r,n;if(!(!e||e==="about:blank"))try{if((r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open){window.cordova.InAppBrowser.open(e,"_system");return}if((n=window.cordova)!=null&&n.exec){window.cordova.exec(null,null,"System","open-in-browser",[e]);return}window.open(e,"_blank","noopener")}catch{se(e,2500)}}function Ji(){if(!(Lt||typeof editorManager=="undefined"||!(editorManager!=null&&editorManager.on))){Lt=()=>{k().overlayAutoSave!==!1&&(clearTimeout($n),$n=setTimeout(async()=>{var r;let e=X(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";if(e&&e.isUnsaved&&(e.uri||e.url)&&Vi.test(t))try{await((r=e.save)==null?void 0:r.call(e))}catch(n){console.warn("[LiveServer] overlay auto-save",n)}},700))};try{editorManager.on("update",Lt)}catch{}}}function vs(){var e;if(clearTimeout($n),Lt)try{(e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"update",Lt)}catch{}Lt=null}function Pr(){return tt==="page"&&!!k().browserOverlay}function Fn(){var n,o;if(!z)return;let e=k(),t=Qe((n=e.browserOpacity)!=null?n:1),r=Pr();z.classList.toggle("is-overlay",r),z.classList.toggle("no-url",e.showAddressBar===!1),z.style.setProperty("--ls-op",String(t)),tt==="page"?((o=j==null?void 0:j.setAppearance)==null||o.call(j,{overlay:r,opacity:t}),z.style.opacity=""):z.style.opacity=t<1?String(t):"",r?Ji():vs(),Y==null||Y.layout()}function hs(e){if("opacity"in e&&M("browserOpacity",Qe(e.opacity)),"overlay"in e){if(e.overlay&&tt!=="page"){se("Overlay needs the Acode page display mode",2200);return}M("browserOverlay",!!e.overlay)}"autoSave"in e&&M("overlayAutoSave",!!e.autoSave),Fn()}function Qi(e){var At,Ve,it;let t=u=>e.querySelector(u),r=t(".ls-browser-tabs"),n=t(".ls-stage"),o=t(".ls-box"),i=t(".ls-device"),s=t(".ls-ntp"),d=t(".ls-back"),f=t(".ls-fwd"),l=t(".ls-browser-url"),c=t(".ls-reload"),p=t(".ls-star"),g=t(".ls-site"),a=t(".ls-menu-btn"),m=t(".ls-op-btn"),y=t(".ls-dev-toggle"),q=t(".ls-find"),b=q.querySelector("input"),L=!1;Y=rs({shell:e,stage:n,box:o,device:i,bar:t(".ls-devbar"),onChange:u=>M("browserDevice",u)});let R=k().browserDevice;R&&typeof R=="object"&&Y.setState(R);let _=()=>e.getRootNode().activeElement===l,v=async u=>{if(u==="about:blank"){ze("about:blank");return}let w=Je(u);if(!w||w==="about:blank"){ze("about:blank");return}if(!xt(w)){let U=k().externalSiteMode||"proxy";if(U==="acodeWebview"){await qn(w);return}if(U==="systemBrowser"){fs(w);return}}ze(w)},P=()=>{s.innerHTML="";let u=document.createElement("div");u.className="ls-ntp-hero";let w=document.createElement("img");w.className="ls-ntp-logo",w.src=Xi,w.alt="Live Server",w.onerror=()=>{w.style.display="none"},u.appendChild(w);let U=document.createElement("div");U.className="ls-ntp-title",U.textContent="Live Server",u.appendChild(U);let V=document.createElement("div");V.className="ls-ntp-search";let ie=document.createElement("span");ie.className="ls-ntp-search-ico",ie.innerHTML=A(T.search,17);let ae=document.createElement("input");ae.type="text",ae.placeholder="Search or type a URL",ae.setAttribute("enterkeyhint","enter"),ae.setAttribute("inputmode","text"),ae.setAttribute("spellcheck","false"),ae.setAttribute("autocapitalize","off"),ae.setAttribute("autocomplete","off");let Oe=document.createElement("button");Oe.type="button",Oe.className="ls-ntp-search-btn",Oe.textContent="Search";let W=()=>{let S=ae.value.trim();if(!S){ae.focus();return}v(S)};ae.addEventListener("keydown",S=>{S.key==="Enter"&&W()}),Oe.addEventListener("click",W),V.append(ie,ae,Oe);let He=document.createElement("div");He.className="ls-ntp-tiles";let zr=async S=>{let $=et();if(S<0||S>=$.length)return;let G=acode.require("prompt"),Q=acode.require("select"),te=$[S],F=await Q("Shortcut",[["edit","Edit name / URL"],["delete","Remove shortcut"]],{hideOnSelect:!0});if(!F)return;if(F==="delete"){$.splice(S,1),M("browserBookmarks",$),P();return}let at=await G("Bookmark URL",te.url||"https://","text");if(!at)return;let Ye=Je(at),ye=await G("Shortcut name",te.title||Ye.replace(/^https?:\/\//,""),"text")||Ye;$[S]={url:Ye,title:ye},M("browserBookmarks",$),P()},Ur=(S,$)=>{let G=null,Q=!1,te=()=>{G&&clearTimeout(G),G=null};S.addEventListener("touchstart",F=>{Q=!1,te(),G=setTimeout(()=>{G=null,$(F)},480)},{passive:!0}),S.addEventListener("touchmove",()=>{Q=!0,te()},{passive:!0}),S.addEventListener("touchend",te),S.addEventListener("touchcancel",te),S.addEventListener("contextmenu",F=>{F.preventDefault(),$(F)}),S.addEventListener("pointerdown",F=>{F.pointerType==="mouse"&&F.button===2||F.pointerType})},oo=(S,$,G,Q,te={})=>{let F=document.createElement("button");F.type="button",F.className="ls-ntp-tile",F.innerHTML='<span class="ls-ntp-dot"></span><span class="ls-ntp-name"></span>';let at=F.querySelector(".ls-ntp-dot");if(Q&&/^https?:/i.test(Q)&&!xt(Q)){let ye=document.createElement("img");ye.src=Q,ye.alt="",ye.onerror=()=>{at.textContent=G},at.appendChild(ye)}else at.textContent=G;F.querySelector(".ls-ntp-name").textContent=S;let Ye=!1;return F.addEventListener("click",async ye=>{if(Ye){Ye=!1,ye.preventDefault();return}let ao=typeof $=="function"?await $():$;if(!ao)return se("Server not running",2e3);v(ao)}),typeof te.onLongPress=="function"&&Ur(F,ye=>{Ye=!0,te.onLongPress(ye)}),F};He.appendChild(oo("Server root",Ki,"S",null)),et().forEach((S,$)=>{var te;let G=null;try{let F=new URL(S.url).hostname;F&&F!=="127.0.0.1"&&F!=="localhost"&&(G=`https://www.google.com/s2/favicons?domain=${encodeURIComponent(F)}&sz=64`)}catch{}let Q=((te=(S.title||S.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:te.toUpperCase())||"B";He.appendChild(oo(S.title||S.url,S.url,Q,G,{onLongPress:()=>zr($)}))});let Rt=document.createElement("button");Rt.type="button",Rt.className="ls-ntp-tile",Rt.innerHTML=`<span class="ls-ntp-dot">${A(T.plus,20)}</span><span class="ls-ntp-name">Add shortcut</span>`,Rt.addEventListener("click",async()=>{let S=acode.require("prompt"),$=await S("Bookmark URL (e.g. https://duckduckgo.com)","https://","text");if(!$)return;let G=Je($),Q=await S("Shortcut name",G.replace(/^https?:\/\//,""),"text")||G,te=et();M("browserBookmarks",[...te,{title:Q.trim(),url:G}]),P()}),He.appendChild(Rt);let sr=document.createElement("div");sr.className="ls-ntp-recent-wrap";let Nr=kr(),ir=document.createElement("div");ir.className="ls-ntp-sec-head";let so=document.createElement("span");if(so.textContent="Recent",ir.appendChild(so),Nr.length>0){let S=document.createElement("button");S.type="button",S.className="ls-ntp-more",S.textContent=L?"Less":"More",S.addEventListener("click",()=>{L=!L,P()}),ir.appendChild(S)}sr.appendChild(ir);let ar=document.createElement("div");ar.className="ls-ntp-recent-list";let io=L?Nr:Nr.slice(0,5);if(io.length)io.forEach(S=>{var Q;let $=document.createElement("button");$.type="button",$.className="ls-ntp-recent-row";let G=((Q=(S.title||S.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:Q.toUpperCase())||"W";$.innerHTML=`
          <span class="ls-ntp-recent-ico">${G}</span>
          <span class="ls-ntp-recent-meta">
            <span class="ls-ntp-recent-title"></span>
            <span class="ls-ntp-recent-url"></span>
          </span>
        `,$.querySelector(".ls-ntp-recent-title").textContent=S.title||S.url,$.querySelector(".ls-ntp-recent-url").textContent=S.url,$.addEventListener("click",()=>v(S.url)),ar.appendChild($)});else{let S=document.createElement("div");S.className="ls-ntp-empty",S.textContent="No recent pages yet",ar.appendChild(S)}sr.appendChild(ar),s.append(u,V,He,sr)},I=()=>{let u=D();Cn(r),l&&!_()&&(l.value=u&&u.url!=="about:blank"?u.url:""),e.classList.toggle("is-loading",!!(u!=null&&u.loading)),e.classList.toggle("is-installing",document.body.classList.contains("ls-green-loading")),c.innerHTML=A(u!=null&&u.loading?T.close:T.reload,18),c.title=u!=null&&u.loading?"Stop loading":"Reload",d&&(d.disabled=!pn()),f&&(f.disabled=!fn());let w=/^https:/i.test((u==null?void 0:u.url)||"");g.innerHTML=A(w?T.lock:T.info,16),g.title=w?"Connection is secure":"Not secure";let U=!!u&&et().some(ie=>ie.url===u.url);p.classList.toggle("is-on",U);let V=!u||u.url==="about:blank";V&&P(),s.classList.toggle("is-on",V),yt().length||_t()};Ue==null||Ue(),Ue=hn(I);let H=()=>{var w;let u=Vt(e);(w=j==null?void 0:j.onFullscreen)==null||w.call(j,u)},h=()=>{var u;L=!1,kt(i,"about:blank"),Et((u=D())==null?void 0:u.id)},x=()=>{L=!1;let u=String(k().browserHomeUrl||"").trim();u?v(u):ze("about:blank")},ee=(u,w)=>{var U,V;return w>0?(U=ps.find(ie=>ie>u))!=null?U:u:(V=[...ps].reverse().find(ie=>ie<u))!=null?V:u},be=u=>kn(b.value,u),Xe=()=>{let u=D();if(!u||u.url==="about:blank")return se("Nothing to bookmark",1500);let w=et(),U=w.some(V=>V.url===u.url);M("browserBookmarks",U?w.filter(V=>V.url!==u.url):[...w,{title:u.title||u.url,url:u.url}]),I(),se(U?"Bookmark removed":"Bookmarked",1200)},Tt=()=>Jo({host:e,anchor:m,get:()=>{var u;return{opacity:Qe((u=k().browserOpacity)!=null?u:1),overlay:Pr(),autoSave:k().overlayAutoSave!==!1,canOverlay:tt==="page"}},set:hs}),or=()=>({newTab:h,duplicateTab:()=>xn(i),closeTab:()=>{let u=D();u&&zt(u.id)},closeOtherTabs:()=>{let u=D();yt().filter(w=>w.id!==(u==null?void 0:u.id)).forEach(w=>zt(w.id))},navigate:u=>v(u),getUrl:()=>{var u;return((u=D())==null?void 0:u.url)||""},getVisited:kr,clearHistory:()=>{un(),P(),se("History cleared",1500)},getBookmarks:et,isBookmarked:()=>{let u=D();return!!u&&et().some(w=>w.url===u.url)},toggleBookmark:Xe,getZoom:()=>{var u,w;return(w=(u=D())==null?void 0:u.zoom)!=null?w:100},zoom:(u,w)=>{let U=D();return U?_n(w?100:ee(U.zoom||100,u)):100},toggleFullscreen:H,print:()=>{En()||se("Cannot print this page",1800)},find:()=>{q.hidden=!1,b.focus(),b.select()},isDevtools:()=>{var u;return!!((u=D())!=null&&u.devtools)},toggleDevtools:()=>{let u=D();if(!u||u.url==="about:blank")return se("Open a page first",1800);Ln()||se("DevTools work on pages served by Live Server",3e3)},isDeviceMode:()=>Y.isOn(),toggleDeviceMode:()=>Y.toggle(),viewSource:async()=>{var ae,Oe;let u=D();if(!u||u.url==="about:blank"||String(u.url).startsWith("view-source:"))return se("No page source here",1800);se("Loading source\u2026",1200);let w="";try{let W=(ae=u.iframe)==null?void 0:ae.contentDocument;W!=null&&W.documentElement&&(w=`<!DOCTYPE html>
`+W.documentElement.outerHTML)}catch{}if(!w)try{let W=(Oe=u.iframe)!=null&&Oe.src&&u.iframe.src!=="about:blank"?u.iframe.src:u.url,He=new AbortController,zr=setTimeout(()=>He.abort(),15e3),Ur=await fetch(W,{signal:He.signal,credentials:"omit"});clearTimeout(zr),w=await Ur.text()}catch(W){se("Could not load source: "+((W==null?void 0:W.message)||W),2800);return}if(!w){se("Empty source",1800);return}let U=String(w).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),V="view-source:"+String(u.url).replace(/^https?:\/\//i,""),ie='<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+V.replace(/[<>]/g,"")+"</title><style>html,body{margin:0;background:#1e1e1e;color:#d4d4d4}pre{margin:12px;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-word}</style></head><body><pre>"+U+"</pre></body></html>";try{Tn(i,V,ie)}catch(W){se("Could not open source tab: "+((W==null?void 0:W.message)||W),2500)}},openExternal:()=>{var w;let u=(w=D())==null?void 0:w.url;u&&u!=="about:blank"&&fs(u)},openOpacity:Tt,isOverlay:Pr,canOverlay:()=>tt==="page",toggleOverlay:()=>hs({overlay:!Pr()}),closeBrowser:()=>_t()});return(At=t(".ls-tab-new"))==null||At.addEventListener("click",h),e.querySelectorAll(".ls-close-btn, .ls-ov-close").forEach(u=>u.addEventListener("click",()=>_t())),(Ve=t(".ls-fs-btn"))==null||Ve.addEventListener("click",H),d==null||d.addEventListener("click",()=>Lr(-1)),f==null||f.addEventListener("click",()=>Lr(1)),c.addEventListener("click",()=>{var u;return(u=D())!=null&&u.loading?Sn():Er()}),(it=t(".ls-home"))==null||it.addEventListener("click",x),p.addEventListener("click",Xe),m.addEventListener("click",Tt),y.addEventListener("click",()=>{let u=Y.toggle();y.classList.toggle("is-on",u)}),y.classList.toggle("is-on",Y.isOn()),a.addEventListener("click",()=>On(or(),{host:e,anchor:a})),l.addEventListener("keydown",u=>{u.key==="Enter"&&(v(l.value),l.blur())}),l.addEventListener("focus",()=>l.select()),q.querySelector(".ls-find-prev").addEventListener("click",()=>be(!0)),q.querySelector(".ls-find-next").addEventListener("click",()=>be(!1)),q.querySelector(".ls-find-close").addEventListener("click",()=>q.hidden=!0),b.addEventListener("keydown",u=>{u.key==="Enter"&&be(u.shiftKey),u.key==="Escape"&&(q.hidden=!0)}),e._lsDevice=i,e._sync=I,e}function ea(){let e=document.createElement("div");return e.className="ls-browser-shell",e.dataset.theme=Mo(),e.innerHTML=`
    <div class="ls-chrome">
      <div class="ls-tabstrip">
        <div class="ls-browser-tabs"></div>
        <button type="button" class="ls-ib ls-tab-new" title="New tab">${A(T.plus,16)}</button>
        <span class="ls-spacer"></span>
        <div class="ls-win">
          <button type="button" class="ls-ib ls-win-btn ls-fs-btn" title="Fullscreen">${A(T.maximize,14)}</button>
          <button type="button" class="ls-ib ls-win-btn ls-close-btn" title="Close">${A(T.close,14)}</button>
        </div>
      </div>
      <div class="ls-toolbar">
        <button type="button" class="ls-ib ls-back" title="Back" disabled>${A(T.back,18)}</button>
        <button type="button" class="ls-ib ls-fwd" title="Forward" disabled>${A(T.forward,18)}</button>
        <button type="button" class="ls-ib ls-reload" title="Reload">${A(T.reload,18)}</button>
        <button type="button" class="ls-ib ls-home" title="Home">${A(T.home,18)}</button>
        <div class="ls-omni">
          <button type="button" class="ls-site" title="Site information">${A(T.info,16)}</button>
          <input class="ls-browser-url" type="text" spellcheck="false" autocapitalize="off" autocomplete="off" enterkeyhint="enter" inputmode="text" placeholder="Search or type a URL" />
          <button type="button" class="ls-ib ls-star" title="Bookmark this tab">${A(T.star,16)}</button>
        </div>
        <button type="button" class="ls-ib ls-op-btn" title="Opacity">${A(T.drop,18)}</button>
        <button type="button" class="ls-ib ls-dev-toggle" title="Device mode">${A(T.device,18)}</button>
        <button type="button" class="ls-ib ls-menu-btn" title="Customize and control">${A(T.dots,18,3)}</button>
        <button type="button" class="ls-ib ls-ov-close" title="Close">${A(T.close,16)}</button>
        <div class="ls-progress"></div>
        <div class="ls-green-progress"></div>
      </div>
      <div class="ls-devbar" hidden></div>
    </div>
    <div class="ls-stage">
      <div class="ls-ntp"></div>
      <div class="ls-box"><div class="ls-device"></div></div>
    </div>
    <div class="ls-find" hidden>
      <input type="text" placeholder="Find in page" spellcheck="false" />
      <button type="button" class="ls-ib ls-find-prev" title="Previous">${A(T.up,16)}</button>
      <button type="button" class="ls-ib ls-find-next" title="Next">${A(T.down,16)}</button>
      <button type="button" class="ls-ib ls-find-close" title="Close">${A(T.close,16)}</button>
    </div>
  `,Qi(e)}function ta(){var t;if(Go())return Nt(),!0;let e=z==null?void 0:z.querySelector(".ls-find");return e&&!e.hidden?(e.hidden=!0,!0):z!=null&&z.classList.contains("is-fullscreen")?((t=j==null?void 0:j.onFullscreen)==null||t.call(j,Vt(z,!1)),!0):!1}function ms(){Rr||_t({fromHost:!0})}async function ra(){var e;return z&&j?((e=j.show)==null||e.call(j),requestAnimationFrame(()=>Y==null?void 0:Y.layout()),z):Yt||(Yt=(async()=>{Ho();let t=ea(),r=null;return tt="page",gs()==="editorTab"&&(r=await ls(t,{title:"Live Preview",css:an,onClose:ms}),r?tt="tab":se("Editor tab not available, using page",2e3)),r||(r=is(t,{title:"Live Preview",onClose:ms,onBack:ta})),j=r,z=t,bn(),Zt=n=>{var o;Yi.includes((o=n==null?void 0:n.detail)==null?void 0:o.key)&&Fn()},window.addEventListener("liveserver-settings",Zt),Fn(),requestAnimationFrame(()=>Y==null?void 0:Y.layout()),t})().finally(()=>{Yt=null}),Yt)}async function jn(e,t={}){let r=await ra(),n=yt();if(n.length>0&&(t.restoreOnly||!e))return;let o=e||"about:blank";if(t.reuse){let s=n.find(d=>Zi(d.url,o));if(s){Et(s.id),s.url!==o?ze(o):t.forceReload&&Er();return}}let i=D();i&&i.url==="about:blank"&&n.length===1?ze(o):kt(r._lsDevice,o)}function _t(e={}){if(!Rr){Rr=!0;try{Nt(),Ue==null||Ue(),Ue=null,Zt&&window.removeEventListener("liveserver-settings",Zt),Zt=null,vs(),yn();try{Y==null||Y.destroy()}catch{}Y=null,wn(),os(z);try{z==null||z.remove()}catch{}e.fromHost||j==null||j.close()}finally{j=null,z=null,document.body.classList.remove("ls-browser-fs"),Rr=!1}}}function na(e={}){return{open:t=>jn(t||e.initialUrl),addTab:t=>jn(t),setFullscreen:t=>Vt(z,t),dispose:_t,getMode:gs}}var se,Xi,ps,Vi,Yi,z,j,tt,Ue,Yt,Rr,Y,Zt,Lt,$n,nt=C(()=>{re();Se();jt();Oo();Bo();An();Yo();Gt();Qo();ns();ss();as();cs();In();se=acode.require("toast"),Xi="https://i.postimg.cc/WpYPQ47b/green-fox.png",ps=[25,33,50,67,75,80,90,100,110,125,150,175,200,250,300,400,500],Vi=/\.(html?|css|js|mjs|json|svg|xml|txt|md)$/i,Yi=["browserOpacity","browserOverlay","overlayAutoSave","showAddressBar"],z=null,j=null,tt="page",Ue=null,Yt=null,Rr=!1,Y=null,Zt=null,Lt=null,$n=null});var le={};xe(le,{changePortAndRestart:()=>la,ensureProxyServer:()=>Rn,probeExistingServer:()=>Gn,reapplySetup:()=>ca,refreshStatusFromBackend:()=>sn,restartServer:()=>aa,setProcessBaseUrl:()=>Nn,startServer:()=>Jt,stopServer:()=>qr});function Nn(e){Kt=e||""}async function Or(e,t=900){try{let r=new AbortController,n=setTimeout(()=>r.abort(),t),o=await fetch("http://127.0.0.1:"+e+"/check",{signal:r.signal});if(clearTimeout(n),!o||!o.ok)return{alive:!1,proxy:!1};let i=await o.json().catch(()=>({}));return{alive:!0,proxy:(i==null?void 0:i.proxy)===!0}}catch{return{alive:!1,proxy:!1}}}async function ws(e,t=800){return(await Or(e,t)).alive}async function oa(e){try{let t=await ne("if command -v wget >/dev/null 2>&1; then wget -qO- -T 2 http://127.0.0.1:"+e+"/check 2>/dev/null; elif command -v curl >/dev/null 2>&1; then curl -s --max-time 2 http://127.0.0.1:"+e+"/check 2>/dev/null; else echo NOCLIENT; fi",{timeoutMs:8e3});return/Ready|AcodeLiveServer|"port"/i.test(String(t||""))}catch{return!1}}async function zn(e,t={}){let r=String(parseInt(e,10)||8080);return await ws(r)?!0:t.deep?oa(r):!1}async function Wn(e){let t=String(parseInt(e,10)||8080);Ne=null;let r=`for pid in $(ps -o pid,args 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; for pid in $(ps 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; pkill -9 -f "node index.js ${t}" 2>/dev/null || true; fuser -k ${t}/tcp 2>/dev/null || true`;try{await ne(r,{timeoutMs:12e3})}catch{}for(let n=0;n<10&&await ws(t,400);n++)await new Promise(o=>setTimeout(o,200))}function Hr(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=t.match(/^\/storage\/emulated\/0(\/.*)?$/);return r?"/sdcard"+(r[1]||""):t}async function bs(e,t){let r=await sa(e);if(r)return{aroot:r,mirrored:!1};console.warn("[LiveServer] alpine root missing, trying project mirror for",e);try{let{getSettings:n}=await Promise.resolve().then(()=>(re(),Mt)),i=await Co(e,t||"index.html",n().rootFolderUri||"");if(i)return{aroot:i,mirrored:!0}}catch(n){throw console.warn("[LiveServer] mirror failed",n),n}return{aroot:null,mirrored:!1}}async function sa(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=[],n=p=>{p&&!r.includes(p)&&r.push(p)};n(t);let o=t.match(/^\/storage\/emulated\/0(\/.*)?$/);o&&n("/sdcard"+(o[1]||"")),o=t.match(/^\/sdcard(\/.*)?$/),o&&(n("/storage/emulated/0"+(o[1]||"")),n("/storage/self/primary"+(o[1]||""))),o=t.match(/^\/storage\/self\/primary(\/.*)?$/),o&&(n("/sdcard"+(o[1]||"")),n("/storage/emulated/0"+(o[1]||"")));let i=t.match(/^\/storage\/([0-9A-Fa-f]{4}-[0-9A-Fa-f]{4})(\/.*)?$/);if(i){let p=i[1],g=i[2]||"";n("/storage/"+p+g),n("/mnt/media_rw/"+p+g),n("/mnt/runtime/default/"+p+g),n("/storage/"+p.toUpperCase()+g),n("/storage/"+p.toLowerCase()+g)}let s=(()=>{let p=t.match(/\/(?:storage|sdcard|emulated|media_rw)\/[^/]+(\/.+)$/i);return p?p[1]:""})();!/^\/(sdcard|storage|mnt)(\/|$)/.test(t)&&t.startsWith("/data/");let d=p=>"'"+String(p).replace(/'/g,"'\\''")+"'",f="for d in "+r.map(d).join(" ")+'; do [ -d "$d" ] && { echo "OK:$d"; exit 0; }; done; '+(s?'for base in /storage/* /mnt/media_rw/* /sdcard; do [ -d "$base'+s.replace(/'/g,"'\\''")+'" ] && { echo "OK:$base'+s.replace(/'/g,"'\\''")+'"; exit 0; }; done; ':"")+"echo NONE",l="";try{l=await ne(f,{timeoutMs:12e3})}catch(p){return console.warn("[LiveServer] root probe failed, using path as is",p),Hr(t)}let c=String(l||"").match(/OK:(.+)/);return c?(console.log("[LiveServer] alpine root",c[1].trim()),c[1].trim()):/NONE/.test(String(l||""))?(console.warn("[LiveServer] alpine root not found for",t,"cands=",r),null):Hr(t)}function ia(e){let t={};return String(e||"").split(`
`).forEach(r=>{let n=r.indexOf(":");if(n>0){let o=r.slice(0,n).trim(),i=r.slice(n+1).trim();o&&(t[o]=i)}}),t}function ys(){let e=X(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";return/\.html?$/i.test(t)?t:"index.html"}function xs(e){try{let t=X(),r=we((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");if(!r||!e)return ys();let n=e.replace(/\/+$/,"");if(r.startsWith(n+"/")||r.startsWith(n+"\\"))return r.slice(n.length).replace(/^[/\\]+/,"").replace(/\\/g,"/")}catch{}return ys()}async function Br(e,t,r){let n=k(),o={path:t,fileName:r||"index.html",port:e,liveReload:n.liveReload!==!1,directoryListing:n.directoryListing!==!1,enableCors:n.enableCors!==!1,charset:n.customCharset||"utf-8",customHeaders:ia(n.customHeaders),ipWhitelist:n.ipWhitelist||"",basicAuthUser:n.basicAuthUser||"",basicAuthPass:n.basicAuthPass||""};try{let i=await fetch(`http://127.0.0.1:${e}/setup`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)});return!!(i&&(i.ok||i.status===201))}catch(i){return console.warn("[LiveServer] setup",i),!1}}function Un(){Mr&&(clearInterval(Mr),Mr=null)}function Dr(){Un();let e=parseInt(k().autoShutdownMinutes,10)||0;if(e<=0)return;let t=e*60*1e3,r=Date.now();Mr=setInterval(async()=>{let n=B();if(!n.running){Un();return}if(Date.now()-(n.startedAt||r)>t){try{let i=await(await fetch(`http://127.0.0.1:${n.port}/status`)).json();if(i.lastActivity&&Date.now()-i.lastActivity<t)return}catch{}ve("Live Server auto-stopped (inactivity)",2500),qr()}},3e4)}async function Gn(){let e=mt();try{let t=new AbortController,r=setTimeout(()=>t.abort(),1200),n=await fetch(`http://127.0.0.1:${e}/status`,{signal:t.signal});if(clearTimeout(r),!n||!n.ok)return!1;let o=await n.json().catch(()=>({})),i=o.port||e,s=o.fileName||null,d=It(i,"127.0.0.1"),f=s&&s!=="index.html"?d.replace(/\/$/,"/")+encodeURI(s):d,l=B();if(oe({running:!0,port:i,root:o.root||l.root||null,url:f,fileName:s,bind:o.bind||"0.0.0.0",startedAt:l.startedAt||(o.uptime?Date.now()-Math.round(Number(o.uptime)*1e3):Date.now()),lastError:null}),Dr(),!l.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:f,port:i,root:o.root||null,fileName:s}}))}catch{}return!0}catch{return!1}}function Ss(e,t){let r=lt();if(!(r!=null&&r.execute))throw new Error("Executor not available. Open Acode Terminal once, then retry.");let n='ACODIR=""; for d in "'+String(t||"").replace(/"/g,"")+'" /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels; do [ -n "$d" ] || continue; if [ -f "$d/index.js" ] && [ -d "$d/node_modules" ]; then ACODIR="$d"; break; fi; done; [ -z "$ACODIR" ] && { echo acodels_not_found; exit 1; }; cd "$ACODIR" || exit 1; NODE_PATH="$ACODIR/node_modules" exec node index.js '+String(e)+" 0.0.0.0 >liveserver.log 2>&1",o={};Ne=o,r.execute(Vr(n),!0).then(i=>console.log("[LiveServer] node exited",String(i||"").slice(0,200))).catch(i=>console.warn("[LiveServer] node exited",String((i==null?void 0:i.message)||i).slice(0,200))).finally(()=>{if(Ne===o&&(Ne=null,B().running)){oe({running:!1,lastError:"server process exited"});try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}}})}async function Rn(){let e=mt(),t=await Or(e);if(t.alive&&t.proxy)return e;if(!await ur({baseUrl:Kt}))return null;Ce(!0),Te(t.alive?`$ Updating backend on :${e} with Reverse Proxy...`:`$ node index.js ${e} (starting local proxy)...`,{spin:!0});try{t.alive&&!t.proxy&&await Wn(e);let n=await ft(Kt);await tn(n),Ss(e,n);let o=!1;for(let c=0;c<35;c++){await new Promise(g=>setTimeout(g,300));let p=await Or(e,500);if(p.alive&&p.proxy){o=!0;break}if(!Ne)break}if(!o)return Te("Proxy server failed to start",{spin:!1,autoHideMs:3e3}),null;let i=B(),s=i.root||fr()||"/sdcard",d=Hr(s),f=i.fileName||"index.html";await Br(e,d,f);let l=It(e,"127.0.0.1");oe({running:!0,port:e,root:d,url:l,fileName:f,bind:"0.0.0.0",startedAt:Date.now(),lastError:null}),Dr();try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:l,port:e,root:d,fileName:f}}))}catch{}return Te(`\u2713 Reverse proxy ready on 127.0.0.1:${e}`,{spin:!1,autoHideMs:2e3}),e}catch(n){return Te(`Proxy error: ${(n==null?void 0:n.message)||n}`,{spin:!1,autoHideMs:3500}),null}finally{Ce(!1)}}async function Jt(e={}){let t=e.port||mt(),r=e.root||fr(),n=k(),o=e.forceDeps?{alive:!1,proxy:!1}:await Or(t);if(o.alive&&!o.proxy&&(Ce(!0),Te(`$ Upgrading Live Server on :${t}...`,{spin:!0}),await Wn(t),Ce(!1),Ft(0),o.alive=!1),o.alive&&o.proxy){let a=B(),m=r||a.root;if(!m)return ve("Set a root folder or open an HTML file",2500),!1;let y,q=!1;try{let v=await bs(m,b);y=v.aroot||Hr(m),q=v.mirrored}catch(v){return ve("Cannot serve folder: "+((v==null?void 0:v.message)||v),4e3),null}let b=e.fileName||xs(m);(!a.running||a.port!==t||a.root!==y||a.fileName!==b)&&await Br(t,y,b);let R=It(t,"127.0.0.1"),_=b&&b!=="index.html"?R.replace(/\/$/,"/")+encodeURI(b):R;if(oe({running:!0,port:t,root:y,url:_,fileName:b,bind:"0.0.0.0",startedAt:a.startedAt||Date.now(),lastError:null}),Dr(),!a.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:_,port:t,root:y,fileName:b}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:v}=await Promise.resolve().then(()=>(nt(),rt));v(_,{reuse:!0})}catch(v){console.warn("[LiveServer] open browser",v)}return!0}if(!await ur({baseUrl:Kt,force:!!e.forceDeps}))return!1;if(!r)return ve("Set a root folder or open an HTML file",2500),!1;let s=e.fileName||xs(r),d,f=!1;try{let a=await bs(r,s);d=a.aroot,f=a.mirrored}catch(a){return oe({running:!1,lastError:String((a==null?void 0:a.message)||a)}),ve("Cannot serve folder: "+((a==null?void 0:a.message)||a),4500),null}if(!d)return oe({running:!1,lastError:"root not reachable"}),ve("Folder not reachable \u2014 mirror also failed. Use internal /sdcard or grant storage access.",4500),!1;let l="0.0.0.0";if(!await zn(t,{deep:!0})){Ce(!0),Te(`$ node index.js ${t} 0.0.0.0`,{spin:!0});let a=await ft(Kt);try{await tn(a)}catch(y){console.warn("[LiveServer] ensure index",y)}try{Ss(t,a)}catch(y){return Ce(!1),Ft(0),oe({running:!1,lastError:String((y==null?void 0:y.message)||y)}),ve("Start failed: "+((y==null?void 0:y.message)||y),3e3),!1}let m=!1;for(let y=0;y<40;y++){if(await new Promise(q=>setTimeout(q,300)),await zn(t)){m=!0;break}if(!Ne)break}if(!m&&Ne&&(m=await zn(t,{deep:!0})),Ce(!1),!m){Te("Server failed to start",{spin:!1,autoHideMs:3500});try{let y=await ne("tail -n 40 /root/.acode_liveserver/acodels/liveserver.log 2>/dev/null",{timeoutMs:8e3});console.warn("[LiveServer] start failed, log:",y)}catch{}return ve("Server failed to start \u2014 see console log",3500),oe({running:!1,lastError:"start failed"}),Ne=null,!1}Te(`\u2713 Live Server running on :${t}`,{spin:!1,autoHideMs:2200})}await Br(t,d,s)||console.warn("[LiveServer] /setup patch failed");let p=It(t,"127.0.0.1"),g=s&&s!=="index.html"?p.replace(/\/$/,"/")+encodeURI(s):p;oe({running:!0,port:t,root:d,url:g,fileName:s,bind:l,startedAt:Date.now(),lastError:null}),M("port",t),Dr(),ve("Live on "+g,2500);try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:g,port:t,root:r,fileName:s}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:a}=await Promise.resolve().then(()=>(nt(),rt));a(g,{reuse:!0})}catch(a){console.warn("[LiveServer] open browser",a)}return!0}async function qr(){try{on()}catch{}Un();let t=B().port||mt();await Wn(t),oe({running:!1,port:null,url:null,fileName:null,startedAt:null}),ve("Server stopped",1500);try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}return!0}async function aa(){let e=B(),t=e.root,r=e.fileName;return await qr(),await new Promise(n=>setTimeout(n,350)),Jt({root:t||void 0,fileName:r||void 0})}async function la(){let e=acode.require("prompt"),t=String(mt()),r=await e("Port",t,"number");if(r==null)return!1;let n=parseInt(String(r),10);return!Number.isFinite(n)||n<1||n>65535?(ve("Invalid port",1500),!1):(M("port",n),await qr(),Jt({port:n}))}async function ca(){let e=B();return!e.running||!e.port||!e.root?!1:Br(e.port,e.root,e.fileName||"index.html")}var ve,Kt,Mr,Ne,J=C(()=>{re();ct();ht();yo();qe();To();Ao();he();Se();br();ve=acode.require("toast"),Kt="",Mr=null,Ne=null});var Kn={};xe(Kn,{onFileSwitch:()=>Yn,registerSideButton:()=>Vn,setLiveDot:()=>ot,unregisterSideButton:()=>Zn});function As(){if(document.getElementById("ls-side-btn-css"))return;let e=document.createElement("style");e.id="ls-side-btn-css",e.textContent=`
    [data-ls-sidebtn="1"] {
      gap: 6px;
    }
    [data-ls-sidebtn="1"] .ls-side-ico {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1.05rem;
      height: 1.05rem;
      flex-shrink: 0;
      margin-right: 4px;
      vertical-align: middle;
    }
    [data-ls-sidebtn="1"] .ls-side-ico svg {
      width: 1.05rem;
      height: 1.05rem;
      display: block;
    }
    [data-ls-sidebtn="1"][data-live="1"] {
      background: #22c55e !important;
      color: #0b1220 !important;
    }
    [data-ls-sidebtn="1"][data-live="0"] {
      background: var(--button-background-color, var(--secondary-color, #3c4043)) !important;
      color: var(--button-text-color, var(--color, #e8eaed)) !important;
    }
  `,document.head.appendChild(e)}function Ls(){return'<svg class="ls-side-ico" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M5.63605 5.63603L18.364 18.364M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="#666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'}function _s(){return'<svg class="ls-side-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>'}function ua(){let e=k();if(e.bindLocalhostOnly!==!1)return"127.0.0.1";let t=String(e.bindAddress||"127.0.0.1").trim();return!t||t==="0.0.0.0"?"127.0.0.1":t}function pa(){let e=B(),t=k(),r=String(t.sideButtonRunningLabel||"{HOST}:{PORT}"),n=ua(),o=e.port||t.port||8080;return r.replace(/\{HOST\}/gi,n).replace(/\{PORT\}/gi,String(o))}function fa(){return String(k().sideButtonOfflineLabel||"Go Live")}function Qt(e){return e?pa():fa()}function Cs(){var e;return k().showSideButton!==!1&&Le(X()||((e=window.editorManager)==null?void 0:e.activeFile))}function Rs(){return E?E.$el||E.el||E.root||(E instanceof HTMLElement?E:null):null}function Ps(e,t){var s,d,f;if(!e)return!1;e.setAttribute("data-ls-sidebtn","1"),e.setAttribute("data-live",t?"1":"0");let r=Qt(t),n=t?Ls():_s(),o=e.querySelectorAll('.text, .label, .side-button-text, [class*="text"], span, small'),i=!1;for(let l of o)(s=l.classList)!=null&&s.contains("icon")||(d=l.classList)!=null&&d.contains("ls-side-ico")||(f=l.children)!=null&&f.length&&l.querySelector(".icon, svg")||(l.innerHTML=n+r,i=!0);if(!i){let l=e.querySelector(".icon");if(l){l.innerHTML=t?Ls():_s();let c=!1;for(let p of e.childNodes)p.nodeType===3&&p.textContent.trim()&&(p.textContent=" "+r,c=!0);c||(e.setAttribute("aria-label",r),e.title=r)}else e.innerHTML=n+'<span class="ls-side-label">'+r+"</span>"}return e.setAttribute("aria-label",r),e.title=r,!0}function ha(e){return{text:Qt(e),icon:e?"block":"public",backgroundColor:e?"#22c55e":void 0,textColor:e?"#0b1220":void 0,onclick:()=>ma()}}function Ts(e){var t;try{(t=E==null?void 0:E.hide)==null||t.call(E)}catch{}if(E=null,!!ks)try{E=ks(ha(e));let r=Rs();r&&Ps(r,e)}catch(r){console.warn("[LiveServer] recreate side",r)}}function ot(e){var t,r,n;try{As();let o=e==null?!!B().running:!!e;if(document.body.classList.toggle("ls-server-live",o),!Cs()){try{(t=E==null?void 0:E.hide)==null||t.call(E)}catch{}Xn=o;return}if(!E)Ts(o);else{try{typeof E.setText=="function"&&E.setText(Qt(o)),"text"in E&&(E.text=Qt(o)),E.$text&&(E.$text.textContent=Qt(o))}catch{}let i=Rs();(!(i?Ps(i,o):!1)||Xn!==o)&&Ts(o)}Cs()?(r=E==null?void 0:E.show)==null||r.call(E):(n=E==null?void 0:E.hide)==null||n.call(E),Xn=o}catch(o){console.warn("[LiveServer] setLiveDot",o)}}async function ma(){let t=B().running?["stop","Stop live server"]:["start","Start live server"],r=await da("Live Server",[t,["startSelected","Start server on selected path"],["restart","Restart server"],["port","Change port"],["root","Select root folder"],["rootBrowse","Select path (Acode browser)"],["browser","Open browser"],["deps","Check dependencies"],["settings","Settings"]],{hideOnSelect:!0});if(r){try{if(r==="start"){let{startServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="startSelected"){let{startServer:n}=await Promise.resolve().then(()=>(J(),le)),{getSettings:o}=await Promise.resolve().then(()=>(re(),Mt)),{browseRootFolder:i,getEffectiveRoot:s}=await Promise.resolve().then(()=>(qe(),Ze)),d=o().rootFolder||s();if(d||(d=await i()),!d){Es("Select a folder first",2e3);return}await n({root:d})}else if(r==="stop"){let{stopServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="restart"){let{restartServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="port"){let{changePortAndRestart:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="root"){let{pickRootFolder:n}=await Promise.resolve().then(()=>(qe(),Ze));await n()}else if(r==="rootBrowse"){let{browseRootFolder:n}=await Promise.resolve().then(()=>(qe(),Ze));await n()}else if(r==="browser"){let{openBrowser:n}=await Promise.resolve().then(()=>(nt(),rt)),o=B().url||"http://127.0.0.1:"+(B().port||8080)+"/";n(o,{restoreOnly:!0})}else if(r==="deps"){let{checkDependenciesAction:n}=await Promise.resolve().then(()=>(ht(),pr));await n()}else if(r==="settings"){let{openSettingsHub:n}=await Promise.resolve().then(()=>(Xt(),_r));n()}}catch(n){Es(String((n==null?void 0:n.message)||n),2500)}ot(B().running)}}function Vn(){if(k().showSideButton!==!1){As();try{ot(B().running)}catch(e){console.warn("[LiveServer] side button",e)}}}function Yn(){ot(B().running)}function Zn(){var e;try{(e=E==null?void 0:E.hide)==null||e.call(E)}catch{}E=null,document.body.classList.remove("ls-server-live")}var ks,da,Es,E,Xn,Ir=C(()=>{re();Se();he();ks=acode.require("sideButton"),da=acode.require("select"),Es=acode.require("toast"),E=null,Xn=null});function Ms(){let e=[];return er.forEach(t=>{e.includes(t.category)||e.push(t.category)}),e}function Ge(e){let t=k();return t[e]!==void 0?t[e]:Pt[e]}function Os(e){if(e.checkbox||e.noValue)return"";let t=Ge(e.key);if(e.select){let n=e.select.find(o=>String(Array.isArray(o)?o[0]:o)===String(t));return n?Array.isArray(n)?n[1]:n:String(t!=null?t:"")}if(e.secret)return t?"\u2022\u2022\u2022\u2022\u2022\u2022":"";let r=t==null?"":String(t);return r.length>28?r.slice(0,27)+"\u2026":r}async function va(e){try{if(e==="start")return(await Promise.resolve().then(()=>(J(),le))).startServer();if(e==="stop")return(await Promise.resolve().then(()=>(J(),le))).stopServer();if(e==="restart")return(await Promise.resolve().then(()=>(J(),le))).restartServer();if(e==="open"){let r=(await Promise.resolve().then(()=>(he(),gt))).getServerStatus();return r.running?(await Promise.resolve().then(()=>(nt(),rt))).openBrowser(r.url||"http://127.0.0.1:"+r.port+"/",{restoreOnly:!0}):We("Server is not running",2e3)}if(e==="root")return(await Promise.resolve().then(()=>(qe(),Ze))).pickRootFolder();if(e==="status"){let r=(await Promise.resolve().then(()=>(he(),gt))).getServerStatus();return We(r.running?(r.url||"")+" \u2014 port "+r.port:"Not running",3e3)}if(e==="deps")return(await Promise.resolve().then(()=>(ht(),pr))).checkDependenciesAction();if(e==="reinstall")return(await Promise.resolve().then(()=>(ht(),pr))).reinstallDependenciesAction()}catch(t){We(String((t==null?void 0:t.message)||t),3e3)}}async function tr(e,t){var n;if(e==="__action")return await va(t),!0;if(e==="__browserAction"){try{t==="clearHistory"?((await Promise.resolve().then(()=>(An(),Wo))).clearVisited(),We("Browser history cleared",1800)):t==="clearBookmarks"&&(M("browserBookmarks",[]),We("Bookmarks cleared",1800))}catch(o){We(String((o==null?void 0:o.message)||o),2500)}return!0}let r=t;if(e==="port"){let o=parseInt(String(t),10);if(!Number.isFinite(o)||o<1||o>65535)return We("Invalid port",1800),!1;r=o}else if(e==="autoShutdownMinutes"){let o=parseInt(String(t),10);if(!Number.isFinite(o)||o<0)return We("Invalid number",1800),!1;r=o}else if(e==="browserOpacity"){let o=parseFloat(String(t));r=Number.isFinite(o)?Math.min(1,Math.max(.1,Math.round(o*100)/100)):1}if(M(e,r),e==="sideButtonRunningLabel"||e==="sideButtonOfflineLabel")try{let o=await Promise.resolve().then(()=>(Ir(),Kn));(n=o.setLiveDot)==null||n.call(o,null)}catch{}if(e==="showSideButton")try{let o=await Promise.resolve().then(()=>(Ir(),Kn));r===!1?o.unregisterSideButton():o.registerSideButton()}catch{}return!0}function Hs(){return{list:er.map(t=>{let r={key:t.key,text:t.text,category:t.category};return t.info&&(r.info=t.info),t.checkbox?(r.checkbox=!0,r.value=!!Ge(t.key)):t.select?(r.select=t.select,t.noValue?(r.value="",r.valueText=()=>"Choose\u2026"):r.value=t.asString?String(Ge(t.key)):Ge(t.key)):t.prompt&&(r.prompt=t.prompt,t.promptType&&(r.promptType=t.promptType),r.value=Ge(t.key),t.secret&&(r.valueText=n=>n?"\u2022\u2022\u2022\u2022\u2022\u2022":"")),r}),cb:(t,r)=>{tr(t,r)}}}var We,ga,er,Jn=C(()=>{Gr();re();We=acode.require("toast"),ga=[["start","Start server"],["stop","Stop server"],["restart","Restart server"],["open","Open browser"],["root","Select root folder"],["status","Show server status"],["deps","Check dependencies"],["reinstall","Reinstall dependencies"]],er=[{key:"__action",category:"Actions",text:"Run action",info:"Start / stop / open browser / dependencies",select:ga,noValue:!0},{key:"port",category:"General",text:"Port",info:"Default 8080",prompt:"Port number",promptType:"number"},{key:"bindAddress",category:"General",text:"Bind address",select:[["127.0.0.1","Localhost only (127.0.0.1)"],["0.0.0.0","All interfaces (0.0.0.0)"]]},{key:"rootFolder",category:"General",text:"Root folder",info:"Empty = folder of the active HTML file",prompt:"Absolute folder path",promptType:"text"},{key:"liveReload",category:"General",text:"Live reload on save",checkbox:!0},{key:"openBrowserOnStart",category:"General",text:"Open browser on start",checkbox:!0},{key:"autoShutdownMinutes",category:"General",text:"Auto shutdown (minutes)",info:"0 = off",prompt:"Minutes (0 = off)",promptType:"number"},{key:"browserDisplayMode",category:"Browser",text:"Show browser in",info:"Acode page or editor tab",select:[["inPage","Acode page (default)"],["editorTab","Editor tab"]]},{key:"browserSearchEngine",category:"Browser",text:"Search engine",info:"Used when searching keywords in address bar or New Tab",select:[["google","Google"],["duckduckgo","DuckDuckGo"],["bing","Bing"],["brave","Brave Search"]]},{key:"externalSiteMode",category:"Browser",text:"External websites",info:"Proxy auto-switches to Chromium if slow, or select Chromium directly",select:[["proxy","Local Node.js Reverse Proxy (Default)"],["acodeWebview","Acode Native WebView (Fullscreen)"],["inApp","Direct iframe (without proxy)"],["systemBrowser","Chrome / External system browser"]]},{key:"browserHomeUrl",category:"Browser",text:"Home button URL",info:"Empty = Green Fox Homepage",prompt:"Home URL (leave empty for Green Fox Homepage)",promptType:"text"},{key:"browserOpacity",category:"Browser",text:"Browser opacity",info:"0.1 - 1.0 (page mode)",asString:!0,select:["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1"].map(e=>[e,e])},{key:"browserOverlay",category:"Browser",text:"Preview as overlay",info:"See-through preview over the editor; you can still type in the editor",checkbox:!0},{key:"overlayAutoSave",category:"Browser",text:"Auto-save in overlay mode",info:"Saves the file after you stop typing so the preview updates live",checkbox:!0},{key:"showAddressBar",category:"Browser",text:"Show address bar",checkbox:!0},{key:"showSideButton",category:"Browser",text:"Show side button",checkbox:!0},{key:"sideButtonRunningLabel",category:"Browser",text:"Side button running label",value:"{HOST}:{PORT}",valueText:e=>String(e||"{HOST}:{PORT}"),prompt:"Running label ({HOST} {PORT} tokens)",promptType:"text",info:"Shown when server is live. Tokens: {HOST} {PORT}."},{key:"sideButtonOfflineLabel",category:"Browser",text:"Side button offline label",value:"Go Live",valueText:e=>String(e||"Go Live"),prompt:"Offline label",promptType:"text",info:"Shown when server is stopped."},{key:"__browserAction",category:"Browser",text:"Browser data",info:"Clear recent history or saved bookmarks",select:[["clearHistory","Clear recent history"],["clearBookmarks","Clear all bookmarks"]],noValue:!0},{key:"directoryListing",category:"HTML / static",text:"Enable directory listing",checkbox:!0},{key:"enableCors",category:"HTML / static",text:"Enable CORS",checkbox:!0},{key:"customCharset",category:"HTML / static",text:"Custom charset",prompt:"Charset",promptType:"text"},{key:"customHeaders",category:"HTML / static",text:"Custom response headers",info:'One "Header: value" per line',prompt:"Custom headers",promptType:"textarea"},{key:"bindLocalhostOnly",category:"Security",text:"Prefer localhost bind",checkbox:!0},{key:"ipWhitelist",category:"Security",text:"Client IP whitelist",info:"Comma or newline separated; empty = all",prompt:"IP whitelist",promptType:"textarea"},{key:"basicAuthUser",category:"Security",text:"Basic auth user",prompt:"User name",promptType:"text"},{key:"basicAuthPass",category:"Security",text:"Basic auth password",prompt:"Password",promptType:"text",secret:!0}]});var _r={};xe(_r,{openSettingsHub:()=>Ca,registerPluginSettings:()=>Fs});function ka(){if(document.getElementById("ls-settings-css"))return;let e=document.createElement("style");e.id="ls-settings-css",e.textContent=Sa,document.head.appendChild(e)}function Me(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.textContent=r),n}function Is(e,t,r,n){let o=Me("div","ls-set-row");o.setAttribute("role","button"),o.tabIndex=0;let i=Me("div","ls-set-main");return i.appendChild(Me("div","ls-set-title",e)),t&&i.appendChild(Me("div","ls-set-info",t)),o.appendChild(i),r&&o.appendChild(r),o.addEventListener("click",n),o}function $s(){let e=Me("span","ls-set-chev");return e.innerHTML=Ut(wa,16),e}async function Ea(e,t){let r=Ge(e.key);if(e.checkbox)return await tr(e.key,!r),t();if(e.select){let n=await ya(e.text,e.select,{hideOnSelect:!0,default:e.noValue?void 0:String(r)});n!=null&&(await tr(e.key,n),t());return}if(e.prompt){let n=e.promptType==="number"?"number":e.promptType==="textarea"?"textarea":"text",o=await xa(e.prompt,r==null?"":String(r),n);o!=null&&(await tr(e.key,o),t())}}function La(e,t){e.textContent="",Ms().forEach(r=>{let n=er.filter(o=>o.category===r).length;e.appendChild(Is(r,n+" options",$s(),()=>t(r)))})}function _a(e,t,r){e.textContent="",er.filter(n=>n.category===t).forEach(n=>{let o=null;if(n.checkbox)o=Me("span","ls-set-switch"+(Ge(n.key)?" is-on":""));else{o=Me("span"),o.style.cssText="display:flex;align-items:center;gap:6px;min-width:0;max-width:50%";let i=Os(n);i&&o.appendChild(Me("span","ls-set-val",i)),o.appendChild($s())}e.appendChild(Is(n.text,n.info,o,()=>Ea(n,r)))})}function qs(e,t,r){var f,l;ka();let n=document.createElement("span");n.className="icon arrow_back",n.dataset.action="back",n.style.cssText="pointer-events:auto;cursor:pointer;";let o=ba(e,{lead:n}),i=Me("div","ls-set-body");try{o.appendBody(i)}catch{(f=o.appendChild)==null||f.call(o,i)}let s=()=>t(i,s),d=()=>{var c,p;try{Bs.remove(r)}catch{}try{(c=o.hide)==null||c.call(o)}catch{}try{(p=o.remove)==null||p.call(o)}catch{}};n.onclick=c=>{var p,g;try{(p=c==null?void 0:c.preventDefault)==null||p.call(c),(g=c==null?void 0:c.stopPropagation)==null||g.call(c)}catch{}d()};try{Bs.push({id:r,action:d})}catch{}s();try{(window.app||document.body).append(o)}catch{document.body.append(o)}try{(l=o.show)==null||l.call(o)}catch{}}function Ca(){qs("Live Server",e=>La(e,t=>qs(t,(r,n)=>_a(r,t,n),Ds+t)),Ds+"hub")}function Fs(){}var ba,Bs,ya,xa,Ds,wa,Sa,Xt=C(()=>{Jn();Pn();ba=acode.require("page"),Bs=acode.require("actionStack"),ya=acode.require("select"),xa=acode.require("prompt"),Ds="liveserver-settings-",wa="M9 18l6-6-6-6",Sa=`
.ls-set-body{height:100%;overflow:auto;padding:4px 0 24px}
.ls-set-row{display:flex;align-items:center;gap:12px;padding:12px 16px;cursor:pointer;border-bottom:1px solid rgba(128,128,128,.15)}
.ls-set-row:active{background:rgba(128,128,128,.14)}
.ls-set-main{flex:1;min-width:0}
.ls-set-title{font-size:15px}
.ls-set-info{font-size:12px;opacity:.65;margin-top:2px}
.ls-set-val{max-width:45%;font-size:12px;opacity:.75;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ls-set-chev{display:inline-flex;opacity:.55;flex-shrink:0}
.ls-set-switch{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0}
.ls-set-switch::before{content:'';position:absolute;inset:0;border-radius:3px;background:rgba(128,128,128,.45);transition:background .15s}
.ls-set-switch::after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:3px;background:#fff;transition:transform .15s}
.ls-set-switch.is-on::before{background:var(--active-color,#61afef)}
.ls-set-switch.is-on::after{transform:translateX(18px)}
`});var Wr={id:"acode.plugin.sugerserver",name:"Html Server - Devtool",main:"main.js",version:"2.0.0",readme:"readme.md",icon:"icon.png",files:["acodels/","devtool/","icon.png","readme.md"],minVersionCode:290,license:"",changelogs:"changelogs.md",keywords:["Live Server","HTML","HTTP","browser","preview"],price:55,repository:"",author:{name:"Dev.Sourav",email:"devs.sourav@gmail.com",github:"Sou6900"}};Xt();Ir();Se();var Qn=acode.require("toast"),eo=[];function js(){try{let e=acode.require("commands");if(!(e!=null&&e.add))return;let t=(r,n,o)=>{try{e.add({name:r,description:n,exec:o}),eo.push(r)}catch{}};t("liveserver:run-file","Live Server: Run this file in HTTP server",async()=>{if(!X())return Qn("Open a file in the editor first",2e3);let{startServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}),t("liveserver:select-root","Live Server: Select root folder",async()=>{let{pickRootFolder:r}=await Promise.resolve().then(()=>(qe(),Ze));await r()}),t("liveserver:run-selected-root","Live Server: Run HTTP server for selected / saved root",async()=>{let{startServer:r}=await Promise.resolve().then(()=>(J(),le)),{getSettings:n}=await Promise.resolve().then(()=>(re(),Mt)),{rootFromSelectedFolder:o}=await Promise.resolve().then(()=>(qe(),Ze)),i=n().rootFolder||o();if(!i)return Qn("Select a root folder first (command: Select root folder)",3e3);await r({root:i})}),t("liveserver:stop","Live Server: Stop server",async()=>{let{stopServer:r}=await Promise.resolve().then(()=>(J(),le));await r()}),t("liveserver:restart","Live Server: Restart server",async()=>{let{restartServer:r}=await Promise.resolve().then(()=>(J(),le));await r()}),t("liveserver:open-browser","Live Server: Open browser",async()=>{let{getServerStatus:r}=await Promise.resolve().then(()=>(he(),gt)),{openBrowser:n}=await Promise.resolve().then(()=>(nt(),rt)),o=r();if(!o.running)return Qn("Server is not running",2e3);n(o.url||`http://127.0.0.1:${o.port}/`,{restoreOnly:!0})}),t("liveserver:settings","Live Server: Open settings",async()=>{let{openSettingsHub:r}=await Promise.resolve().then(()=>(Xt(),_r));r()})}catch(e){console.warn("[LiveServer] commands",e)}}function zs(){try{let e=acode.require("commands");eo.forEach(t=>{var r;try{(r=e==null?void 0:e.remove)==null||r.call(e,t)}catch{}})}catch{}eo=[]}ln();Se();Se();J();var Us=acode.require("toast"),to=!1;async function Ns(e){var t;if(to)return!1;to=!0;try{let r=e||X();if(!Le(r))return Us("Open an .html / .htm file first",2e3),!1;if(r.isUnsaved&&(r.uri||r.url))try{await((t=r.save)==null?void 0:t.call(r))}catch(n){console.warn("[LiveServer] save before run",n)}return await Jt({openBrowser:!0})}catch(r){return Us(String((r==null?void 0:r.message)||r),3e3),!1}finally{to=!1}}var N=null,$r=null,ro=!1;function Ta(){if(document.getElementById("ls-run-css"))return;let e=document.createElement("style");e.id="ls-run-css",e.textContent=`
    body.ls-html-file #root > header.tile > [action="run"]:not([data-ls-run]) {
      display: none !important;
    }
  `,document.head.appendChild(e)}var Ws="#root > header.tile";function Aa(){return document.querySelector(`${Ws} > span.icon.play_arrow[action="run"]`)||document.querySelector('[action="run"]:not([data-ls-run])')}async function Ra(e){var t;if(e.preventDefault(),e.stopPropagation(),!ro){ro=!0;try{let r=X()||((t=window.editorManager)==null?void 0:t.activeFile);await Ns(r)}catch(r){console.error("[LiveServer] runPreview failed:",r);try{acode.require("toast")((r==null?void 0:r.message)||"Failed to launch Live Server")}catch{}}finally{ro=!1}}}function ke(){var o;Ta();let e=X()||((o=window.editorManager)==null?void 0:o.activeFile),t=Le(e);if(document.body.classList.toggle("ls-html-file",t),!t){N!=null&&N.isConnected&&N.remove();return}N||(N=document.createElement("span"),N.className="icon play_arrow",N.setAttribute("action","run-live-server"),N.setAttribute("data-ls-run","1"),N.setAttribute("title","Run with Live Server"),N.onclick=Ra),N.className="icon play_arrow";let r=Aa(),n=document.querySelector(Ws);r&&r.parentNode?(N.parentNode!==r.parentNode||N.nextSibling!==r)&&r.parentNode.insertBefore(N,r):n&&!N.isConnected&&n.insertBefore(N,n.lastChild)}function Gs(){ke(),window.editorManager&&(editorManager.off("switch-file",ke),editorManager.off("rename-file",ke),editorManager.on("switch-file",ke),editorManager.on("rename-file",ke)),clearInterval($r),$r=setInterval(ke,1500)}function Xs(){var e;clearInterval($r),$r=null,window.editorManager&&(editorManager.off("switch-file",ke),editorManager.off("rename-file",ke));try{N==null||N.remove()}catch{}N=null,document.body.classList.remove("ls-html-file"),(e=document.getElementById("ls-run-css"))==null||e.remove()}ht();J();he();re();he();Se();var Ct=null;function Vs(){var e;if(!Ct){Ct=async t=>{try{if(k().liveReload===!1)return;let r=B();if(!r.running||!r.port)return;await fetch(`http://127.0.0.1:${r.port}/reload`,{method:"POST"}).catch(()=>{}),(Le(t)||Le(editorManager==null?void 0:editorManager.activeFile))&&console.log("[LiveServer] reload signal after save")}catch(r){console.warn("[LiveServer] save reload",r)}};try{(e=editorManager==null?void 0:editorManager.on)==null||e.call(editorManager,"save-file",Ct)}catch{}}}function Ys(){var e;try{Ct&&((e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"save-file",Ct))}catch{}Ct=null}var no=null;function Zs(){no&&(no(!1),no=null)}br();var Ks=["switch-file","rename-file","file-loaded","new-file"],Fr="",rr=null,st=null,nr=null;async function Js(e){Fr=e||"",Nn(Fr),qo(Fr),en();try{let{getSettings:r,updateSetting:n}=await Promise.resolve().then(()=>(re(),Mt)),o=r().acodelsPath||"";/^\/public|com\.termux/.test(String(o))&&n("acodelsPath","")}catch{}try{}catch(r){console.warn("[LiveServer] settings",r)}try{Vn()}catch(r){console.warn("[LiveServer] side",r)}try{js()}catch(r){console.warn("[LiveServer] commands",r)}try{Vs()}catch(r){console.warn("[LiveServer] liveReload",r)}try{Gs()}catch(r){console.warn("[LiveServer] run button",r)}rr=()=>{Yn(),ke()},Ks.forEach(r=>{var n;try{(n=editorManager==null?void 0:editorManager.on)==null||n.call(editorManager,r,rr)}catch{}}),st=()=>ot(B().running);try{window.addEventListener("liveserver-status",st),window.addEventListener("liveserver-started",st),window.addEventListener("liveserver-stopped",st)}catch{}let t=async()=>{let r=await Gn();ot(r)};t(),setTimeout(t,1200),setTimeout(rr,400),nr=()=>{document.visibilityState==="visible"&&t()},document.addEventListener("visibilitychange",nr);try{window.addEventListener("liveserver-settings",async()=>{try{let{reapplySetup:r}=await Promise.resolve().then(()=>(J(),le));B().running&&await r()}catch{}})}catch{}console.log("[LiveServer] v2 init",Fr)}function Qs(){Ks.forEach(e=>{var t;try{rr&&((t=editorManager==null?void 0:editorManager.off)==null||t.call(editorManager,e,rr))}catch{}});try{Xs()}catch{}try{window.removeEventListener("liveserver-status",st),window.removeEventListener("liveserver-started",st),window.removeEventListener("liveserver-stopped",st)}catch{}nr&&(document.removeEventListener("visibilitychange",nr),nr=null),Zs(),Po(),Zn(),zs();try{Ys()}catch{}try{Promise.resolve().then(()=>(nt(),rt)).then(e=>{var t;return(t=e.hideBrowser)==null?void 0:t.call(e)})}catch{}try{Promise.resolve().then(()=>(In(),us)).then(e=>{var t;return(t=e.destroyAcodeWebview)==null?void 0:t.call(e)})}catch{}}Jn();var jr=class{constructor(){this.baseUrl=""}async init(t){var r;this.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await Js(this.baseUrl)}async destroy(){Qs()}};if(window.acode){let e=new jr;acode.setPluginInit(Wr.id,async t=>{var r;e.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await e.init(e.baseUrl)},Hs()),acode.setPluginUnmount(Wr.id,()=>{e.destroy()})}var Uc=jr;})();
