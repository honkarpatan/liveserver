(()=>{var ws=Object.defineProperty;var _=(e,t)=>()=>(e&&(t=e(e=0)),t);var pe=(e,t)=>{for(var r in t)ws(e,r,{get:t[r],enumerable:!0})};var St,Tr=_(()=>{St={pluginEnabled:!0,port:8080,bindAddress:"127.0.0.1",rootFolder:"",liveReload:!0,openBrowserOnStart:!0,directoryListing:!0,autoShutdownMinutes:0,browserDisplayMode:"inPage",browserSearchEngine:"google",externalSiteMode:"proxy",browserHomeUrl:"",showSideButton:!0,browserOpacity:1,browserOverlay:!1,overlayAutoSave:!0,browserBookmarks:[],browserDevice:{on:!1,id:"responsive",w:390,h:844,zoom:"fit"},enableCors:!0,customHeaders:"",customCharset:"utf-8",bindLocalhostOnly:!0,ipWhitelist:"",basicAuthUser:"",basicAuthPass:"",dependenciesInstalled:!1,acodelsPath:"",showAddressBar:!0}});var Rr={};pe(Rr,{getPluginId:()=>Ss,getSettings:()=>C,saveSettingsPatch:()=>Es,updateSetting:()=>$});function Ss(){return Pr}function C(){var e;try{let t=acode.require("settings"),r=(e=t==null?void 0:t.value)==null?void 0:e[Pr];return(!r||typeof r!="object")&&(r={...St},t!=null&&t.value&&(t.value[Pr]=r)),r}catch{return{...St}}}function $(e,t){let r=C();r[e]=t;try{acode.require("settings").update(!1)}catch{}try{window.dispatchEvent(new CustomEvent("liveserver-settings",{detail:{key:e,value:t}}))}catch{}}function Es(e){let t=C();Object.assign(t,e);try{acode.require("settings").update(!1)}catch{}}var Pr,oe=_(()=>{Tr();Pr="acode.plugin.sugerserver"});function ge(e){return String(e!=null?e:"").replace(/'/g,`'"'"'`)}function Mr(e){let t=String(e||"").trim();return t?/^sh\s+-c\s+/i.test(t)?t:`sh -c '${ge(t)}'`:"sh -c 'true'"}function Et(e){return String(e||"").split(`
`).filter(t=>!/proot warning:/i.test(t)).join(`
`)}function Fn(e){if(e==null)return"";if(typeof e=="string")return Et(e);if(typeof e=="object"){let t=[e.stdout,e.stderr,e.output,e.message].filter(r=>r!=null&&r!=="").map(String);if(t.length)return Et(t.join(`
`));try{return Et(JSON.stringify(e))}catch{return Et(String(e))}}return Et(String(e))}function Hr(e){try{return btoa(unescape(encodeURIComponent(e)))}catch{let r=new TextEncoder().encode(e),n="";return r.forEach(o=>{n+=String.fromCharCode(o)}),btoa(n)}}function Xe(){try{let e=acode.require("terminal"),t=typeof Executor!="undefined"&&Executor||window.Executor||globalThis.Executor||(e==null?void 0:e.Executor)||null;if(t!=null&&t.execute)return t}catch{}return null}async function ee(e,t={}){let r=typeof t=="number"?t:t.timeoutMs||0,n=typeof t=="object"&&t.alpine!==!1,o=Xe();if(!(o!=null&&o.execute))throw console.warn("[LiveServer:exec] no executor",{hasWindow:!!window.Executor,hasGlobal:!!globalThis.Executor,hasTerminal:!!acode.require("terminal")}),new Error("Executor not available. Open Acode Terminal once (or install Executor), then retry.");let i=Mr(e);console.log("[LiveServer:exec] run len=",i.length);let s=async()=>{try{let c=await o.execute(i,n),u=Fn(c);return console.log("[LiveServer:exec] ok len=",u.length),u}catch(c){let u=Fn(c)||c&&c.message||String(c);return console.warn("[LiveServer:exec] catch \u2192",String(u).slice(0,240)),u}};return r>0?Promise.race([s(),new Promise(c=>setTimeout(()=>{console.warn("[LiveServer:exec] timeout",r,"ms \u2014 continuing"),c("")},r))]):s()}async function Lt(e,t={}){let r=Hr(String(e||""));return ee(`echo '${ge(r)}' | base64 -d | sh`,{timeoutMs:t.timeoutMs||0,alpine:t.alpine!==!1})}async function Or(e){try{let t=await ee(`command -v ${ge(e)} 2>/dev/null || which ${ge(e)} 2>/dev/null || echo MISS`,{timeoutMs:2e4}),r=String(t||"").trim();return!r||/MISS|not found/i.test(r)?!1:/\//.test(r)||r.split(`
`).some(n=>n.includes("/"))}catch(t){return console.warn("[LiveServer:exec] commandExists",e,(t==null?void 0:t.message)||t),!1}}var Ct=_(()=>{});function Un(){if(document.getElementById("ls-deps-picker-css"))return;let e=document.createElement("style");e.id="ls-deps-picker-css",e.textContent=`
#ls-deps-picker {
  position: fixed; inset: 0; z-index: 99999;
  display: flex; align-items: center; justify-content: center;
  animation: ls-dp-in 0.2s ease-out;
}
@keyframes ls-dp-in { from { opacity: 0; } to { opacity: 1; } }
#ls-deps-picker.ls-dp-leaving { opacity: 0; transition: opacity 0.18s ease; }
.ls-dp-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,0.5); }
.ls-dp-card {
  position: relative; z-index: 1;
  width: min(420px, 92vw); max-height: min(78vh, 560px);
  display: flex; flex-direction: column;
  border-radius: 3px;
  background: var(--secondary-color, #1e1e1e);
  color: var(--color, #e0e0e0);
  box-shadow: 0 12px 40px rgba(0,0,0,0.45);
  overflow: hidden;
  border: 1px solid rgba(128,128,128,0.25);
}
.ls-dp-header {
  padding: 12px 14px 8px;
  border-bottom: 1px solid rgba(128,128,128,0.25);
  flex-shrink: 0;
}
.ls-dp-title { font-weight: 600; font-size: 1.02rem; }
.ls-dp-subtitle { font-size: 0.75rem; opacity: 0.75; margin-top: 4px; }
.ls-dp-body { flex: 1; overflow: auto; padding: 10px 12px; min-height: 80px; }
.ls-dp-checking {
  display: flex; align-items: center; gap: 10px; justify-content: center; padding: 24px 8px;
}
.ls-dp-spinner {
  width: 18px; height: 18px; border-radius: 50%;
  border: 2px solid rgba(128,128,128,0.35);
  border-top-color: var(--active-color, #61afef);
  animation: ls-spin 0.7s linear infinite;
  flex-shrink: 0;
}
@keyframes ls-spin { to { transform: rotate(360deg); } }
.ls-dp-row {
  display: flex; align-items: center; gap: 10px;
  padding: 10px 8px; border-radius: 3px; margin-bottom: 6px;
  background: rgba(128,128,128,0.1);
}
.ls-dp-row.is-present { opacity: 0.75; }
.ls-dp-row input[type="checkbox"] {
  width: 1.15rem; height: 1.15rem; flex-shrink: 0;
  accent-color: var(--active-color, #61afef);
}
.ls-dp-row-main { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 2px; }
.ls-dp-name { font-weight: 500; font-size: 0.92rem; }
.ls-dp-desc { font-size: 0.7rem; opacity: 0.7; word-break: break-all; }
.ls-dp-status { font-size: 0.72rem; flex-shrink: 0; font-weight: 600; }
.ls-dp-status.ok { color: #66bb6a; }
.ls-dp-status.miss { color: #f48771; }
.ls-dp-progress { padding: 6px 2px 10px; }
.ls-dp-progress-track {
  height: 4px; border-radius: 3px;
  background: rgba(128,128,128,0.3); overflow: hidden;
}
.ls-dp-progress-bar {
  height: 100%; width: 0;
  background: var(--active-color, #61afef);
  transition: width 0.25s ease;
  border-radius: 3px;
}
.ls-dp-progress-info {
  font-size: 0.8rem; margin-top: 10px; opacity: 0.95; line-height: 1.35;
}
.ls-dp-link {
  display: inline-block; margin-top: 10px;
  background: none; border: none;
  color: var(--active-color, #61afef);
  font-size: 0.78rem; cursor: pointer; padding: 0;
  text-decoration: underline;
}
.ls-dp-log {
  margin-top: 8px; max-height: 160px; overflow: auto;
  font-size: 0.68rem; line-height: 1.35;
  background: rgba(0,0,0,0.35); padding: 8px; border-radius: 3px;
  white-space: pre-wrap; word-break: break-word;
  border: 1px solid rgba(128,128,128,0.2);
  color: #c8c8c8;
}
.ls-dp-footer {
  display: flex; flex-wrap: wrap; gap: 8px; justify-content: flex-end;
  padding: 10px 12px;
  border-top: 1px solid rgba(128,128,128,0.25);
  flex-shrink: 0;
}
.ls-dp-btn {
  border: none; border-radius: 3px; padding: 9px 14px; font-size: 0.85rem;
  cursor: pointer; background: rgba(128,128,128,0.25); color: inherit;
  min-height: 36px;
}
.ls-dp-btn.ls-dp-install,
.ls-dp-btn.ls-dp-done {
  background: var(--active-color, #61afef); color: #111; font-weight: 600;
}
.ls-dp-btn.ls-dp-cancel {
  background: rgba(244, 135, 113, 0.25); color: #f48771;
}
.ls-dp-empty { opacity: 0.7; padding: 12px; text-align: center; }
`,document.head.appendChild(e)}var Wn=_(()=>{});function _t(e){return String(e!=null?e:"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function Gn(){return!!O}function Br(){return At}function Xn(){At=!1}function Kn(e={}){Un(),Vn(!0),At=!1;let t=e.title||"Live Server Dependencies",r=e.subtitle||"",n=Array.isArray(e.items)?e.items.slice():[];return new Promise(o=>{Ke=o,O=document.createElement("div"),O.id="ls-deps-picker",O.innerHTML=`
      <div class="ls-dp-backdrop"></div>
      <div class="ls-dp-card" role="dialog">
        <div class="ls-dp-header">
          <div class="ls-dp-title">${_t(t)}</div>
          <div class="ls-dp-subtitle">${_t(r)}</div>
        </div>
        <div class="ls-dp-body">
          <div class="ls-dp-checking" style="display:${e.checking?"flex":"none"}">
            <span class="ls-dp-spinner"></span>
            <span>Checking dependencies\u2026</span>
          </div>
          <div class="ls-dp-lists" style="display:${e.checking?"none":"block"}"></div>
          <div class="ls-dp-progress" style="display:none">
            <div class="ls-dp-progress-track"><div class="ls-dp-progress-bar" style="width:0%"></div></div>
            <div class="ls-dp-progress-info">Installing\u2026</div>
            <button type="button" class="ls-dp-link ls-dp-toggle-log">Expand details</button>
            <pre class="ls-dp-log" style="display:none"></pre>
          </div>
        </div>
        <div class="ls-dp-footer">
          <button type="button" class="ls-dp-btn ls-dp-notnow">Not now</button>
          <button type="button" class="ls-dp-btn ls-dp-cancel" style="display:none">Cancel</button>
          <button type="button" class="ls-dp-btn ls-dp-install">Install selected</button>
          <button type="button" class="ls-dp-btn ls-dp-done" style="display:none">Close</button>
        </div>
      </div>`,document.body.appendChild(O);let i=O.querySelector(".ls-dp-lists"),s=O.querySelector(".ls-dp-checking"),c=O.querySelector(".ls-dp-progress"),u=O.querySelector(".ls-dp-progress-bar"),a=O.querySelector(".ls-dp-progress-info"),p=O.querySelector(".ls-dp-log"),h=O.querySelector(".ls-dp-install"),m=O.querySelector(".ls-dp-notnow"),l=O.querySelector(".ls-dp-cancel"),f=O.querySelector(".ls-dp-done"),L=O.querySelector(".ls-dp-toggle-log"),D=O.querySelector(".ls-dp-subtitle"),y=O.querySelector(".ls-dp-backdrop");function S(){if(!i)return;let g="";for(let k of n){let R=k.present?'<span class="ls-dp-status ok">installed</span>':'<span class="ls-dp-status miss">missing</span>';g+=`<label class="ls-dp-row ${k.present?"is-present":"is-missing"}">
          <input type="checkbox" data-id="${_t(k.id)}" ${k.checked?"checked":""} ${k.present?"disabled":""}/>
          <span class="ls-dp-row-main">
            <span class="ls-dp-name">${_t(k.label)}</span>
            <span class="ls-dp-desc">${_t(k.desc||"")}</span>
          </span>${R}</label>`}i.innerHTML=g||'<div class="ls-dp-empty">No items</div>'}function T(){let g=[];return O==null||O.querySelectorAll("input[type=checkbox][data-id]:checked:not(:disabled)").forEach(k=>g.push(k.getAttribute("data-id"))),g}function P(g){let k=T(),R=Ke;Ke=null,Vn(!1),R&&R({action:g,selected:k})}function b(){let g=T();if(!g.length){try{acode.require("toast")("Select at least one item",2e3)}catch{}return}At=!1,i&&(i.style.display="none"),s&&(s.style.display="none"),c&&(c.style.display="block"),h&&(h.style.display="none"),m&&(m.style.display="none"),l&&(l.style.display="inline-block"),f&&(f.style.display="none"),u&&(u.style.width="2%"),a&&(a.textContent="Starting\u2026"),p&&(p.textContent=""),D&&(D.textContent="Installing selected packages\u2026");let k=Ke;Ke=null,k&&k({action:"install",selected:g,keepOpen:!0})}h==null||h.addEventListener("click",()=>b()),m==null||m.addEventListener("click",()=>P("notnow")),l==null||l.addEventListener("click",()=>{At=!0,a&&(a.textContent="Cancelled\u2026"),P("cancel")}),f==null||f.addEventListener("click",()=>P("done")),y==null||y.addEventListener("click",()=>{c&&c.style.display!=="none"&&(l==null?void 0:l.style.display)!=="none"||P("close")}),L==null||L.addEventListener("click",()=>{if(!p)return;let g=p.style.display!=="none";p.style.display=g?"none":"block",L.textContent=g?"Expand details":"Hide details"}),O._lsDpUpdate=g=>{g.checking===!1&&s&&i&&(s.style.display="none",i.style.display="block"),g.checking===!0&&s&&i&&(s.style.display="flex",i.style.display="none"),g.subtitle!=null&&D&&(D.textContent=g.subtitle),Array.isArray(g.items)&&(n.length=0,g.items.forEach(k=>n.push({...k,checked:k.checked!=null?!!k.checked:!k.present})),S()),g.progressMode&&(i&&(i.style.display="none"),s&&(s.style.display="none"),c&&(c.style.display="block"),h&&(h.style.display="none"),m&&(m.style.display="none"),l&&(l.style.display=g.showDone?"none":"inline-block"),f&&(f.style.display=g.showDone?"inline-block":"none")),typeof g.percent=="number"&&u&&(u.style.width=Math.max(0,Math.min(100,g.percent))+"%"),g.info&&a&&(a.textContent=g.info),g.logAppend&&p&&(p.textContent+=g.logAppend,p.scrollTop=p.scrollHeight),g.logSet!=null&&p&&(p.textContent=g.logSet)},S()})}function ae(e){O&&typeof O._lsDpUpdate=="function"&&O._lsDpUpdate(e)}function Vn(e){if(!O)return;let t=O;O=null,Ke=null;try{t.classList.add("ls-dp-leaving")}catch{}let r=()=>{try{t.remove()}catch{}};e?r():setTimeout(r,180)}var O,Ke,At,Yn=_(()=>{Wn();O=null,Ke=null,At=!1});var nr={};pe(nr,{DEP_CATALOG:()=>Qt,checkDependenciesAction:()=>Ps,ensureLiveServerDeps:()=>rr,reinstallDependenciesAction:()=>Rs,resetDepsSession:()=>Ir,resolveAcodelsPath:()=>Qe,scanAllDeps:()=>Dr,showDepsPickerFlow:()=>tr,verifyDependencies:()=>Je});async function Qe(e){let t=C();try{let n=await ee(`for d in /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do
  [ -f "$d/index.js" ] || continue
  if [ -d "$d/node_modules/express" ]; then echo "FULL:$d"; exit 0; fi
  echo "BARE:$d"
done
exit 0
`,{timeoutMs:12e3}),o=String(n||"").split(`
`).map(a=>a.trim()).filter(Boolean);console.log("[LiveServer:deps] probe",o.slice(0,8));let i=o.filter(a=>a.startsWith("FULL:")).map(a=>a.slice(5)),s=o.filter(a=>a.startsWith("BARE:")).map(a=>a.slice(5)),c=a=>a.filter(h=>h&&!h.startsWith("/public")).sort((h,m)=>(m.startsWith("/root")?1:0)-(h.startsWith("/root")?1:0))[0]||a.find(h=>h&&!h.startsWith("/public"))||a[0]||null,u=c(i)||c(s);if(u){try{$("acodelsPath",u)}catch{}return console.log("[LiveServer:deps] acodels path",u),u}}catch(n){console.warn("[LiveServer:deps] probe",(n==null?void 0:n.message)||n)}let r=String(t.acodelsPath||"").trim();if(r&&!r.startsWith("/public")&&!r.includes("com.termux"))return r;try{r&&$("acodelsPath","")}catch{}return"/root/.acode_liveserver/acodels"}async function Cs(e){try{let t=e?ge(e):"''",r=await ee("for d in "+t+' /root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do [ -d "$d/node_modules/express" ] && [ -d "$d/node_modules/ws" ] && echo OK && exit 0; done; echo MISS',{timeoutMs:1e4});return String(r).includes("OK")}catch{return!1}}async function Dr(e){Ae=e||Ae;let t=await Or("node"),r=await Or("npm"),n=await Qe(e),o=t?await Cs(n):!1;return[{...Qt[0],present:t},{...Qt[1],present:r},{...Qt[2],present:o,path:n}]}async function Je(e){let t=await Dr(e),r=t.filter(n=>!n.present).map(n=>n.id);return{ok:r.length===0,missing:r,all:t}}function _s(e){return e.map(t=>({id:t.id,label:t.label,desc:t.desc+(t.path?` \xB7 ${t.path}`:""),present:t.present,checked:!t.present}))}async function As(){return Lt(`#!/bin/sh
set +e
echo "[pm] detecting..."
if command -v pkg >/dev/null 2>&1; then
  echo "[pm] termux pkg"
  pkg update -y 2>&1
  pkg install -y nodejs 2>&1 || pkg install -y nodejs-lts 2>&1
elif command -v apk >/dev/null 2>&1; then
  echo "[pm] apk"
  apk add --no-cache nodejs npm 2>&1
elif command -v apt-get >/dev/null 2>&1; then
  echo "[pm] apt"
  apt-get update -y 2>&1
  apt-get install -y nodejs npm 2>&1
else
  echo "[pm] none found"
  exit 1
fi
echo "[which] node=$(command -v node 2>/dev/null)"
echo "[which] npm=$(command -v npm 2>/dev/null)"
node -v 2>&1
npm -v 2>&1
echo "[done] node packages"
`,{timeoutMs:0})}async function Ts(e,t){let r=`#!/bin/sh
set +e
DIR=${ge(e)}
case "$DIR" in
  '$HOME'/*|$HOME/*) DIR="/root/.acode_liveserver/acodels" ;;
esac
if [ -z "$DIR" ] || echo "$DIR" | grep -q com.termux; then
  DIR="/root/.acode_liveserver/acodels"
fi
echo "[acodels] HOME=$HOME"
echo "[acodels] DIR=$DIR"
mkdir -p "$DIR" 2>&1
cd "$DIR" || { echo "[acodels] cd failed"; exit 1; }
if [ ! -f package.json ]; then
  echo "[acodels] writing package.json"
  cat > package.json << 'JSON'
{
  "name": "acodels",
  "version": "1.0.0",
  "main": "index.js",
  "dependencies": {
    "chokidar": "^3.5.3",
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "ws": "^8.11.0"
  }
}
JSON
fi
echo "[acodels] npm install in $DIR"
npm install --omit=dev 2>&1
echo "[test] express=$(test -d node_modules/express && echo ok || echo miss)"
echo "[test] ws=$(test -d node_modules/ws && echo ok || echo miss)"
echo "[pwd] $(pwd)"
echo "[done] acodels"
`;return Lt(r,{timeoutMs:0})}async function tr(e={}){var s,c,u;let t=e.baseUrl||Ae||"";if(Ae=t,Ye)return _e("Install already running\u2026",2e3),!1;if(Gn()&&!e.force)return _e("Dependency UI already open\u2026",2e3),!1;if(!e.force&&!e.fromSettings&&Ze)return!1;if(!e.force&&!e.fromSettings&&(await Je(t)).ok)return $("dependenciesInstalled",!0),!0;(s=Xe())!=null&&s.execute||(_e("Open Acode Terminal once, then retry Install",3500),console.warn("[LiveServer:deps] Executor missing before picker"));let r=Kn({title:"Live Server Dependencies",subtitle:"Checking\u2026",items:[],checking:!0}),n;try{n=await Dr(t)}catch(a){return ae({checking:!1,subtitle:"Check failed \u2014 "+((a==null?void 0:a.message)||a),items:[]}),await r,!1}let o=n.filter(a=>!a.present).length;ae({checking:!1,subtitle:o===0?"All required tools present":`${o} missing \xB7 tick what to install`,items:_s(n)});let i=await r;if(i.action==="notnow"||i.action==="close"||i.action==="cancel")return Ze=!0,i.action==="notnow"&&_e("Skipped for this session",2e3),!1;if(i.action==="done")return(await Je(t)).ok;if(i.action==="install"&&((c=i.selected)!=null&&c.length)){if(Ye=!0,Xn(),!((u=Xe())!=null&&u.execute))return ae({progressMode:!0,percent:0,info:"Executor not available",logAppend:`Open Acode Terminal once (Alpine/Termux), then open this dialog again and Install.
`,showDone:!0}),_e("Executor missing \u2014 open Terminal first",3500),Ye=!1,!1;ae({progressMode:!0,percent:5,info:"Preparing\u2026",logAppend:"Selected: "+i.selected.join(", ")+`
`});try{let a=await Qe(t);if(i.selected.includes("node")||i.selected.includes("npm")){if(ae({percent:15,info:"Installing Node.js / npm (may take several minutes)\u2026",logAppend:`
=== node / npm ===
`}),Br())return Ye=!1,!1;let h=await As();ae({percent:50,logAppend:String(h||"").slice(-2500)+`
`})}if(i.selected.includes("acodels")){if(ae({percent:60,info:"npm install in acodels\u2026",logAppend:`
=== acodels @ ${a} ===
`}),Br())return Ye=!1,!1;let h=await Ts(a,t);ae({percent:90,logAppend:String(h||"").slice(-3e3)+`
`});try{let m=await ee('echo "$HOME/.acode_liveserver/acodels"',{timeoutMs:1e4}),l=String(m||"").split(`
`).map(f=>f.trim()).find(f=>f.startsWith("/")&&f.includes("acodels"));$("acodelsPath",l||a.replace(/^\$HOME/,""))}catch{try{$("acodelsPath",a)}catch{}}}let p=await Je(t);return ae({progressMode:!0,percent:100,info:p.ok?"Done \u2014 all required present":"Finished \u2014 still missing: "+p.missing.join(", "),showDone:!0,logAppend:p.ok?`
OK
`:`
Missing: `+p.missing.join(", ")+`
`}),$("dependenciesInstalled",p.ok),p.ok?(Ze=!0,_e("Dependencies ready",2500)):_e("Still missing: "+p.missing.join(", "),4e3),p.ok}catch(a){return console.warn("[LiveServer:deps] install",a),ae({progressMode:!0,percent:100,info:"Failed",showDone:!0,logAppend:`
ERROR: `+((a==null?void 0:a.message)||a)+`
`}),_e("Install error: "+((a==null?void 0:a.message)||a),4e3),!1}finally{Ye=!1}}return!1}async function rr(e={}){let t=e.baseUrl||Ae||"";Ae=t;try{return!e.force&&Ze?!0:!e.force&&er?(await Je(t)).ok:(er=!0,(await Je(t)).ok?($("dependenciesInstalled",!0),!0):tr({...e,baseUrl:t}))}catch(r){return console.warn("[LiveServer:deps]",r),!1}}async function Ps(e){return tr({force:!0,fromSettings:!0,baseUrl:e||Ae})}async function Rs(e){return await Ls("Reinstall dependencies?","Will run pkg/apk install for Node and npm install in acodels.")?(Ze=!1,er=!1,tr({force:!0,fromSettings:!0,baseUrl:e||Ae})):!1}function Ir(){Ze=!1,er=!1}var _e,Ls,Ze,er,Ye,Ae,Qt,et=_(()=>{oe();Ct();Yn();_e=acode.require("toast"),Ls=acode.require("confirm"),Ze=!1,er=!1,Ye=!1,Ae="",Qt=[{id:"node",label:"node",desc:"Node.js runtime",required:!0},{id:"npm",label:"npm",desc:"Package manager",required:!0},{id:"acodels",label:"acodels modules",desc:"Backend node_modules (express, ws, chokidar)",required:!0}]});var Ms,Zn,Jn=_(()=>{Ct();Ms=`/**
 * acodels \u2014 Live Server + Local Reverse Proxy Node backend (ls-proxy-v1, ls-bridge-v1)
 */
const http = require('http');
const https = require('https');
const express = require('express');
const path = require('path');
const fs = require('fs');
const net = require('net');
const zlib = require('zlib');
const { URL } = require('url');
const { Server: WebSocketServer } = require('ws');
const chokidar = require('chokidar');

let BASE_DIR = null;
let jsonData = {};
let erudaEnabled = false;
let consoleType = 'suger';
let zoomEnabled = false;
let liveReloadEnabled = true;
let directoryListing = true;
let fileWatcher = null;
let connectedSockets = [];
let customHeaders = {};
let charset = 'utf-8';
let ipWhitelist = [];
let basicAuth = null;
let lastActivity = Date.now();

const args = process.argv.slice(2);
let currentPort = args[0] ? parseInt(args[0], 10) : 8080;
if (!Number.isFinite(currentPort) || currentPort < 1) currentPort = 8080;
const bindHost = args[1] || '0.0.0.0';

function isPortAvailable(port) {
  return new Promise((resolve) => {
    const tester = net
      .createServer()
      .once('error', () => resolve(false))
      .once('listening', () => tester.close(() => resolve(true)))
      .listen(port, bindHost === '0.0.0.0' ? undefined : bindHost);
  });
}

const webSocketScript = \`
<script>
  (function() {
    try {
      var wsUrl = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
      var ws = new WebSocket(wsUrl);
      ws.onmessage = function (event) {
        if (event.data === 'reload') location.reload();
      };
    } catch (e) {}
  })();
<\/script>\`;

const sugerScript = \`<script src="/dt/suger-dev.js"><\/script>\`;
const erudaRealScript = \`
<script src="/eruda.min.js"><\/script>
<script>if (typeof eruda !== 'undefined') eruda.init();<\/script>
\`;
const inspectorScript = \`<script src="/inspector.js"><\/script>\`;

/* ls-bridge-v1: page <-> Acode browser bridge */
const LS_BRIDGE_JS = \`
(function () {
  var P = window.__lsParent || window.parent;
  if (window.__lsBridge || !P || P === window) return;
  window.__lsBridge = 1;
  function post(m) {
    try { m.ls = 1; P.postMessage(m, '*'); } catch (e) {}
  }
  function currentHref() {
    return window.__LS_PROXY_TARGET__ || location.href;
  }
  function fav() {
    var l = document.querySelector('link[rel~="icon"]');
    if (l && l.href) return l.href;
    try { return new URL('/favicon.ico', currentHref()).href; } catch (e) { return ''; }
  }
  function meta() {
    post({ type: 'meta', href: currentHref(), title: document.title || '', favicon: fav() });
  }
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(meta, 0);
  window.addEventListener('load', meta);
  window.addEventListener('popstate', function () { setTimeout(meta, 0); });
  window.addEventListener('hashchange', function () { setTimeout(meta, 0); });
  try {
    var t = document.querySelector('title');
    if (t) new MutationObserver(meta).observe(t, { childList: true, characterData: true, subtree: true });
  } catch (e) {}

  var dtOn = false;
  function devtools(d) {
    try {
      if (d.on) {
        if (!window.suger) {
          if (!d.code) { post({ type: 'need-devtools' }); return; }
          var s = document.createElement('script');
          s.textContent = d.code;
          (document.head || document.documentElement).appendChild(s);
        }
        if (window.suger) {
          if (!window.__lsDtInit) { window.__lsDtInit = 1; window.suger.init(); }
          else window.suger.show();
          dtOn = true;
        }
      } else if (window.suger) {
        window.suger.hide();
        dtOn = false;
      }
    } catch (e) {
      post({ type: 'devtools-error', message: String(e && e.message || e) });
    }
    post({ type: 'devtools', on: dtOn });
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.ls !== 1 || e.source !== P) return;
    try {
      if (d.cmd === 'history') history.go(d.dir < 0 ? -1 : 1);
      else if (d.cmd === 'reload') location.reload();
      else if (d.cmd === 'stop') window.stop();
      else if (d.cmd === 'zoom') document.documentElement.style.zoom = String((d.pct || 100) / 100);
      else if (d.cmd === 'print') window.print();
      else if (d.cmd === 'find') post({ type: 'found', ok: !!window.find(d.q, false, !!d.back, true, false, false, false) });
      else if (d.cmd === 'devtools') devtools(d);
      else if (d.cmd === 'ping') meta();
    } catch (err) {}
  });
})();
\`;

const lsBridgeScript = '<script src="/__ls/bridge.js"><\/script>';
const zoomScript = \`
<script src="/zoom-handler.js"><\/script>
<script>try { new ZoomHandler(document.body); } catch (e) {}<\/script>\`;

const app = express();
app.use(express.json({ limit: '2mb' }));

// Activity + security middleware
app.use((req, res, next) => {
  lastActivity = Date.now();
  if (ipWhitelist.length) {
    const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (!ipWhitelist.includes(ip) && ip !== '127.0.0.1' && ip !== '::1') {
      return res.status(403).send('Forbidden');
    }
  }
  if (basicAuth && basicAuth.user && !req.path.startsWith('/__proxy')) {
    const hdr = req.headers.authorization || '';
    const ok = (() => {
      if (!hdr.startsWith('Basic ')) return false;
      try {
        const decoded = Buffer.from(hdr.slice(6), 'base64').toString('utf8');
        const i = decoded.indexOf(':');
        const u = decoded.slice(0, i);
        const p = decoded.slice(i + 1);
        return u === basicAuth.user && p === (basicAuth.pass || '');
      } catch (_) {
        return false;
      }
    })();
    if (!ok) {
      res.setHeader('WWW-Authenticate', 'Basic realm="Live Server"');
      return res.status(401).send('Unauthorized');
    }
  }
  Object.keys(customHeaders).forEach((k) => {
    try { res.setHeader(k, customHeaders[k]); } catch (_) {}
  });
  next();
});

// CORS
app.use((req, res, next) => {
  if (jsonData.enableCors !== false) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
  }
  next();
});

app.get('/check', (req, res) => {
  res.status(200).json({
    message: 'Ready',
    key: 'AcodeLiveServer_NodeJS',
    port: currentPort,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    proxy: true,
  });
});

app.get('/status', (req, res) => {
  res.json({
    port: currentPort,
    bind: bindHost,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    directoryListing,
    clients: connectedSockets.length,
    lastActivity,
    uptime: process.uptime(),
    proxy: true,
  });
});

app.post('/reload', (req, res) => {
  broadcastReload();
  res.json({ ok: true, clients: connectedSockets.length });
});

app.patch('/setup', (req, res) => {
  const data = req.body || {};
  if (!data.path) return res.status(400).json({ error: 'Missing path' });

  BASE_DIR = data.path;
  jsonData = data;
  erudaEnabled = data.eruda === true;
  if (data.consoleType) consoleType = data.consoleType;
  zoomEnabled = data.zoom === true;
  liveReloadEnabled = data.liveReload !== false;
  directoryListing = data.directoryListing !== false;

  if (typeof data.charset === 'string' && data.charset) charset = data.charset;
  customHeaders = {};
  if (data.customHeaders && typeof data.customHeaders === 'object') {
    customHeaders = data.customHeaders;
  } else if (typeof data.customHeaders === 'string') {
    String(data.customHeaders).split('\\n').forEach((line) => {
      const i = line.indexOf(':');
      if (i > 0) {
        const k = line.slice(0, i).trim();
        const v = line.slice(i + 1).trim();
        if (k) customHeaders[k] = v;
      }
    });
  }

  ipWhitelist = [];
  if (data.ipWhitelist) {
    const raw = Array.isArray(data.ipWhitelist)
      ? data.ipWhitelist
      : String(data.ipWhitelist).split(/[\\n,]+/);
    ipWhitelist = raw.map((s) => String(s).trim()).filter(Boolean);
  }

  if (data.basicAuthUser) {
    basicAuth = { user: String(data.basicAuthUser), pass: String(data.basicAuthPass || '') };
  } else {
    basicAuth = null;
  }

  if (liveReloadEnabled) startFileWatcher(res);
  else {
    if (fileWatcher) {
      try { fileWatcher.close(); } catch (_) {}
      fileWatcher = null;
    }
    res.status(201).json({ message: 'OK', liveReload: false });
  }
});

app.get('/__ls/bridge.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.send(LS_BRIDGE_JS);
});

// ============================================================================
// LOCAL REVERSE PROXY (/__proxy?url=...)
// ============================================================================

function buildProxyRuntimeScript(targetUrl) {
  let origin = '';
  try { origin = new URL(targetUrl).origin; } catch (_) {}
  return \`<script>
(function() {
  window.__LS_PROXY_TARGET__ = \${JSON.stringify(targetUrl)};
  window.__LS_PROXY_ORIGIN__ = \${JSON.stringify(origin)};
  var proxyBase = location.origin + '/__proxy?url=';

  function wrapUrl(raw) {
    if (!raw || typeof raw !== 'string') return raw;
    var s = raw.trim();
    if (!s || s.startsWith('#') || s.startsWith('data:') || s.startsWith('blob:') || s.startsWith('javascript:') || s.startsWith('mailto:') || s.startsWith('tel:')) {
      return raw;
    }
    if (s.indexOf('/__proxy?url=') !== -1) return raw;
    try {
      var resolved = new URL(s, window.__LS_PROXY_TARGET__).href;
      if (/^https?:\\/\\//i.test(resolved)) {
        return proxyBase + encodeURIComponent(resolved);
      }
    } catch (e) {}
    return raw;
  }

  // Patch fetch
  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function(input, init) {
      if (typeof input === 'string') {
        input = wrapUrl(input);
      } else if (input && typeof input.url === 'string') {
        try {
          input = new Request(wrapUrl(input.url), input);
        } catch (e) {}
      }
      return origFetch.call(this, input, init);
    };
  }

  // Patch XMLHttpRequest
  if (window.XMLHttpRequest) {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
      var args = Array.prototype.slice.call(arguments);
      if (typeof url === 'string') args[1] = wrapUrl(url);
      return origOpen.apply(this, args);
    };
  }

  // Intercept anchor clicks & form submissions
  document.addEventListener('click', function(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
    e.preventDefault();
    var nextUrl = wrapUrl(href);
    location.href = nextUrl;
  }, true);

  document.addEventListener('submit', function(e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    var rawAction = form.getAttribute('action') || window.__LS_PROXY_TARGET__;
    var targetAction = rawAction;
    if (targetAction.indexOf('/__proxy?url=') !== -1) {
      try {
        targetAction = decodeURIComponent(targetAction.split('/__proxy?url=')[1]);
      } catch (err) {}
    } else {
      try { targetAction = new URL(rawAction, window.__LS_PROXY_TARGET__).href; } catch (err) {}
    }
    var method = (form.method || 'GET').toUpperCase();
    if (method === 'GET') {
      e.preventDefault();
      var fd = new FormData(form);
      var u = new URL(targetAction);
      fd.forEach(function(v, k) { u.searchParams.set(k, String(v)); });
      location.href = proxyBase + encodeURIComponent(u.href);
    } else {
      form.action = proxyBase + encodeURIComponent(targetAction);
    }
  }, true);

  window.open = function(url) {
    if (url) location.href = wrapUrl(url);
    return window;
  };
})();
<\/script>\`;
}

function rewriteHtmlForProxy(html, targetUrl) {
  let baseHref = targetUrl;
  try {
    const u = new URL(targetUrl);
    baseHref = u.origin + u.pathname.replace(/[^/]*$/, '');
  } catch (_) {}

  const toProxy = (raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('#') ||
      s.startsWith('data:') ||
      s.startsWith('blob:') ||
      s.startsWith('javascript:') ||
      s.startsWith('mailto:') ||
      s.startsWith('tel:') ||
      s.includes('/__proxy?url=')
    ) {
      return raw;
    }
    try {
      const abs = new URL(s, targetUrl).href;
      if (/^https?:///i.test(abs)) {
        return '/__proxy?url=' + encodeURIComponent(abs);
      }
    } catch (_) {}
    return raw;
  };

  // Rewrite src, href, action attributes
  let out = html.replace(
    /\\b(href|src|action)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      return \`\${attr}=\${quote}\${toProxy(val)}\${quote}\`;
    }
  );

  // Strip integrity attributes (since proxied scripts/CSS may differ slightly) & frame-busting meta tags
  out = out.replace(/\\s+integrity\\s*=\\s*(["'])[^"']*\\1/gi, '');
  out = out.replace(/<meta[^>]+http-equiv\\s*=\\s*["']Content-Security-Policy["'][^>]*>/gi, '');

  const injectedHead =
    \`<base href="\${baseHref.replace(/"/g, '"')}">\` +
    buildProxyRuntimeScript(targetUrl) +
    lsBridgeScript;

  if (/<head[^>]*>/i.test(out)) {
    out = out.replace(/<head[^>]*>/i, (m) => m + '\\n' + injectedHead);
  } else if (/<html[^>]*>/i.test(out)) {
    out = out.replace(/<html[^>]*>/i, (m) => m + '<head>' + injectedHead + '</head>');
  } else {
    out = injectedHead + '\\n' + out;
  }

  return out;
}

function rewriteCssForProxy(css, targetUrl) {
  return css.replace(/url\\(\\s*(["']?)([^"')]+)\\1\\s*\\)/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (!s || s.startsWith('data:') || s.startsWith('#') || s.includes('/__proxy?url=')) return match;
    try {
      const abs = new URL(s, targetUrl).href;
      if (/^https?:///i.test(abs)) {
        return \`url(\${quote}/__proxy?url=\${encodeURIComponent(abs)}\${quote})\`;
      }
    } catch (_) {}
    return match;
  });
}

function decompressBuffer(buf, encoding) {
  const enc = String(encoding || '').toLowerCase();
  try {
    if (enc.includes('gzip')) return zlib.gunzipSync(buf);
    if (enc.includes('br') && typeof zlib.brotliDecompressSync === 'function') {
      return zlib.brotliDecompressSync(buf);
    }
    if (enc.includes('deflate')) return zlib.inflateSync(buf);
  } catch (_) {}
  return buf;
}

function fetchUpstream(targetUrl, method, reqHeaders, bodyBuf, redirectsLeft = 6) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(targetUrl);
    } catch (e) {
      return reject(new Error('Invalid target URL'));
    }
    if (!/^https?:$/i.test(parsed.protocol)) {
      return reject(new Error('Only HTTP/HTTPS URLs are supported'));
    }

    const client = parsed.protocol === 'https:' ? https : http;
    const headers = {
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
      'Accept':
        reqHeaders['accept'] ||
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': reqHeaders['accept-language'] || 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'Referer': parsed.origin + '/',
      'Origin': parsed.origin,
    };
    if (reqHeaders['content-type']) headers['Content-Type'] = reqHeaders['content-type'];
    if (reqHeaders['cookie']) headers['Cookie'] = reqHeaders['cookie'];
    if (bodyBuf && bodyBuf.length) headers['Content-Length'] = bodyBuf.length;

    const upstreamReq = client.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method: method || 'GET',
        headers,
        timeout: 20000,
        rejectUnauthorized: false,
      },
      (upstreamRes) => {
        const status = upstreamRes.statusCode || 200;
        const loc = upstreamRes.headers['location'];
        if ([301, 302, 303, 307, 308].includes(status) && loc && redirectsLeft > 0) {
          upstreamRes.resume();
          const nextUrl = new URL(loc, parsed.href).href;
          const nextMethod = status === 303 || ((status === 301 || status === 302) && method === 'POST') ? 'GET' : method;
          return resolve(fetchUpstream(nextUrl, nextMethod, reqHeaders, nextMethod === 'GET' ? null : bodyBuf, redirectsLeft - 1));
        }

        const chunks = [];
        upstreamRes.on('data', (c) => chunks.push(c));
        upstreamRes.on('end', () => {
          resolve({
            status,
            headers: upstreamRes.headers,
            body: Buffer.concat(chunks),
            finalUrl: parsed.href,
          });
        });
      }
    );

    upstreamReq.on('timeout', () => {
      upstreamReq.destroy(new Error('Upstream request timed out'));
    });
    upstreamReq.on('error', reject);
    if (bodyBuf && bodyBuf.length) upstreamReq.write(bodyBuf);
    upstreamReq.end();
  });
}

async function handleProxyRequest(req, res, targetUrl) {
  try {
    const bodyChunks = [];
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      if (req.body && typeof req.body === 'object' && Object.keys(req.body).length > 0) {
        bodyChunks.push(Buffer.from(JSON.stringify(req.body)));
      } else {
        await new Promise((r) => {
          req.on('data', (c) => bodyChunks.push(c));
          req.on('end', r);
        });
      }
    }
    const bodyBuf = bodyChunks.length ? Buffer.concat(bodyChunks) : null;
    const result = await fetchUpstream(targetUrl, req.method, req.headers, bodyBuf);

    const blockedHeaders = new Set([
      'x-frame-options',
      'content-security-policy',
      'content-security-policy-report-only',
      'cross-origin-opener-policy',
      'cross-origin-embedder-policy',
      'cross-origin-resource-policy',
      'content-length',
      'content-encoding',
      'transfer-encoding',
      'connection',
    ]);

    Object.entries(result.headers || {}).forEach(([k, v]) => {
      const lower = k.toLowerCase();
      if (blockedHeaders.has(lower)) return;
      if (lower === 'set-cookie' && Array.isArray(v)) {
        const cleanCookies = v.map((c) =>
          String(c)
            .replace(/;\\s*Domain=[^;]+/gi, '')
            .replace(/;\\s*Secure/gi, '')
            .replace(/SameSite=None/gi, 'SameSite=Lax')
        );
        res.setHeader('Set-Cookie', cleanCookies);
        return;
      }
      try {
        res.setHeader(k, v);
      } catch (_) {}
    });

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-LS-Final-Url', result.finalUrl);

    const contentType = String(result.headers['content-type'] || '');
    const rawBuf = decompressBuffer(result.body, result.headers['content-encoding']);

    if (/text\\/html|application\\/xhtml\\+xml/i.test(contentType)) {
      const htmlText = rawBuf.toString('utf8');
      const rewritten = rewriteHtmlForProxy(htmlText, result.finalUrl);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.status(result.status).send(rewritten);
    }

    if (/text\\/css/i.test(contentType)) {
      const cssText = rawBuf.toString('utf8');
      const rewrittenCss = rewriteCssForProxy(cssText, result.finalUrl);
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
      return res.status(result.status).send(rewrittenCss);
    }

    return res.status(result.status).send(rawBuf);
  } catch (err) {
    const safeUrl = String(targetUrl || '').replace(/</g, '<');
    const safeMsg = String(err && err.message || err).replace(/</g, '<');
    res.status(502).setHeader('Content-Type', 'text/html; charset=utf-8').send(\`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
      <style>
        body { font-family: system-ui, sans-serif; background: #1e1e1e; color: #e8eaed; padding: 28px 18px; text-align: center; }
        .card { max-width: 420px; margin: 24px auto; padding: 20px; border-radius: 8px; background: #292a2d; border: 1px solid #3c4043; }
        h3 { margin: 0 0 8px; color: #f87171; }
        p { font-size: 13px; color: #9aa0a6; word-break: break-all; }
        button { margin-top: 12px; padding: 8px 16px; border: 0; border-radius: 5px; background: #22c55e; color: #052e16; font-weight: 600; cursor: pointer; }
      </style></head>
      <body>
        <div class="card">
          <h3>Proxy Could Not Load Page</h3>
          <p>\${safeMsg}</p>
          <p>\${safeUrl}</p>
          <button onclick="location.reload()">Retry</button>
        </div>
      </body></html>
    \`);
  }
}

app.all('/__proxy', (req, res) => {
  const targetUrl = req.query.url;
  if (!targetUrl) return res.status(400).send('Missing ?url=');
  handleProxyRequest(req, res, String(targetUrl));
});

// Referer-based fallback for root-relative assets/APIs requested by proxied pages
app.use((req, res, next) => {
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (idx !== -1 && !req.path.startsWith('/__ls/') && !req.path.startsWith('/dt/')) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const resolved = new URL(req.originalUrl, baseTarget).href;
      return handleProxyRequest(req, res, resolved);
    } catch (_) {}
  }
  next();
});

// ============================================================================
// LOCAL STATIC LIVE SERVER
// ============================================================================

app.get('/dt/suger-dev.js', (req, res) => {
  const p = path.join(__dirname, 'suger-dev.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/zoom-handler.js', (req, res) => {
  const p = path.join(__dirname, 'zoom-handler.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/inspector.js', (req, res) => {
  const p = path.join(__dirname, 'inspector.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/eruda.min.js', (req, res) => {
  const erudaPath = path.join(__dirname, 'eruda.min.js');
  if (fs.existsSync(erudaPath)) res.sendFile(erudaPath);
  else res.status(404).send('Eruda not found');
});

function injectHtml(html) {
  let injected = html;
  if (liveReloadEnabled) {
    injected = injected.replace(/<\\/body>/i, webSocketScript + '</body>');
    if (!/<\\/body>/i.test(html)) injected = injected + webSocketScript;
  }
  if (erudaEnabled) {
    const extra =
      consoleType === 'eruda' ? erudaRealScript + '\\n' + inspectorScript : sugerScript + '\\n' + inspectorScript;
    injected = injected.replace(/<\\/body>/i, extra + '</body>');
  }
  if (zoomEnabled) {
    injected = injected.replace(/<\\/body>/i, zoomScript + '</body>');
  }
  if (/<\\/body>/i.test(injected)) injected = injected.replace(/<\\/body>/i, lsBridgeScript + '</body>');
  else injected += lsBridgeScript;
  return injected;
}

function sendHtmlFile(res, fullPath) {
  fs.readFile(fullPath, 'utf8', (err, html_content) => {
    if (err) return res.status(404).send('Not found');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(injectHtml(html_content));
  });
}

app.get('/', (req, res) => {
  if (!BASE_DIR) return res.status(400).send('Not configured. PATCH /setup first.');
  const fileName = jsonData.fileName || 'index.html';
  const fullPath = path.join(BASE_DIR, fileName);
  if (fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    return sendHtmlFile(res, fullPath);
  }
  const indexPath = path.join(BASE_DIR, 'index.html');
  if (fs.existsSync(indexPath)) return sendHtmlFile(res, indexPath);
  if (directoryListing) return listDir(res, BASE_DIR, '/');
  return res.status(404).send('No index.html');
});

function listDir(res, dirPath, urlPath) {
  fs.readdir(dirPath, { withFileTypes: true }, (err, entries) => {
    if (err) return res.status(500).send('Cannot list directory');
    const rows = entries
      .filter((e) => !e.name.startsWith('.'))
      .map((e) => {
        const href = path.posix.join(urlPath, e.name) + (e.isDirectory() ? '/' : '');
        return \`<li><a href="\${href}">\${e.name}\${e.isDirectory() ? '/' : ''}</a></li>\`;
      })
      .join('\\n');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(
      \`<!DOCTYPE html><html><head><meta charset="\${charset}"/><title>Index of \${urlPath}</title></head><body><h1>Index of \${urlPath}</h1><ul>\${rows}</ul></body></html>\`
    );
  });
}

app.use((req, res, next) => {
  if (!BASE_DIR) return next();
  const rel = decodeURIComponent(req.path || '/');
  const full = path.join(BASE_DIR, rel);
  if (!full.startsWith(path.resolve(BASE_DIR))) return res.status(403).end();
  fs.stat(full, (err, st) => {
    if (err) return next();
    if (st.isDirectory()) {
      if (directoryListing) return listDir(res, full, rel.endsWith('/') ? rel : rel + '/');
      const idx = path.join(full, 'index.html');
      if (fs.existsSync(idx)) return sendHtmlFile(res, idx);
      return res.status(404).end();
    }
    if (/\\.html?$/i.test(full)) return sendHtmlFile(res, full);
    res.sendFile(full, (e) => {
      if (e) next();
    });
  });
});

app.use(express.static(__dirname));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  connectedSockets.push(ws);
  lastActivity = Date.now();
  ws.on('close', () => {
    connectedSockets = connectedSockets.filter((s) => s !== ws);
  });
});

function broadcastReload() {
  for (const ws of connectedSockets) {
    try {
      ws.send('reload');
    } catch (_) {}
  }
}

function startFileWatcher(res) {
  if (fileWatcher) {
    try { fileWatcher.close(); } catch (_) {}
    fileWatcher = null;
  }
  if (!BASE_DIR || !liveReloadEnabled) {
    if (res) res.status(201).json({ message: 'OK' });
    return;
  }
  fileWatcher = chokidar.watch(BASE_DIR, {
    ignored: /(^|[\\/\\\\])\\.\\./,
    persistent: true,
    ignoreInitial: true,
  });
  fileWatcher.on('change', () => {
    lastActivity = Date.now();
    broadcastReload();
  });
  let responseSent = false;
  const done = (code, body) => {
    if (responseSent || !res) return;
    responseSent = true;
    res.status(code).json(body);
  };
  fileWatcher.on('ready', () => done(201, { message: 'OK', liveReload: true }));
  fileWatcher.on('error', (error) => {
    console.error('Watcher Error:', error.message);
    done(500, { error: error.message });
  });
  setTimeout(() => done(201, { message: 'OK', liveReload: true }), 3000);
}

async function main() {
  const ok = await isPortAvailable(currentPort);
  if (!ok) {
    console.error('[acodels] port busy', currentPort);
    process.exit(1);
  }
  server.listen(currentPort, bindHost, () => {
    console.log('[acodels] listening', bindHost + ':' + currentPort);
  });
}

main();
`,Zn=Hr(Ms)});async function $r(e){let t=e||"/root/.acode_liveserver/acodels";try{let o=await ee("D="+ge(t)+'; if [ ! -f "$D/index.js" ]; then echo NEED; exit 0; fi; if grep -q WebSocket "$D/index.js" 2>/dev/null && grep -q chokidar "$D/index.js" 2>/dev/null && grep -q ls-proxy-v1 "$D/index.js" 2>/dev/null; then echo FULL; else echo NEED; fi',{timeoutMs:8e3});if(String(o).includes("FULL")&&!String(o).includes("NEED"))return!1}catch(o){console.warn("[LiveServer] index check",(o==null?void 0:o.message)||o)}let r=Zn,n=["#!/bin/sh","set -e","D="+t.replace(/'/g,""),'mkdir -p "$D"',"echo '"+r+`' | base64 -d > "$D/index.js"`,"echo RESTORED"].join(`
`);try{return await Lt(n,{timeoutMs:0}),!0}catch(o){return console.warn("[LiveServer] restore failed",(o==null?void 0:o.message)||o),!1}}var Qn=_(()=>{Ct();Jn()});function Hs(e){return/\.html?$/i.test(String(e||""))}function ve(e){return!!(e&&Hs(e.filename||e.name))}function G(){try{return(editorManager==null?void 0:editorManager.activeFile)||null}catch{return null}}function qr(e){try{return decodeURIComponent(e)}catch{return e}}function eo(e){let t=String(e||""),r=t.indexOf(":");if(r<0)return t.startsWith("/")?t:null;let n=t.slice(0,r),o=t.slice(r+1).replace(/^\/+/,""),i=o?"/"+o:"";return n==="primary"?"/sdcard"+i:n==="home"?"/sdcard/Documents"+i:/^[0-9A-F]{4}-[0-9A-F]{4}$/i.test(n)?"/storage/"+n+i:null}function tt(e){if(!e||typeof e!="string")return null;let t=e;if(t.startsWith("content://")){if(t.includes("::")){let n=qr(t.split("::").pop());if(n.startsWith("/"))return n;let o=eo(n);if(o)return o}let r=t.indexOf("/document/");if(r>=0){let n=qr(t.slice(r+10).split("?")[0]);if(n.startsWith("/"))return n;let o=eo(n);if(o)return o}return null}if(t.startsWith("file://")&&(t=qr(t.replace(/^file:\/\//,""))),t.includes("/data/data/com.termux/files/home"))return t.includes("::")?t.split("::").pop():t;if(t.includes("::")){let r=t.split("::").pop();if(r&&r.startsWith("/"))return r}if(/\/(storage|sdcard|emulated)\//i.test(t)){let r=t.match(/(\/(?:storage|sdcard|emulated)\/[^?#]*)/i);if(r)return r[1]}return t.startsWith("/")?t:null}function jr(e){if(!e)return null;let t=Math.max(e.lastIndexOf("/"),e.lastIndexOf("\\"));return t<=0?e:e.slice(0,t)}var be=_(()=>{});var Pe={};pe(Pe,{getServerStatus:()=>B,refreshStatusFromBackend:()=>Nr,setServerStatus:()=>Q});function B(){return{...Te}}function Q(e){Object.assign(Te,e||{});try{window.dispatchEvent(new CustomEvent("liveserver-status",{detail:B()}))}catch{}}async function Nr(){if(!Te.port)return Te;try{let e=await fetch(`http://127.0.0.1:${Te.port}/status`);if(!e.ok)return Q({running:!1,lastError:"status "+e.status}),B();let t=await e.json();Q({running:!0,port:t.port||Te.port,root:t.root||Te.root,fileName:t.fileName||Te.fileName})}catch{Q({running:!1})}return B()}var Te,te=_(()=>{Te={running:!1,port:null,root:null,url:null,fileName:null,bind:null,startedAt:null,lastError:null}});var Tt={};pe(Tt,{getEffectiveRoot:()=>or,pickRootFolder:()=>Ds,rootFromSelectedFolder:()=>Is});function or(){let e=C();if(e.rootFolder&&String(e.rootFolder).trim())return String(e.rootFolder).trim();let t=G(),r=tt((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");return r?jr(r):null}async function Ds(){try{let e=C().rootFolder||"",t=G(),r=jr(tt((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")||"")||"",n=[["active",r?"Use active file folder":"Use active file folder (open a file first)"],["type","Type absolute path\u2026"],["clear","Clear (auto from active HTML)"]];e&&n.unshift(["keep","Keep: "+e]);let o=await Os("Server root folder",n,{hideOnSelect:!0,default:e?"keep":r?"active":"type"});if(o==null)return null;if(o==="keep")return e;if(o==="clear")return $("rootFolder",""),rt("Root: auto (active file folder)",2e3),"";if(o==="active"){if(!r)return rt("Open a file first",2e3),null;$("rootFolder",r),rt("Root: "+r,2500);try{let{getServerStatus:c}=await Promise.resolve().then(()=>(te(),Pe)),{reapplySetup:u,startServer:a}=await Promise.resolve().then(()=>(W(),Z));c().running&&await u()}catch{}return r}let i=await Bs("Absolute folder path",e||r||"/data/data/com.termux/files/home","text");if(i==null)return null;let s=String(i).trim();if(!s)return rt("Empty path",1500),null;$("rootFolder",s),rt("Root folder saved",1500);try{let{getServerStatus:c}=await Promise.resolve().then(()=>(te(),Pe)),{reapplySetup:u}=await Promise.resolve().then(()=>(W(),Z));c().running&&await u()}catch{}return s}catch(e){return rt("Could not set root: "+((e==null?void 0:e.message)||e),2500),null}}function Is(){var e,t,r;try{let n=((e=window.fileBrowser)==null?void 0:e.selectedFolder)||((r=(t=window.addedFolder)==null?void 0:t[0])==null?void 0:r.url)||null;if(n)return tt(n)||n}catch{}return null}var rt,Os,Bs,nt=_(()=>{oe();be();rt=acode.require("toast"),Os=acode.require("select"),Bs=acode.require("prompt")});function ot(){let e=parseInt(C().port,10);return Number.isFinite(e)&&e>0?e:8080}function Pt(e,t){return`http://${t==="0.0.0.0"?"127.0.0.1":t||"127.0.0.1"}:${e}/`}var to=_(()=>{oe()});function ro(){if(document.getElementById("ls-status-pill-css"))return;let e=document.createElement("style");e.id="ls-status-pill-css",e.textContent=`
    #ls-status-pill {
      position: fixed;
      left: 8px;
      bottom: 8px;
      z-index: 100001;
      max-width: min(82vw, 440px);
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 5px 10px;
      border-radius: 4px;
      background: var(--secondary-color, rgba(28, 30, 34, 0.94));
      color: var(--primary-text-color, var(--color, #e8eaed));
      border: 1px solid var(--border-color, rgba(255, 255, 255, 0.12));
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.45), 0 1px 3px rgba(0, 0, 0, 0.3);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 11px;
      line-height: 1.3;
      pointer-events: none;
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #ls-status-pill.is-visible {
      opacity: 0.96;
      transform: translateY(0);
    }
    .ls-sp-dot {
      width: 7px;
      height: 7px;
      min-width: 7px;
      border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 6px rgba(34, 197, 94, 0.9);
    }
    .ls-sp-dot.is-spin {
      animation: ls-sp-pulse 0.9s ease-in-out infinite alternate;
    }
    @keyframes ls-sp-pulse {
      from { opacity: 0.4; transform: scale(0.85); }
      to { opacity: 1; transform: scale(1.15); }
    }
    .ls-sp-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Global top green progress bar (shown when installing in background) */
    #ls-global-green-loader {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      z-index: 100002;
      overflow: hidden;
      pointer-events: none;
      display: none;
      background: rgba(34, 197, 94, 0.15);
    }
    #ls-global-green-loader.is-active {
      display: block;
    }
    #ls-global-green-loader::before {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      width: 35%;
      background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
      box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
      animation: ls-green-slide 1.15s ease-in-out infinite;
    }
    @keyframes ls-green-slide {
      0% { left: -35%; }
      100% { left: 100%; }
    }
  `,document.head.appendChild(e)}function $s(){return ro(),(!re||!re.isConnected)&&(re=document.createElement("div"),re.id="ls-status-pill",it=document.createElement("span"),it.className="ls-sp-dot",st=document.createElement("span"),st.className="ls-sp-text",re.append(it,st),document.body.appendChild(re)),re}function ye(e){ro();let t=!!e;document.body.classList.toggle("ls-green-loading",t),document.querySelectorAll(".ls-browser-shell").forEach(r=>{r.classList.toggle("is-installing",t)}),(!ue||!ue.isConnected)&&(ue=document.createElement("div"),ue.id="ls-global-green-loader",document.body.appendChild(ue)),ue.classList.toggle("is-active",t)}function xe(e,t={}){clearTimeout(Rt);let r=$s();st&&(st.textContent=String(e||"")),it&&it.classList.toggle("is-spin",t.spin!==!1),requestAnimationFrame(()=>{r.classList.add("is-visible")}),t.autoHideMs&&t.autoHideMs>0&&(Rt=setTimeout(()=>{sr(0)},t.autoHideMs))}function sr(e=0){clearTimeout(Rt);let t=()=>{re&&re.classList.remove("is-visible")};e>0?Rt=setTimeout(t,e):t()}function no(){clearTimeout(Rt),ye(!1);try{re==null||re.remove(),ue==null||ue.remove()}catch{}re=null,st=null,it=null,ue=null}var re,st,it,ue,Rt,zr=_(()=>{re=null,st=null,it=null,ue=null,Rt=null});function A(e,t=18,r=2){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${r}" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var E,Mt=_(()=>{E={back:"M19 12H5M12 19l-7-7 7-7",forward:"M5 12h14M12 5l7 7-7 7",reload:"M21 2v6h-6M3 12a9 9 0 0115-6.7L21 8M3 22v-6h6M21 12a9 9 0 01-15 6.7L3 16",close:"M18 6L6 18M6 6l12 12",plus:"M12 5v14M5 12h14",home:"M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2zM9 22V12h6v10",star:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",lock:"M5 11h14a2 2 0 012 2v7a2 2 0 01-2 2H5a2 2 0 01-2-2v-7a2 2 0 012-2zM7 11V7a5 5 0 0110 0v4",info:"M12 2a10 10 0 100 20 10 10 0 000-20zM12 16v-4M12 8h.01",device:"M7 2h10a2 2 0 012 2v16a2 2 0 01-2 2H7a2 2 0 01-2-2V4a2 2 0 012-2zM12 18h.01",rotate:"M21 12a9 9 0 11-9-9c2.5 0 4.7 1 6.3 2.7L21 8M21 3v5h-5",dots:"M12 5h.01M12 12h.01M12 19h.01",maximize:"M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3",drop:"M12 2.69l5.66 5.66a8 8 0 11-11.31 0z",down:"M6 9l6 6 6-6",up:"M18 15l-6-6-6 6",search:"M11 3a8 8 0 100 16 8 8 0 000-16zM21 21l-4.35-4.35",globe:"M12 2a10 10 0 100 20 10 10 0 000-20zM2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20",minus:"M5 12h14"}});function qs(e){let t=String(e||"").trim().match(/^#([0-9a-f]{3,8})$/i),r,n,o;if(t){let i=t[1];i.length===3&&(i=i.split("").map(s=>s+s).join("")),r=parseInt(i.slice(0,2),16),n=parseInt(i.slice(2,4),16),o=parseInt(i.slice(4,6),16)}else{if(t=String(e||"").match(/rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i),!t)return null;r=+t[1],n=+t[2],o=+t[3]}return(.299*r+.587*n+.114*o)/255}function oo(){try{let e=getComputedStyle(document.documentElement),t=e.getPropertyValue("--primary-color")||e.getPropertyValue("--secondary-color"),r=qs(t);if(r!=null)return r>.6?"light":"dark"}catch{}return"dark"}var so=_(()=>{});function io(){let e=document.getElementById("ls-browser-styles");e&&e.remove();let t=document.createElement("style");t.id="ls-browser-styles",t.textContent=Fr,document.head.appendChild(t)}var Fr,ao=_(()=>{Fr=`
:host { display: block; position: relative; height: 100%; width: 100%; }
.ls-browser-shell {
  --ls-frame: #202124; --ls-toolbar: #35363a; --ls-omni: #202124; --ls-text: #e8eaed; --ls-sub: #9aa0a6;
  --ls-hover: rgba(255,255,255,.10); --ls-press: rgba(255,255,255,.16); --ls-line: #3c4043; --ls-accent: #8ab4f8;
  --ls-menu: #292a2d; --ls-stage: #1b1c1e; --ls-active-tab-text: #e8eaed;
  position: absolute; inset: 0; z-index: 1;
  display: flex; flex-direction: column; box-sizing: border-box;
  background: var(--ls-frame); color: var(--ls-text);
  font: 13px/1.3 Roboto, "Noto Sans", "Segoe UI", system-ui, sans-serif;
}
.ls-browser-shell[data-theme="light"] {
  --ls-frame: #dee1e6; --ls-toolbar: #ffffff; --ls-omni: #f1f3f4; --ls-text: #202124; --ls-sub: #5f6368;
  --ls-hover: rgba(0,0,0,.08); --ls-press: rgba(0,0,0,.14); --ls-line: #dadce0; --ls-accent: #1a73e8;
  --ls-menu: #ffffff; --ls-stage: #e8eaed; --ls-active-tab-text: #202124;
}
.ls-browser-shell *, .ls-browser-shell *::before, .ls-browser-shell *::after { box-sizing: border-box; }
.ls-browser-shell button { font: inherit; color: inherit; }
.ls-browser-shell.is-fullscreen { position: fixed; inset: 0; z-index: 99990; }

/* ---- chrome (tab strip + toolbar) */
.ls-chrome { flex-shrink: 0; display: flex; flex-direction: column; background: var(--ls-frame); }
.ls-tabstrip { display: flex; align-items: flex-end; height: 38px; padding: 6px 6px 0 6px; gap: 2px; }
.ls-browser-tabs { display: flex; flex: 0 1 auto; min-width: 0; overflow: hidden; align-items: flex-end; }
.ls-tab {
  position: relative; display: flex; align-items: center; gap: 6px; flex: 0 1 200px; min-width: 36px; max-width: 220px;
  height: 32px; padding: 0 6px 0 10px; border-radius: 3px 3px 0 0; color: var(--ls-sub); cursor: default; user-select: none;
}
.ls-tab:hover { background: var(--ls-hover); }
.ls-tab.is-active { background: var(--ls-toolbar); color: var(--ls-active-tab-text); }
.ls-tab:not(.is-active)::after { content: ""; position: absolute; right: -1px; top: 8px; height: 16px; width: 1px; background: var(--ls-line); }
.ls-tab:hover::after, .ls-tab.is-active::after, .ls-tab:has(+ .ls-tab.is-active)::after { display: none; }
.ls-fav { width: 16px; height: 16px; flex: none; display: inline-flex; align-items: center; justify-content: center; }
.ls-fav img { width: 16px; height: 16px; }
.ls-fav.is-spin { border: 2px solid var(--ls-line); border-top-color: var(--ls-accent); border-radius: 50%; animation: ls-spin .8s linear infinite; }
.ls-tab-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ls-tab-x { width: 18px; height: 18px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; }
.ls-tab-x:hover { background: var(--ls-press); }
.ls-tabstrip .ls-spacer { flex: 1; }
.ls-win { display: flex; align-items: center; align-self: center; gap: 2px; }
.ls-ib {
  width: 32px; height: 32px; flex: none; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub);
  display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
}
.ls-ib:hover { background: var(--ls-hover); }
.ls-ib:active { background: var(--ls-press); }
.ls-ib:disabled { opacity: .4; pointer-events: none; }
.ls-ib.is-on { color: var(--ls-accent); }
.ls-ib.is-on svg { fill: var(--ls-accent); }
.ls-ib.ls-tab-new { width: 28px; height: 28px; margin-left: 2px; align-self: center; }
.ls-ib.ls-win-btn { width: 26px; height: 26px; }

.ls-toolbar { position: relative; display: flex; align-items: center; gap: 2px; height: 40px; padding: 0 6px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); }
.ls-omni { flex: 1; min-width: 0; height: 30px; margin: 0 6px; display: flex; align-items: center; gap: 2px; padding: 0 2px 0 4px; border-radius: 3px; background: var(--ls-omni); }
.ls-omni:focus-within { box-shadow: inset 0 0 0 2px var(--ls-accent); }
.ls-site { width: 24px; height: 24px; flex: none; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; padding: 0; }
.ls-site:hover { background: var(--ls-hover); }
.ls-browser-url { flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent; color: var(--ls-text); font: inherit; font-size: 14px; padding: 0 4px; }
.ls-browser-url::placeholder { color: var(--ls-sub); }
.ls-omni .ls-ib { width: 26px; height: 26px; }
.ls-browser-shell.no-url .ls-omni { visibility: hidden; }
.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }
@keyframes ls-bar { 0% { left: -30%; } 100% { left: 100%; } }
@keyframes ls-spin { to { transform: rotate(360deg); } }

/* ---- external site fallback banner */
.ls-ext-bar {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 5px 10px; background: var(--ls-menu); border-bottom: 1px solid var(--ls-line);
  font-size: 12px; color: var(--ls-sub);
}
.ls-ext-bar[hidden] { display: none; }
.ls-ext-open {
  border: 0; border-radius: 3px; padding: 4px 10px; background: #22c55e;
  color: #052e16; font-weight: 600; font-size: 11.5px; cursor: pointer; white-space: nowrap;
}

/* ---- device toolbar */
.ls-devbar { display: flex; align-items: center; gap: 6px; min-height: 34px; padding: 3px 8px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); overflow-x: auto; scrollbar-width: none; }
.ls-devbar[hidden] { display: none; }
.ls-devbar::-webkit-scrollbar { height: 0; }
.ls-dev-btn { display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 8px; border: 1px solid var(--ls-line); border-radius: 3px; background: transparent; white-space: nowrap; cursor: pointer; }
.ls-dev-btn:hover { background: var(--ls-hover); }
.ls-dev-num { width: 58px; height: 26px; padding: 0 6px; border: 1px solid var(--ls-line); border-radius: 3px; background: var(--ls-omni); color: var(--ls-text); font: inherit; text-align: center; outline: 0; -moz-appearance: textfield; }
.ls-dev-num:focus { border-color: var(--ls-accent); }
.ls-dev-num::-webkit-outer-spin-button, .ls-dev-num::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ls-dev-x { color: var(--ls-sub); }
.ls-dev-spacer { flex: 1; }
.ls-dev-icon { width: 26px; height: 26px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; }
.ls-dev-icon:hover { background: var(--ls-hover); }

/* ---- stage (page area) */
.ls-stage { position: relative; flex: 1; min-height: 0; overflow: hidden; background: #fff; }
.ls-browser-shell.is-device .ls-stage { overflow: auto; display: flex; padding: 12px; background: var(--ls-stage); }
.ls-box { position: relative; width: 100%; height: 100%; }
.ls-browser-shell.is-device .ls-box { flex: none; margin: auto; background: #fff; box-shadow: 0 0 0 1px var(--ls-line), 0 2px 12px rgba(0,0,0,.35); }
.ls-device { position: relative; width: 100%; height: 100%; transform-origin: 0 0; }
.ls-browser-frame { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; background: #fff; }
.ls-hdl { display: none; position: absolute; z-index: 3; background: transparent; touch-action: none; }
.ls-browser-shell.is-device .ls-hdl { display: block; }
.ls-hdl-r { top: 0; bottom: 0; right: -12px; width: 12px; cursor: ew-resize; }
.ls-hdl-b { left: 0; right: 0; bottom: -12px; height: 12px; cursor: ns-resize; }
.ls-hdl-c { right: -12px; bottom: -12px; width: 12px; height: 12px; cursor: nwse-resize; }
.ls-hdl::after { content: ""; position: absolute; background: var(--ls-sub); border-radius: 3px; opacity: .8; }
.ls-hdl-r::after { top: calc(50% - 14px); left: 4px; width: 4px; height: 28px; }
.ls-hdl-b::after { left: calc(50% - 14px); top: 4px; height: 4px; width: 28px; }
.ls-hdl-c::after { left: 4px; top: 4px; width: 4px; height: 4px; border-radius: 50%; }

/* ---- new tab page (Mozilla Firefox style: large Green Fox top-center + search bar + round bookmarks + recent) */
.ls-ntp {
  position: absolute; inset: 0; z-index: 2; display: none; flex-direction: column;
  align-items: center; justify-content: flex-start; gap: 20px; padding: 26px 16px 28px;
  overflow-y: auto; background: var(--ls-toolbar); color: var(--ls-text);
}
.ls-ntp.is-on { display: flex; }
.ls-ntp-hero {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 10px; margin-top: 6px;
}
.ls-ntp-logo {
  width: 92px; height: 92px; object-fit: contain; display: block;
  filter: drop-shadow(0 6px 16px rgba(34, 197, 94, 0.25));
}
.ls-ntp-title {
  font-size: 22px; font-weight: 600; letter-spacing: .3px;
}
.ls-ntp-search {
  width: min(480px, 95%); height: 44px; border-radius: 8px;
  background: var(--ls-omni); border: 1px solid var(--ls-line);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
  display: flex; align-items: center; gap: 8px; padding: 0 6px 0 12px; color: var(--ls-sub);
}
.ls-ntp-search:focus-within {
  border-color: #22c55e;
  box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.28);
}
.ls-ntp-search-ico {
  display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ls-ntp-search input {
  flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent;
  color: var(--ls-text); font: inherit; font-size: 14px;
}
.ls-ntp-search-btn {
  height: 32px; padding: 0 14px; border: 0; border-radius: 6px;
  background: #22c55e; color: #052e16; font-weight: 600; font-size: 12.5px;
  cursor: pointer; flex-shrink: 0;
}
.ls-ntp-search-btn:active { opacity: 0.85; }
.ls-ntp-tiles {
  display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;
  width: min(480px, 100%);
}
.ls-ntp-tile {
  width: 78px; display: flex; flex-direction: column; align-items: center; gap: 6px;
  padding: 8px 4px; border: 0; border-radius: 6px; background: transparent; cursor: pointer;
}
.ls-ntp-tile:hover { background: var(--ls-hover); }
.ls-ntp-dot {
  width: 48px; height: 48px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); color: var(--ls-text);
  display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600;
  overflow: hidden; flex-shrink: 0;
}
.ls-ntp-dot img { width: 24px; height: 24px; border-radius: 50%; object-fit: contain; }
.ls-ntp-name {
  max-width: 74px; font-size: 11.5px; overflow: hidden; text-overflow: ellipsis;
  white-space: nowrap; color: var(--ls-text);
}
.ls-ntp-recent-wrap {
  width: min(480px, 100%); display: flex; flex-direction: column; gap: 6px;
  border-top: 1px solid var(--ls-line); padding-top: 12px;
}
.ls-ntp-sec-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 4px 4px; font-size: 12px; font-weight: 600; color: var(--ls-sub);
}
.ls-ntp-more {
  border: 0; background: transparent; color: #22c55e; font-size: 12px;
  font-weight: 600; cursor: pointer; padding: 2px 6px; border-radius: 3px;
}
.ls-ntp-more:hover { background: var(--ls-hover); }
.ls-ntp-recent-list { display: flex; flex-direction: column; gap: 2px; }
.ls-ntp-recent-row {
  display: flex; align-items: center; gap: 10px; width: 100%; text-align: left;
  padding: 8px 8px; border: 0; border-radius: 4px; background: transparent; cursor: pointer;
}
.ls-ntp-recent-row:hover { background: var(--ls-hover); }
.ls-ntp-recent-ico {
  width: 28px; height: 28px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); display: inline-flex; align-items: center;
  justify-content: center; font-size: 12px; font-weight: 600; flex-shrink: 0;
}
.ls-ntp-recent-meta { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.ls-ntp-recent-title {
  font-size: 13px; color: var(--ls-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-recent-url {
  font-size: 11px; color: var(--ls-sub); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-empty { font-size: 12px; color: var(--ls-sub); padding: 8px 4px; }

/* ---- find bar */
.ls-find { position: absolute; top: 80px; right: 10px; z-index: 40; display: flex; align-items: center; gap: 2px; padding: 4px 6px; background: var(--ls-menu); border: 1px solid var(--ls-line); border-radius: 3px; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
.ls-find[hidden] { display: none; }
.ls-find input { width: 150px; height: 26px; border: 0; border-bottom: 2px solid var(--ls-accent); background: transparent; color: var(--ls-text); outline: 0; font: inherit; padding: 0 4px; }
.ls-find .ls-ib { width: 26px; height: 26px; }

/* ---- overlay preview (page see-through, editor underneath stays usable) */
.ls-browser-shell.is-overlay { pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-tabstrip { display: none; }
.ls-ov-close { display: none !important; }
.ls-browser-shell.is-overlay .ls-ov-close { display: inline-flex !important; }
.ls-browser-shell.is-overlay .ls-chrome { pointer-events: auto; }
.ls-browser-shell.is-overlay .ls-stage { opacity: var(--ls-op, 1); pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-stage * { pointer-events: none; }
.ls-browser-shell.is-overlay .ls-dd-layer, .ls-browser-shell.is-overlay .ls-find { pointer-events: auto; }

/* ---- dropdown menu (desktop style) */
.ls-dd-layer { position: absolute; inset: 0; z-index: 60; }
.ls-dd-backdrop { position: absolute; inset: 0; background: transparent; }
.ls-dd-menu {
  position: absolute; min-width: 220px; max-width: calc(100% - 8px); padding: 6px 0;
  background: var(--ls-menu, #292a2d); color: var(--ls-text, #e8eaed);
  border: 1px solid var(--ls-line, #3c4043); border-radius: 3px;
  box-shadow: 0 4px 16px rgba(0,0,0,.4); font-size: 13px; overflow: auto;
}
.ls-dd-item { display: flex; align-items: center; gap: 8px; min-height: 32px; padding: 6px 14px 6px 8px; cursor: pointer; white-space: nowrap; user-select: none; }
.ls-dd-item:hover, .ls-dd-item.is-active { background: var(--ls-hover, rgba(128,128,128,.22)); }
.ls-dd-item.is-disabled { opacity: .45; pointer-events: none; }
.ls-dd-check { width: 14px; height: 14px; display: inline-flex; flex-shrink: 0; }
.ls-dd-label { flex: 1; }
.ls-dd-arrow { opacity: .7; display: inline-flex; }
.ls-dd-sep { height: 1px; margin: 6px 0; background: var(--ls-line, rgba(128,128,128,.3)); }
.ls-dd-custom { padding: 2px 8px 2px 22px; }
.ls-zoomrow { display: flex; align-items: center; gap: 4px; min-height: 32px; }
.ls-zoomrow .ls-zl { flex: 1; }
.ls-zoomrow .ls-zv { min-width: 44px; text-align: center; }
.ls-zoomrow .ls-ib { width: 26px; height: 26px; color: var(--ls-text); }

/* ---- opacity panel */
.ls-dd-panel { width: 250px; padding: 12px 14px; }
.ls-op-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.ls-op-val { color: var(--ls-accent); font-variant-numeric: tabular-nums; }
.ls-range { -webkit-appearance: none; appearance: none; width: 100%; height: 18px; margin: 0; background: transparent; outline: 0; }
.ls-range::-webkit-slider-runnable-track { height: 4px; border-radius: 3px; background: linear-gradient(to right, var(--ls-accent) var(--ls-fill, 100%), var(--ls-line) var(--ls-fill, 100%)); }
.ls-range::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; margin-top: -6px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-range::-moz-range-track { height: 4px; border-radius: 3px; background: var(--ls-line); }
.ls-range::-moz-range-progress { height: 4px; border-radius: 3px; background: var(--ls-accent); }
.ls-range::-moz-range-thumb { width: 16px; height: 16px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-op-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 12px; cursor: pointer; }
.ls-op-row.is-disabled { opacity: .45; pointer-events: none; }
.ls-op-hint { margin-top: 8px; font-size: 11px; color: var(--ls-sub); }
.ls-switch { position: relative; flex: none; width: 36px; height: 20px; }
.ls-switch::before { content: ""; position: absolute; inset: 0; border-radius: 3px; background: var(--ls-line); transition: background .15s; }
.ls-switch::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 3px; background: var(--ls-text); transition: transform .15s; }
.ls-switch.is-on::before { background: var(--ls-accent); }
.ls-switch.is-on::after { transform: translateX(16px); background: #fff; }

 #ls-deps-picker{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center}
.ls-dp-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.45)}
.ls-dp-card{position:relative;width:min(420px,92vw);max-height:min(72vh,540px);display:flex;flex-direction:column;border-radius:3px;background:var(--secondary-color,#1e1e1e);color:var(--color,#e0e0e0);overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4)}
.ls-dp-header{padding:12px 14px 8px;border-bottom:1px solid rgba(128,128,128,.25)}
.ls-dp-title{font-weight:600}
.ls-dp-subtitle{font-size:.75rem;opacity:.75;margin-top:4px}
.ls-dp-body{flex:1;overflow:auto;padding:8px 12px}
.ls-dp-row{display:flex;align-items:center;gap:10px;padding:8px 6px;border-radius:3px;margin-bottom:4px;background:rgba(128,128,128,.08)}
.ls-dp-status.ok{color:#66bb6a}.ls-dp-status.miss{color:#f48771}
.ls-dp-footer{display:flex;gap:8px;justify-content:flex-end;padding:10px 12px;border-top:1px solid rgba(128,128,128,.25)}
.ls-dp-btn{border:none;border-radius:3px;padding:8px 12px;background:rgba(128,128,128,.2);color:inherit}
.ls-dp-btn.ls-dp-install{background:var(--active-color,#61afef);color:#111;font-weight:600}
.ls-dp-progress-track{height:3px;border-radius:3px;background:rgba(128,128,128,.25);overflow:hidden}
.ls-dp-progress-bar{height:100%;background:var(--active-color,#61afef);transition:width .25s}
.ls-dp-spinner{width:16px;height:16px;border-radius:50%;border:2px solid rgba(128,128,128,.35);border-top-color:var(--active-color,#61afef);animation:ls-spin .7s linear infinite}
@keyframes ls-spin{to{transform:rotate(360deg)}}



.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }

.ls-green-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 3px; overflow: hidden; display: none; background: rgba(34, 197, 94, 0.16); }
.ls-browser-shell.is-installing .ls-green-progress { display: block; }
.ls-green-progress::before {
  content: ""; position: absolute; top: 0; bottom: 0; width: 35%;
  background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
  box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
  animation: ls-bar 1.1s ease-in-out infinite;
}
`});function co(e){lo=e?String(e).endsWith("/")?String(e):e+"/":""}function po(){return lo}var lo,Ur=_(()=>{lo=""});async function uo(){if(ir)return ir;let e=po()+js;try{let r=await acode.require("fsOperation")(e).readFile("utf8");if(r&&r.length>1e3)return ir=String(r)}catch(t){console.warn("[LiveServer] devtool via fsOperation",t)}try{let t=await fetch(e);if(t.ok){let r=await t.text();if(r.length>1e3)return ir=r}}catch(t){console.warn("[LiveServer] devtool via fetch",t)}return null}var js,ir,fo=_(()=>{Ur();js="devtool/suger-dev.js",ir=null});var go={};pe(go,{activateTab:()=>ft,addTab:()=>ut,applyZoom:()=>Zr,canGoBack:()=>Gr,canGoForward:()=>Xr,clearVisited:()=>Vr,closeAllTabs:()=>rn,closeTab:()=>Ht,disposeBridge:()=>en,duplicateActive:()=>tn,findInActive:()=>on,getActiveTab:()=>H,getTabs:()=>at,getVisited:()=>cr,historyActive:()=>pr,initBridge:()=>Qr,isLocalUrl:()=>lt,navigateActive:()=>Re,normalizeUrl:()=>dt,onTabsChange:()=>Kr,printActive:()=>sn,reloadActive:()=>dr,renderTabStrip:()=>cn,sendToTab:()=>we,setZoomActive:()=>ln,stopActive:()=>nn,toDisplayUrl:()=>ct,toggleDevtoolsActive:()=>an});function at(){return X.slice()}function H(){return X.find(e=>e.id===je)||null}function cr(){return qe.slice()}function Vr(){qe=[],K()}function Gr(){let e=H();return!!(e&&e.historyIndex>0)}function Xr(){let e=H();return!!(e&&e.historyIndex<e.history.length-1)}function Kr(e){return ar.push(e),()=>{ar=ar.filter(t=>t!==e)}}function K(){ar.forEach(e=>{try{e(at(),H())}catch{}})}function Yr(e,t){let r=ct(e);!r||r==="about:blank"||r.startsWith("blob:")||(qe=qe.filter(n=>n.url!==r),qe.unshift({url:r,title:t||r.replace(/^https?:\/\//i,""),ts:Date.now()}),qe.length>50&&(qe.length=50))}function lt(e){let t=ct(e);return/^https?:\/\/(127\.0\.0\.1|localhost|0\.0\.0\.0|192\.168\.|10\.)/i.test(String(t||""))}function ct(e){let t=String(e||"").trim();if(!t)return"about:blank";let r="/__proxy?url=",n=t.indexOf(r);if(n!==-1)try{let o=t.slice(n+r.length).split("&")[0];return decodeURIComponent(o)}catch{}return t}function dt(e){let t=ct(e);if(!t||t==="about:blank")return"about:blank";if(/^(about:|blob:|data:|https?:\/\/)/i.test(t))return t;if(/^(localhost|127\.0\.0\.1|0\.0\.0\.0|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(t))return"http://"+t;if(!/\s/.test(t)&&/^[a-z0-9-]+(\.[a-z0-9-]+)+([/?#].*)?$/i.test(t))return"https://"+t;let r=C().browserSearchEngine||"google",n=encodeURIComponent(t);return r==="duckduckgo"?`https://duckduckgo.com/?q=${n}`:r==="bing"?`https://www.bing.com/search?q=${n}`:r==="brave"?`https://search.brave.com/search?q=${n}`:`https://www.google.com/search?q=${n}`}async function zs(e){if(!e||e==="about:blank"||e.startsWith("blob:"))return e||"about:blank";if(lt(e))return e;if((C().externalSiteMode||"proxy")==="proxy"){let r=B(),n=r.running&&r.port?r.port:await pn();if(n)return`http://127.0.0.1:${n}/__proxy?url=${encodeURIComponent(e)}`}return e}function we(e,t,r){try{return e.iframe.contentWindow.postMessage({ls:1,cmd:t,...r||{}},"*"),!0}catch{return!1}}function pt(e){var t;try{let r=(t=e.iframe)==null?void 0:t.contentWindow;return r.document,r}catch{return null}}function Zr(e){let t=pt(e);if(t)try{t.document.documentElement.style.zoom=String((e.zoom||100)/100);return}catch{}we(e,"zoom",{pct:e.zoom||100})}function Fs(e){return X.find(t=>{try{return t.iframe.contentWindow===e}catch{return!1}})}function Jr(e,t){!e||!t||e.history[e.historyIndex]===t||(e.history=e.history.slice(0,e.historyIndex+1),e.history.push(t),e.historyIndex=e.history.length-1)}function mo(e){let t=e.data;if(!t||t.ls!==1)return;let r=Fs(e.source);if(r)if(r.bridge=!0,t.type==="meta"){if(r.loading=!1,t.href&&t.href!=="about:blank"){let n=ct(t.href);n!==r.url&&(r.url=n,Jr(r,n))}r.pinTitle||(r.title=String(t.title||r.url.replace(/^https?:\/\//,"")).slice(0,60)),t.favicon&&(r.favicon=t.favicon),(r.zoom||100)!==100&&we(r,"zoom",{pct:r.zoom}),Yr(r.url,r.title),K()}else t.type==="devtools"?(r.devtools=!!t.on,K()):t.type==="need-devtools"?uo().then(n=>{if(!n)return ho("Suger DevTool file missing (devtool/suger-dev.js). Reinstall the plugin.",3500);we(r,"devtools",{on:!0,code:n})}):t.type==="devtools-error"&&ho("DevTool: "+t.message,3e3)}function Qr(){window.addEventListener("message",mo)}function en(){window.removeEventListener("message",mo)}function Wr(e,t){lt(t)||t==="about:blank"||t.startsWith("blob:")?e.setAttribute("sandbox","allow-scripts allow-same-origin allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-downloads"):e.removeAttribute("sandbox")}async function lr(e,t,r={}){let n=dt(t);if(r.pushHistory!==!1&&Jr(e,n),e.url=n,e.devtools=!1,n==="about:blank"){e.loading=!1,e.title="New tab",e.favicon=null,Wr(e.iframe,"about:blank"),e.iframe.src="about:blank",K();return}e.loading=!0,e.pinTitle||(e.title=n.replace(/^https?:\/\//i,"")),K();let o=await zs(n);Wr(e.iframe,o),e.iframe.src=o,Yr(n,e.title),K()}function ut(e,t,r){let n=Ns++,o=document.createElement("iframe");o.className="ls-browser-frame",o.setAttribute("allow","fullscreen; clipboard-read; clipboard-write");let i=t?dt(t):"about:blank",s={id:n,url:i,title:r||(i==="about:blank"?"New tab":i.replace(/^https?:\/\//i,"")),iframe:o,loading:i!=="about:blank",favicon:null,zoom:100,pinTitle:!!r,history:[i],historyIndex:0};return e.appendChild(o),X.push(s),X.forEach(c=>{c.iframe&&(c.iframe.style.display=c.id===n?"block":"none")}),je=n,o.addEventListener("load",()=>{s.loading=!1,s.devtools=!1;let c=pt(s);if(c)try{let a=c.__LS_PROXY_TARGET__||ct(c.location.href);a&&a!=="about:blank"&&a!==s.url&&(s.url=a,Jr(s,a)),s.pinTitle||(c.document.title?s.title=c.document.title.slice(0,60):s.url!=="about:blank"&&(s.title=s.url.replace(/^https?:\/\//,"")));let p=c.document.querySelector('link[rel~="icon"]');p!=null&&p.href&&(s.favicon=p.href)}catch{}else!s.pinTitle&&s.url!=="about:blank"&&(s.title=s.url.replace(/^https?:\/\//,""));if(!s.favicon&&/^https?:/i.test(s.url))try{s.favicon=new URL("/favicon.ico",s.url).href}catch{}Zr(s),Yr(s.url,s.title),K()}),i==="about:blank"?(Wr(o,"about:blank"),o.src="about:blank",K()):lr(s,i,{pushHistory:!1}),s}function tn(e){let t=H();return t?ut(e,t.url,t.title):null}function ft(e){X.some(t=>t.id===e)&&(je=e,X.forEach(t=>{t.iframe&&(t.iframe.style.display=t.id===e?"block":"none")}),K())}function Ht(e){var n;let t=X.findIndex(o=>o.id===e);if(t<0)return X.length;let[r]=X.splice(t,1);try{(n=r.iframe)==null||n.remove()}catch{}if(je===e)if(X.length){let o=X[Math.min(t,X.length-1)];ft(o.id)}else je=null,K();else K();return X.length}function rn(){X.forEach(e=>{var t;try{(t=e.iframe)==null||t.remove()}catch{}}),X=[],je=null,K()}function Re(e){let t=H();t!=null&&t.iframe&&lr(t,e,{pushHistory:!0})}function dr(){let e=H();if(!(e!=null&&e.iframe))return;if(e.url==="about:blank"){K();return}e.loading=!0;let t=pt(e),r=!1;if(t)try{t.location.reload(),r=!0}catch{}!r&&!(e.bridge&&we(e,"reload"))&&(e.iframe.src=e.iframe.src),K()}function nn(){let e=H();if(!(e!=null&&e.iframe))return;let t=pt(e);if(t)try{t.stop()}catch{}else we(e,"stop");e.loading=!1,K()}function pr(e){let t=H();if(t){if(e<0&&t.historyIndex>0){t.historyIndex-=1;let r=t.history[t.historyIndex];lr(t,r,{pushHistory:!1});return}if(e>0&&t.historyIndex<t.history.length-1){t.historyIndex+=1;let r=t.history[t.historyIndex];lr(t,r,{pushHistory:!1});return}}}function on(e,t){var o;let r=H();if(!r||!e)return;let n=pt(r);if(n)try{(o=n.find)==null||o.call(n,e,!1,!!t,!0,!1,!1,!1);return}catch{}we(r,"find",{q:e,back:!!t})}function sn(){let e=H();if(!e)return!1;let t=pt(e);if(t)try{return t.print(),!0}catch{}return we(e,"print")}function an(){let e=H();return!e||!e.bridge?!1:we(e,"devtools",{on:!e.devtools})}function ln(e){let t=H();return t?(t.zoom=Math.min(500,Math.max(25,Math.round(e))),Zr(t),K(),t.zoom):100}function cn(e){e&&(e.innerHTML="",X.forEach(t=>{let r=document.createElement("div");r.className="ls-tab"+(t.id===je?" is-active":"")+(t.loading?" is-loading":""),r.setAttribute("role","tab"),r.title=t.title||"";let n=document.createElement("span");if(n.className="ls-fav",t.loading)n.classList.add("is-spin");else if(t.favicon){let s=document.createElement("img");s.src=t.favicon,s.alt="",s.addEventListener("error",()=>{n.innerHTML=A(E.globe,14)}),n.appendChild(s)}else n.innerHTML=A(E.globe,14);r.appendChild(n);let o=document.createElement("span");o.className="ls-tab-label",o.textContent=t.title||"Tab",r.appendChild(o);let i=document.createElement("span");i.className="ls-tab-x",i.setAttribute("role","button"),i.title="Close tab",i.innerHTML=A(E.close,12),i.addEventListener("click",s=>{s.stopPropagation(),Ht(t.id)}),r.appendChild(i),r.addEventListener("click",()=>ft(t.id)),e.appendChild(r)}))}var ho,X,je,Ns,ar,qe,dn=_(()=>{Mt();fo();oe();W();te();ho=acode.require("toast"),X=[],je=null,Ns=1,ar=[],qe=[]});function Ot(e,t=20){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var un=_(()=>{});function se(e,t){let r=document.createElement(e);return t&&(r.className=t),r}function Bt(){le&&le.close()}function vo(){return!!le}function Dt({host:e,anchor:t,items:r,onClose:n}){if(Bt(),!e||!(r!=null&&r.length))return{close(){}};let o=se("div","ls-dd-layer"),i=se("div","ls-dd-backdrop");o.appendChild(i),e.appendChild(o);let s=[],c=!1;function u(f){for(;s.length>f;)s.pop().remove()}function a(){if(!c){c=!0,document.removeEventListener("keydown",p,!0);try{o.remove()}catch{}le&&le.close===a&&(le=null);try{n==null||n()}catch{}}}function p(f){f.key==="Escape"&&(f.stopPropagation(),a())}function h(f,L,D){let y=e.getBoundingClientRect(),S=f.offsetWidth,T=f.offsetHeight,P,b;L===0?(b=D.bottom-y.top+2,P=D.right-y.left-S,P<4&&(P=D.left-y.left)):(b=D.top-y.top-4,P=D.right-y.left-2,P+S>y.width-4&&(P=D.left-y.left-S+2)),P+S>y.width-4&&(P=y.width-S-4),P<4&&(P=4);let g=y.height-b-4;T>g&&y.height&&(L>0&&y.height-T-4>0?b=y.height-T-4:f.style.maxHeight=Math.max(g,80)+"px"),b<4&&(b=4),f.style.left=P+"px",f.style.top=b+"px"}function m(f,L,D){u(L);let y=se("div","ls-dd-menu");return y.setAttribute("role","menu"),y.style.visibility="hidden",f.forEach(S=>{if(S.separator){y.appendChild(se("div","ls-dd-sep"));return}if(S.render){let R=se("div","ls-dd-custom");S.render(R,a),y.appendChild(R);return}let T=se("div","ls-dd-item"+(S.disabled?" is-disabled":""));T.setAttribute("role","menuitem");let P=se("span","ls-dd-check");S.checked&&(P.innerHTML=Ot(Us,14)),T.appendChild(P);let b=se("span","ls-dd-label");if(b.textContent=S.label,T.appendChild(b),S.children){let R=se("span","ls-dd-arrow");R.innerHTML=Ot(Ws,14),T.appendChild(R)}let g=()=>{y.querySelectorAll(".ls-dd-item.is-active").forEach(R=>R.classList.remove("is-active")),T.classList.add("is-active"),m(S.children,L+1,T.getBoundingClientRect())},k=()=>{u(L+1),T.classList.remove("is-active")};T.addEventListener("pointerenter",R=>{R.pointerType&&R.pointerType!=="mouse"||(S.children?g():(u(L+1),y.querySelectorAll(".ls-dd-item.is-active").forEach(v=>v.classList.remove("is-active"))))}),T.addEventListener("click",R=>{var v;if(R.stopPropagation(),!S.disabled){if(S.children){T.classList.contains("is-active")&&s.length>L+1?k():g();return}a();try{(v=S.onClick)==null||v.call(S)}catch(j){console.warn("[LiveServer] menu item",j)}}}),y.appendChild(T)}),o.appendChild(y),s.push(y),h(y,L,D),y.style.visibility="",y}i.addEventListener("click",f=>{f.stopPropagation(),a()}),i.addEventListener("contextmenu",f=>{f.preventDefault(),a()}),document.addEventListener("keydown",p,!0);let l=t?t.getBoundingClientRect():e.getBoundingClientRect();return m(r,0,l),le={close:a},{close:a}}function bo({host:e,anchor:t,render:r,onClose:n}){if(Bt(),!e)return{close(){}};let o=se("div","ls-dd-layer"),i=se("div","ls-dd-backdrop"),s=se("div","ls-dd-menu ls-dd-panel");o.append(i,s),e.appendChild(o);let c=!1;function u(){if(!c){c=!0,document.removeEventListener("keydown",a,!0);try{o.remove()}catch{}le&&le.close===u&&(le=null);try{n==null||n()}catch{}}}function a(f){f.key==="Escape"&&(f.stopPropagation(),u())}i.addEventListener("click",f=>{f.stopPropagation(),u()}),document.addEventListener("keydown",a,!0),r(s,u);let p=e.getBoundingClientRect(),h=t?t.getBoundingClientRect():p,m=s.offsetWidth,l=h.right-p.left-m;return l>p.width-m-4&&(l=p.width-m-4),l<4&&(l=4),s.style.left=l+"px",s.style.top=h.bottom-p.top+2+"px",le={close:u},{close:u,panel:s}}var Us,Ws,le,It=_(()=>{un();Us="M20 6L9 17l-5-5",Ws="M9 18l6-6-6-6",le=null});async function Vs(e){var t;try{if((t=navigator.clipboard)!=null&&t.writeText)await navigator.clipboard.writeText(e);else{let r=document.createElement("textarea");r.value=e,document.body.appendChild(r),r.select(),document.execCommand("copy"),r.remove()}fn("URL copied",1500)}catch{fn(e||"No URL",2500)}}async function Gs(){let{getServerStatus:e}=await Promise.resolve().then(()=>(te(),Pe)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function yo(e,t=38){return e=String(e||""),e.length>t?e.slice(0,t-1)+"\u2026":e}function Xs(e){return{render(t){var a,p;let r=document.createElement("div");r.className="ls-zoomrow";let n=document.createElement("span");n.className="ls-zl",n.textContent="Zoom";let o=document.createElement("button");o.type="button",o.className="ls-ib",o.innerHTML=A(E.minus,14);let i=document.createElement("span");i.className="ls-zv",i.textContent=((p=(a=e.getZoom)==null?void 0:a.call(e))!=null?p:100)+"%";let s=document.createElement("button");s.type="button",s.className="ls-ib",s.innerHTML=A(E.plus,14);let c=document.createElement("button");c.type="button",c.className="ls-ib",c.title="Fullscreen",c.innerHTML=A(E.maximize,14);let u=h=>{var l;let m=(l=e.zoom)==null?void 0:l.call(e,h);m!=null&&(i.textContent=m+"%")};o.addEventListener("click",h=>{h.stopPropagation(),u(-10)}),s.addEventListener("click",h=>{h.stopPropagation(),u(10)}),i.style.cursor="pointer",i.addEventListener("click",h=>{var l;h.stopPropagation();let m=(l=e.zoom)==null?void 0:l.call(e,0,!0);m!=null&&(i.textContent=m+"%")}),c.addEventListener("click",h=>{var m;h.stopPropagation(),(m=e.toggleFullscreen)==null||m.call(e)}),r.append(n,o,i,s,c),t.appendChild(r)}}}function hn(e,t){var s,c,u,a,p,h,m;let r=((s=e.getVisited)==null?void 0:s.call(e))||[],n=((c=e.getBookmarks)==null?void 0:c.call(e))||[],o=!!((u=e.isBookmarked)!=null&&u.call(e)),i=[{label:"New tab",onClick:()=>{var l;return(l=e.newTab)==null?void 0:l.call(e)}},{label:"Duplicate tab",onClick:()=>{var l;return(l=e.duplicateTab)==null?void 0:l.call(e)}},{separator:!0},{label:"History",children:r.length?[...r.slice(0,15).map(l=>({label:yo(l.title||l.url),onClick:()=>{var f;return(f=e.navigate)==null?void 0:f.call(e,l.url)}})),{separator:!0},{label:"Clear history",onClick:()=>{var l;return(l=e.clearHistory)==null?void 0:l.call(e)}}]:[{label:"No history yet",disabled:!0}]},{label:"Bookmarks",children:[{label:o?"Remove bookmark for this tab":"Bookmark this tab",onClick:()=>{var l;return(l=e.toggleBookmark)==null?void 0:l.call(e)}},...n.length?[{separator:!0}]:[],...n.map(l=>({label:yo(l.title||l.url),onClick:()=>{var f;return(f=e.navigate)==null?void 0:f.call(e,l.url)}}))]},{separator:!0},Xs(e),{label:"Print\u2026",onClick:()=>{var l;return(l=e.print)==null?void 0:l.call(e)}},{label:"Find\u2026",onClick:()=>{var l;return(l=e.find)==null?void 0:l.call(e)}},{label:"Developer tools",checked:!!((a=e.isDevtools)!=null&&a.call(e)),onClick:()=>{var l;return(l=e.toggleDevtools)==null?void 0:l.call(e)}},{separator:!0},{label:"More tools",children:[{label:"Device mode (responsive)",checked:!!((p=e.isDeviceMode)!=null&&p.call(e)),onClick:()=>{var l;return(l=e.toggleDeviceMode)==null?void 0:l.call(e)}},{label:"View page source",onClick:()=>{var l;return(l=e.viewSource)==null?void 0:l.call(e)}},{separator:!0},{label:"Open server root",onClick:async()=>{var f;let l=await Gs();l?(f=e.navigate)==null||f.call(e,l):fn("Server not running",2e3)}},{label:"Copy current URL",onClick:()=>{var l;return Vs(((l=e.getUrl)==null?void 0:l.call(e))||"")}},{label:"Open in external browser",onClick:()=>{var l;return(l=e.openExternal)==null?void 0:l.call(e)}},{separator:!0},{label:"Close other tabs",onClick:()=>{var l;return(l=e.closeOtherTabs)==null?void 0:l.call(e)}},{label:"Close current tab",onClick:()=>{var l;return(l=e.closeTab)==null?void 0:l.call(e)}}]},{label:"Opacity\u2026",onClick:()=>{var l;return(l=e.openOpacity)==null?void 0:l.call(e)}},{label:"Preview as overlay",checked:!!((h=e.isOverlay)!=null&&h.call(e)),disabled:!((m=e.canOverlay)!=null&&m.call(e)),onClick:()=>{var l;return(l=e.toggleOverlay)==null?void 0:l.call(e)}},{separator:!0},{label:"Settings",onClick:async()=>{let{openSettingsHub:l}=await Promise.resolve().then(()=>($t(),ur));l()}},{label:"Exit",onClick:()=>{var l;return(l=e.closeBrowser)==null?void 0:l.call(e)}}];return Dt({host:t.host,anchor:t.anchor,items:i})}var fn,xo=_(()=>{It();Mt();fn=acode.require("toast")});function Ne(e){let t=parseFloat(e);return Number.isFinite(t)?Math.min(mn,Math.max(fr,Math.round(t*100)/100)):1}function wo(e){return String(Ne(e)).replace(/(\.\d)0$/,"$1")}function ko(e,t,r){let n=document.createElement("div");n.className="ls-op-row"+(r?" is-disabled":"");let o=document.createElement("span");o.textContent=e;let i=document.createElement("span");return i.className="ls-switch"+(t?" is-on":""),n.append(o,i),{r:n,sw:i}}function So({host:e,anchor:t,get:r,set:n}){return bo({host:e,anchor:t,render(o){let i=r(),s=document.createElement("div");s.className="ls-op-head";let c=document.createElement("span");c.textContent="Browser opacity";let u=document.createElement("span");u.className="ls-op-val",u.textContent=wo(i.opacity),s.append(c,u);let a=document.createElement("input");a.type="range",a.className="ls-range",a.min=String(fr),a.max=String(mn),a.step="0.05",a.value=String(Ne(i.opacity));let p=()=>{let f=(a.value-fr)/(mn-fr)*100;a.style.setProperty("--ls-fill",f+"%")};p(),a.addEventListener("input",()=>{p(),u.textContent=wo(a.value),n({opacity:Ne(a.value)})});let h=ko("Preview as overlay",i.overlay,!i.canOverlay),m=ko("Auto-save while typing",i.autoSave,!1);m.r.style.display=i.overlay?"":"none",h.r.addEventListener("click",()=>{let f=!h.sw.classList.contains("is-on");h.sw.classList.toggle("is-on",f),m.r.style.display=f?"":"none",n({overlay:f})}),m.r.addEventListener("click",()=>{let f=!m.sw.classList.contains("is-on");m.sw.classList.toggle("is-on",f),n({autoSave:f})});let l=document.createElement("div");l.className="ls-op-hint",l.textContent=i.canOverlay?"Overlay: the preview is see-through and you can keep editing underneath.":"Overlay needs the Acode page display mode.",o.append(s,a,h.r,m.r,l)}})}var fr,mn,Eo=_(()=>{It();fr=.1,mn=1});function mr(e){return hr.find(t=>t.id===e)||hr[0]}function ke(e){let t=Math.round(Number(e));return Number.isFinite(t)?Math.min(Ks,Math.max(vn,t)):null}function Lo(e,t,r,n,o){return e!=="fit"?Math.max(.1,Number(e)/100):!n||!o?1:Math.min(1,n/t,o/r)}var hr,gn,vn,Ks,Co=_(()=>{hr=[{id:"responsive",name:"Responsive",w:390,h:844},{id:"iphone-se",name:"iPhone SE",w:375,h:667},{id:"iphone-xr",name:"iPhone XR",w:414,h:896},{id:"iphone-12-pro",name:"iPhone 12 Pro",w:390,h:844},{id:"iphone-14-pro-max",name:"iPhone 14 Pro Max",w:430,h:932},{id:"pixel-7",name:"Pixel 7",w:412,h:915},{id:"galaxy-s8-plus",name:"Samsung Galaxy S8+",w:360,h:740},{id:"galaxy-s20-ultra",name:"Samsung Galaxy S20 Ultra",w:412,h:915},{id:"galaxy-fold",name:"Galaxy Fold",w:280,h:653},{id:"surface-duo",name:"Surface Duo",w:540,h:720},{id:"ipad-mini",name:"iPad Mini",w:768,h:1024},{id:"ipad-air",name:"iPad Air",w:820,h:1180},{id:"ipad-pro",name:"iPad Pro",w:1024,h:1366},{id:"surface-pro-7",name:"Surface Pro 7",w:912,h:1368},{id:"nest-hub",name:"Nest Hub",w:1024,h:600},{id:"nest-hub-max",name:"Nest Hub Max",w:1280,h:800},{id:"laptop",name:"Laptop 1366",w:1366,h:768},{id:"desktop",name:"Desktop 1920",w:1920,h:1080}],gn=["fit",25,50,75,100,125,150,200];vn=50,Ks=9999});function Se(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.innerHTML=r),n}function _o({shell:e,stage:t,box:r,device:n,bar:o,onChange:i}){let s={on:!1,id:"responsive",w:390,h:844,zoom:"fit"},c=1,u=null,a=Se("button","ls-dev-btn ls-dev-device");a.type="button";let p=Se("input","ls-dev-num"),h=Se("input","ls-dev-num");[p,h].forEach(v=>{v.type="number",v.min=String(vn),v.inputMode="numeric"});let m=Se("span","ls-dev-x","&times;"),l=Se("button","ls-dev-btn ls-dev-zoom");l.type="button";let f=Se("button","ls-dev-icon",A(E.rotate,16));f.type="button",f.title="Rotate";let L=Se("button","ls-dev-icon",A(E.close,16));L.type="button",L.title="Close device mode";let D=Se("span","ls-dev-spacer");o.append(a,p,m,h,l,f,D,L);function y(){try{i==null||i({...s})}catch{}}function S(){return s.zoom==="fit"?"Fit to window ("+Math.round(c*100)+"%)":s.zoom+"%"}function T(){a.innerHTML="<span>"+mr(s.id).name+"</span>"+A(E.down,12),document.activeElement!==p&&(p.value=String(s.w)),document.activeElement!==h&&(h.value=String(s.h)),l.innerHTML="<span>"+S()+"</span>"+A(E.down,12)}function P(){if(e.classList.toggle("is-device",s.on),o.hidden=!s.on,!s.on){r.style.width="",r.style.height="",n.style.width="",n.style.height="",n.style.transform="";return}let v=t.clientWidth-24,j=t.clientHeight-24;c=Lo(s.zoom,s.w,s.h,v,j),r.style.width=Math.round(s.w*c)+"px",r.style.height=Math.round(s.h*c)+"px",n.style.width=s.w+"px",n.style.height=s.h+"px",n.style.transform="scale("+c+")",T()}function b(v,j,he){let Ce=ke(v),De=ke(j);Ce!=null&&(s.w=Ce),De!=null&&(s.h=De),he||(s.id="responsive"),P(),y()}function g(v){let j=mr(v);s.id=j.id,s.w=j.w,s.h=j.h,P(),y()}a.addEventListener("click",()=>{Dt({host:e,anchor:a,items:hr.map(v=>({label:v.id==="responsive"?v.name:v.name+"  "+v.w+" x "+v.h,checked:v.id===s.id,onClick:()=>g(v.id)}))})}),l.addEventListener("click",()=>{Dt({host:e,anchor:l,items:gn.map(v=>({label:v==="fit"?"Fit to window":v+"%",checked:v===s.zoom,onClick:()=>{s.zoom=v,P(),y()}}))})}),f.addEventListener("click",()=>b(s.h,s.w,!0)),L.addEventListener("click",()=>R.toggle(!1));let k=()=>b(p.value,h.value);[p,h].forEach(v=>{v.addEventListener("change",k),v.addEventListener("keydown",j=>{j.key==="Enter"&&(k(),v.blur())})}),["r","b","c"].forEach(v=>{let j=Se("div","ls-hdl ls-hdl-"+v);r.appendChild(j),j.addEventListener("pointerdown",he=>{he.preventDefault(),he.stopPropagation();let Ce=he.clientX,De=he.clientY,bt=s.w,Kt=s.h;try{j.setPointerCapture(he.pointerId)}catch{}n.style.pointerEvents="none";let yt=Ge=>{var U,J;let d=c||1,w=v==="b"?bt:bt+(Ge.clientX-Ce)/d,I=v==="r"?Kt:Kt+(Ge.clientY-De)/d;s.id="responsive",s.w=(U=ke(w))!=null?U:s.w,s.h=(J=ke(I))!=null?J:s.h,P()},Ie=()=>{j.removeEventListener("pointermove",yt),j.removeEventListener("pointerup",Ie),j.removeEventListener("pointercancel",Ie),n.style.pointerEvents="",y()};j.addEventListener("pointermove",yt),j.addEventListener("pointerup",Ie),j.addEventListener("pointercancel",Ie)})}),typeof ResizeObserver=="function"&&(u=new ResizeObserver(()=>{s.on&&s.zoom==="fit"&&P()}),u.observe(t));let R={getState:()=>({...s}),getScale:()=>c,isOn:()=>s.on,setState(v){v&&(typeof v.id=="string"&&(s.id=mr(v.id).id),ke(v.w)!=null&&(s.w=ke(v.w)),ke(v.h)!=null&&(s.h=ke(v.h)),v.zoom!=null&&(s.zoom=gn.includes(v.zoom)?v.zoom:"fit"),s.on=!!v.on,P())},toggle(v){return s.on=v==null?!s.on:!!v,P(),y(),s.on},layout:P,destroy(){try{u==null||u.disconnect()}catch{}}};return T(),R}var Ao=_(()=>{Mt();It();Co()});function qt(e,t){if(!e)return;let r=t==null?!e.classList.contains("is-fullscreen"):!!t;return e.classList.toggle("is-fullscreen",r),document.body.classList.toggle("ls-browser-fs",r),r}function To(e){return qt(e,!1)}var Po=_(()=>{});function Ro(e,t={}){var T,P;let r=acode.require("page"),n=acode.require("actionStack"),o="liveserver-browser-page-"+ ++Ys,i=document.createElement("span");i.className="icon arrow_back",i.dataset.action="back",i.style.cssText="pointer-events:auto;cursor:pointer;";let s=r(t.title||"Live Preview",{lead:i}),c=s.body||s,u=s.header||((T=s.querySelector)==null?void 0:T.call(s,"header"));u&&(u.style.display="none"),Object.assign(c.style,{position:"absolute",inset:"0",top:"0",left:"0",right:"0",bottom:"0",width:"auto",height:"auto",padding:"0",margin:"0",overflow:"hidden"}),e.classList.add("is-in-page"),typeof s.appendBody=="function"?s.appendBody(e):c.appendChild(e);let a=!1,p=null,h=()=>{var g;let b=!1;try{b=!!((g=t.onBack)!=null&&g.call(t))}catch{}if(b){try{n.remove(o),n.push({id:o,action:h})}catch{}return}l()};function m(){try{n.remove(o),n.push({id:o,action:h})}catch{}}function l(){if(!a){try{n.remove(o)}catch{}try{s.style.display="none"}catch{}}}function f(){var b;if(!a){try{s.style.display="",s.isConnected||(window.app||document.body).append(s),(b=s.show)==null||b.call(s)}catch{}m()}}function L(b){var g,k,R;if(!a){a=!0;try{window.removeEventListener("resize",S)}catch{}try{n.remove(o)}catch{}try{(g=s.hide)==null||g.call(s)}catch{}try{(k=s.remove)==null||k.call(s)}catch{}if(b)try{(R=t.onClose)==null||R.call(t)}catch{}}}i.onclick=b=>{var g,k;try{(g=b==null?void 0:b.preventDefault)==null||g.call(b),(k=b==null?void 0:b.stopPropagation)==null||k.call(b)}catch{}l()};try{s.onhide=()=>{a||l()}}catch{}(window.app||document.body).append(s);try{getComputedStyle(s).position==="static"&&Object.assign(s.style,{position:"absolute",inset:"0",width:"100%",height:"100%"})}catch{}try{(P=s.show)==null||P.call(s)}catch{}m();let D=()=>{var b,g;try{let k=(b=window.editorManager)==null?void 0:b.container,R=(g=k==null?void 0:k.getBoundingClientRect)==null?void 0:g.call(k);if(R&&R.width>0&&R.height>0)return R}catch{}return{left:0,top:0,width:window.innerWidth,height:window.innerHeight}},y=()=>{let b=D();s.style.left=b.left+"px",s.style.top=b.top+"px",s.style.width=b.width+"px",s.style.height=b.height+"px"},S=()=>{p!=null&&y()};return window.addEventListener("resize",S),{page:s,show:f,minimize:l,setAppearance({overlay:b,opacity:g}){b?(p==null&&(p=s.style.cssText),Object.assign(s.style,{position:"fixed",background:"transparent",pointerEvents:"none",opacity:"1"}),y(),c.style.background="transparent"):(p!=null&&(s.style.cssText=p,p=null),c.style.background="",s.style.opacity=g<1?String(g):"")},close:()=>{window.removeEventListener("resize",S),L(!1)},onFullscreen(){}}}var Ys,Mo=_(()=>{Ys=0});function Js(){for(let e of["editorFile","EditorFile"])try{let t=acode.require(e);if(typeof t=="function")return t}catch{}return null}async function Ho(e,t={}){var a;let r=Js();if(!r)return null;e.classList.add("is-in-tab");let n=t.title||"Live Preview",o="liveserver-preview-"+Date.now()+"-"+ ++Zs,i=null,s=[{type:"custom",content:e,stylesheets:t.css?[t.css]:[],hideQuickTools:!0,id:o,render:!0},{type:"page",content:e,stylesheets:t.css?[t.css]:[],id:o,render:!0}];for(let p of s)try{i=new r(n,p);break}catch(h){console.warn("[LiveServer] EditorFile "+p.type,h),i=null}if(!i)return e.classList.remove("is-in-tab"),null;let c=!1,u=()=>{var p;if(!c){c=!0;try{(p=t.onClose)==null||p.call(t)}catch{}}};try{(a=i.on)==null||a.call(i,"close",u)}catch{}try{i.onclose=u}catch{}return{file:i,show(){var p;if(!c)try{(p=i.makeActive)==null||p.call(i)}catch{}},close(){var p,h;if(!c){c=!0;try{(p=i.remove)==null||p.call(i,!0)}catch{try{(h=i.remove)==null||h.call(i)}catch{}}}},onFullscreen(){},setAppearance(){}}}var Zs,Oo=_(()=>{Zs=0});var Do={};pe(Do,{destroyAcodeWebview:()=>ti,isNativeWebviewSupported:()=>ei,openInAcodeWebview:()=>bn});function Bo(e){var t,r,n;try{return(r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open?(window.cordova.InAppBrowser.open(e,"_system"),!0):(n=window.cordova)!=null&&n.exec?(window.cordova.exec(null,null,"System","open-in-browser",[e]),!0):(window.open(e,"_blank","noopener"),!0)}catch{return Qs(e,2500),!1}}function ei(){try{let e=acode.require("webview");return!!(e&&typeof e.create=="function")}catch{return!1}}async function bn(e,t={}){if(!e||e==="about:blank")return!1;let r=null;try{r=acode.require("webview")}catch{}if(!(r!=null&&r.create))return Bo(e);if(ce)try{return await ce.loadURL(e),await ce.show(),!0}catch{ce=null}try{let n=await r.create({mode:"fullscreen",title:t.title||e.replace(/^https?:\/\//i,""),allowNavigation:!0,allowDownloads:t.allowDownloads!==!1,visible:!0});return ce=n,n.on("closed",()=>{ce===n&&(ce=null)}),await n.loadURL(e),!0}catch(n){return console.warn("[LiveServer] native webview failed, falling back:",n),ce=null,Bo(e)}}async function ti(){if(!ce)return;let e=ce;ce=null;try{await e.destroy()}catch{}}var Qs,ce,yn=_(()=>{Qs=acode.require("toast"),ce=null});var Fe={};pe(Fe,{createBrowserShell:()=>ui,hideBrowser:()=>gt,openBrowser:()=>kn,openBrowserMenu:()=>hn});function No(){return C().browserDisplayMode==="editorTab"?"editorTab":"inPage"}function si(e,t){try{return new URL(e).origin===new URL(t).origin}catch{return!1}}function ht(){let e=C().browserBookmarks;return Array.isArray(e)?e:[]}async function ii(){let{getServerStatus:e}=await Promise.resolve().then(()=>(te(),Pe)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function $o(e){var t,r,n;if(!(!e||e==="about:blank"))try{if((r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open){window.cordova.InAppBrowser.open(e,"_system");return}if((n=window.cordova)!=null&&n.exec){window.cordova.exec(null,null,"System","open-in-browser",[e]);return}window.open(e,"_blank","noopener")}catch{ie(e,2500)}}function ai(){if(!(mt||typeof editorManager=="undefined"||!(editorManager!=null&&editorManager.on))){mt=()=>{C().overlayAutoSave!==!1&&(clearTimeout(xn),xn=setTimeout(async()=>{var r;let e=G(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";if(e&&e.isUnsaved&&(e.uri||e.url)&&ni.test(t))try{await((r=e.save)==null?void 0:r.call(e))}catch(n){console.warn("[LiveServer] overlay auto-save",n)}},700))};try{editorManager.on("update",mt)}catch{}}}function zo(){var e;if(clearTimeout(xn),mt)try{(e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"update",mt)}catch{}mt=null}function vr(){return ze==="page"&&!!C().browserOverlay}function wn(){var n,o;if(!N)return;let e=C(),t=Ne((n=e.browserOpacity)!=null?n:1),r=vr();N.classList.toggle("is-overlay",r),N.classList.toggle("no-url",e.showAddressBar===!1),N.style.setProperty("--ls-op",String(t)),ze==="page"?((o=q==null?void 0:q.setAppearance)==null||o.call(q,{overlay:r,opacity:t}),N.style.opacity=""):N.style.opacity=t<1?String(t):"",r?ai():zo(),F==null||F.layout()}function qo(e){if("opacity"in e&&$("browserOpacity",Ne(e.opacity)),"overlay"in e){if(e.overlay&&ze!=="page"){ie("Overlay needs the Acode page display mode",2200);return}$("browserOverlay",!!e.overlay)}"autoSave"in e&&$("overlayAutoSave",!!e.autoSave),wn()}function li(e){var yt,Ie,Ge;let t=d=>e.querySelector(d),r=t(".ls-browser-tabs"),n=t(".ls-stage"),o=t(".ls-box"),i=t(".ls-device"),s=t(".ls-ntp"),c=t(".ls-back"),u=t(".ls-fwd"),a=t(".ls-browser-url"),p=t(".ls-reload"),h=t(".ls-star"),m=t(".ls-site"),l=t(".ls-menu-btn"),f=t(".ls-op-btn"),L=t(".ls-dev-toggle"),D=t(".ls-find"),y=D.querySelector("input"),S=!1;F=_o({shell:e,stage:n,box:o,device:i,bar:t(".ls-devbar"),onChange:d=>$("browserDevice",d)});let T=C().browserDevice;T&&typeof T=="object"&&F.setState(T);let P=()=>e.getRootNode().activeElement===a,b=async d=>{if(d==="about:blank"){Re("about:blank");return}let w=dt(d);if(!w||w==="about:blank"){Re("about:blank");return}if(!lt(w)){let I=C().externalSiteMode||"proxy";if(I==="acodeWebview"){await bn(w);return}if(I==="systemBrowser"){$o(w);return}}Re(w)},g=()=>{s.innerHTML="";let d=document.createElement("div");d.className="ls-ntp-hero";let w=document.createElement("img");w.className="ls-ntp-logo",w.src=ri,w.alt="Live Server",w.onerror=()=>{w.style.display="none"},d.appendChild(w);let I=document.createElement("div");I.className="ls-ntp-title",I.textContent="Live Server",d.appendChild(I);let U=document.createElement("div");U.className="ls-ntp-search";let J=document.createElement("span");J.className="ls-ntp-search-ico",J.innerHTML=A(E.search,17);let me=document.createElement("input");me.type="text",me.placeholder="Search or enter web address",me.setAttribute("spellcheck","false"),me.setAttribute("autocapitalize","off"),me.setAttribute("autocomplete","off");let xt=document.createElement("button");xt.type="button",xt.className="ls-ntp-search-btn",xt.textContent="Search";let qn=()=>{let M=me.value.trim();if(!M){me.focus();return}b(M)};me.addEventListener("keydown",M=>{M.key==="Enter"&&qn()}),xt.addEventListener("click",qn),U.append(J,me,xt);let wt=document.createElement("div");wt.className="ls-ntp-tiles";let jn=(M,V,de,ne)=>{let Y=document.createElement("button");Y.type="button",Y.className="ls-ntp-tile",Y.innerHTML='<span class="ls-ntp-dot"></span><span class="ls-ntp-name"></span>';let _r=Y.querySelector(".ls-ntp-dot");if(ne&&/^https?:/i.test(ne)&&!lt(ne)){let $e=document.createElement("img");$e.src=ne,$e.alt="",$e.onerror=()=>{_r.textContent=de},_r.appendChild($e)}else _r.textContent=de;return Y.querySelector(".ls-ntp-name").textContent=M,Y.addEventListener("click",async()=>{let $e=typeof V=="function"?await V():V;if(!$e)return ie("Server not running",2e3);b($e)}),Y};wt.appendChild(jn("Server root",ii,"S",null)),ht().forEach(M=>{var ne;let V=null;try{let Y=new URL(M.url).hostname;Y&&Y!=="127.0.0.1"&&Y!=="localhost"&&(V=`https://www.google.com/s2/favicons?domain=${encodeURIComponent(Y)}&sz=64`)}catch{}let de=((ne=(M.title||M.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:ne.toUpperCase())||"B";wt.appendChild(jn(M.title||M.url,M.url,de,V))});let kt=document.createElement("button");kt.type="button",kt.className="ls-ntp-tile",kt.innerHTML=`<span class="ls-ntp-dot">${A(E.plus,20)}</span><span class="ls-ntp-name">Add shortcut</span>`,kt.addEventListener("click",async()=>{let M=acode.require("prompt"),V=await M("Bookmark URL (e.g. https://duckduckgo.com)","https://","text");if(!V)return;let de=dt(V),ne=await M("Shortcut name",de.replace(/^https?:\/\//,""),"text")||de,Y=ht();$("browserBookmarks",[...Y,{title:ne.trim(),url:de}]),g()}),wt.appendChild(kt);let Yt=document.createElement("div");Yt.className="ls-ntp-recent-wrap";let Cr=cr(),Zt=document.createElement("div");Zt.className="ls-ntp-sec-head";let Nn=document.createElement("span");if(Nn.textContent="Recent",Zt.appendChild(Nn),Cr.length>0){let M=document.createElement("button");M.type="button",M.className="ls-ntp-more",M.textContent=S?"Less":"More",M.addEventListener("click",()=>{S=!S,g()}),Zt.appendChild(M)}Yt.appendChild(Zt);let Jt=document.createElement("div");Jt.className="ls-ntp-recent-list";let zn=S?Cr:Cr.slice(0,5);if(zn.length)zn.forEach(M=>{var ne;let V=document.createElement("button");V.type="button",V.className="ls-ntp-recent-row";let de=((ne=(M.title||M.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:ne.toUpperCase())||"W";V.innerHTML=`
          <span class="ls-ntp-recent-ico">${de}</span>
          <span class="ls-ntp-recent-meta">
            <span class="ls-ntp-recent-title"></span>
            <span class="ls-ntp-recent-url"></span>
          </span>
        `,V.querySelector(".ls-ntp-recent-title").textContent=M.title||M.url,V.querySelector(".ls-ntp-recent-url").textContent=M.url,V.addEventListener("click",()=>b(M.url)),Jt.appendChild(V)});else{let M=document.createElement("div");M.className="ls-ntp-empty",M.textContent="No recent pages yet",Jt.appendChild(M)}Yt.appendChild(Jt),s.append(d,U,wt,Yt)},k=()=>{let d=H();cn(r),a&&!P()&&(a.value=d&&d.url!=="about:blank"?d.url:""),e.classList.toggle("is-loading",!!(d!=null&&d.loading)),e.classList.toggle("is-installing",document.body.classList.contains("ls-green-loading")),p.innerHTML=A(d!=null&&d.loading?E.close:E.reload,18),p.title=d!=null&&d.loading?"Stop loading":"Reload",c&&(c.disabled=!Gr()),u&&(u.disabled=!Xr());let w=/^https:/i.test((d==null?void 0:d.url)||"");m.innerHTML=A(w?E.lock:E.info,16),m.title=w?"Connection is secure":"Not secure";let I=!!d&&ht().some(J=>J.url===d.url);h.classList.toggle("is-on",I);let U=!d||d.url==="about:blank";U&&g(),s.classList.toggle("is-on",U),at().length||gt()};Me==null||Me(),Me=Kr(k);let R=()=>{var w;let d=qt(e);(w=q==null?void 0:q.onFullscreen)==null||w.call(q,d)},v=()=>{var d;S=!1,ut(i,"about:blank"),ft((d=H())==null?void 0:d.id)},j=()=>{S=!1;let d=String(C().browserHomeUrl||"").trim();d?b(d):Re("about:blank")},he=(d,w)=>{var I,U;return w>0?(I=Io.find(J=>J>d))!=null?I:d:(U=[...Io].reverse().find(J=>J<d))!=null?U:d},Ce=d=>on(y.value,d),De=()=>{let d=H();if(!d||d.url==="about:blank")return ie("Nothing to bookmark",1500);let w=ht(),I=w.some(U=>U.url===d.url);$("browserBookmarks",I?w.filter(U=>U.url!==d.url):[...w,{title:d.title||d.url,url:d.url}]),k(),ie(I?"Bookmark removed":"Bookmarked",1200)},bt=()=>So({host:e,anchor:f,get:()=>{var d;return{opacity:Ne((d=C().browserOpacity)!=null?d:1),overlay:vr(),autoSave:C().overlayAutoSave!==!1,canOverlay:ze==="page"}},set:qo}),Kt=()=>({newTab:v,duplicateTab:()=>tn(i),closeTab:()=>{let d=H();d&&Ht(d.id)},closeOtherTabs:()=>{let d=H();at().filter(w=>w.id!==(d==null?void 0:d.id)).forEach(w=>Ht(w.id))},navigate:d=>b(d),getUrl:()=>{var d;return((d=H())==null?void 0:d.url)||""},getVisited:cr,clearHistory:()=>{Vr(),g(),ie("History cleared",1500)},getBookmarks:ht,isBookmarked:()=>{let d=H();return!!d&&ht().some(w=>w.url===d.url)},toggleBookmark:De,getZoom:()=>{var d,w;return(w=(d=H())==null?void 0:d.zoom)!=null?w:100},zoom:(d,w)=>{let I=H();return I?ln(w?100:he(I.zoom||100,d)):100},toggleFullscreen:R,print:()=>{sn()||ie("Cannot print this page",1800)},find:()=>{D.hidden=!1,y.focus(),y.select()},isDevtools:()=>{var d;return!!((d=H())!=null&&d.devtools)},toggleDevtools:()=>{let d=H();if(!d||d.url==="about:blank")return ie("Open a page first",1800);an()||ie("DevTools work on pages served by Live Server",3e3)},isDeviceMode:()=>F.isOn(),toggleDeviceMode:()=>F.toggle(),viewSource:async()=>{var w;let d=H();if(!d||!/^https?:/i.test(d.url))return ie("No page source here",1800);try{let I=(w=d.iframe)!=null&&w.src&&d.iframe.src!=="about:blank"?d.iframe.src:d.url,U=await(await fetch(I)).text(),J=URL.createObjectURL(new Blob([U],{type:"text/plain;charset=utf-8"}));ut(i,J,"view-source:"+d.url.replace(/^https?:\/\//,""))}catch(I){ie("Could not load source: "+((I==null?void 0:I.message)||I),2500)}},openExternal:()=>{var w;let d=(w=H())==null?void 0:w.url;d&&d!=="about:blank"&&$o(d)},openOpacity:bt,isOverlay:vr,canOverlay:()=>ze==="page",toggleOverlay:()=>qo({overlay:!vr()}),closeBrowser:()=>gt()});return(yt=t(".ls-tab-new"))==null||yt.addEventListener("click",v),e.querySelectorAll(".ls-close-btn, .ls-ov-close").forEach(d=>d.addEventListener("click",()=>gt())),(Ie=t(".ls-fs-btn"))==null||Ie.addEventListener("click",R),c==null||c.addEventListener("click",()=>pr(-1)),u==null||u.addEventListener("click",()=>pr(1)),p.addEventListener("click",()=>{var d;return(d=H())!=null&&d.loading?nn():dr()}),(Ge=t(".ls-home"))==null||Ge.addEventListener("click",j),h.addEventListener("click",De),f.addEventListener("click",bt),L.addEventListener("click",()=>{let d=F.toggle();L.classList.toggle("is-on",d)}),L.classList.toggle("is-on",F.isOn()),l.addEventListener("click",()=>hn(Kt(),{host:e,anchor:l})),a.addEventListener("keydown",d=>{d.key==="Enter"&&(b(a.value),a.blur())}),a.addEventListener("focus",()=>a.select()),D.querySelector(".ls-find-prev").addEventListener("click",()=>Ce(!0)),D.querySelector(".ls-find-next").addEventListener("click",()=>Ce(!1)),D.querySelector(".ls-find-close").addEventListener("click",()=>D.hidden=!0),y.addEventListener("keydown",d=>{d.key==="Enter"&&Ce(d.shiftKey),d.key==="Escape"&&(D.hidden=!0)}),e._lsDevice=i,e._sync=k,e}function ci(){let e=document.createElement("div");return e.className="ls-browser-shell",e.dataset.theme=oo(),e.innerHTML=`
    <div class="ls-chrome">
      <div class="ls-tabstrip">
        <div class="ls-browser-tabs"></div>
        <button type="button" class="ls-ib ls-tab-new" title="New tab">${A(E.plus,16)}</button>
        <span class="ls-spacer"></span>
        <div class="ls-win">
          <button type="button" class="ls-ib ls-win-btn ls-fs-btn" title="Fullscreen">${A(E.maximize,14)}</button>
          <button type="button" class="ls-ib ls-win-btn ls-close-btn" title="Close">${A(E.close,14)}</button>
        </div>
      </div>
      <div class="ls-toolbar">
        <button type="button" class="ls-ib ls-back" title="Back" disabled>${A(E.back,18)}</button>
        <button type="button" class="ls-ib ls-fwd" title="Forward" disabled>${A(E.forward,18)}</button>
        <button type="button" class="ls-ib ls-reload" title="Reload">${A(E.reload,18)}</button>
        <button type="button" class="ls-ib ls-home" title="Home">${A(E.home,18)}</button>
        <div class="ls-omni">
          <button type="button" class="ls-site" title="Site information">${A(E.info,16)}</button>
          <input class="ls-browser-url" type="text" spellcheck="false" autocapitalize="off" autocomplete="off" placeholder="Search or type a URL" />
          <button type="button" class="ls-ib ls-star" title="Bookmark this tab">${A(E.star,16)}</button>
        </div>
        <button type="button" class="ls-ib ls-op-btn" title="Opacity">${A(E.drop,18)}</button>
        <button type="button" class="ls-ib ls-dev-toggle" title="Device mode">${A(E.device,18)}</button>
        <button type="button" class="ls-ib ls-menu-btn" title="Customize and control">${A(E.dots,18,3)}</button>
        <button type="button" class="ls-ib ls-ov-close" title="Close">${A(E.close,16)}</button>
        <div class="ls-progress"></div>
        <div class="ls-green-progress"></div>
      </div>
      <div class="ls-devbar" hidden></div>
    </div>
    <div class="ls-stage">
      <div class="ls-ntp"></div>
      <div class="ls-box"><div class="ls-device"></div></div>
    </div>
    <div class="ls-find" hidden>
      <input type="text" placeholder="Find in page" spellcheck="false" />
      <button type="button" class="ls-ib ls-find-prev" title="Previous">${A(E.up,16)}</button>
      <button type="button" class="ls-ib ls-find-next" title="Next">${A(E.down,16)}</button>
      <button type="button" class="ls-ib ls-find-close" title="Close">${A(E.close,16)}</button>
    </div>
  `,li(e)}function di(){var t;if(vo())return Bt(),!0;let e=N==null?void 0:N.querySelector(".ls-find");return e&&!e.hidden?(e.hidden=!0,!0):N!=null&&N.classList.contains("is-fullscreen")?((t=q==null?void 0:q.onFullscreen)==null||t.call(q,qt(N,!1)),!0):!1}function jo(){gr||gt({fromHost:!0})}async function pi(){var e;return N&&q?((e=q.show)==null||e.call(q),requestAnimationFrame(()=>F==null?void 0:F.layout()),N):jt||(jt=(async()=>{io();let t=ci(),r=null;return ze="page",No()==="editorTab"&&(r=await Ho(t,{title:"Live Preview",css:Fr,onClose:jo}),r?ze="tab":ie("Editor tab not available, using page",2e3)),r||(r=Ro(t,{title:"Live Preview",onClose:jo,onBack:di})),q=r,N=t,Qr(),Nt=n=>{var o;oi.includes((o=n==null?void 0:n.detail)==null?void 0:o.key)&&wn()},window.addEventListener("liveserver-settings",Nt),wn(),requestAnimationFrame(()=>F==null?void 0:F.layout()),t})().finally(()=>{jt=null}),jt)}async function kn(e,t={}){let r=await pi(),n=at();if(n.length>0&&(t.restoreOnly||!e))return;let o=e||"about:blank";if(t.reuse){let s=n.find(c=>si(c.url,o));if(s){ft(s.id),s.url!==o?Re(o):t.forceReload&&dr();return}}let i=H();i&&i.url==="about:blank"&&n.length===1?Re(o):ut(r._lsDevice,o)}function gt(e={}){if(!gr){gr=!0;try{Bt(),Me==null||Me(),Me=null,Nt&&window.removeEventListener("liveserver-settings",Nt),Nt=null,zo(),en();try{F==null||F.destroy()}catch{}F=null,rn(),To(N);try{N==null||N.remove()}catch{}e.fromHost||q==null||q.close()}finally{q=null,N=null,document.body.classList.remove("ls-browser-fs"),gr=!1}}}function ui(e={}){return{open:t=>kn(t||e.initialUrl),addTab:t=>kn(t),setFullscreen:t=>qt(N,t),dispose:gt,getMode:No}}var ie,ri,Io,ni,oi,N,q,ze,Me,jt,gr,F,Nt,mt,xn,Ue=_(()=>{oe();be();Mt();so();ao();dn();xo();It();Eo();Ao();Po();Mo();Oo();yn();ie=acode.require("toast"),ri="https://i.postimg.cc/WpYPQ47b/green-fox.png",Io=[25,33,50,67,75,80,90,100,110,125,150,175,200,250,300,400,500],ni=/\.(html?|css|js|mjs|json|svg|xml|txt|md)$/i,oi=["browserOpacity","browserOverlay","overlayAutoSave","showAddressBar"],N=null,q=null,ze="page",Me=null,jt=null,gr=!1,F=null,Nt=null,mt=null,xn=null});var Z={};pe(Z,{changePortAndRestart:()=>vi,ensureProxyServer:()=>pn,probeExistingServer:()=>_n,reapplySetup:()=>bi,refreshStatusFromBackend:()=>Nr,restartServer:()=>gi,setProcessBaseUrl:()=>Ln,startServer:()=>Ft,stopServer:()=>kr});function Ln(e){zt=e||""}async function yr(e,t=900){try{let r=new AbortController,n=setTimeout(()=>r.abort(),t),o=await fetch("http://127.0.0.1:"+e+"/check",{signal:r.signal});if(clearTimeout(n),!o||!o.ok)return{alive:!1,proxy:!1};let i=await o.json().catch(()=>({}));return{alive:!0,proxy:(i==null?void 0:i.proxy)===!0}}catch{return{alive:!1,proxy:!1}}}async function Wo(e,t=800){return(await yr(e,t)).alive}async function fi(e){try{let t=await ee("if command -v wget >/dev/null 2>&1; then wget -qO- -T 2 http://127.0.0.1:"+e+"/check 2>/dev/null; elif command -v curl >/dev/null 2>&1; then curl -s --max-time 2 http://127.0.0.1:"+e+"/check 2>/dev/null; else echo NOCLIENT; fi",{timeoutMs:8e3});return/Ready|AcodeLiveServer|"port"/i.test(String(t||""))}catch{return!1}}async function Sn(e,t={}){let r=String(parseInt(e,10)||8080);return await Wo(r)?!0:t.deep?fi(r):!1}async function Cn(e){let t=String(parseInt(e,10)||8080);He=null;let r=`for pid in $(ps -o pid,args 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; for pid in $(ps 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; pkill -9 -f "node index.js ${t}" 2>/dev/null || true; fuser -k ${t}/tcp 2>/dev/null || true`;try{await ee(r,{timeoutMs:12e3})}catch{}for(let n=0;n<10&&await Wo(t,400);n++)await new Promise(o=>setTimeout(o,200))}function Vo(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=t.match(/^\/storage\/emulated\/0(\/.*)?$/);return r?"/sdcard"+(r[1]||""):t}async function hi(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=[t],n=t.match(/^\/storage\/emulated\/0(\/.*)?$/);if(n&&r.push("/sdcard"+(n[1]||"")),n=t.match(/^\/sdcard(\/.*)?$/),n&&r.push("/storage/emulated/0"+(n[1]||"")),!/^\/(sdcard|storage)(\/|$)/.test(t))return t;let o=c=>"'"+String(c).replace(/'/g,"'\\''")+"'",i="";try{i=await ee("for d in "+r.map(o).join(" ")+'; do [ -d "$d" ] && { echo "OK:$d"; exit 0; }; done; echo NONE',{timeoutMs:1e4})}catch(c){return console.warn("[LiveServer] root probe failed, using path as is",c),t}let s=String(i||"").match(/OK:(.+)/);return s?s[1].trim():/NONE/.test(String(i||""))?null:t}function mi(e){let t={};return String(e||"").split(`
`).forEach(r=>{let n=r.indexOf(":");if(n>0){let o=r.slice(0,n).trim(),i=r.slice(n+1).trim();o&&(t[o]=i)}}),t}function Fo(){let e=G(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";return/\.html?$/i.test(t)?t:"index.html"}function Uo(e){try{let t=G(),r=tt((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");if(!r||!e)return Fo();let n=e.replace(/\/+$/,"");if(r.startsWith(n+"/")||r.startsWith(n+"\\"))return r.slice(n.length).replace(/^[/\\]+/,"").replace(/\\/g,"/")}catch{}return Fo()}async function xr(e,t,r){let n=C(),o={path:t,fileName:r||"index.html",port:e,liveReload:n.liveReload!==!1,directoryListing:n.directoryListing!==!1,enableCors:n.enableCors!==!1,charset:n.customCharset||"utf-8",customHeaders:mi(n.customHeaders),ipWhitelist:n.ipWhitelist||"",basicAuthUser:n.basicAuthUser||"",basicAuthPass:n.basicAuthPass||""};try{let i=await fetch(`http://127.0.0.1:${e}/setup`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)});return!!(i&&(i.ok||i.status===201))}catch(i){return console.warn("[LiveServer] setup",i),!1}}function En(){br&&(clearInterval(br),br=null)}function wr(){En();let e=parseInt(C().autoShutdownMinutes,10)||0;if(e<=0)return;let t=e*60*1e3,r=Date.now();br=setInterval(async()=>{let n=B();if(!n.running){En();return}if(Date.now()-(n.startedAt||r)>t){try{let i=await(await fetch(`http://127.0.0.1:${n.port}/status`)).json();if(i.lastActivity&&Date.now()-i.lastActivity<t)return}catch{}Ee("Live Server auto-stopped (inactivity)",2500),kr()}},3e4)}async function _n(){let e=ot();try{let t=new AbortController,r=setTimeout(()=>t.abort(),1200),n=await fetch(`http://127.0.0.1:${e}/status`,{signal:t.signal});if(clearTimeout(r),!n||!n.ok)return!1;let o=await n.json().catch(()=>({})),i=o.port||e,s=o.fileName||null,c=Pt(i,"127.0.0.1"),u=s&&s!=="index.html"?c.replace(/\/$/,"/")+encodeURI(s):c,a=B();if(Q({running:!0,port:i,root:o.root||a.root||null,url:u,fileName:s,bind:o.bind||"0.0.0.0",startedAt:a.startedAt||(o.uptime?Date.now()-Math.round(Number(o.uptime)*1e3):Date.now()),lastError:null}),wr(),!a.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:u,port:i,root:o.root||null,fileName:s}}))}catch{}return!0}catch{return!1}}function Go(e,t){let r=Xe();if(!(r!=null&&r.execute))throw new Error("Executor not available. Open Acode Terminal once, then retry.");let n='ACODIR=""; for d in "'+String(t||"").replace(/"/g,"")+'" /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels; do [ -n "$d" ] || continue; if [ -f "$d/index.js" ] && [ -d "$d/node_modules" ]; then ACODIR="$d"; break; fi; done; [ -z "$ACODIR" ] && { echo acodels_not_found; exit 1; }; cd "$ACODIR" || exit 1; NODE_PATH="$ACODIR/node_modules" exec node index.js '+String(e)+" 0.0.0.0 >liveserver.log 2>&1",o={};He=o,r.execute(Mr(n),!0).then(i=>console.log("[LiveServer] node exited",String(i||"").slice(0,200))).catch(i=>console.warn("[LiveServer] node exited",String((i==null?void 0:i.message)||i).slice(0,200))).finally(()=>{if(He===o&&(He=null,B().running)){Q({running:!1,lastError:"server process exited"});try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}}})}async function pn(){let e=ot(),t=await yr(e);if(t.alive&&t.proxy)return e;if(!await rr({baseUrl:zt}))return null;ye(!0),xe(t.alive?`$ Updating backend on :${e} with Reverse Proxy...`:`$ node index.js ${e} (starting local proxy)...`,{spin:!0});try{t.alive&&!t.proxy&&await Cn(e);let n=await Qe(zt);await $r(n),Go(e,n);let o=!1;for(let p=0;p<35;p++){await new Promise(m=>setTimeout(m,300));let h=await yr(e,500);if(h.alive&&h.proxy){o=!0;break}if(!He)break}if(!o)return xe("Proxy server failed to start",{spin:!1,autoHideMs:3e3}),null;let i=B(),s=i.root||or()||"/sdcard",c=Vo(s),u=i.fileName||"index.html";await xr(e,c,u);let a=Pt(e,"127.0.0.1");Q({running:!0,port:e,root:c,url:a,fileName:u,bind:"0.0.0.0",startedAt:Date.now(),lastError:null}),wr();try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:a,port:e,root:c,fileName:u}}))}catch{}return xe(`\u2713 Reverse proxy ready on 127.0.0.1:${e}`,{spin:!1,autoHideMs:2e3}),e}catch(n){return xe(`Proxy error: ${(n==null?void 0:n.message)||n}`,{spin:!1,autoHideMs:3500}),null}finally{ye(!1)}}async function Ft(e={}){let t=e.port||ot(),r=e.root||or(),n=C(),o=e.forceDeps?{alive:!1,proxy:!1}:await yr(t);if(o.alive&&!o.proxy&&(ye(!0),xe(`$ Upgrading Live Server on :${t}...`,{spin:!0}),await Cn(t),ye(!1),sr(0),o.alive=!1),o.alive&&o.proxy){let m=B(),l=r||m.root;if(!l)return Ee("Set a root folder or open an HTML file",2500),!1;let f=Vo(l),L=e.fileName||Uo(l);(!m.running||m.port!==t||m.root!==f||m.fileName!==L)&&await xr(t,f,L);let y=Pt(t,"127.0.0.1"),S=L&&L!=="index.html"?y.replace(/\/$/,"/")+encodeURI(L):y;if(Q({running:!0,port:t,root:f,url:S,fileName:L,bind:"0.0.0.0",startedAt:m.startedAt||Date.now(),lastError:null}),wr(),!m.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:S,port:t,root:f,fileName:L}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:T}=await Promise.resolve().then(()=>(Ue(),Fe));T(S,{reuse:!0})}catch(T){console.warn("[LiveServer] open browser",T)}return!0}if(!await rr({baseUrl:zt,force:!!e.forceDeps}))return!1;if(!r)return Ee("Set a root folder or open an HTML file",2500),!1;let s=e.fileName||Uo(r),c=await hi(r);if(!c)return Q({running:!1,lastError:"root not reachable"}),Ee("Folder not reachable from Alpine: "+r+" (allow Acode storage permission)",4500),!1;let u="0.0.0.0";if(!await Sn(t,{deep:!0})){ye(!0),xe(`$ node index.js ${t} 0.0.0.0`,{spin:!0});let m=await Qe(zt);try{await $r(m)}catch(f){console.warn("[LiveServer] ensure index",f)}try{Go(t,m)}catch(f){return ye(!1),sr(0),Q({running:!1,lastError:String((f==null?void 0:f.message)||f)}),Ee("Start failed: "+((f==null?void 0:f.message)||f),3e3),!1}let l=!1;for(let f=0;f<40;f++){if(await new Promise(L=>setTimeout(L,300)),await Sn(t)){l=!0;break}if(!He)break}if(!l&&He&&(l=await Sn(t,{deep:!0})),ye(!1),!l){xe("Server failed to start",{spin:!1,autoHideMs:3500});try{let f=await ee("tail -n 40 /root/.acode_liveserver/acodels/liveserver.log 2>/dev/null",{timeoutMs:8e3});console.warn("[LiveServer] start failed, log:",f)}catch{}return Ee("Server failed to start \u2014 see console log",3500),Q({running:!1,lastError:"start failed"}),He=null,!1}xe(`\u2713 Live Server running on :${t}`,{spin:!1,autoHideMs:2200})}await xr(t,c,s)||console.warn("[LiveServer] /setup patch failed");let p=Pt(t,"127.0.0.1"),h=s&&s!=="index.html"?p.replace(/\/$/,"/")+encodeURI(s):p;Q({running:!0,port:t,root:c,url:h,fileName:s,bind:u,startedAt:Date.now(),lastError:null}),$("port",t),wr(),Ee("Live on "+h,2500);try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:h,port:t,root:r,fileName:s}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:m}=await Promise.resolve().then(()=>(Ue(),Fe));m(h,{reuse:!0})}catch(m){console.warn("[LiveServer] open browser",m)}return!0}async function kr(){En();let t=B().port||ot();await Cn(t),Q({running:!1,port:null,url:null,fileName:null,startedAt:null}),Ee("Server stopped",1500);try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}return!0}async function gi(){let e=B(),t=e.root,r=e.fileName;return await kr(),await new Promise(n=>setTimeout(n,350)),Ft({root:t||void 0,fileName:r||void 0})}async function vi(){let e=acode.require("prompt"),t=String(ot()),r=await e("Port",t,"number");if(r==null)return!1;let n=parseInt(String(r),10);return!Number.isFinite(n)||n<1||n>65535?(Ee("Invalid port",1500),!1):($("port",n),await kr(),Ft({port:n}))}async function bi(){let e=B();return!e.running||!e.port||!e.root?!1:xr(e.port,e.root,e.fileName||"index.html")}var Ee,zt,br,He,W=_(()=>{oe();Ct();et();Qn();nt();to();te();be();zr();Ee=acode.require("toast"),zt="",br=null,He=null});var Jo={};pe(Jo,{onFileSwitch:()=>Pn,registerSideButton:()=>Tn,setLiveDot:()=>We,unregisterSideButton:()=>Rn});function Xo(){if(document.getElementById("ls-side-dot-css"))return;let e=document.createElement("style");e.id="ls-side-dot-css",e.textContent=`
    .ls-side-live-dot {
      display: inline-block;
      width: 9px;
      height: 9px;
      min-width: 9px;
      border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 6px rgba(34, 197, 94, 0.95);
      margin-right: 6px;
      vertical-align: middle;
      flex-shrink: 0;
    }
    [data-ls-sidebtn="1"][data-live="1"] {
      border-left: 3px solid #22c55e !important;
    }
  `,document.head.appendChild(e)}function Ko(){var e;return C().showSideButton!==!1&&ve(G()||((e=window.editorManager)==null?void 0:e.activeFile))}function Yo(){return x?x.$el||x.el||x.root||(x instanceof HTMLElement?x:null):null}function Zo(e,t){var o,i,s;if(!e)return!1;e.setAttribute("data-ls-sidebtn","1"),e.setAttribute("data-live",t?"1":"0");let r=!1,n=e.querySelectorAll('.text, .label, .side-button-text, [class*="text"], span, small');for(let c=0;c<n.length;c++){let u=n[c];if(!((o=u.classList)!=null&&o.contains("icon")||(i=u.classList)!=null&&i.contains("ls-side-live-dot"))&&!((s=u.children)!=null&&s.length&&u.querySelector(".icon"))){if(u.textContent="Live Server",t){let a=document.createElement("span");a.className="ls-side-live-dot",a.setAttribute("aria-hidden","true"),u.prepend(a)}r=!0}}if(!r){let c=t?"\u25CF Live Server":"Live Server";e.setAttribute("aria-label",c),e.title=c;for(let u of[...e.childNodes])u.nodeType===3&&u.textContent.trim()&&(u.textContent=c,r=!0)}return r}function An(e){return{text:e?"\u25CF Live Server":"Live Server",icon:"public",backgroundColor:e?"#14532d":"var(--primary-color, #1e1e1e)",textColor:e?"#86efac":"var(--primary-text-color, #fff)",onclick:()=>ki()}}function wi(e){var r,n,o;let t=Ko();try{(r=x==null?void 0:x.hide)==null||r.call(x)}catch{}x=null;try{x=Ut(An(e));let i=Yo();i&&Zo(i,e),t?(n=x==null?void 0:x.show)==null||n.call(x):(o=x==null?void 0:x.hide)==null||o.call(x)}catch(i){console.warn("[LiveServer] recreateSideButton",i)}}function We(e){var r,n;let t=!!e;try{if(Xo(),document.body.classList.toggle("ls-server-live",t),!x&&Ut&&(x=Ut(An(t))),!x)return;let o=t?"\u25CF Live Server":"Live Server";try{typeof x.setText=="function"&&x.setText(o),"text"in x&&(x.text=o),x.$text&&(x.$text.textContent=o)}catch{}let i=Yo();if(!(i?Zo(i,t):!1)){wi(t);return}Ko()?(r=x.show)==null||r.call(x):(n=x.hide)==null||n.call(x)}catch(o){console.warn("[LiveServer] setLiveDot",o)}}async function ki(){let t=B().running?["stop","Stop live server"]:["start","Start live server"],r=await yi("Live Server",[t,["restart","Restart server"],["port","Change port"],["root","Select root folder"],["browser","Open browser"],["deps","Check dependencies"],["settings","Settings"]],{hideOnSelect:!0});if(r){try{if(r==="start"){let{startServer:n}=await Promise.resolve().then(()=>(W(),Z));await n()}else if(r==="stop"){let{stopServer:n}=await Promise.resolve().then(()=>(W(),Z));await n()}else if(r==="restart"){let{restartServer:n}=await Promise.resolve().then(()=>(W(),Z));await n()}else if(r==="port"){let{changePortAndRestart:n}=await Promise.resolve().then(()=>(W(),Z));await n()}else if(r==="root"){let{pickRootFolder:n}=await Promise.resolve().then(()=>(nt(),Tt));await n()}else if(r==="browser"){let{openBrowser:n}=await Promise.resolve().then(()=>(Ue(),Fe)),o=B().url||"http://127.0.0.1:"+(B().port||8080)+"/";n(o,{restoreOnly:!0})}else if(r==="deps"){let{checkDependenciesAction:n}=await Promise.resolve().then(()=>(et(),nr));await n()}else if(r==="settings"){let{openSettingsHub:n}=await Promise.resolve().then(()=>($t(),ur));n()}}catch(n){xi(String((n==null?void 0:n.message)||n),2500)}We(B().running)}}function Tn(){if(C().showSideButton!==!1){Xo();try{let e=B().running;!x&&Ut&&(x=Ut(An(e))),We(e)}catch(e){console.warn("[LiveServer] side button",e)}}}function Pn(){We(B().running)}function Rn(){var e;try{(e=x==null?void 0:x.hide)==null||e.call(x)}catch{}x=null,document.body.classList.remove("ls-server-live")}var Ut,yi,xi,x,Mn=_(()=>{oe();be();te();Ut=acode.require("sideButton"),yi=acode.require("select"),xi=acode.require("toast"),x=null});function Qo(){let e=[];return Wt.forEach(t=>{e.includes(t.category)||e.push(t.category)}),e}function Be(e){let t=C();return t[e]!==void 0?t[e]:St[e]}function es(e){if(e.checkbox||e.noValue)return"";let t=Be(e.key);if(e.select){let n=e.select.find(o=>String(Array.isArray(o)?o[0]:o)===String(t));return n?Array.isArray(n)?n[1]:n:String(t!=null?t:"")}if(e.secret)return t?"\u2022\u2022\u2022\u2022\u2022\u2022":"";let r=t==null?"":String(t);return r.length>28?r.slice(0,27)+"\u2026":r}async function Ei(e){try{if(e==="start")return(await Promise.resolve().then(()=>(W(),Z))).startServer();if(e==="stop")return(await Promise.resolve().then(()=>(W(),Z))).stopServer();if(e==="restart")return(await Promise.resolve().then(()=>(W(),Z))).restartServer();if(e==="open"){let r=(await Promise.resolve().then(()=>(te(),Pe))).getServerStatus();return r.running?(await Promise.resolve().then(()=>(Ue(),Fe))).openBrowser(r.url||"http://127.0.0.1:"+r.port+"/",{restoreOnly:!0}):Oe("Server is not running",2e3)}if(e==="root")return(await Promise.resolve().then(()=>(nt(),Tt))).pickRootFolder();if(e==="status"){let r=(await Promise.resolve().then(()=>(te(),Pe))).getServerStatus();return Oe(r.running?(r.url||"")+" \u2014 port "+r.port:"Not running",3e3)}if(e==="deps")return(await Promise.resolve().then(()=>(et(),nr))).checkDependenciesAction();if(e==="reinstall")return(await Promise.resolve().then(()=>(et(),nr))).reinstallDependenciesAction()}catch(t){Oe(String((t==null?void 0:t.message)||t),3e3)}}async function Vt(e,t){if(e==="__action")return await Ei(t),!0;if(e==="__browserAction"){try{t==="clearHistory"?((await Promise.resolve().then(()=>(dn(),go))).clearVisited(),Oe("Browser history cleared",1800)):t==="clearBookmarks"&&($("browserBookmarks",[]),Oe("Bookmarks cleared",1800))}catch(n){Oe(String((n==null?void 0:n.message)||n),2500)}return!0}let r=t;if(e==="port"){let n=parseInt(String(t),10);if(!Number.isFinite(n)||n<1||n>65535)return Oe("Invalid port",1800),!1;r=n}else if(e==="autoShutdownMinutes"){let n=parseInt(String(t),10);if(!Number.isFinite(n)||n<0)return Oe("Invalid number",1800),!1;r=n}else if(e==="browserOpacity"){let n=parseFloat(String(t));r=Number.isFinite(n)?Math.min(1,Math.max(.1,Math.round(n*100)/100)):1}if($(e,r),e==="showSideButton")try{let n=await Promise.resolve().then(()=>(Mn(),Jo));r===!1?n.unregisterSideButton():n.registerSideButton()}catch{}return!0}function ts(){return{list:Wt.map(t=>{let r={key:t.key,text:t.text,category:t.category};return t.info&&(r.info=t.info),t.checkbox?(r.checkbox=!0,r.value=!!Be(t.key)):t.select?(r.select=t.select,t.noValue?(r.value="",r.valueText=()=>"Choose\u2026"):r.value=t.asString?String(Be(t.key)):Be(t.key)):t.prompt&&(r.prompt=t.prompt,t.promptType&&(r.promptType=t.promptType),r.value=Be(t.key),t.secret&&(r.valueText=n=>n?"\u2022\u2022\u2022\u2022\u2022\u2022":"")),r}),cb:(t,r)=>{Vt(t,r)}}}var Oe,Si,Wt,Hn=_(()=>{Tr();oe();Oe=acode.require("toast"),Si=[["start","Start server"],["stop","Stop server"],["restart","Restart server"],["open","Open browser"],["root","Select root folder"],["status","Show server status"],["deps","Check dependencies"],["reinstall","Reinstall dependencies"]],Wt=[{key:"__action",category:"Actions",text:"Run action",info:"Start / stop / open browser / dependencies",select:Si,noValue:!0},{key:"port",category:"General",text:"Port",info:"Default 8080",prompt:"Port number",promptType:"number"},{key:"bindAddress",category:"General",text:"Bind address",select:[["127.0.0.1","Localhost only (127.0.0.1)"],["0.0.0.0","All interfaces (0.0.0.0)"]]},{key:"rootFolder",category:"General",text:"Root folder",info:"Empty = folder of the active HTML file",prompt:"Absolute folder path",promptType:"text"},{key:"liveReload",category:"General",text:"Live reload on save",checkbox:!0},{key:"openBrowserOnStart",category:"General",text:"Open browser on start",checkbox:!0},{key:"autoShutdownMinutes",category:"General",text:"Auto shutdown (minutes)",info:"0 = off",prompt:"Minutes (0 = off)",promptType:"number"},{key:"browserDisplayMode",category:"Browser",text:"Show browser in",info:"Acode page or editor tab",select:[["inPage","Acode page (default)"],["editorTab","Editor tab"]]},{key:"browserSearchEngine",category:"Browser",text:"Search engine",info:"Used when searching keywords in address bar or New Tab",select:[["google","Google"],["duckduckgo","DuckDuckGo"],["bing","Bing"],["brave","Brave Search"]]},{key:"externalSiteMode",category:"Browser",text:"External websites",info:"Local Node.js Reverse Proxy loads sites directly inside browser tabs",select:[["proxy","Local Node.js Reverse Proxy (Default)"],["acodeWebview","Acode Native WebView (Fullscreen)"],["inApp","Direct iframe (without proxy)"],["systemBrowser","Chrome / External system browser"]]},{key:"browserHomeUrl",category:"Browser",text:"Home button URL",info:"Empty = Live Server root URL",prompt:"Home URL (leave empty for server root)",promptType:"text"},{key:"browserOpacity",category:"Browser",text:"Browser opacity",info:"0.1 - 1.0 (page mode)",asString:!0,select:["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1"].map(e=>[e,e])},{key:"browserOverlay",category:"Browser",text:"Preview as overlay",info:"See-through preview over the editor; you can still type in the editor",checkbox:!0},{key:"overlayAutoSave",category:"Browser",text:"Auto-save in overlay mode",info:"Saves the file after you stop typing so the preview updates live",checkbox:!0},{key:"showAddressBar",category:"Browser",text:"Show address bar",checkbox:!0},{key:"showSideButton",category:"Browser",text:"Show side button",checkbox:!0},{key:"__browserAction",category:"Browser",text:"Browser data",info:"Clear recent history or saved bookmarks",select:[["clearHistory","Clear recent history"],["clearBookmarks","Clear all bookmarks"]],noValue:!0},{key:"directoryListing",category:"HTML / static",text:"Enable directory listing",checkbox:!0},{key:"enableCors",category:"HTML / static",text:"Enable CORS",checkbox:!0},{key:"customCharset",category:"HTML / static",text:"Custom charset",prompt:"Charset",promptType:"text"},{key:"customHeaders",category:"HTML / static",text:"Custom response headers",info:'One "Header: value" per line',prompt:"Custom headers",promptType:"textarea"},{key:"bindLocalhostOnly",category:"Security",text:"Prefer localhost bind",checkbox:!0},{key:"ipWhitelist",category:"Security",text:"Client IP whitelist",info:"Comma or newline separated; empty = all",prompt:"IP whitelist",promptType:"textarea"},{key:"basicAuthUser",category:"Security",text:"Basic auth user",prompt:"User name",promptType:"text"},{key:"basicAuthPass",category:"Security",text:"Basic auth password",prompt:"Password",promptType:"text",secret:!0}]});var ur={};pe(ur,{openSettingsHub:()=>Oi,registerPluginSettings:()=>as});function Pi(){if(document.getElementById("ls-settings-css"))return;let e=document.createElement("style");e.id="ls-settings-css",e.textContent=Ti,document.head.appendChild(e)}function Le(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.textContent=r),n}function ss(e,t,r,n){let o=Le("div","ls-set-row");o.setAttribute("role","button"),o.tabIndex=0;let i=Le("div","ls-set-main");return i.appendChild(Le("div","ls-set-title",e)),t&&i.appendChild(Le("div","ls-set-info",t)),o.appendChild(i),r&&o.appendChild(r),o.addEventListener("click",n),o}function is(){let e=Le("span","ls-set-chev");return e.innerHTML=Ot(Ai,16),e}async function Ri(e,t){let r=Be(e.key);if(e.checkbox)return await Vt(e.key,!r),t();if(e.select){let n=await Ci(e.text,e.select,{hideOnSelect:!0,default:e.noValue?void 0:String(r)});n!=null&&(await Vt(e.key,n),t());return}if(e.prompt){let n=e.promptType==="number"?"number":e.promptType==="textarea"?"textarea":"text",o=await _i(e.prompt,r==null?"":String(r),n);o!=null&&(await Vt(e.key,o),t())}}function Mi(e,t){e.textContent="",Qo().forEach(r=>{let n=Wt.filter(o=>o.category===r).length;e.appendChild(ss(r,n+" options",is(),()=>t(r)))})}function Hi(e,t,r){e.textContent="",Wt.filter(n=>n.category===t).forEach(n=>{let o=null;if(n.checkbox)o=Le("span","ls-set-switch"+(Be(n.key)?" is-on":""));else{o=Le("span"),o.style.cssText="display:flex;align-items:center;gap:6px;min-width:0;max-width:50%";let i=es(n);i&&o.appendChild(Le("span","ls-set-val",i)),o.appendChild(is())}e.appendChild(ss(n.text,n.info,o,()=>Ri(n,r)))})}function os(e,t,r){var u,a;Pi();let n=document.createElement("span");n.className="icon arrow_back",n.dataset.action="back",n.style.cssText="pointer-events:auto;cursor:pointer;";let o=Li(e,{lead:n}),i=Le("div","ls-set-body");try{o.appendBody(i)}catch{(u=o.appendChild)==null||u.call(o,i)}let s=()=>t(i,s),c=()=>{var p,h;try{rs.remove(r)}catch{}try{(p=o.hide)==null||p.call(o)}catch{}try{(h=o.remove)==null||h.call(o)}catch{}};n.onclick=p=>{var h,m;try{(h=p==null?void 0:p.preventDefault)==null||h.call(p),(m=p==null?void 0:p.stopPropagation)==null||m.call(p)}catch{}c()};try{rs.push({id:r,action:c})}catch{}s();try{(window.app||document.body).append(o)}catch{document.body.append(o)}try{(a=o.show)==null||a.call(o)}catch{}}function Oi(){os("Live Server",e=>Mi(e,t=>os(t,(r,n)=>Hi(r,t,n),ns+t)),ns+"hub")}function as(){}var Li,rs,Ci,_i,ns,Ai,Ti,$t=_(()=>{Hn();un();Li=acode.require("page"),rs=acode.require("actionStack"),Ci=acode.require("select"),_i=acode.require("prompt"),ns="liveserver-settings-",Ai="M9 18l6-6-6-6",Ti=`
.ls-set-body{height:100%;overflow:auto;padding:4px 0 24px}
.ls-set-row{display:flex;align-items:center;gap:12px;padding:12px 16px;cursor:pointer;border-bottom:1px solid rgba(128,128,128,.15)}
.ls-set-row:active{background:rgba(128,128,128,.14)}
.ls-set-main{flex:1;min-width:0}
.ls-set-title{font-size:15px}
.ls-set-info{font-size:12px;opacity:.65;margin-top:2px}
.ls-set-val{max-width:45%;font-size:12px;opacity:.75;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ls-set-chev{display:inline-flex;opacity:.55;flex-shrink:0}
.ls-set-switch{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0}
.ls-set-switch::before{content:'';position:absolute;inset:0;border-radius:3px;background:rgba(128,128,128,.45);transition:background .15s}
.ls-set-switch::after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:3px;background:#fff;transition:transform .15s}
.ls-set-switch.is-on::before{background:var(--active-color,#61afef)}
.ls-set-switch.is-on::after{transform:translateX(18px)}
`});var Ar={id:"acode.plugin.sugerserver",name:"Live Server",main:"main.js",version:"2.0.0",readme:"readme.md",icon:"icon.png",files:["acodels/","devtool/","icon.png","readme.md"],minVersionCode:290,license:"",changelogs:"changelogs.md",keywords:["Live Server","HTML","HTTP","browser","preview"],price:25,repository:"",author:{name:"Dev.Sourav",email:"devs.sourav@gmail.com",github:"Sou6900"}};$t();Mn();be();var On=acode.require("toast"),Bn=[];function ls(){try{let e=acode.require("commands");if(!(e!=null&&e.add))return;let t=(r,n,o)=>{try{e.add({name:r,description:n,exec:o}),Bn.push(r)}catch{}};t("liveserver:run-file","Live Server: Run this file in HTTP server",async()=>{if(!G())return On("Open a file in the editor first",2e3);let{startServer:n}=await Promise.resolve().then(()=>(W(),Z));await n()}),t("liveserver:select-root","Live Server: Select root folder",async()=>{let{pickRootFolder:r}=await Promise.resolve().then(()=>(nt(),Tt));await r()}),t("liveserver:run-selected-root","Live Server: Run HTTP server for selected / saved root",async()=>{let{startServer:r}=await Promise.resolve().then(()=>(W(),Z)),{getSettings:n}=await Promise.resolve().then(()=>(oe(),Rr)),{rootFromSelectedFolder:o}=await Promise.resolve().then(()=>(nt(),Tt)),i=n().rootFolder||o();if(!i)return On("Select a root folder first (command: Select root folder)",3e3);await r({root:i})}),t("liveserver:stop","Live Server: Stop server",async()=>{let{stopServer:r}=await Promise.resolve().then(()=>(W(),Z));await r()}),t("liveserver:restart","Live Server: Restart server",async()=>{let{restartServer:r}=await Promise.resolve().then(()=>(W(),Z));await r()}),t("liveserver:open-browser","Live Server: Open browser",async()=>{let{getServerStatus:r}=await Promise.resolve().then(()=>(te(),Pe)),{openBrowser:n}=await Promise.resolve().then(()=>(Ue(),Fe)),o=r();if(!o.running)return On("Server is not running",2e3);n(o.url||`http://127.0.0.1:${o.port}/`,{restoreOnly:!0})}),t("liveserver:settings","Live Server: Open settings",async()=>{let{openSettingsHub:r}=await Promise.resolve().then(()=>($t(),ur));r()})}catch(e){console.warn("[LiveServer] commands",e)}}function cs(){try{let e=acode.require("commands");Bn.forEach(t=>{var r;try{(r=e==null?void 0:e.remove)==null||r.call(e,t)}catch{}})}catch{}Bn=[]}Ur();be();be();W();var ds=acode.require("toast"),Dn=!1;async function ps(e){var t;if(Dn)return!1;Dn=!0;try{let r=e||G();if(!ve(r))return ds("Open an .html / .htm file first",2e3),!1;if(r.isUnsaved&&(r.uri||r.url))try{await((t=r.save)==null?void 0:t.call(r))}catch(n){console.warn("[LiveServer] save before run",n)}return await Ft({openBrowser:!0})}catch(r){return ds(String((r==null?void 0:r.message)||r),3e3),!1}finally{Dn=!1}}var z=null,Sr=null,In=!1;function Bi(){if(document.getElementById("ls-run-css"))return;let e=document.createElement("style");e.id="ls-run-css",e.textContent=`
    body.ls-html-file #root > header.tile > [action="run"]:not([data-ls-run]) {
      display: none !important;
    }
  `,document.head.appendChild(e)}var us="#root > header.tile";function Di(){return document.querySelector(`${us} > span.icon.play_arrow[action="run"]`)||document.querySelector('[action="run"]:not([data-ls-run])')}async function Ii(e){var t;if(e.preventDefault(),e.stopPropagation(),!In){In=!0;try{let r=G()||((t=window.editorManager)==null?void 0:t.activeFile);await ps(r)}catch(r){console.error("[LiveServer] runPreview failed:",r);try{acode.require("toast")((r==null?void 0:r.message)||"Failed to launch Live Server")}catch{}}finally{In=!1}}}function fe(){var o;Bi();let e=G()||((o=window.editorManager)==null?void 0:o.activeFile),t=ve(e);if(document.body.classList.toggle("ls-html-file",t),!t){z!=null&&z.isConnected&&z.remove();return}z||(z=document.createElement("span"),z.className="icon play_arrow",z.setAttribute("action","run-live-server"),z.setAttribute("data-ls-run","1"),z.setAttribute("title","Run with Live Server"),z.onclick=Ii),z.className="icon play_arrow";let r=Di(),n=document.querySelector(us);r&&r.parentNode?(z.parentNode!==r.parentNode||z.nextSibling!==r)&&r.parentNode.insertBefore(z,r):n&&!z.isConnected&&n.insertBefore(z,n.lastChild)}function fs(){fe(),window.editorManager&&(editorManager.off("switch-file",fe),editorManager.off("rename-file",fe),editorManager.on("switch-file",fe),editorManager.on("rename-file",fe)),clearInterval(Sr),Sr=setInterval(fe,1500)}function hs(){var e;clearInterval(Sr),Sr=null,window.editorManager&&(editorManager.off("switch-file",fe),editorManager.off("rename-file",fe));try{z==null||z.remove()}catch{}z=null,document.body.classList.remove("ls-html-file"),(e=document.getElementById("ls-run-css"))==null||e.remove()}et();W();te();oe();te();be();var vt=null;function ms(){var e;if(!vt){vt=async t=>{try{if(C().liveReload===!1)return;let r=B();if(!r.running||!r.port)return;await fetch(`http://127.0.0.1:${r.port}/reload`,{method:"POST"}).catch(()=>{}),(ve(t)||ve(editorManager==null?void 0:editorManager.activeFile))&&console.log("[LiveServer] reload signal after save")}catch(r){console.warn("[LiveServer] save reload",r)}};try{(e=editorManager==null?void 0:editorManager.on)==null||e.call(editorManager,"save-file",vt)}catch{}}}function gs(){var e;try{vt&&((e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"save-file",vt))}catch{}vt=null}var $n=null;function vs(){$n&&($n(!1),$n=null)}zr();var bs=["switch-file","rename-file","file-loaded","new-file"],Er="",Gt=null,Ve=null,Xt=null;async function ys(e){Er=e||"",Ln(Er),co(Er),Ir();try{let{getSettings:r,updateSetting:n}=await Promise.resolve().then(()=>(oe(),Rr)),o=r().acodelsPath||"";/^\/public|com\.termux/.test(String(o))&&n("acodelsPath","")}catch{}try{}catch(r){console.warn("[LiveServer] settings",r)}try{Tn()}catch(r){console.warn("[LiveServer] side",r)}try{ls()}catch(r){console.warn("[LiveServer] commands",r)}try{ms()}catch(r){console.warn("[LiveServer] liveReload",r)}try{fs()}catch(r){console.warn("[LiveServer] run button",r)}Gt=()=>{Pn(),fe()},bs.forEach(r=>{var n;try{(n=editorManager==null?void 0:editorManager.on)==null||n.call(editorManager,r,Gt)}catch{}}),Ve=()=>We(B().running);try{window.addEventListener("liveserver-status",Ve),window.addEventListener("liveserver-started",Ve),window.addEventListener("liveserver-stopped",Ve)}catch{}let t=async()=>{let r=await _n();We(r)};t(),setTimeout(t,1200),setTimeout(Gt,400),Xt=()=>{document.visibilityState==="visible"&&t()},document.addEventListener("visibilitychange",Xt);try{window.addEventListener("liveserver-settings",async()=>{try{let{reapplySetup:r}=await Promise.resolve().then(()=>(W(),Z));B().running&&await r()}catch{}})}catch{}console.log("[LiveServer] v2 init",Er)}function xs(){bs.forEach(e=>{var t;try{Gt&&((t=editorManager==null?void 0:editorManager.off)==null||t.call(editorManager,e,Gt))}catch{}});try{hs()}catch{}try{window.removeEventListener("liveserver-status",Ve),window.removeEventListener("liveserver-started",Ve),window.removeEventListener("liveserver-stopped",Ve)}catch{}Xt&&(document.removeEventListener("visibilitychange",Xt),Xt=null),vs(),no(),Rn(),cs();try{gs()}catch{}try{Promise.resolve().then(()=>(Ue(),Fe)).then(e=>{var t;return(t=e.hideBrowser)==null?void 0:t.call(e)})}catch{}try{Promise.resolve().then(()=>(yn(),Do)).then(e=>{var t;return(t=e.destroyAcodeWebview)==null?void 0:t.call(e)})}catch{}}Hn();var Lr=class{constructor(){this.baseUrl=""}async init(t){var r;this.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await ys(this.baseUrl)}async destroy(){xs()}};if(window.acode){let e=new Lr;acode.setPluginInit(Ar.id,async t=>{var r;e.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await e.init(e.baseUrl)},ts()),acode.setPluginUnmount(Ar.id,()=>{e.destroy()})}var jl=Lr;})();
