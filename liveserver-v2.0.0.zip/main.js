(()=>{var ti=Object.defineProperty;var T=(e,t)=>()=>(e&&(t=e(e=0)),t);var xe=(e,t)=>{for(var r in t)ti(e,r,{get:t[r],enumerable:!0})};var Pt,Gr=T(()=>{Pt={pluginEnabled:!0,port:8080,bindAddress:"127.0.0.1",rootFolder:"",rootFolderUri:"",lastMirrorRoot:"",liveReload:!0,openBrowserOnStart:!0,directoryListing:!0,autoShutdownMinutes:0,browserDisplayMode:"inPage",browserSearchEngine:"google",externalSiteMode:"proxy",browserHomeUrl:"",showSideButton:!0,sideButtonRunningLabel:"{HOST}:{PORT}",sideButtonOfflineLabel:"Go Live",browserOpacity:1,browserOverlay:!1,overlayAutoSave:!0,browserBookmarks:[],browserDevice:{on:!1,id:"responsive",w:390,h:844,zoom:"fit"},enableCors:!0,customHeaders:"",customCharset:"utf-8",bindLocalhostOnly:!0,ipWhitelist:"",basicAuthUser:"",basicAuthPass:"",dependenciesInstalled:!1,acodelsPath:"",showAddressBar:!0}});var Mt={};xe(Mt,{getPluginId:()=>ni,getSettings:()=>k,saveSettingsPatch:()=>oi,updateSetting:()=>O});function ni(){return Xr}function k(){var e;try{let t=acode.require("settings"),r=(e=t==null?void 0:t.value)==null?void 0:e[Xr];return(!r||typeof r!="object")&&(r={...Pt},t!=null&&t.value&&(t.value[Xr]=r)),r}catch{return{...Pt}}}function O(e,t){let r=k();r[e]=t;try{acode.require("settings").update(!1)}catch{}try{window.dispatchEvent(new CustomEvent("liveserver-settings",{detail:{key:e,value:t}}))}catch{}}function oi(e){let t=k();Object.assign(t,e);try{acode.require("settings").update(!1)}catch{}}var Xr,ne=T(()=>{Gr();Xr="acode.plugin.sugerserver"});function Ee(e){return String(e!=null?e:"").replace(/'/g,`'"'"'`)}function Vr(e){let t=String(e||"").trim();return t?/^sh\s+-c\s+/i.test(t)?t:`sh -c '${Ee(t)}'`:"sh -c 'true'"}function Ot(e){return String(e||"").split(`
`).filter(t=>!/proot warning:/i.test(t)).join(`
`)}function uo(e){if(e==null)return"";if(typeof e=="string")return Ot(e);if(typeof e=="object"){let t=[e.stdout,e.stderr,e.output,e.message].filter(r=>r!=null&&r!=="").map(String);if(t.length)return Ot(t.join(`
`));try{return Ot(JSON.stringify(e))}catch{return Ot(String(e))}}return Ot(String(e))}function Yr(e){try{return btoa(unescape(encodeURIComponent(e)))}catch{let r=new TextEncoder().encode(e),n="";return r.forEach(o=>{n+=String.fromCharCode(o)}),btoa(n)}}function lt(){try{let e=acode.require("terminal"),t=typeof Executor!="undefined"&&Executor||window.Executor||globalThis.Executor||(e==null?void 0:e.Executor)||null;if(t!=null&&t.execute)return t}catch{}return null}async function ee(e,t={}){let r=typeof t=="number"?t:t.timeoutMs||0,n=typeof t=="object"&&t.alpine!==!1,o=lt();if(!(o!=null&&o.execute))throw console.warn("[LiveServer:exec] no executor",{hasWindow:!!window.Executor,hasGlobal:!!globalThis.Executor,hasTerminal:!!acode.require("terminal")}),new Error("Executor not available. Open Acode Terminal once (or install Executor), then retry.");let s=Vr(e);console.log("[LiveServer:exec] run len=",s.length);let i=async()=>{try{let c=await o.execute(s,n),p=uo(c);return console.log("[LiveServer:exec] ok len=",p.length),p}catch(c){let p=uo(c)||c&&c.message||String(c);return console.warn("[LiveServer:exec] catch \u2192",String(p).slice(0,240)),p}};return r>0?Promise.race([i(),new Promise(c=>setTimeout(()=>{console.warn("[LiveServer:exec] timeout",r,"ms \u2014 continuing"),c("")},r))]):i()}async function Ht(e,t={}){let r=Yr(String(e||""));return ee(`echo '${Ee(r)}' | base64 -d | sh`,{timeoutMs:t.timeoutMs||0,alpine:t.alpine!==!1})}async function Kr(e){try{let t=await ee(`command -v ${Ee(e)} 2>/dev/null || which ${Ee(e)} 2>/dev/null || echo MISS`,{timeoutMs:2e4}),r=String(t||"").trim();return!r||/MISS|not found/i.test(r)?!1:/\//.test(r)||r.split(`
`).some(n=>n.includes("/"))}catch(t){return console.warn("[LiveServer:exec] commandExists",e,(t==null?void 0:t.message)||t),!1}}var ct=T(()=>{});function po(){let e=document.getElementById("ls-deps-picker-css");e&&e.remove();let t=document.createElement("style");t.id="ls-deps-picker-css",t.textContent=`
#ls-deps-picker {
  position: fixed;
  inset: 0;
  z-index: 100005;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background: rgba(0, 0, 0, 0.56);
  backdrop-filter: blur(3px);
  animation: ls-dp-in 0.18s ease-out;
}
@keyframes ls-dp-in {
  from { opacity: 0; }
  to { opacity: 1; }
}
#ls-deps-picker.ls-dp-leaving {
  opacity: 0;
  transition: opacity 0.16s ease;
}
.ls-dp-backdrop {
  position: absolute;
  inset: 0;
}
.ls-dp-card {
  position: relative;
  z-index: 1;
  width: min(440px, 94vw);
  max-height: min(82vh, 580px);
  display: flex;
  flex-direction: column;
  border-radius: 8px;
  background: var(--popup-background-color, var(--secondary-color, #1e1f22));
  color: var(--popup-text-color, var(--primary-text-color, var(--color, #e8eaed)));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.28));
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.52);
  overflow: hidden;
  font-family: inherit;
}

/* ---- Linux Window Titlebar ---- */
.ls-dp-titlebar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.24));
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-title-left {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}
.ls-dp-dots {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex-shrink: 0;
}
.ls-dp-dots span {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  display: inline-block;
}
.ls-dp-dots span:nth-child(1) { background: #ef4444; }
.ls-dp-dots span:nth-child(2) { background: #f59e0b; }
.ls-dp-dots span:nth-child(3) { background: #22c55e; }
.ls-dp-title {
  font-weight: 600;
  font-size: 14px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ls-dp-subbar {
  padding: 8px 16px;
  font-size: 12px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.85;
  background: rgba(128, 128, 128, 0.06);
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.16));
  flex-shrink: 0;
}

/* ---- Body ---- */
.ls-dp-body {
  flex: 1;
  overflow-y: auto;
  padding: 12px 15px;
  min-height: 90px;
}
.ls-dp-checking {
  display: flex;
  align-items: center;
  gap: 10px;
  justify-content: center;
  padding: 26px 8px;
  font-size: 13px;
}
.ls-dp-spinner {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid rgba(128, 128, 128, 0.3);
  border-top-color: var(--active-color, #22c55e);
  animation: ls-spin 0.7s linear infinite;
  flex-shrink: 0;
}
@keyframes ls-spin {
  to { transform: rotate(360deg); }
}

/* ---- Package Rows ---- */
.ls-dp-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 11px;
  border-radius: 6px;
  margin-bottom: 7px;
  background: var(--primary-color, rgba(128, 128, 128, 0.1));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
  cursor: pointer;
  transition: border-color 0.15s ease;
}
.ls-dp-row:last-child {
  margin-bottom: 0;
}
.ls-dp-row.is-present {
  opacity: 0.78;
  cursor: default;
}
.ls-dp-row input[type="checkbox"] {
  width: 1.12rem;
  height: 1.12rem;
  flex-shrink: 0;
  accent-color: var(--active-color, #22c55e);
}
.ls-dp-row-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.ls-dp-name {
  font-weight: 600;
  font-size: 13px;
}
.ls-dp-desc {
  font-size: 11.5px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.75;
  word-break: break-word;
}
.ls-dp-status {
  font-size: 11px;
  flex-shrink: 0;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 4px;
}
.ls-dp-status.ok {
  background: rgba(34, 197, 94, 0.16);
  color: #4ade80;
}
.ls-dp-status.miss {
  background: rgba(239, 68, 68, 0.16);
  color: #f87171;
}
.ls-dp-status.opt {
  background: rgba(128, 128, 128, 0.18);
  color: var(--secondary-text-color, #9aa0a6);
}

/* ---- Linux Installation Progress View ---- */
.ls-dp-progress {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ls-dp-warn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 11px;
  border-radius: 5px;
  background: rgba(245, 158, 11, 0.14);
  border: 1px solid rgba(245, 158, 11, 0.35);
  color: #fbbf24;
  font-size: 12px;
  font-weight: 500;
}
.ls-dp-prog-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  font-size: 12.5px;
}
.ls-dp-progress-info {
  opacity: 0.92;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ls-dp-pct {
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  color: var(--active-color, #22c55e);
  flex-shrink: 0;
}
.ls-dp-progress-track {
  width: 100%;
  height: 8px;
  border-radius: 99px;
  background: var(--primary-color, rgba(128, 128, 128, 0.25));
  overflow: hidden;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
}
.ls-dp-progress-bar {
  height: 100%;
  width: 0%;
  border-radius: 99px;
  background: var(--active-color, #22c55e);
  transition: width 0.28s ease;
}
.ls-dp-link {
  align-self: flex-start;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  color: var(--active-color, #61afef);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  padding: 2px 0;
  font-family: inherit;
}
.ls-dp-log {
  margin: 0;
  max-height: 155px;
  overflow-y: auto;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 11px;
  line-height: 1.4;
  background: #0d1117;
  color: #c9d1d9;
  padding: 10px;
  border-radius: 5px;
  white-space: pre-wrap;
  word-break: break-word;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.25));
}

/* ---- Footer ---- */
.ls-dp-footer {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.18));
  border-top: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-btn {
  border: none;
  border-radius: 5px;
  padding: 8px 14px;
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  background: rgba(128, 128, 128, 0.22);
  color: inherit;
  font-family: inherit;
}
.ls-dp-btn:active {
  opacity: 0.85;
}
.ls-dp-btn.ls-dp-install,
.ls-dp-btn.ls-dp-done {
  background: var(--active-color, #22c55e);
  color: var(--button-text-color, #0b1116);
}
.ls-dp-btn.ls-dp-cancel {
  background: rgba(239, 68, 68, 0.18);
  color: #f87171;
  border: 1px solid rgba(239, 68, 68, 0.38);
}
.ls-dp-empty {
  opacity: 0.7;
  padding: 14px;
  text-align: center;
  font-size: 13px;
}
  `,document.head.appendChild(t)}var fo=T(()=>{});function Bt(e){return String(e!=null?e:"").replace(/&/g,"&").replace(/</g,"<").replace(/>/g,">").replace(/"/g,'"')}function mo(){return!!H}function Zr(){return Dt}function go(){Dt=!1}function vo(e={}){po(),ho(!0),Dt=!1;let t=e.title||"Live Server Dependencies",r=e.subtitle||"Checking Alpine Linux packages...",n=Array.isArray(e.items)?e.items.slice():[];return new Promise(o=>{dt=o,H=document.createElement("div"),H.id="ls-deps-picker",H.innerHTML=`
      <div class="ls-dp-backdrop"></div>
      <div class="ls-dp-card" role="dialog" aria-modal="true">
        <div class="ls-dp-titlebar">
          <div class="ls-dp-title-left">
            <span class="ls-dp-dots"><span></span><span></span><span></span></span>
            <div class="ls-dp-title">${Bt(t)}</div>
          </div>
        </div>
        <div class="ls-dp-subbar ls-dp-subtitle">${Bt(r)}</div>

        <div class="ls-dp-body">
          <div class="ls-dp-checking" style="display:${e.checking?"flex":"none"}">
            <span class="ls-dp-spinner"></span>
            <span>Scanning Alpine environment...</span>
          </div>

          <div class="ls-dp-lists" style="display:${e.checking?"none":"block"}"></div>

          <div class="ls-dp-progress" style="display:none">
            <div class="ls-dp-warn">
              <span>\u26A0</span>
              <span>Don't close Acode while packages are installing.</span>
            </div>

            <div class="ls-dp-prog-top">
              <div class="ls-dp-progress-info">Preparing installation...</div>
              <span class="ls-dp-pct">0%</span>
            </div>

            <div class="ls-dp-progress-track">
              <div class="ls-dp-progress-bar" style="width:0%"></div>
            </div>

            <button type="button" class="ls-dp-link ls-dp-toggle-log">
              <span class="ls-dp-arrow">\u25B8</span>
              <span class="ls-dp-more-label">Show more</span>
            </button>
            <pre class="ls-dp-log" style="display:none"></pre>
          </div>
        </div>

        <div class="ls-dp-footer">
          <button type="button" class="ls-dp-btn ls-dp-notnow">Not now</button>
          <button type="button" class="ls-dp-btn ls-dp-cancel" style="display:none">Cancel installation</button>
          <button type="button" class="ls-dp-btn ls-dp-install">Install selected</button>
          <button type="button" class="ls-dp-btn ls-dp-done" style="display:none">Close</button>
        </div>
      </div>`,document.body.appendChild(H);let s=H.querySelector(".ls-dp-lists"),i=H.querySelector(".ls-dp-checking"),c=H.querySelector(".ls-dp-progress"),p=H.querySelector(".ls-dp-progress-bar"),l=H.querySelector(".ls-dp-pct"),d=H.querySelector(".ls-dp-progress-info"),f=H.querySelector(".ls-dp-log"),g=H.querySelector(".ls-dp-install"),a=H.querySelector(".ls-dp-notnow"),m=H.querySelector(".ls-dp-cancel"),b=H.querySelector(".ls-dp-done"),L=H.querySelector(".ls-dp-toggle-log"),S=H.querySelector(".ls-dp-arrow"),_=H.querySelector(".ls-dp-more-label"),P=H.querySelector(".ls-dp-subtitle"),C=H.querySelector(".ls-dp-backdrop");function v(){if(!s)return;let h="";for(let y of n){let te=y.present?'<span class="ls-dp-status ok">installed</span>':y.optional?'<span class="ls-dp-status opt">optional</span>':'<span class="ls-dp-status miss">missing</span>',be=y.checked!=null?!!y.checked:!y.present&&!y.optional;h+=`<label class="ls-dp-row ${y.present?"is-present":"is-missing"}">
          <input type="checkbox" data-id="${Bt(y.id)}" ${be?"checked":""} ${y.present?"disabled":""}/>
          <span class="ls-dp-row-main">
            <span class="ls-dp-name">${Bt(y.label)}</span>
            <span class="ls-dp-desc">${Bt(y.desc||"")}</span>
          </span>${te}</label>`}s.innerHTML=h||'<div class="ls-dp-empty">No items</div>'}function M(){let h=[];return H==null||H.querySelectorAll("input[type=checkbox][data-id]:checked:not(:disabled)").forEach(y=>h.push(y.getAttribute("data-id"))),h}function q(h){let y=M(),te=dt;dt=null,ho(!1),te&&te({action:h,selected:y})}function B(){let h=M();if(!h.length){try{acode.require("toast")("Select at least one item",2e3)}catch{}return}Dt=!1,s&&(s.style.display="none"),i&&(i.style.display="none"),c&&(c.style.display="flex"),g&&(g.style.display="none"),a&&(a.style.display="none"),m&&(m.style.display="inline-block"),b&&(b.style.display="none"),p&&(p.style.width="2%"),l&&(l.textContent="2%"),d&&(d.textContent="Initializing package installer..."),f&&(f.textContent=""),P&&(P.textContent="Installing selected packages in Alpine Linux...");let y=dt;dt=null,y&&y({action:"install",selected:h,keepOpen:!0})}g==null||g.addEventListener("click",()=>B()),a==null||a.addEventListener("click",()=>q("notnow")),m==null||m.addEventListener("click",()=>{Dt=!0,d&&(d.textContent="Cancelled"),q("cancel")}),b==null||b.addEventListener("click",()=>q("done")),C==null||C.addEventListener("click",()=>{c&&c.style.display!=="none"&&(m==null?void 0:m.style.display)!=="none"||q("close")}),L==null||L.addEventListener("click",()=>{if(!f)return;let h=f.style.display!=="none";f.style.display=h?"none":"block",S&&(S.textContent=h?"\u25B8":"\u25BE"),_&&(_.textContent=h?"Show more":"Show less"),h||(f.scrollTop=f.scrollHeight)}),H._lsDpUpdate=h=>{if(h.checking===!1&&i&&s&&(i.style.display="none",s.style.display="block"),h.checking===!0&&i&&s&&(i.style.display="flex",s.style.display="none"),h.subtitle!=null&&P&&(P.textContent=h.subtitle),Array.isArray(h.items)&&(n.length=0,h.items.forEach(y=>n.push({...y,checked:y.checked!=null?!!y.checked:!y.present&&!y.optional})),v()),h.progressMode&&(s&&(s.style.display="none"),i&&(i.style.display="none"),c&&(c.style.display="flex"),g&&(g.style.display="none"),a&&(a.style.display="none"),m&&(m.style.display=h.showDone?"none":"inline-block"),b&&(b.style.display=h.showDone?"inline-block":"none")),typeof h.percent=="number"){let y=Math.max(0,Math.min(100,Math.round(h.percent)));p&&(p.style.width=y+"%"),l&&(l.textContent=y+"%")}h.info&&d&&(d.textContent=h.info),h.logAppend&&f&&(f.textContent+=h.logAppend,f.scrollTop=f.scrollHeight),h.logSet!=null&&f&&(f.textContent=h.logSet)},v()})}function pe(e){H&&typeof H._lsDpUpdate=="function"&&H._lsDpUpdate(e)}function ho(e){if(!H)return;let t=H;H=null,dt=null;try{t.classList.add("ls-dp-leaving")}catch{}let r=()=>{try{t.remove()}catch{}};e?r():setTimeout(r,180)}var H,dt,Dt,bo=T(()=>{fo();H=null,dt=null,Dt=!1});var hr={};xe(hr,{DEP_CATALOG:()=>dr,checkDependenciesAction:()=>di,ensureLiveServerDeps:()=>fr,reinstallDependenciesAction:()=>ui,resetDepsSession:()=>en,resolveAcodelsPath:()=>ft,scanAllDeps:()=>Qr,showDepsPickerFlow:()=>pr,verifyDependencies:()=>It});async function ft(){let e=k();try{let r=await ee(`for d in /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do
  [ -f "$d/index.js" ] || continue
  if [ -d "$d/node_modules/express" ]; then echo "FULL:$d"; exit 0; fi
  echo "BARE:$d"
done
exit 0`,{timeoutMs:12e3}),n=String(r||"").split(`
`).map(p=>p.trim()).filter(Boolean),o=n.filter(p=>p.startsWith("FULL:")).map(p=>p.slice(5)),s=n.filter(p=>p.startsWith("BARE:")).map(p=>p.slice(5)),i=p=>p.filter(d=>d&&!d.startsWith("/public")).sort((d,f)=>(f.startsWith("/root")?1:0)-(d.startsWith("/root")?1:0))[0]||p.find(d=>d&&!d.startsWith("/public"))||p[0]||null,c=i(o)||i(s);if(c){try{O("acodelsPath",c)}catch{}return c}}catch(r){console.warn("[LiveServer:deps] probe",(r==null?void 0:r.message)||r)}let t=String(e.acodelsPath||"").trim();if(t&&!t.startsWith("/public")&&!t.includes("com.termux"))return t;try{t&&O("acodelsPath","")}catch{}return"/root/.acode_liveserver/acodels"}async function ii(e){try{let t=e?Ee(e):"''",r=await ee("for d in "+t+' /root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do [ -d "$d/node_modules/express" ] && [ -d "$d/node_modules/ws" ] && echo OK && exit 0; done; echo MISS',{timeoutMs:1e4});return String(r).includes("OK")}catch{return!1}}async function Qr(e){Be=e||Be;let t=await Kr("node"),r=await Kr("npm"),n=await ft(e),o=t?await ii(n):!1;return[{...dr[0],present:t},{...dr[1],present:r},{...dr[2],present:o,path:n}]}async function It(e){let t=await Qr(e),r=t.filter(n=>!n.present).map(n=>n.id);return{ok:r.length===0,missing:r,all:t}}function ai(e){return e.map(t=>({id:t.id,label:t.label,desc:t.desc+(t.path?` \u2014 ${t.path}`:""),present:t.present,optional:!1,checked:!t.present}))}async function li(){return Ht(`#!/bin/sh
set +e
echo "[pm] detecting..."
if command -v pkg >/dev/null 2>&1; then
  echo "[pm] termux pkg"
  pkg update -y 2>&1
  pkg install -y nodejs 2>&1 || pkg install -y nodejs-lts 2>&1
elif command -v apk >/dev/null 2>&1; then
  echo "[pm] apk"
  apk update 2>&1
  apk add --no-cache nodejs npm 2>&1
elif command -v apt-get >/dev/null 2>&1; then
  echo "[pm] apt"
  apt-get update -y 2>&1
  apt-get install -y nodejs npm 2>&1
else
  echo "[pm] none found"
  exit 1
fi
node -v 2>&1
npm -v 2>&1
echo "[done] node packages"
`,{timeoutMs:0})}async function ci(e){let t=`#!/bin/sh
set +e
DIR=${Ee(e)}
case "$DIR" in
  '$HOME'/*|$HOME/*) DIR="/root/.acode_liveserver/acodels" ;;
esac
if [ -z "$DIR" ] || echo "$DIR" | grep -q com.termux; then
  DIR="/root/.acode_liveserver/acodels"
fi
mkdir -p "$DIR" 2>&1
cd "$DIR" || { echo "[acodels] cd failed"; exit 1; }
if [ ! -f package.json ]; then
  cat > package.json << 'JSON'
{
  "name": "acodels",
  "version": "1.0.0",
  "main": "index.js",
  "dependencies": {
    "chokidar": "^3.5.3",
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "ws": "^8.11.0"
  }
}
JSON
fi
echo "[acodels] npm install in $DIR"
npm install --omit=dev --no-audit --no-fund 2>&1
echo "[done] acodels"
`;return Ht(t,{timeoutMs:0})}async function pr(e={}){var i,c,p;let t=e.baseUrl||Be||"";if(Be=t,ut)return Jr("Install already running...",2e3),!1;if(mo()&&!e.force||!e.force&&!e.fromSettings&&pt)return!1;if(!e.force&&!e.fromSettings&&(await It(t)).ok)return O("dependenciesInstalled",!0),!0;(i=lt())!=null&&i.execute||Jr("Open Acode Terminal once, then retry Install",3500);let r=vo({title:"Live Server Dependencies",subtitle:"Checking...",items:[],checking:!0}),n;try{n=await Qr(t)}catch(l){return pe({checking:!1,subtitle:"Check failed \u2014 "+((l==null?void 0:l.message)||l),items:[]}),await r,!1}let o=n.filter(l=>l.required!==!1&&!l.present).length;pe({checking:!1,subtitle:o===0?"All required tools present":`${o} required missing \u2014 tick what to install`,items:ai(n)});let s=await r;if(s.action==="notnow"||s.action==="close"||s.action==="cancel")return pt=!0,!1;if(s.action==="done")return(await It(t)).ok;if(s.action==="install"&&((c=s.selected)!=null&&c.length)){if(ut=!0,go(),!((p=lt())!=null&&p.execute))return pe({progressMode:!0,percent:0,info:"Executor not available",logAppend:`Open Acode Terminal once (Alpine/Termux), then open this dialog again.
`,showDone:!0}),ut=!1,!1;pe({progressMode:!0,percent:5,info:"Preparing...",logAppend:"Selected: "+s.selected.join(", ")+`
`});try{let l=await ft(t);if(s.selected.includes("node")||s.selected.includes("npm")){if(pe({percent:15,info:"Installing Node.js / npm...",logAppend:`
=== node / npm ===
`}),Zr())return ut=!1,!1;let f=await li();pe({percent:48,logAppend:String(f||"").slice(-2500)+`
`})}if(s.selected.includes("acodels")){if(pe({percent:58,info:"Installing backend modules in acodels...",logAppend:`
=== acodels @ ${l} ===
`}),Zr())return ut=!1,!1;let f=await ci(l);pe({percent:82,logAppend:String(f||"").slice(-3e3)+`
`})}let d=await It(t);return pe({progressMode:!0,percent:100,info:d.ok?"Done \u2014 all required present":"Finished \u2014 still missing: "+d.missing.join(", "),showDone:!0,logAppend:d.ok?`
OK
`:`
Missing: `+d.missing.join(", ")+`
`}),O("dependenciesInstalled",d.ok),d.ok&&(pt=!0,Jr("Dependencies ready",2500)),d.ok}catch(l){return pe({progressMode:!0,percent:100,info:"Failed",showDone:!0,logAppend:`
ERROR: `+((l==null?void 0:l.message)||l)+`
`}),!1}finally{ut=!1}}return!1}async function fr(e={}){let t=e.baseUrl||Be||"";Be=t;try{return!e.force&&pt||!e.force&&ur&&k().dependenciesInstalled===!0?!0:(ur=!0,(await It(t)).ok?(O("dependenciesInstalled",!0),!0):pr({...e,baseUrl:t}))}catch(r){return console.warn("[LiveServer:deps]",r),!1}}async function di(e){return pr({force:!0,fromSettings:!0,baseUrl:e||Be})}async function ui(e){return await si("Reinstall dependencies?","Will run pkg/apk install for Node and npm install in acodels.")?(pt=!1,ur=!1,pr({force:!0,fromSettings:!0,baseUrl:e||Be})):!1}function en(){pt=!1,ur=!1}var Jr,si,pt,ur,ut,Be,dr,ht=T(()=>{ne();ct();bo();Jr=acode.require("toast"),si=acode.require("confirm"),pt=!1,ur=!1,ut=!1,Be="",dr=[{id:"node",label:"node",desc:"Node.js runtime",required:!0},{id:"npm",label:"npm",desc:"Package manager",required:!0},{id:"acodels",label:"acodels modules",desc:"Backend node_modules (express, ws, chokidar)",required:!0}]});var pi,yo,xo=T(()=>{ct();pi=`/**
 * acodels \u2014 Live Server + Local Reverse Proxy Node backend (ls-proxy-v7, ls-bridge-v1)
 */
const http = require('http');
const https = require('https');
const express = require('express');
const path = require('path');
const fs = require('fs');
const net = require('net');
const zlib = require('zlib');
const { URL } = require('url');
const { Server: WebSocketServer } = require('ws');
const chokidar = require('chokidar');

let BASE_DIR = null;
let jsonData = {};
let erudaEnabled = false;
let consoleType = 'suger';
let zoomEnabled = false;
let liveReloadEnabled = true;
let directoryListing = true;
let fileWatcher = null;
let connectedSockets = [];
let customHeaders = {};
let charset = 'utf-8';
let ipWhitelist = [];
let basicAuth = null;
let lastActivity = Date.now();

const args = process.argv.slice(2);
let currentPort = args[0] ? parseInt(args[0], 10) : 8080;
if (!Number.isFinite(currentPort) || currentPort < 1) currentPort = 8080;
const bindHost = args[1] || '0.0.0.0';

function isPortAvailable(port) {
  return new Promise((resolve) => {
    const tester = net
      .createServer()
      .once('error', () => resolve(false))
      .once('listening', () => tester.close(() => resolve(true)))
      .listen(port, bindHost === '0.0.0.0' ? undefined : bindHost);
  });
}

const webSocketScript = \`
<script>
  (function() {
    try {
      var wsUrl = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
      var ws = new WebSocket(wsUrl);
      ws.onmessage = function (event) {
        if (event.data === 'reload') location.reload();
      };
    } catch (e) {}
  })();
<\/script>\`;

const sugerScript = \`<script src="/dt/suger-dev.js"><\/script>\`;
const erudaRealScript = \`
<script src="/eruda.min.js"><\/script>
<script>if (typeof eruda !== 'undefined') eruda.init();<\/script>
\`;
const inspectorScript = \`<script src="/inspector.js"><\/script>\`;

/* ls-bridge-v1: page <-> Acode browser bridge */
const LS_BRIDGE_JS = \`
(function () {
  var P = window.__lsParent || window.parent;
  if (window.__lsBridge || !P || P === window) return;
  window.__lsBridge = 1;
  function post(m) {
    try { m.ls = 1; P.postMessage(m, '*'); } catch (e) {}
  }
  function currentHref() {
    return window.__LS_PROXY_TARGET__ || location.href;
  }
  function fav() {
    var l = document.querySelector('link[rel~="icon"]');
    if (l && l.href) return l.href;
    try { return new URL('/favicon.ico', currentHref()).href; } catch (e) { return ''; }
  }
  function meta() {
    post({ type: 'meta', href: currentHref(), title: document.title || '', favicon: fav() });
  }
  window.__lsPostMeta = meta;
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(meta, 0);
  window.addEventListener('load', meta);
  window.addEventListener('popstate', function () { setTimeout(meta, 0); });
  window.addEventListener('hashchange', function () { setTimeout(meta, 0); });
  try {
    var t = document.querySelector('title');
    if (t) new MutationObserver(meta).observe(t, { childList: true, characterData: true, subtree: true });
  } catch (e) {}

  var dtOn = false;
  function devtools(d) {
    try {
      if (d.on) {
        if (!window.suger) {
          if (!d.code) { post({ type: 'need-devtools' }); return; }
          var s = document.createElement('script');
          s.textContent = d.code;
          (document.head || document.documentElement).appendChild(s);
        }
        if (window.suger) {
          if (!window.__lsDtInit) { window.__lsDtInit = 1; window.suger.init(); }
          else window.suger.show();
          dtOn = true;
        }
      } else if (window.suger) {
        window.suger.hide();
        dtOn = false;
      }
    } catch (e) {
      post({ type: 'devtools-error', message: String(e && e.message || e) });
    }
    post({ type: 'devtools', on: dtOn });
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.ls !== 1 || e.source !== P) return;
    try {
      if (d.cmd === 'history') history.go(d.dir < 0 ? -1 : 1);
      else if (d.cmd === 'reload') location.reload();
      else if (d.cmd === 'stop') window.stop();
      else if (d.cmd === 'zoom') document.documentElement.style.zoom = String((d.pct || 100) / 100);
      else if (d.cmd === 'print') window.print();
      else if (d.cmd === 'find') post({ type: 'found', ok: !!window.find(d.q, false, !!d.back, true, false, false, false) });
      else if (d.cmd === 'devtools') devtools(d);
      else if (d.cmd === 'ping') meta();
    } catch (err) {}
  });
})();
\`;

const lsBridgeScript = '<script src="/__ls/bridge.js"><\/script>';
const zoomScript = \`
<script src="/zoom-handler.js"><\/script>
<script>try { new ZoomHandler(document.body); } catch (e) {}<\/script>\`;

const app = express();

// Capture raw body for /__proxy while still parsing JSON for /setup
app.use((req, res, next) => {
  if (req.path === '/__proxy' || req.path === '/_proxy') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      req.rawBody = chunks.length ? Buffer.concat(chunks) : null;
      next();
    });
    return;
  }
  express.json({ limit: '2mb' })(req, res, next);
});

// Activity + security middleware
app.use((req, res, next) => {
  lastActivity = Date.now();
  if (ipWhitelist.length) {
    const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (!ipWhitelist.includes(ip) && ip !== '127.0.0.1' && ip !== '::1') {
      return res.status(403).send('Forbidden');
    }
  }
  if (basicAuth && basicAuth.user && !req.path.startsWith('/__proxy')) {
    const hdr = req.headers.authorization || '';
    const ok = (() => {
      if (!hdr.startsWith('Basic ')) return false;
      try {
        const decoded = Buffer.from(hdr.slice(6), 'base64').toString('utf8');
        const i = decoded.indexOf(':');
        const u = decoded.slice(0, i);
        const p = decoded.slice(i + 1);
        return u === basicAuth.user && p === (basicAuth.pass || '');
      } catch (_) {
        return false;
      }
    })();
    if (!ok) {
      res.setHeader('WWW-Authenticate', 'Basic realm="Live Server"');
      return res.status(401).send('Unauthorized');
    }
  }
  Object.keys(customHeaders).forEach((k) => {
    try { res.setHeader(k, customHeaders[k]); } catch (_) {}
  });
  next();
});

// CORS
app.use((req, res, next) => {
  if (jsonData.enableCors !== false) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
  }
  next();
});

app.get('/check', (req, res) => {
  res.status(200).json({
    message: 'Ready',
    key: 'AcodeLiveServer_NodeJS',
    port: currentPort,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    proxy: true,
    proxyVersion: 3,
  });
});

app.get('/status', (req, res) => {
  res.json({
    port: currentPort,
    bind: bindHost,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    directoryListing,
    clients: connectedSockets.length,
    lastActivity,
    uptime: process.uptime(),
    proxy: true,
    proxyVersion: 3,
  });
});

app.post('/reload', (req, res) => {
  broadcastReload();
  res.json({ ok: true, clients: connectedSockets.length });
});

app.patch('/setup', (req, res) => {
  const data = req.body || {};
  if (!data.path) return res.status(400).json({ error: 'Missing path' });

  BASE_DIR = data.path;
  jsonData = data;
  erudaEnabled = data.eruda === true;
  if (data.consoleType) consoleType = data.consoleType;
  zoomEnabled = data.zoom === true;
  liveReloadEnabled = data.liveReload !== false;
  directoryListing = data.directoryListing !== false;

  if (typeof data.charset === 'string' && data.charset) charset = data.charset;
  customHeaders = {};
  if (data.customHeaders && typeof data.customHeaders === 'object') {
    customHeaders = data.customHeaders;
  } else if (typeof data.customHeaders === 'string') {
    String(data.customHeaders).split('\\n').forEach((line) => {
      const i = line.indexOf(':');
      if (i > 0) {
        const k = line.slice(0, i).trim();
        const v = line.slice(i + 1).trim();
        if (k) customHeaders[k] = v;
      }
    });
  }

  ipWhitelist = [];
  if (data.ipWhitelist) {
    const raw = Array.isArray(data.ipWhitelist)
      ? data.ipWhitelist
      : String(data.ipWhitelist).split(/[\\n,]+/);
    ipWhitelist = raw.map((s) => String(s).trim()).filter(Boolean);
  }

  if (data.basicAuthUser) {
    basicAuth = { user: String(data.basicAuthUser), pass: String(data.basicAuthPass || '') };
  } else {
    basicAuth = null;
  }

  if (liveReloadEnabled) startFileWatcher(res);
  else {
    if (fileWatcher) {
      try { fileWatcher.close(); } catch (_) {}
      fileWatcher = null;
    }
    res.status(201).json({ message: 'OK', liveReload: false });
  }
});

app.get('/__ls/bridge.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.send(LS_BRIDGE_JS);
});

// ============================================================================
// LOCAL REVERSE PROXY (/__proxy?url=...)
// ============================================================================

function buildProxyRuntimeScript(targetUrl) {
  let origin = '';
  try { origin = new URL(targetUrl).origin; } catch (_) {}
  return \`<script>
(function() {
  window.__LS_PROXY_TARGET__ = \${JSON.stringify(targetUrl)};
  window.__LS_PROXY_ORIGIN__ = \${JSON.stringify(origin)};
  var proxyBase = location.origin + '/__proxy?url=';

  function unwrapUrl(u) {
    var s = String(u || '');
    var idx = s.indexOf('/__proxy?url=');
    if (idx !== -1) {
      try {
        return decodeURIComponent(s.slice(idx + '/__proxy?url='.length).split('&')[0]);
      } catch (e) {}
    }
    return s;
  }

  function wrapUrl(raw) {
    if (!raw || typeof raw !== 'string') return raw;
    var s = raw.trim();
    if (!s || s.charAt(0) === '#' || s.indexOf('data:') === 0 || s.indexOf('blob:') === 0 || s.indexOf('javascript:') === 0 || s.indexOf('mailto:') === 0 || s.indexOf('tel:') === 0) {
      return raw;
    }
    if (s.indexOf('/__proxy?url=') !== -1 || s.indexOf('/__ls/') === 0 || s.indexOf('/dt/') === 0) {
      return raw;
    }
    try {
      var resolved = new URL(s, window.__LS_PROXY_TARGET__);
      if (resolved.protocol === 'http:' || resolved.protocol === 'https:') {
        return proxyBase + encodeURIComponent(resolved.href);
      }
    } catch (e) {}
    return raw;
  }

  // Prevent proxied Service Workers from hijacking 127.0.0.1
  try {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.register = function() {
        return Promise.resolve({ scope: '/' });
      };
    }
  } catch (e) {}

  // Patch history.pushState / replaceState so SPAs don't throw cross-origin SecurityError
  try {
    var origPush = history.pushState;
    var origReplace = history.replaceState;
    history.pushState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origPush.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
    history.replaceState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origReplace.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
  } catch (e) {}

  // Patch fetch
  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function(input, init) {
      if (typeof input === 'string') {
        input = wrapUrl(input);
      } else if (input && typeof input.url === 'string') {
        try {
          input = new Request(wrapUrl(input.url), input);
        } catch (e) {}
      }
      return origFetch.call(this, input, init);
    };
  }

  // Patch XMLHttpRequest
  if (window.XMLHttpRequest) {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
      var args = Array.prototype.slice.call(arguments);
      if (typeof url === 'string') args[1] = wrapUrl(url);
      return origOpen.apply(this, args);
    };
  }

  // Patch dynamic DOM element URL setters (fixes dynamically injected CSS <link> and <script>)
  function patchProp(Proto, prop) {
    if (!Proto) return;
    var desc = Object.getOwnPropertyDescriptor(Proto, prop);
    if (!desc || !desc.set) return;
    Object.defineProperty(Proto, prop, {
      get: desc.get,
      set: function(val) {
        return desc.set.call(this, typeof val === 'string' ? wrapUrl(val) : val);
      },
      configurable: true
    });
  }
  try {
    patchProp(window.HTMLScriptElement && HTMLScriptElement.prototype, 'src');
    patchProp(window.HTMLLinkElement && HTMLLinkElement.prototype, 'href');
    patchProp(window.HTMLImageElement && HTMLImageElement.prototype, 'src');
    patchProp(window.HTMLIFrameElement && HTMLIFrameElement.prototype, 'src');
    var origSetAttr = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function(name, val) {
      var lower = String(name || '').toLowerCase();
      if ((lower === 'src' || lower === 'href' || lower === 'action') && typeof val === 'string') {
        val = wrapUrl(val);
      }
      return origSetAttr.call(this, name, val);
    };
  } catch (e) {}

  // Intercept anchor clicks
  document.addEventListener('click', function(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0 || href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
    e.preventDefault();
    location.href = wrapUrl(href);
  }, true);

  // Helper to submit forms cleanly without losing ?url= on GET forms (fixes Google Search 404)
  function submitProxiedForm(form) {
    var rawAction = form.getAttribute('action') || window.__LS_PROXY_TARGET__;
    var targetAction = unwrapUrl(rawAction);
    try {
      targetAction = new URL(targetAction, window.__LS_PROXY_TARGET__).href;
    } catch (err) {}

    var method = (form.getAttribute('method') || form.method || 'GET').toUpperCase();
    if (method === 'GET') {
      var u = new URL(targetAction);
      var fd = new FormData(form);
      fd.forEach(function(v, k) {
        if (typeof v === 'string') u.searchParams.append(k, v);
      });
      location.href = proxyBase + encodeURIComponent(u.href);
      return true;
    } else {
      origSetAttr.call(form, 'action', proxyBase + encodeURIComponent(targetAction));
      return false;
    }
  }

  document.addEventListener('submit', function(e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    if (submitProxiedForm(form)) {
      e.preventDefault();
    }
  }, true);

  // Also intercept programmatic form.submit() calls (used by Google Search)
  try {
    var origFormSubmit = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function() {
      if (submitProxiedForm(this)) return;
      return origFormSubmit.apply(this, arguments);
    };
  } catch (e) {}

  window.open = function(url) {
    if (url) location.href = wrapUrl(url);
    return window;
  };
})();
<\/script>\`;
}

function rewriteCssForProxy(css, targetUrl) {
  let out = String(css || '');
  // Rewrite url(...)
  out = out.replace(/url\\(\\s*(["']?)([^"')]+)\\1\\s*\\)/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('data:') ||
      s.startsWith('#') ||
      s.startsWith('blob:') ||
      s.includes('/__proxy?url=')
    ) {
      return match;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return 'url(' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote + ')';
      }
    } catch (_) {}
    return match;
  });

  // Rewrite @import "..." or @import '...'
  out = out.replace(/@import\\s+(["'])([^"']+)\\1/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (!s || s.includes('/__proxy?url=')) return match;
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '@import ' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote;
      }
    } catch (_) {}
    return match;
  });

  return out;
}

function rewriteHtmlForProxy(html, targetUrl) {
  const toProxy = (raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('#') ||
      s.startsWith('data:') ||
      s.startsWith('blob:') ||
      s.startsWith('javascript:') ||
      s.startsWith('mailto:') ||
      s.startsWith('tel:') ||
      s.includes('/__proxy?url=')
    ) {
      return raw;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '/__proxy?url=' + encodeURIComponent(parsed.href);
      }
    } catch (_) {}
    return raw;
  };

  // Rewrite href, src, action, poster attributes
  let out = String(html || '').replace(
    /\\b(href|src|action|poster)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      return attr + '=' + quote + toProxy(val) + quote;
    }
  );

  // Rewrite srcset / imagesrcset
  out = out.replace(
    /\\b(srcset|imagesrcset)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      const rewrittenList = val
        .split(',')
        .map((part) => {
          const trimmed = part.trim();
          if (!trimmed) return part;
          const spaceIdx = trimmed.search(/\\s/);
          if (spaceIdx === -1) return toProxy(trimmed);
          const u = trimmed.slice(0, spaceIdx);
          const descriptor = trimmed.slice(spaceIdx);
          return toProxy(u) + descriptor;
        })
        .join(', ');
      return attr + '=' + quote + rewrittenList + quote;
    }
  );

  // Rewrite inline <style> blocks
  out = out.replace(
    /(<style[^>]*>)([\\s\\S]*?)(<\\/style>)/gi,
    (match, openTag, cssBody, closeTag) => openTag + rewriteCssForProxy(cssBody, targetUrl) + closeTag
  );

  // Strip SRI integrity, CSP nonces, and CSP meta tags
  out = out.replace(/\\s+(?:integrity|nonce)\\s*=\\s*(["'])[^"']*\\1/gi, '');
  out = out.replace(/<meta[^>]+http-equiv\\s*=\\s*["']?Content-Security-Policy["']?[^>]*>/gi, '');

  // Rewrite meta refresh redirects
  out = out.replace(
    /(<meta[^>]+http-equiv\\s*=\\s*["']?refresh["']?[^>]+content\\s*=\\s*["'][^"']*?url=)([^"'>]+)(["'][^>]*>)/gi,
    (match, prefix, urlVal, suffix) => prefix + toProxy(urlVal.trim()) + suffix
  );

  const injectedHead = buildProxyRuntimeScript(targetUrl) + lsBridgeScript;

  if (/<head[^>]*>/i.test(out)) {
    out = out.replace(/<head[^>]*>/i, (m) => m + '\\n' + injectedHead);
  } else if (/<html[^>]*>/i.test(out)) {
    out = out.replace(/<html[^>]*>/i, (m) => m + '<head>' + injectedHead + '</head>');
  } else {
    out = injectedHead + '\\n' + out;
  }

  return out;
}

function decompressBuffer(buf, encoding) {
  const enc = String(encoding || '').toLowerCase();
  try {
    if (enc.includes('gzip')) return zlib.gunzipSync(buf);
    if (enc.includes('br') && typeof zlib.brotliDecompressSync === 'function') {
      return zlib.brotliDecompressSync(buf);
    }
    if (enc.includes('deflate')) return zlib.inflateSync(buf);
  } catch (_) {}
  return buf;
}

function fetchUpstream(targetUrl, method, reqHeaders, bodyBuf, redirectsLeft = 6) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(targetUrl);
    } catch (e) {
      return reject(new Error('Invalid target URL'));
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return reject(new Error('Only HTTP/HTTPS URLs are supported'));
    }

    const client = parsed.protocol === 'https:' ? https : http;
    const upperMethod = (method || 'GET').toUpperCase();
    const headers = {
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
      'Accept':
        reqHeaders['accept'] ||
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': reqHeaders['accept-language'] || 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'Referer': parsed.origin + '/',
    };
    if (upperMethod !== 'GET' && upperMethod !== 'HEAD') {
      headers['Origin'] = parsed.origin;
    }
    if (reqHeaders['content-type']) headers['Content-Type'] = reqHeaders['content-type'];
    if (reqHeaders['cookie']) headers['Cookie'] = reqHeaders['cookie'];
    if (bodyBuf && bodyBuf.length) headers['Content-Length'] = bodyBuf.length;

    const upstreamReq = client.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method: upperMethod,
        headers,
        timeout: 20000,
        rejectUnauthorized: false,
      },
      (upstreamRes) => {
        const status = upstreamRes.statusCode || 200;
        const loc = upstreamRes.headers['location'];
        if ([301, 302, 303, 307, 308].includes(status) && loc && redirectsLeft > 0) {
          upstreamRes.resume();
          const nextUrl = new URL(loc, parsed.href).href;
          const nextMethod =
            status === 303 || ((status === 301 || status === 302) && upperMethod === 'POST')
              ? 'GET'
              : upperMethod;
          return resolve(
            fetchUpstream(
              nextUrl,
              nextMethod,
              reqHeaders,
              nextMethod === 'GET' ? null : bodyBuf,
              redirectsLeft - 1
            )
          );
        }

        const chunks = [];
        upstreamRes.on('data', (c) => chunks.push(c));
        upstreamRes.on('end', () => {
          resolve({
            status,
            headers: upstreamRes.headers,
            body: Buffer.concat(chunks),
            finalUrl: parsed.href,
          });
        });
      }
    );

    upstreamReq.on('timeout', () => {
      upstreamReq.destroy(new Error('Upstream request timed out'));
    });
    upstreamReq.on('error', reject);
    if (bodyBuf && bodyBuf.length) upstreamReq.write(bodyBuf);
    upstreamReq.end();
  });
}

async function handleProxyRequest(req, res, targetUrl) {
  try {
    const bodyBuf = req.rawBody || null;
    const result = await fetchUpstream(targetUrl, req.method, req.headers, bodyBuf);

    const blockedHeaders = new Set([
      'x-frame-options',
      'content-security-policy',
      'content-security-policy-report-only',
      'cross-origin-opener-policy',
      'cross-origin-embedder-policy',
      'cross-origin-resource-policy',
      'content-length',
      'content-encoding',
      'transfer-encoding',
      'connection',
    ]);

    Object.entries(result.headers || {}).forEach(([k, v]) => {
      const lower = k.toLowerCase();
      if (blockedHeaders.has(lower)) return;
      if (lower === 'set-cookie' && Array.isArray(v)) {
        const cleanCookies = v.map((c) =>
          String(c)
            .replace(/;\\s*Domain=[^;]+/gi, '')
            .replace(/;\\s*Secure/gi, '')
            .replace(/SameSite=None/gi, 'SameSite=Lax')
        );
        res.setHeader('Set-Cookie', cleanCookies);
        return;
      }
      try {
        res.setHeader(k, v);
      } catch (_) {}
    });

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-LS-Final-Url', result.finalUrl);

    const contentType = String(result.headers['content-type'] || '');
    const rawBuf = decompressBuffer(result.body, result.headers['content-encoding']);

    if (/text\\/html|application\\/xhtml\\+xml/i.test(contentType)) {
      const htmlText = rawBuf.toString('utf8');
      const rewritten = rewriteHtmlForProxy(htmlText, result.finalUrl);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.status(result.status).send(rewritten);
    }

    if (/text\\/css/i.test(contentType)) {
      const cssText = rawBuf.toString('utf8');
      const rewrittenCss = rewriteCssForProxy(cssText, result.finalUrl);
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
      return res.status(result.status).send(rewrittenCss);
    }

    return res.status(result.status).send(rawBuf);
  } catch (err) {
    const safeUrl = String(targetUrl || '').replace(/</g, '<');
    const safeMsg = String((err && err.message) || err).replace(/</g, '<');
    res.status(502).setHeader('Content-Type', 'text/html; charset=utf-8').send(\`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
      <style>
        body { font-family: system-ui, sans-serif; background: #1e1e1e; color: #e8eaed; padding: 28px 18px; text-align: center; }
        .card { max-width: 420px; margin: 24px auto; padding: 20px; border-radius: 8px; background: #292a2d; border: 1px solid #3c4043; }
        h3 { margin: 0 0 8px; color: #f87171; }
        p { font-size: 13px; color: #9aa0a6; word-break: break-all; }
        button { margin-top: 12px; padding: 8px 16px; border: 0; border-radius: 5px; background: #22c55e; color: #052e16; font-weight: 600; cursor: pointer; }
      </style></head>
      <body>
        <div class="card">
          <h3>Proxy Could Not Load Page</h3>
          <p>\${safeMsg}</p>
          <p>\${safeUrl}</p>
          <button onclick="location.reload()">Retry</button>
        </div>
      </body></html>
    \`);
  }
}

app.all(['/__proxy', '/_proxy'], (req, res) => {
  if (req.query.url) {
    const target = String(req.query.url);
        return handleProxyRequest(req, res, target);
  }
  // Fallback when a GET form (like Google Search) strips ?url= and submits ?q=... directly to /__proxy
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (idx !== -1) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const u = new URL('/search', baseTarget);
      Object.entries(req.query || {}).forEach(([k, v]) => {
        if (typeof v === 'string') u.searchParams.set(k, v);
      });
      return handleProxyRequest(req, res, u.href);
    } catch (_) {}
  }
  return res.status(400).send('Missing ?url=');
});

// Referer-based fallback for root-relative assets/APIs requested by proxied pages
app.use((req, res, next) => {
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (
    idx !== -1 &&
    !req.path.startsWith('/__ls/') &&
    !req.path.startsWith('/dt/') &&
    req.path !== '/__proxy' &&
    req.path !== '/_proxy'
  ) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const resolved = new URL(req.originalUrl, baseTarget).href;
      return handleProxyRequest(req, res, resolved);
    } catch (_) {}
  }
  next();
});

// ============================================================================
// LOCAL STATIC LIVE SERVER
// ============================================================================

app.get('/dt/suger-dev.js', (req, res) => {
  const p = path.join(__dirname, 'suger-dev.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/zoom-handler.js', (req, res) => {
  const p = path.join(__dirname, 'zoom-handler.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/inspector.js', (req, res) => {
  const p = path.join(__dirname, 'inspector.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/eruda.min.js', (req, res) => {
  const erudaPath = path.join(__dirname, 'eruda.min.js');
  if (fs.existsSync(erudaPath)) res.sendFile(erudaPath);
  else res.status(404).send('Eruda not found');
});

function injectHtml(html) {
  let injected = html;
  if (liveReloadEnabled) {
    injected = injected.replace(/<\\/body>/i, webSocketScript + '</body>');
    if (!/<\\/body>/i.test(html)) injected = injected + webSocketScript;
  }
  if (erudaEnabled) {
    const extra =
      consoleType === 'eruda' ? erudaRealScript + '\\n' + inspectorScript : sugerScript + '\\n' + inspectorScript;
    injected = injected.replace(/<\\/body>/i, extra + '</body>');
  }
  if (zoomEnabled) {
    injected = injected.replace(/<\\/body>/i, zoomScript + '</body>');
  }
  if (/<\\/body>/i.test(injected)) injected = injected.replace(/<\\/body>/i, lsBridgeScript + '</body>');
  else injected += lsBridgeScript;
  return injected;
}

function sendHtmlFile(res, fullPath) {
  fs.readFile(fullPath, 'utf8', (err, html_content) => {
    if (err) return res.status(404).send('Not found');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(injectHtml(html_content));
  });
}


function safeJoinRoot(root, reqPath) {
  const base = path.resolve(String(root || '/'));
  let rel = decodeURIComponent(String(reqPath || ''));
  rel = rel.split('?')[0].split('#')[0];
  // CRITICAL: path.join(root, '/T.html') => '/T.html' on Node \u2014 strip leading slashes
  while (rel.charAt(0) === '/') rel = rel.slice(1);
  if (!rel || rel === '.') return base;
  const full = path.resolve(base, rel);
  const prefix = base.endsWith(path.sep) ? base : base + path.sep;
  if (full !== base && !full.startsWith(prefix)) return null;
  return full;
}

app.get('/', (req, res) => {
  if (!BASE_DIR) return res.status(400).send('Not configured. PATCH /setup first.');
  const fileName = String(jsonData.fileName || 'index.html').split('/').filter(Boolean).join('/');
  const fullPath = safeJoinRoot(BASE_DIR, fileName);
  if (fullPath && fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    return sendHtmlFile(res, fullPath);
  }
  const indexPath = safeJoinRoot(BASE_DIR, 'index.html');
  if (indexPath && fs.existsSync(indexPath)) return sendHtmlFile(res, indexPath);
  if (directoryListing) return listDir(res, BASE_DIR, '/');
  return res.status(404).send('No index.html in ' + BASE_DIR + ' (wanted ' + fileName + ')');
});

function listDir(res, dirPath, urlPath) {
  fs.readdir(dirPath, { withFileTypes: true }, (err, entries) => {
    if (err) return res.status(500).send('Cannot list directory');
    const rows = entries
      .filter((e) => !e.name.startsWith('.'))
      .map((e) => {
        const href = path.posix.join(urlPath, e.name) + (e.isDirectory() ? '/' : '');
        return \`<li><a href="\${href}">\${e.name}\${e.isDirectory() ? '/' : ''}</a></li>\`;
      })
      .join('\\n');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(
      \`<!DOCTYPE html><html><head><meta charset="\${charset}"/><title>Index of \${urlPath}</title></head><body><h1>Index of \${urlPath}</h1><ul>\${rows}</ul></body></html>\`
    );
  });
}

app.use((req, res, next) => {
  if (!BASE_DIR) return next();
  const rel = decodeURIComponent(req.path || '/');
  if (rel === '/' || rel === '') return next();
  const full = safeJoinRoot(BASE_DIR, rel);
  if (!full) return res.status(403).send('Forbidden path');
  fs.stat(full, (err, st) => {
    if (err) {
      return res.status(404).send('Cannot get ' + rel.replace(/^[/]+/, '') + ' (root ' + BASE_DIR + ')');
    }
    if (st.isDirectory()) {
      if (directoryListing) return listDir(res, full, rel.endsWith('/') ? rel : rel + '/');
      const idx = safeJoinRoot(full, 'index.html');
      if (idx && fs.existsSync(idx)) return sendHtmlFile(res, idx);
      return res.status(404).end();
    }
    if (/.html?$/i.test(full)) return sendHtmlFile(res, full);
    res.sendFile(full, (e) => {
      if (e) res.status(404).send('Cannot get ' + rel.replace(/^[/]+/, ''));
    });
  });
});

app.use(express.static(__dirname));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  connectedSockets.push(ws);
  lastActivity = Date.now();
  ws.on('close', () => {
    connectedSockets = connectedSockets.filter((s) => s !== ws);
  });
});

function broadcastReload() {
  for (const ws of connectedSockets) {
    try {
      ws.send('reload');
    } catch (_) {}
  }
}

function startFileWatcher(res) {
  if (fileWatcher) {
    try { fileWatcher.close(); } catch (_) {}
    fileWatcher = null;
  }
  if (!BASE_DIR || !liveReloadEnabled) {
    if (res) res.status(201).json({ message: 'OK' });
    return;
  }
  fileWatcher = chokidar.watch(BASE_DIR, {
    ignored: /(^|[\\/\\\\])\\.\\./,
    persistent: true,
    ignoreInitial: true,
  });
  fileWatcher.on('change', () => {
    lastActivity = Date.now();
    broadcastReload();
  });
  let responseSent = false;
  const done = (code, body) => {
    if (responseSent || !res) return;
    responseSent = true;
    res.status(code).json(body);
  };
  fileWatcher.on('ready', () => done(201, { message: 'OK', liveReload: true }));
  fileWatcher.on('error', (error) => {
    console.error('Watcher Error:', error.message);
    done(500, { error: error.message });
  });
  setTimeout(() => done(201, { message: 'OK', liveReload: true }), 3000);
}

async function main() {
  const ok = await isPortAvailable(currentPort);
  if (!ok) {
    console.error('[acodels] port busy', currentPort);
    process.exit(1);
  }
  server.listen(currentPort, bindHost, () => {
    console.log('[acodels] listening', bindHost + ':' + currentPort);
  });
}

main();
`,yo=Yr(pi)});async function tn(e){let t=e||"/root/.acode_liveserver/acodels";try{let o=await ee("D="+Ee(t)+'; if [ ! -f "$D/index.js" ]; then echo NEED; exit 0; fi; if grep -q WebSocket "$D/index.js" 2>/dev/null && grep -q chokidar "$D/index.js" 2>/dev/null && grep -q ls-proxy-v7 "$D/index.js" 2>/dev/null; then echo FULL; else echo NEED; fi',{timeoutMs:8e3});if(String(o).includes("FULL")&&!String(o).includes("NEED"))return!1}catch(o){console.warn("[LiveServer] index check",(o==null?void 0:o.message)||o)}let r=yo,n=["#!/bin/sh","set -e","D="+t.replace(/'/g,""),'mkdir -p "$D"',"echo '"+r+`' | base64 -d > "$D/index.js"`,"echo RESTORED"].join(`
`);try{return await Ht(n,{timeoutMs:0}),!0}catch(o){return console.warn("[LiveServer] restore failed",(o==null?void 0:o.message)||o),!1}}var wo=T(()=>{ct();xo()});function fi(e){return/\.html?$/i.test(String(e||""))}function Le(e){return!!(e&&fi(e.filename||e.name))}function X(){try{return(editorManager==null?void 0:editorManager.activeFile)||null}catch{return null}}function rn(e){try{return decodeURIComponent(e)}catch{return e}}function So(e){let t=String(e||""),r=t.indexOf(":");if(r<0)return t.startsWith("/")?t:null;let n=t.slice(0,r),o=t.slice(r+1).replace(/^\/+/,""),s=o?"/"+o:"";return n==="primary"?"/sdcard"+s:n==="home"?"/sdcard/Documents"+s:/^[0-9A-F]{4}-[0-9A-F]{4}$/i.test(n)?"/storage/"+n+s:null}function we(e){if(!e||typeof e!="string")return null;let t=e;if(t.startsWith("content://")){if(t.includes("::")){let n=rn(t.split("::").pop());if(n.startsWith("/"))return n;let o=So(n);if(o)return o}let r=t.indexOf("/document/");if(r>=0){let n=rn(t.slice(r+10).split("?")[0]);if(n.startsWith("/"))return n;let o=So(n);if(o)return o}return null}if(t.startsWith("file://")&&(t=rn(t.replace(/^file:\/\//,""))),t.includes("/data/data/com.termux/files/home"))return t.includes("::")?t.split("::").pop():t;if(t.includes("::")){let r=t.split("::").pop();if(r&&r.startsWith("/"))return r}if(/\/(storage|sdcard|emulated)\//i.test(t)){let r=t.match(/(\/(?:storage|sdcard|emulated)\/[^?#]*)/i);if(r)return r[1]}return t.startsWith("/")?t:null}function fe(e){if(!e)return null;let t=Math.max(e.lastIndexOf("/"),e.lastIndexOf("\\"));return t<=0?e:e.slice(0,t)}var Se=T(()=>{});var Ke={};xe(Ke,{browseRootFolder:()=>ko,getEffectiveRoot:()=>mr,getEffectiveRootUri:()=>gi,pickRootFolder:()=>vi,rootFromSelectedFolder:()=>bi});function mr(){let e=k();if(e.rootFolder&&String(e.rootFolder).trim())return String(e.rootFolder).trim();let t=X(),r=we((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");return r?fe(r):null}function gi(){let e=k();if(e.rootFolderUri&&String(e.rootFolderUri).trim())return String(e.rootFolderUri).trim();let t=X(),r=(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"";if(!r)return null;if(r.includes("::"))return r.split("::")[0];let n=we(r);return n?fe(n):null}async function ko(){try{let e=acode.require("fileBrowser");if(!e)return De("File browser not available",2e3),null;let t=await e("folder","Select Live Server root");if(!t)return null;let r=t.url||t.uri||t,n=we(typeof r=="string"?r:(r==null?void 0:r.url)||"")||String(r);O("rootFolder",n);try{O("rootFolderUri",typeof r=="string"?r:(r==null?void 0:r.url)||n)}catch{}return De("Root: "+n,2500),n}catch(e){return De(String((e==null?void 0:e.message)||e),2500),null}}async function vi(){try{let e=k().rootFolder||"",t=X(),r=fe(we((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")||"")||"",n=[["browse","Browse with Acode file browser\u2026"],["active",r?`Use active file folder
${r}`:"Use active file folder"],["type","Type path\u2026"],["clear","Clear (auto from active HTML)"]];e&&n.splice(1,0,["keep",`Keep current
${e}`]);let o=await hi("Select root folder",n,{hideOnSelect:!0});if(!o||o==="keep")return e||null;if(o==="browse")return ko();if(o==="active"){if(!r)return De("Open an HTML file first",2e3),null;O("rootFolder",r);try{O("rootFolderUri",(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")}catch{}return De("Root: "+r,2200),r}if(o==="clear"){O("rootFolder","");try{O("rootFolderUri","")}catch{}return De("Root cleared \u2014 will use active file folder",2200),null}if(o==="type"){let s=await mi("Absolute folder path",e||r||"/sdcard/","text");if(!s)return null;let i=String(s).trim();return O("rootFolder",i),De("Root: "+i,2200),i}return null}catch(e){return De(String((e==null?void 0:e.message)||e),2500),null}}function bi(){var e,t,r;try{let n=((e=window.fileBrowser)==null?void 0:e.selectedFolder)||((r=(t=window.addedFolder)==null?void 0:t[0])==null?void 0:r.url)||null;if(n)return we(n)||n}catch{}return null}var De,hi,mi,Ie=T(()=>{ne();Se();De=acode.require("toast"),hi=acode.require("select"),mi=acode.require("prompt")});function nn(){try{return acode.require("fsOperation")||window.fsOperation}catch{return window.fsOperation}}function ki(e){let t=0,r=String(e||"");for(let n=0;n<r.length;n++)t=Math.imul(31,t)+r.charCodeAt(n)|0;return"p"+Math.abs(t).toString(36)}function vr(e){return/^(https?:|data:|blob:|\/\/|#|mailto:|tel:)/i.test(String(e||"").trim())}function Ei(e){let t=new Set,r=/(?:src|href|data-src|poster)\s*=\s*["']([^"']+)["']/gi,n;for(;n=r.exec(e);)vr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);let o=/url\(\s*['"]?([^'")\s]+)['"]?\s*\)/gi;for(;n=o.exec(e);)vr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);return[...t]}function Li(e){let t=new Set,r=/url\(\s*['"]?([^'")\s]+)['"]?\s*\)/gi,n;for(;n=r.exec(e);)vr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);let o=/@import\s+['"]([^'"]+)['"]/gi;for(;n=o.exec(e);)vr(n[1])||t.add(n[1].split("?")[0].split("#")[0]);return[...t]}function _i(e,t){if(!t)return null;if(t.startsWith("/"))return t.replace(/^\/+/,"");let r=String(e||"").replace(/\/+$/,""),n=(r?r.split("/"):[]).concat(String(t).split("/")),o=[];for(let s of n)!s||s==="."||(s===".."?o.pop():o.push(s));return o.join("/")}async function br(e){let t=nn();if(!t)throw new Error("fsOperation missing");try{let r=await t(e).readFile("utf-8");return typeof r=="string"?r:r instanceof ArrayBuffer?new TextDecoder().decode(r):String(r||"")}catch{let n=await t(e).readFile();return typeof n=="string"?n:n instanceof ArrayBuffer?new TextDecoder().decode(n):String(n||"")}}async function _o(e,t){let r=nn();if(!r)throw new Error("fsOperation missing");let n=fe(e);try{n&&!await r(n).exists()&&await yr(n)}catch{}try{if(await r(e).exists())await r(e).writeFile(t);else{let o=e.slice(e.lastIndexOf("/")+1),s=fe(e);await r(s).createFile(o,t)}}catch{let s=btoa(unescape(encodeURIComponent(t))),i=c=>"'"+String(c).replace(/'/g,"'\\''")+"'";await ee(`mkdir -p ${i(fe(e))} && echo ${i(s)} | base64 -d > ${i(e)}`,{timeoutMs:2e4})}}async function yr(e){let t=nn(),r=n=>"'"+String(n).replace(/'/g,"'\\''")+"'";try{if(t){let n=String(e).split("/").filter(Boolean),o=(e.startsWith("/"),"")}}catch{}await ee(`mkdir -p ${r(e)}`,{timeoutMs:1e4})}function Co(e,t){if(!e)return null;let r=String(t||"").replace(/^\/+/,"");return e.includes("::")?e:e.startsWith("content://")?null:e.replace(/\/+$/,"")+"/"+r}async function Ci(e,t,r){let n=new Map,o=[t.replace(/^\/+/,"")],s=0;for(;o.length&&n.size<xi&&s<Si;){let i=o.shift();if(!i||n.has(i))continue;let c=e.replace(/\/+$/,"")+"/"+i,p=null;try{let g=Co(r,i)||c;p=await br(g.startsWith("content:")?g:c)}catch{try{p=await br(c)}catch(a){console.warn("[LiveServer:mirror] skip",i,(a==null?void 0:a.message)||a),n.set(i,null);continue}}if(p==null){n.set(i,null);continue}if(p.length>wi){console.warn("[LiveServer:mirror] too large",i),n.set(i,null);continue}n.set(i,p),s+=p.length;let l=fe(i)||"",d=i.toLowerCase(),f=[];if(/\.html?$/.test(d))f=Ei(p);else if(/\.css$/.test(d))f=Li(p);else continue;for(let g of f){let a=_i(l,g);a&&!n.has(a)&&!a.includes("..")&&o.push(a)}}return n}function on(){gr&&(clearInterval(gr),gr=null)}async function Ti(e={}){let t=String(e.sourceRoot||"").replace(/\/+$/,"");if(!t)throw new Error("No source root to mirror");let r=String(e.entryRel||"index.html").replace(/^\/+/,""),n=e.sourceRootUri||k().rootFolderUri||"",o=ki(t+"|"+r),s=`${yi}/${o}`;Eo("Mirroring project to internal storage\u2026",2e3),await yr(s);let i=await Ci(t,r,n),c=0;for(let[l,d]of i){if(d==null)continue;let f=s+"/"+l;await yr(fe(f)),await _o(f,d),c++}if(c===0)throw new Error("Could not read any project files for mirror");let p={};for(let[l,d]of i)d!=null&&(p[l]=d.length+":"+d.slice(0,32));_e={id:o,files:p},qe={id:o,alpineRoot:s,sourceRoot:t,sourceRootUri:n,entryRel:r};try{O("lastMirrorRoot",s)}catch{}return Ri(),console.log("[LiveServer:mirror] ready",s,"files=",c),Eo(`Mirrored ${c} file(s) \u2192 internal cache`,2500),s}async function To(e){var c;if(!qe)return!1;let{sourceRoot:t,sourceRootUri:r,alpineRoot:n}=qe,o=t.replace(/\/+$/,"")+"/"+e,s;try{let p=Co(r,e)||o;s=await br(p.startsWith("content:")?p:o)}catch{try{s=await br(o)}catch{return!1}}if(s==null)return!1;let i=s.length+":"+s.slice(0,32);return((c=_e==null?void 0:_e.files)==null?void 0:c[e])===i?!1:(await yr(fe(n+"/"+e)),await _o(n+"/"+e,s),_e||(_e={id:qe.id,files:{}}),_e.files[e]=i,console.log("[LiveServer:mirror] updated",e),!0)}function Ri(){var e;if(on(),!!qe){try{(e=editorManager==null?void 0:editorManager.on)==null||e.call(editorManager,"save-file",Lo),document.addEventListener("liveserver-file-saved",Lo)}catch{}gr=setInterval(async()=>{if(!qe||!_e)return;let t=Object.keys(_e.files||{}),r=!1;for(let n of t.slice(0,40))try{await To(n)&&(r=!0)}catch{}if(r)try{document.dispatchEvent(new CustomEvent("liveserver-mirror-updated"))}catch{}},2500)}}function Lo(e){try{if(!qe)return;let t=(e==null?void 0:e.target)||(e==null?void 0:e.file)||X(),r=(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"",n=we(r);if(!n)return;let o=qe.sourceRoot;if(!n.startsWith(o))return;let s=n.slice(o.length).replace(/^\/+/,"");s&&To(s)}catch{}}async function sn(e,t,r){return Ti({sourceRoot:e,entryRel:t,sourceRootUri:r})}var Eo,yi,xi,wi,Si,gr,_e,qe,Ro=T(()=>{ne();Se();ct();Eo=acode.require("toast"),yi="/sdcard/Acode/liveserver_cache",xi=250,wi=2*1024*1024,Si=40*1024*1024,gr=null,_e=null,qe=null});function mt(){let e=parseInt(k().port,10);return Number.isFinite(e)&&e>0?e:8080}function qt(e,t){return`http://${t==="0.0.0.0"?"127.0.0.1":t||"127.0.0.1"}:${e}/`}var Ao=T(()=>{ne()});var gt={};xe(gt,{getServerStatus:()=>D,refreshStatusFromBackend:()=>an,setServerStatus:()=>oe});function D(){return{...$e}}function oe(e){Object.assign($e,e||{});try{window.dispatchEvent(new CustomEvent("liveserver-status",{detail:D()}))}catch{}}async function an(){if(!$e.port)return $e;try{let e=await fetch(`http://127.0.0.1:${$e.port}/status`);if(!e.ok)return oe({running:!1,lastError:"status "+e.status}),D();let t=await e.json();oe({running:!0,port:t.port||$e.port,root:t.root||$e.root,fileName:t.fileName||$e.fileName})}catch{oe({running:!1})}return D()}var $e,he=T(()=>{$e={running:!1,port:null,root:null,url:null,fileName:null,bind:null,startedAt:null,lastError:null}});function Po(){if(document.getElementById("ls-status-pill-css"))return;let e=document.createElement("style");e.id="ls-status-pill-css",e.textContent=`
    #ls-status-pill {
      position: fixed;
      left: 8px;
      bottom: 8px;
      z-index: 100001;
      max-width: min(82vw, 440px);
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 5px 10px;
      border-radius: 4px;
      background: var(--secondary-color, rgba(28, 30, 34, 0.94));
      color: var(--primary-text-color, var(--color, #e8eaed));
      border: 1px solid var(--border-color, rgba(255, 255, 255, 0.12));
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.45), 0 1px 3px rgba(0, 0, 0, 0.3);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 11px;
      line-height: 1.3;
      pointer-events: none;
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #ls-status-pill.is-visible {
      opacity: 0.96;
      transform: translateY(0);
    }
    .ls-sp-dot {
      width: 7px;
      height: 7px;
      min-width: 7px;
      border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 6px rgba(34, 197, 94, 0.9);
    }
    .ls-sp-dot.is-spin {
      animation: ls-sp-pulse 0.9s ease-in-out infinite alternate;
    }
    @keyframes ls-sp-pulse {
      from { opacity: 0.4; transform: scale(0.85); }
      to { opacity: 1; transform: scale(1.15); }
    }
    .ls-sp-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Global top green progress bar (shown when installing in background) */
    #ls-global-green-loader {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      z-index: 100002;
      overflow: hidden;
      pointer-events: none;
      display: none;
      background: rgba(34, 197, 94, 0.15);
    }
    #ls-global-green-loader.is-active {
      display: block;
    }
    #ls-global-green-loader::before {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      width: 35%;
      background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
      box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
      animation: ls-green-slide 1.15s ease-in-out infinite;
    }
    @keyframes ls-green-slide {
      0% { left: -35%; }
      100% { left: 100%; }
    }
  `,document.head.appendChild(e)}function Ai(){return Po(),(!ce||!ce.isConnected)&&(ce=document.createElement("div"),ce.id="ls-status-pill",bt=document.createElement("span"),bt.className="ls-sp-dot",vt=document.createElement("span"),vt.className="ls-sp-text",ce.append(bt,vt),document.body.appendChild(ce)),ce}function Ce(e,t={}){Po();let r=!!e,o=!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")||t.force===!0;if(document.body.classList.toggle("ls-green-loading",r&&o),document.querySelectorAll(".ls-browser-shell").forEach(s=>{s.classList.toggle("is-installing",r)}),!o){de&&de.classList.remove("is-active");return}(!de||!de.isConnected)&&(de=document.createElement("div"),de.id="ls-global-green-loader",document.body.appendChild(de)),de.classList.toggle("is-active",r)}function Te(e,t={}){if(!!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")&&t.force!==!0){Ft(0);return}clearTimeout($t);let n=Ai();vt&&(vt.textContent=String(e||"")),bt&&bt.classList.toggle("is-spin",t.spin!==!1),requestAnimationFrame(()=>{n.classList.add("is-visible")}),t.autoHideMs&&t.autoHideMs>0&&($t=setTimeout(()=>{Ft(0)},t.autoHideMs))}function Ft(e=0){clearTimeout($t);let t=()=>{ce&&ce.classList.remove("is-visible")};e>0?$t=setTimeout(t,e):t()}function Mo(){clearTimeout($t),Ce(!1);try{ce==null||ce.remove(),de==null||de.remove()}catch{}ce=null,vt=null,bt=null,de=null}var ce,vt,bt,de,$t,xr=T(()=>{ce=null,vt=null,bt=null,de=null,$t=null});function A(e,t=18,r=2){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${r}" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var R,jt=T(()=>{R={back:"M19 12H5M12 19l-7-7 7-7",forward:"M5 12h14M12 5l7 7-7 7",reload:"M21 2v6h-6M3 12a9 9 0 0115-6.7L21 8M3 22v-6h6M21 12a9 9 0 01-15 6.7L3 16",close:"M18 6L6 18M6 6l12 12",plus:"M12 5v14M5 12h14",home:"M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2zM9 22V12h6v10",star:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",lock:"M5 11h14a2 2 0 012 2v7a2 2 0 01-2 2H5a2 2 0 01-2-2v-7a2 2 0 012-2zM7 11V7a5 5 0 0110 0v4",info:"M12 2a10 10 0 100 20 10 10 0 000-20zM12 16v-4M12 8h.01",device:"M7 2h10a2 2 0 012 2v16a2 2 0 01-2 2H7a2 2 0 01-2-2V4a2 2 0 012-2zM12 18h.01",rotate:"M21 12a9 9 0 11-9-9c2.5 0 4.7 1 6.3 2.7L21 8M21 3v5h-5",dots:"M12 5h.01M12 12h.01M12 19h.01",maximize:"M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3",drop:"M12 2.69l5.66 5.66a8 8 0 11-11.31 0z",down:"M6 9l6 6 6-6",up:"M18 15l-6-6-6 6",search:"M11 3a8 8 0 100 16 8 8 0 000-16zM21 21l-4.35-4.35",globe:"M12 2a10 10 0 100 20 10 10 0 000-20zM2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20",minus:"M5 12h14"}});function Pi(e){let t=String(e||"").trim().match(/^#([0-9a-f]{3,8})$/i),r,n,o;if(t){let s=t[1];s.length===3&&(s=s.split("").map(i=>i+i).join("")),r=parseInt(s.slice(0,2),16),n=parseInt(s.slice(2,4),16),o=parseInt(s.slice(4,6),16)}else{if(t=String(e||"").match(/rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i),!t)return null;r=+t[1],n=+t[2],o=+t[3]}return(.299*r+.587*n+.114*o)/255}function Oo(){try{let e=getComputedStyle(document.documentElement),t=e.getPropertyValue("--primary-color")||e.getPropertyValue("--secondary-color"),r=Pi(t);if(r!=null)return r>.6?"light":"dark"}catch{}return"dark"}var Ho=T(()=>{});function Bo(){let e=document.getElementById("ls-browser-styles");e&&e.remove();let t=document.createElement("style");t.id="ls-browser-styles",t.textContent=ln,document.head.appendChild(t)}var ln,Do=T(()=>{ln=`
:host { display: block; position: relative; height: 100%; width: 100%; }
.ls-browser-shell {
  --ls-frame: #202124; --ls-toolbar: #35363a; --ls-omni: #202124; --ls-text: #e8eaed; --ls-sub: #9aa0a6;
  --ls-hover: rgba(255,255,255,.10); --ls-press: rgba(255,255,255,.16); --ls-line: #3c4043; --ls-accent: #8ab4f8;
  --ls-menu: #292a2d; --ls-stage: #1b1c1e; --ls-active-tab-text: #e8eaed;
  position: absolute; inset: 0; z-index: 1;
  display: flex; flex-direction: column; box-sizing: border-box;
  background: var(--ls-frame); color: var(--ls-text);
  font: 13px/1.3 Roboto, "Noto Sans", "Segoe UI", system-ui, sans-serif;
}
.ls-browser-shell[data-theme="light"] {
  --ls-frame: #dee1e6; --ls-toolbar: #ffffff; --ls-omni: #f1f3f4; --ls-text: #202124; --ls-sub: #5f6368;
  --ls-hover: rgba(0,0,0,.08); --ls-press: rgba(0,0,0,.14); --ls-line: #dadce0; --ls-accent: #1a73e8;
  --ls-menu: #ffffff; --ls-stage: #e8eaed; --ls-active-tab-text: #202124;
}
.ls-browser-shell *, .ls-browser-shell *::before, .ls-browser-shell *::after { box-sizing: border-box; }
.ls-browser-shell button { font: inherit; color: inherit; }
.ls-browser-shell.is-fullscreen { position: fixed; inset: 0; z-index: 99990; }

/* ---- chrome (tab strip + toolbar) */
.ls-chrome { flex-shrink: 0; display: flex; flex-direction: column; background: var(--ls-frame); }
.ls-tabstrip { display: flex; align-items: flex-end; height: 38px; padding: 6px 6px 0 6px; gap: 2px; }
.ls-browser-tabs { display: flex; flex: 0 1 auto; min-width: 0; overflow: hidden; align-items: flex-end; }
.ls-tab {
  position: relative; display: flex; align-items: center; gap: 6px; flex: 0 1 200px; min-width: 36px; max-width: 220px;
  height: 32px; padding: 0 6px 0 10px; border-radius: 3px 3px 0 0; color: var(--ls-sub); cursor: default; user-select: none;
}
.ls-tab:hover { background: var(--ls-hover); }
.ls-tab.is-active { background: var(--ls-toolbar); color: var(--ls-active-tab-text); }
.ls-tab:not(.is-active)::after { content: ""; position: absolute; right: -1px; top: 8px; height: 16px; width: 1px; background: var(--ls-line); }
.ls-tab:hover::after, .ls-tab.is-active::after, .ls-tab:has(+ .ls-tab.is-active)::after { display: none; }
.ls-fav { width: 16px; height: 16px; flex: none; display: inline-flex; align-items: center; justify-content: center; }
.ls-fav img { width: 16px; height: 16px; }
.ls-fav.is-spin { border: 2px solid var(--ls-line); border-top-color: var(--ls-accent); border-radius: 50%; animation: ls-spin .8s linear infinite; }
.ls-tab-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ls-tab-x { width: 18px; height: 18px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; }
.ls-tab-x:hover { background: var(--ls-press); }
.ls-tabstrip .ls-spacer { flex: 1; }
.ls-win { display: flex; align-items: center; align-self: center; gap: 2px; }
.ls-ib {
  width: 32px; height: 32px; flex: none; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub);
  display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
}
.ls-ib:hover { background: var(--ls-hover); }
.ls-ib:active { background: var(--ls-press); }
.ls-ib:disabled { opacity: .4; pointer-events: none; }
.ls-ib.is-on { color: var(--ls-accent); }
.ls-ib.is-on svg { fill: var(--ls-accent); }
.ls-ib.ls-tab-new { width: 28px; height: 28px; margin-left: 2px; align-self: center; }
.ls-ib.ls-win-btn { width: 26px; height: 26px; }

.ls-toolbar { position: relative; display: flex; align-items: center; gap: 2px; height: 40px; padding: 0 6px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); }
.ls-omni { flex: 1; min-width: 0; height: 30px; margin: 0 6px; display: flex; align-items: center; gap: 2px; padding: 0 2px 0 4px; border-radius: 3px; background: var(--ls-omni); }
.ls-omni:focus-within { box-shadow: inset 0 0 0 2px var(--ls-accent); }
.ls-site { width: 24px; height: 24px; flex: none; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; padding: 0; }
.ls-site:hover { background: var(--ls-hover); }
.ls-browser-url { flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent; color: var(--ls-text); font: inherit; font-size: 14px; padding: 0 4px; }
.ls-browser-url::placeholder { color: var(--ls-sub); }
.ls-omni .ls-ib { width: 26px; height: 26px; }
.ls-browser-shell.no-url .ls-omni { visibility: hidden; }
.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }
@keyframes ls-bar { 0% { left: -30%; } 100% { left: 100%; } }
@keyframes ls-spin { to { transform: rotate(360deg); } }

/* ---- external site fallback banner */
.ls-ext-bar {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 5px 10px; background: var(--ls-menu); border-bottom: 1px solid var(--ls-line);
  font-size: 12px; color: var(--ls-sub);
}
.ls-ext-bar[hidden] { display: none; }
.ls-ext-open {
  border: 0; border-radius: 3px; padding: 4px 10px; background: #22c55e;
  color: #052e16; font-weight: 600; font-size: 11.5px; cursor: pointer; white-space: nowrap;
}

/* ---- device toolbar */
.ls-devbar { display: flex; align-items: center; gap: 6px; min-height: 34px; padding: 3px 8px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); overflow-x: auto; scrollbar-width: none; }
.ls-devbar[hidden] { display: none; }
.ls-devbar::-webkit-scrollbar { height: 0; }
.ls-dev-btn { display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 8px; border: 1px solid var(--ls-line); border-radius: 3px; background: transparent; white-space: nowrap; cursor: pointer; }
.ls-dev-btn:hover { background: var(--ls-hover); }
.ls-dev-num { width: 58px; height: 26px; padding: 0 6px; border: 1px solid var(--ls-line); border-radius: 3px; background: var(--ls-omni); color: var(--ls-text); font: inherit; text-align: center; outline: 0; -moz-appearance: textfield; }
.ls-dev-num:focus { border-color: var(--ls-accent); }
.ls-dev-num::-webkit-outer-spin-button, .ls-dev-num::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ls-dev-x { color: var(--ls-sub); }
.ls-dev-spacer { flex: 1; }
.ls-dev-icon { width: 26px; height: 26px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; }
.ls-dev-icon:hover { background: var(--ls-hover); }

/* ---- stage (page area) */
.ls-stage { position: relative; flex: 1; min-height: 0; overflow: hidden; background: #fff; }
.ls-browser-shell.is-device .ls-stage { overflow: auto; display: flex; padding: 12px; background: var(--ls-stage); }
.ls-box { position: relative; width: 100%; height: 100%; }
.ls-browser-shell.is-device .ls-box { flex: none; margin: auto; background: #fff; box-shadow: 0 0 0 1px var(--ls-line), 0 2px 12px rgba(0,0,0,.35); }
.ls-device { position: relative; width: 100%; height: 100%; transform-origin: 0 0; }
.ls-browser-frame { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; background: #fff; }
.ls-hdl { display: none; position: absolute; z-index: 3; background: transparent; touch-action: none; }
.ls-browser-shell.is-device .ls-hdl { display: block; }
.ls-hdl-r { top: 0; bottom: 0; right: -12px; width: 12px; cursor: ew-resize; }
.ls-hdl-b { left: 0; right: 0; bottom: -12px; height: 12px; cursor: ns-resize; }
.ls-hdl-c { right: -12px; bottom: -12px; width: 12px; height: 12px; cursor: nwse-resize; }
.ls-hdl::after { content: ""; position: absolute; background: var(--ls-sub); border-radius: 3px; opacity: .8; }
.ls-hdl-r::after { top: calc(50% - 14px); left: 4px; width: 4px; height: 28px; }
.ls-hdl-b::after { left: calc(50% - 14px); top: 4px; height: 4px; width: 28px; }
.ls-hdl-c::after { left: 4px; top: 4px; width: 4px; height: 4px; border-radius: 50%; }

/* ---- new tab page (Mozilla Firefox style: large Green Fox top-center + search bar + round bookmarks + recent) */
.ls-ntp {
  position: absolute; inset: 0; z-index: 2; display: none; flex-direction: column;
  align-items: center; justify-content: flex-start; gap: 20px; padding: 26px 16px 28px;
  overflow-y: auto; background: var(--ls-toolbar); color: var(--ls-text);
}
.ls-ntp.is-on { display: flex; }
.ls-ntp-hero {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 10px; margin-top: 6px;
}
.ls-ntp-logo {
  width: 92px; height: 92px; object-fit: contain; display: block;
  filter: drop-shadow(0 6px 16px rgba(34, 197, 94, 0.25));
}
.ls-ntp-title {
  font-size: 22px; font-weight: 600; letter-spacing: .3px;
}
.ls-ntp-search {
  width: min(480px, 95%); height: 44px; border-radius: 8px;
  background: var(--ls-omni); border: 1px solid var(--ls-line);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
  display: flex; align-items: center; gap: 8px; padding: 0 6px 0 12px; color: var(--ls-sub);
}
.ls-ntp-search:focus-within {
  border-color: #22c55e;
  box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.28);
}
.ls-ntp-search-ico {
  display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ls-ntp-search input {
  flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent;
  color: var(--ls-text); font: inherit; font-size: 14px;
}
.ls-ntp-search-btn {
  height: 32px; padding: 0 14px; border: 0; border-radius: 6px;
  background: #22c55e; color: #052e16; font-weight: 600; font-size: 12.5px;
  cursor: pointer; flex-shrink: 0;
}
.ls-ntp-search-btn:active { opacity: 0.85; }
.ls-ntp-tiles {
  display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;
  width: min(480px, 100%);
}
.ls-ntp-tile {
  width: 78px; display: flex; flex-direction: column; align-items: center; gap: 6px;
  padding: 8px 4px; border: 0; border-radius: 6px; background: transparent; cursor: pointer;
}
.ls-ntp-tile:hover { background: var(--ls-hover); }
.ls-ntp-dot {
  width: 48px; height: 48px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); color: var(--ls-text);
  display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600;
  overflow: hidden; flex-shrink: 0;
}
.ls-ntp-dot img { width: 24px; height: 24px; border-radius: 50%; object-fit: contain; }
.ls-ntp-name {
  max-width: 74px; font-size: 11.5px; overflow: hidden; text-overflow: ellipsis;
  white-space: nowrap; color: var(--ls-text);
}
.ls-ntp-recent-wrap {
  width: min(480px, 100%); display: flex; flex-direction: column; gap: 6px;
  border-top: 1px solid var(--ls-line); padding-top: 12px;
}
.ls-ntp-sec-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 4px 4px; font-size: 12px; font-weight: 600; color: var(--ls-sub);
}
.ls-ntp-more {
  border: 0; background: transparent; color: #22c55e; font-size: 12px;
  font-weight: 600; cursor: pointer; padding: 2px 6px; border-radius: 3px;
}
.ls-ntp-more:hover { background: var(--ls-hover); }
.ls-ntp-recent-list { display: flex; flex-direction: column; gap: 2px; }
.ls-ntp-recent-row {
  display: flex; align-items: center; gap: 10px; width: 100%; text-align: left;
  padding: 8px 8px; border: 0; border-radius: 4px; background: transparent; cursor: pointer;
}
.ls-ntp-recent-row:hover { background: var(--ls-hover); }
.ls-ntp-recent-ico {
  width: 28px; height: 28px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); display: inline-flex; align-items: center;
  justify-content: center; font-size: 12px; font-weight: 600; flex-shrink: 0;
}
.ls-ntp-recent-meta { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.ls-ntp-recent-title {
  font-size: 13px; color: var(--ls-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-recent-url {
  font-size: 11px; color: var(--ls-sub); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-empty { font-size: 12px; color: var(--ls-sub); padding: 8px 4px; }

/* ---- find bar */
.ls-find { position: absolute; top: 80px; right: 10px; z-index: 40; display: flex; align-items: center; gap: 2px; padding: 4px 6px; background: var(--ls-menu); border: 1px solid var(--ls-line); border-radius: 3px; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
.ls-find[hidden] { display: none; }
.ls-find input { width: 150px; height: 26px; border: 0; border-bottom: 2px solid var(--ls-accent); background: transparent; color: var(--ls-text); outline: 0; font: inherit; padding: 0 4px; }
.ls-find .ls-ib { width: 26px; height: 26px; }

/* ---- overlay preview (page see-through, editor underneath stays usable) */
.ls-browser-shell.is-overlay { pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-tabstrip { display: none; }
.ls-ov-close { display: none !important; }
.ls-browser-shell.is-overlay .ls-ov-close { display: inline-flex !important; }
.ls-browser-shell.is-overlay .ls-chrome { pointer-events: auto; }
.ls-browser-shell.is-overlay .ls-stage { opacity: var(--ls-op, 1); pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-stage * { pointer-events: none; }
.ls-browser-shell.is-overlay .ls-dd-layer, .ls-browser-shell.is-overlay .ls-find { pointer-events: auto; }

/* ---- dropdown menu (desktop style) */
.ls-dd-layer { position: absolute; inset: 0; z-index: 60; }
.ls-dd-backdrop { position: absolute; inset: 0; background: transparent; }
.ls-dd-menu {
  position: absolute; min-width: 220px; max-width: calc(100% - 8px); padding: 6px 0;
  background: var(--ls-menu, #292a2d); color: var(--ls-text, #e8eaed);
  border: 1px solid var(--ls-line, #3c4043); border-radius: 3px;
  box-shadow: 0 4px 16px rgba(0,0,0,.4); font-size: 13px; overflow: auto;
}
.ls-dd-item { display: flex; align-items: center; gap: 8px; min-height: 32px; padding: 6px 14px 6px 8px; cursor: pointer; white-space: nowrap; user-select: none; }
.ls-dd-item:hover, .ls-dd-item.is-active { background: var(--ls-hover, rgba(128,128,128,.22)); }
.ls-dd-item.is-disabled { opacity: .45; pointer-events: none; }
.ls-dd-check { width: 14px; height: 14px; display: inline-flex; flex-shrink: 0; }
.ls-dd-label { flex: 1; }
.ls-dd-arrow { opacity: .7; display: inline-flex; }
.ls-dd-sep { height: 1px; margin: 6px 0; background: var(--ls-line, rgba(128,128,128,.3)); }
.ls-dd-custom { padding: 2px 8px 2px 22px; }
.ls-zoomrow { display: flex; align-items: center; gap: 4px; min-height: 32px; }
.ls-zoomrow .ls-zl { flex: 1; }
.ls-zoomrow .ls-zv { min-width: 44px; text-align: center; }
.ls-zoomrow .ls-ib { width: 26px; height: 26px; color: var(--ls-text); }

/* ---- opacity panel */
.ls-dd-panel { width: 250px; padding: 12px 14px; }
.ls-op-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.ls-op-val { color: var(--ls-accent); font-variant-numeric: tabular-nums; }
.ls-range { -webkit-appearance: none; appearance: none; width: 100%; height: 18px; margin: 0; background: transparent; outline: 0; }
.ls-range::-webkit-slider-runnable-track { height: 4px; border-radius: 3px; background: linear-gradient(to right, var(--ls-accent) var(--ls-fill, 100%), var(--ls-line) var(--ls-fill, 100%)); }
.ls-range::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; margin-top: -6px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-range::-moz-range-track { height: 4px; border-radius: 3px; background: var(--ls-line); }
.ls-range::-moz-range-progress { height: 4px; border-radius: 3px; background: var(--ls-accent); }
.ls-range::-moz-range-thumb { width: 16px; height: 16px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-op-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 12px; cursor: pointer; }
.ls-op-row.is-disabled { opacity: .45; pointer-events: none; }
.ls-op-hint { margin-top: 8px; font-size: 11px; color: var(--ls-sub); }
.ls-switch { position: relative; flex: none; width: 36px; height: 20px; }
.ls-switch::before { content: ""; position: absolute; inset: 0; border-radius: 3px; background: var(--ls-line); transition: background .15s; }
.ls-switch::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 3px; background: var(--ls-text); transition: transform .15s; }
.ls-switch.is-on::before { background: var(--ls-accent); }
.ls-switch.is-on::after { transform: translateX(16px); background: #fff; }

 #ls-deps-picker{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center}
.ls-dp-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.45)}
.ls-dp-card{position:relative;width:min(420px,92vw);max-height:min(72vh,540px);display:flex;flex-direction:column;border-radius:3px;background:var(--secondary-color,#1e1e1e);color:var(--color,#e0e0e0);overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4)}
.ls-dp-header{padding:12px 14px 8px;border-bottom:1px solid rgba(128,128,128,.25)}
.ls-dp-title{font-weight:600}
.ls-dp-subtitle{font-size:.75rem;opacity:.75;margin-top:4px}
.ls-dp-body{flex:1;overflow:auto;padding:8px 12px}
.ls-dp-row{display:flex;align-items:center;gap:10px;padding:8px 6px;border-radius:3px;margin-bottom:4px;background:rgba(128,128,128,.08)}
.ls-dp-status.ok{color:#66bb6a}.ls-dp-status.miss{color:#f48771}
.ls-dp-footer{display:flex;gap:8px;justify-content:flex-end;padding:10px 12px;border-top:1px solid rgba(128,128,128,.25)}
.ls-dp-btn{border:none;border-radius:3px;padding:8px 12px;background:rgba(128,128,128,.2);color:inherit}
.ls-dp-btn.ls-dp-install{background:var(--active-color,#61afef);color:#111;font-weight:600}
.ls-dp-progress-track{height:3px;border-radius:3px;background:rgba(128,128,128,.25);overflow:hidden}
.ls-dp-progress-bar{height:100%;background:var(--active-color,#61afef);transition:width .25s}
.ls-dp-spinner{width:16px;height:16px;border-radius:50%;border:2px solid rgba(128,128,128,.35);border-top-color:var(--active-color,#61afef);animation:ls-spin .7s linear infinite}
@keyframes ls-spin{to{transform:rotate(360deg)}}



.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }

.ls-green-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 3px; overflow: hidden; display: none; background: rgba(34, 197, 94, 0.16); }
.ls-browser-shell.is-installing .ls-green-progress { display: block; }
.ls-green-progress::before {
  content: ""; position: absolute; top: 0; bottom: 0; width: 35%;
  background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
  box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
  animation: ls-bar 1.1s ease-in-out infinite;
}
`});function qo(e){Io=e?String(e).endsWith("/")?String(e):e+"/":""}function $o(){return Io}var Io,cn=T(()=>{Io=""});async function Fo(){if(wr)return wr;let e=$o()+Mi;try{let r=await acode.require("fsOperation")(e).readFile("utf8");if(r&&r.length>1e3)return wr=String(r)}catch(t){console.warn("[LiveServer] devtool via fsOperation",t)}try{let t=await fetch(e);if(t.ok){let r=await t.text();if(r.length>1e3)return wr=r}}catch(t){console.warn("[LiveServer] devtool via fetch",t)}return null}var Mi,wr,jo=T(()=>{cn();Mi="devtool/suger-dev.js",wr=null});var Sr,zo=T(()=>{Sr=class{constructor(t){this.element=t,this.element&&(this.scroller=this.element.parentNode,this.finalScale=1,this.offsetX=0,this.offsetY=0,this.tempScale=1,this.tempOffsetX=0,this.tempOffsetY=0,this.panning=!1,this.isPanningContent=!1,this.initialDistance=0,this.panStart=null,this.pageOrigin=null,this.handleTouchStart=this.handleTouchStart.bind(this),this.handleTouchMove=this.handleTouchMove.bind(this),this.handleTouchEnd=this.handleTouchEnd.bind(this),this.handleDoubleTap=this.handleDoubleTap.bind(this),this.setupZoomEvents())}setupZoomEvents(){let t=()=>{this.element.style.touchAction=this.finalScale>1?"none":"auto"};t(),this.element.style.transformOrigin="0 0",this.element.addEventListener("touchstart",this.handleTouchStart),this.element.addEventListener("touchmove",this.handleTouchMove),this.element.addEventListener("touchend",r=>{this.handleTouchEnd(r),t()}),this.element.addEventListener("touchcancel",this.handleTouchEnd),this.element.addEventListener("dblclick",this.handleDoubleTap)}destroy(){this.element.removeEventListener("touchstart",this.handleTouchStart),this.element.removeEventListener("touchmove",this.handleTouchMove),this.element.removeEventListener("touchend",this.handleTouchEnd),this.element.removeEventListener("touchcancel",this.handleTouchEnd),this.element.removeEventListener("dblclick",this.handleDoubleTap)}getDistance(t,r){let n=t.clientX-r.clientX,o=t.clientY-r.clientY;return Math.sqrt(n*n+o*o)}getPageCoordinates(t){var l,d;if((!this.scroller||!this.scroller.getBoundingClientRect)&&(this.scroller=this.element.parentNode,!this.scroller||!this.scroller.getBoundingClientRect))return console.error("ZoomHandler Error: Cannot find scroller parent element."),null;let r=this.scroller.getBoundingClientRect(),n=this.scroller.scrollLeft,o=this.scroller.scrollTop,s=(t[0].clientX+(((l=t[1])==null?void 0:l.clientX)||t[0].clientX))/t.length,i=(t[0].clientY+(((d=t[1])==null?void 0:d.clientY)||t[0].clientY))/t.length,c=s-r.left,p=i-r.top;return{x:c+n,y:p+o}}handleTouchStart(t){if(t.touches.length===2){if(t.preventDefault(),this.pageOrigin=this.getPageCoordinates(t.touches),!this.pageOrigin)return;this.panning=!0,this.initialDistance=this.getDistance(t.touches[0],t.touches[1])}else if(t.touches.length===1&&this.finalScale>1){let r=this.getPageCoordinates(t.touches);if(!r)return;this.isPanningContent=!0,this.panStart={x:r.x-this.offsetX,y:r.y-this.offsetY}}}handleTouchMove(t){let r=t.currentTarget;if(this.panning&&t.touches.length===2){t.preventDefault();let o=this.getDistance(t.touches[0],t.touches[1])/this.initialDistance;this.tempScale=this.finalScale*o,this.tempScale=Math.max(.5,Math.min(this.tempScale,5));let s=this.tempScale/this.finalScale;this.tempOffsetX=this.pageOrigin.x*(1-s)+this.offsetX*s,this.tempOffsetY=this.pageOrigin.y*(1-s)+this.offsetY*s,r.style.transform=`translate(${this.tempOffsetX}px, ${this.tempOffsetY}px) scale(${this.tempScale})`}else if(this.isPanningContent&&t.touches.length===1&&this.finalScale>1){t.preventDefault();let n=this.getPageCoordinates(t.touches);if(!n)return;this.tempOffsetX=n.x-this.panStart.x,this.tempOffsetY=n.y-this.panStart.y,r.style.transform=`translate(${this.tempOffsetX}px, ${this.tempOffsetY}px) scale(${this.finalScale})`}}handleTouchEnd(t){this.panning&&(this.panning=!1,this.finalScale=this.tempScale,this.offsetX=this.tempOffsetX,this.offsetY=this.tempOffsetY,this.pageOrigin=null),this.isPanningContent&&(this.isPanningContent=!1,this.offsetX=this.tempOffsetX,this.offsetY=this.tempOffsetY)}handleDoubleTap(t){let r=t.currentTarget;this.finalScale=1,this.tempScale=1,this.offsetX=0,this.offsetY=0,this.tempOffsetX=0,this.tempOffsetY=0,r.style.transition="transform 0.25s ease",r.style.transformOrigin="0 0",r.style.transform="translate(0,0) scale(1)",setTimeout(()=>{r.style.transition=""},300)}}});var Go={};xe(Go,{activateTab:()=>Et,addSourceTab:()=>Rn,addTab:()=>kt,applyZoom:()=>vn,canGoBack:()=>fn,canGoForward:()=>hn,clearVisited:()=>pn,closeAllTabs:()=>Sn,closeTab:()=>zt,disposeBridge:()=>xn,duplicateActive:()=>wn,findInActive:()=>En,getActiveTab:()=>I,getTabs:()=>yt,getVisited:()=>Lr,historyActive:()=>Cr,initBridge:()=>yn,isLocalUrl:()=>xt,navigateActive:()=>ze,normalizeUrl:()=>Je,onTabsChange:()=>mn,printActive:()=>Ln,reloadActive:()=>_r,renderTabStrip:()=>Tn,sendToTab:()=>Re,setZoomActive:()=>Cn,stopActive:()=>kn,toDisplayUrl:()=>wt,toggleDevtoolsActive:()=>_n});function yt(){return K.slice()}function I(){return K.find(e=>e.id===Fe)||null}function Lr(){return Ze.slice()}function pn(){Ze=[],Z()}function fn(){let e=I();return!!(e&&e.historyIndex>0)}function hn(){let e=I();return!!(e&&e.historyIndex<e.history.length-1)}function mn(e){return kr.push(e),()=>{kr=kr.filter(t=>t!==e)}}function Z(){kr.forEach(e=>{try{e(yt(),I())}catch{}})}function gn(e,t){let r=wt(e);!r||r==="about:blank"||r.startsWith("blob:")||(Ze=Ze.filter(n=>n.url!==r),Ze.unshift({url:r,title:t||r.replace(/^https?:\/\//i,""),ts:Date.now()}),Ze.length>50&&(Ze.length=50))}function xt(e){let t=wt(e);return/^https?:\/\/(127\.0\.0\.1|localhost|0\.0\.0\.0|192\.168\.|10\.)/i.test(String(t||""))}function wt(e){let t=String(e||"").trim();if(!t)return"about:blank";let r="/__proxy?url=",n=t.indexOf(r);if(n!==-1)try{let o=t.slice(n+r.length).split("&")[0];return decodeURIComponent(o)}catch{}return t}function Je(e){let t=wt(e);if(!t||t==="about:blank")return"about:blank";if(/^(about:|blob:|data:|https?:\/\/)/i.test(t))return t;if(/^(localhost|127\.0\.0\.1|0\.0\.0\.0|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(t))return"http://"+t;if(!/\s/.test(t)&&/^[a-z0-9-]+(\.[a-z0-9-]+)+([/?#].*)?$/i.test(t))return"https://"+t;let r=k().browserSearchEngine||"google",n=encodeURIComponent(t);return r==="duckduckgo"?`https://duckduckgo.com/?q=${n}`:r==="bing"?`https://www.bing.com/search?q=${n}`:r==="brave"?`https://search.brave.com/search?q=${n}`:`https://www.google.com/search?q=${n}`}async function Hi(e,t={}){if(!e||e==="about:blank"||e.startsWith("blob:"))return e||"about:blank";if(xt(e))return e;if((k().externalSiteMode||"proxy")==="proxy"){let n=D(),o=n.running&&n.port?n.port:await Pn();if(o)return`http://127.0.0.1:${o}/__proxy?url=${encodeURIComponent(e)}`}return e}function je(){dn&&(clearTimeout(dn),dn=null)}function No(e,t,r){je()}function Re(e,t,r){try{return e.iframe.contentWindow.postMessage({ls:1,cmd:t,...r||{}},"*"),!0}catch{return!1}}function St(e){var t;try{let r=(t=e.iframe)==null?void 0:t.contentWindow;return r.document,r}catch{return null}}function vn(e){if(!e)return;let t=e.zoom||100,r=t/100;try{e.iframe&&(e.iframe.style.zoom=String(r),e.iframe.style.transformOrigin="0 0")}catch{}let n=St(e);if(n)try{n.document.documentElement.style.zoom=String(r)}catch{}Re(e,"zoom",{pct:t})}function Bi(e){return K.find(t=>{try{return t.iframe.contentWindow===e}catch{return!1}})}function bn(e,t){!e||!t||e.history[e.historyIndex]===t||(e.history=e.history.slice(0,e.historyIndex+1),e.history.push(t),e.historyIndex=e.history.length-1)}function Wo(e){let t=e.data;if(!t||t.ls!==1)return;let r=Bi(e.source);if(r)if(r.bridge=!0,t.type==="meta"){if(je(),r.loading=!1,t.href&&t.href!=="about:blank"){let n=wt(t.href);n!==r.url&&(r.url=n,bn(r,n))}r.pinTitle||(r.title=String(t.title||r.url.replace(/^https?:\/\//,"")).slice(0,60)),t.favicon&&(r.favicon=t.favicon),(r.zoom||100)!==100&&Re(r,"zoom",{pct:r.zoom}),gn(r.url,r.title),Z()}else t.type==="devtools"?(r.devtools=!!t.on,Z()):t.type==="need-devtools"?Fo().then(n=>{if(!n)return Uo("Suger DevTool file missing (devtool/suger-dev.js). Reinstall the plugin.",3500);Re(r,"devtools",{on:!0,code:n})}):t.type==="devtools-error"&&Uo("DevTool: "+t.message,3e3)}function yn(){window.addEventListener("message",Wo)}function xn(){je(),window.removeEventListener("message",Wo)}function un(e,t){!String(t||"").includes("/__proxy?url=")&&(xt(t)||t==="about:blank"||t.startsWith("blob:"))?e.setAttribute("sandbox","allow-scripts allow-same-origin allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-downloads"):e.removeAttribute("sandbox")}async function Er(e,t,r={}){je();let n=k().externalSiteMode||"proxy";e.useChromium=!1;let o=Je(t);if(r.pushHistory!==!1&&bn(e,o),e.url=o,e.devtools=!1,e.useChromium=!1,o==="about:blank"){e.loading=!1,e.title="New tab",e.favicon=null,un(e.iframe,"about:blank"),e.iframe.src="about:blank",Z();return}e.loading=!0,e.pinTitle||(e.title=o.replace(/^https?:\/\//i,"")),Z(),No(e,o,e.useChromium);let s=await Hi(o,{useChromium:e.useChromium});un(e.iframe,s),e.iframe.src=s,gn(o,e.title),Z()}function kt(e,t,r){var c,p;let n=Oi++,o=document.createElement("iframe");o.className="ls-browser-frame",o.setAttribute("allow","fullscreen; clipboard-read; clipboard-write");let s=t?Je(t):"about:blank",i={id:n,url:s,title:r||(s==="about:blank"?"New tab":s.replace(/^https?:\/\//i,"")),iframe:o,loading:s!=="about:blank",favicon:null,zoom:100,pinTitle:!!r,useChromium:!1,history:[s],historyIndex:0};e.appendChild(o);try{(p=(c=i.zoomHandler)==null?void 0:c.destroy)==null||p.call(c),i.zoomHandler=new Sr(o)}catch(l){console.warn("[LiveServer] ZoomHandler",l)}return K.push(i),K.forEach(l=>{l.iframe&&(l.iframe.style.display=l.id===n?"block":"none")}),Fe=n,o.addEventListener("load",()=>{je(),i.loading=!1,i.devtools=!1;let l=St(i);if(l)try{let f=l.__LS_PROXY_TARGET__||wt(l.location.href);f&&f!=="about:blank"&&f!==i.url&&(i.url=f,bn(i,f)),i.pinTitle||(l.document.title?i.title=l.document.title.slice(0,60):i.url!=="about:blank"&&(i.title=i.url.replace(/^https?:\/\//,"")));let g=l.document.querySelector('link[rel~="icon"]');g!=null&&g.href&&(i.favicon=g.href)}catch{}else!i.pinTitle&&i.url!=="about:blank"&&(i.title=i.url.replace(/^https?:\/\//,""));if(!i.favicon&&/^https?:/i.test(i.url))try{i.favicon=new URL("/favicon.ico",i.url).href}catch{}vn(i),gn(i.url,i.title),Z()}),s==="about:blank"?(un(o,"about:blank"),o.src="about:blank",Z()):Er(i,s,{pushHistory:!1}),i}function wn(e){let t=I();return t?kt(e,t.url,t.title):null}function Et(e){K.some(t=>t.id===e)&&(Fe=e,K.forEach(t=>{t.iframe&&(t.iframe.style.display=t.id===e?"block":"none")}),Z())}function zt(e){var n;let t=K.findIndex(o=>o.id===e);if(t<0)return K.length;let[r]=K.splice(t,1);r.id===Fe&&je();try{(n=r.iframe)==null||n.remove()}catch{}if(Fe===e)if(K.length){let o=K[Math.min(t,K.length-1)];Et(o.id)}else Fe=null,Z();else Z();return K.length}function Sn(){je(),K.forEach(e=>{var t;try{(t=e.iframe)==null||t.remove()}catch{}}),K=[],Fe=null,Z()}function ze(e,t={}){let r=I();r!=null&&r.iframe&&Er(r,e,{pushHistory:!0,useChromium:!1})}function _r(){let e=I();if(!(e!=null&&e.iframe))return;if(e.url==="about:blank"){Z();return}e.loading=!0,No(e,e.url,e.useChromium);let t=St(e),r=!1;if(t)try{t.location.reload(),r=!0}catch{}!r&&!(e.bridge&&Re(e,"reload"))&&(e.iframe.src=e.iframe.src),Z()}function kn(){je();let e=I();if(!(e!=null&&e.iframe))return;let t=St(e);if(t)try{t.stop()}catch{}else Re(e,"stop");e.loading=!1,Z()}function Cr(e){let t=I();if(t){if(e<0&&t.historyIndex>0){t.historyIndex-=1;let r=t.history[t.historyIndex];Er(t,r,{pushHistory:!1});return}if(e>0&&t.historyIndex<t.history.length-1){t.historyIndex+=1;let r=t.history[t.historyIndex];Er(t,r,{pushHistory:!1});return}}}function En(e,t){var o;let r=I();if(!r||!e)return;let n=St(r);if(n)try{(o=n.find)==null||o.call(n,e,!1,!!t,!0,!1,!1,!1);return}catch{}Re(r,"find",{q:e,back:!!t})}function Ln(){let e=I();if(!e)return!1;let t=St(e);if(t)try{return t.print(),!0}catch{}return Re(e,"print")}function _n(){let e=I();return!e||!e.bridge?!1:Re(e,"devtools",{on:!e.devtools})}function Cn(e){let t=I();return t?(t.zoom=Math.min(500,Math.max(25,Math.round(e))),vn(t),Z(),t.zoom):100}function Tn(e){e&&(e.innerHTML="",K.forEach(t=>{let r=document.createElement("div");r.className="ls-tab"+(t.id===Fe?" is-active":"")+(t.loading?" is-loading":""),r.setAttribute("role","tab"),r.title=t.title||"";let n=document.createElement("span");if(n.className="ls-fav",t.loading)n.classList.add("is-spin");else if(t.favicon){let i=document.createElement("img");i.src=t.favicon,i.alt="",i.addEventListener("error",()=>{n.innerHTML=A(R.globe,14)}),n.appendChild(i)}else n.innerHTML=A(R.globe,14);r.appendChild(n);let o=document.createElement("span");o.className="ls-tab-label",o.textContent=t.title||"Tab",r.appendChild(o);let s=document.createElement("span");s.className="ls-tab-x",s.setAttribute("role","button"),s.title="Close tab",s.innerHTML=A(R.close,12),s.addEventListener("click",i=>{i.stopPropagation(),zt(t.id)}),r.appendChild(s),r.addEventListener("click",()=>Et(t.id)),e.appendChild(r)}))}function Rn(e,t,r){let n=kt(e,"about:blank",t||"view-source");n.pinTitle=!0,n.loading=!1,n.url=t||"view-source";try{n.iframe.removeAttribute("sandbox")}catch{}try{n.iframe.srcdoc=r}catch{let s=new Blob([r],{type:"text/html;charset=utf-8"});n.iframe.src=URL.createObjectURL(s)}return n.loading=!1,Z(),n}var Uo,K,Fe,Oi,kr,Ze,dn,An=T(()=>{jt();jo();ne();J();he();xr();zo();Uo=acode.require("toast"),K=[],Fe=null,Oi=1,kr=[],Ze=[],dn=null});function Ut(e,t=20){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var Mn=T(()=>{});function ue(e,t){let r=document.createElement(e);return t&&(r.className=t),r}function Nt(){me&&me.close()}function Xo(){return!!me}function Wt({host:e,anchor:t,items:r,onClose:n}){if(Nt(),!e||!(r!=null&&r.length))return{close(){}};let o=ue("div","ls-dd-layer"),s=ue("div","ls-dd-backdrop");o.appendChild(s),e.appendChild(o);let i=[],c=!1;function p(m){for(;i.length>m;)i.pop().remove()}function l(){if(!c){c=!0,document.removeEventListener("keydown",d,!0);try{o.remove()}catch{}me&&me.close===l&&(me=null);try{n==null||n()}catch{}}}function d(m){m.key==="Escape"&&(m.stopPropagation(),l())}function f(m,b,L){let S=e.getBoundingClientRect(),_=m.offsetWidth,P=m.offsetHeight,C,v;b===0?(v=L.bottom-S.top+2,C=L.right-S.left-_,C<4&&(C=L.left-S.left)):(v=L.top-S.top-4,C=L.right-S.left-2,C+_>S.width-4&&(C=L.left-S.left-_+2)),C+_>S.width-4&&(C=S.width-_-4),C<4&&(C=4);let M=S.height-v-4;P>M&&S.height&&(b>0&&S.height-P-4>0?v=S.height-P-4:m.style.maxHeight=Math.max(M,80)+"px"),v<4&&(v=4),m.style.left=C+"px",m.style.top=v+"px"}function g(m,b,L){p(b);let S=ue("div","ls-dd-menu");return S.setAttribute("role","menu"),S.style.visibility="hidden",m.forEach(_=>{if(_.separator){S.appendChild(ue("div","ls-dd-sep"));return}if(_.render){let B=ue("div","ls-dd-custom");_.render(B,l),S.appendChild(B);return}let P=ue("div","ls-dd-item"+(_.disabled?" is-disabled":""));P.setAttribute("role","menuitem");let C=ue("span","ls-dd-check");_.checked&&(C.innerHTML=Ut(Di,14)),P.appendChild(C);let v=ue("span","ls-dd-label");if(v.textContent=_.label,P.appendChild(v),_.children){let B=ue("span","ls-dd-arrow");B.innerHTML=Ut(Ii,14),P.appendChild(B)}let M=()=>{S.querySelectorAll(".ls-dd-item.is-active").forEach(B=>B.classList.remove("is-active")),P.classList.add("is-active"),g(_.children,b+1,P.getBoundingClientRect())},q=()=>{p(b+1),P.classList.remove("is-active")};P.addEventListener("pointerenter",B=>{B.pointerType&&B.pointerType!=="mouse"||(_.children?M():(p(b+1),S.querySelectorAll(".ls-dd-item.is-active").forEach(h=>h.classList.remove("is-active"))))}),P.addEventListener("click",B=>{var h;if(B.stopPropagation(),!_.disabled){if(_.children){P.classList.contains("is-active")&&i.length>b+1?q():M();return}l();try{(h=_.onClick)==null||h.call(_)}catch(y){console.warn("[LiveServer] menu item",y)}}}),S.appendChild(P)}),o.appendChild(S),i.push(S),f(S,b,L),S.style.visibility="",S}s.addEventListener("click",m=>{m.stopPropagation(),l()}),s.addEventListener("contextmenu",m=>{m.preventDefault(),l()}),document.addEventListener("keydown",d,!0);let a=t?t.getBoundingClientRect():e.getBoundingClientRect();return g(r,0,a),me={close:l},{close:l}}function Vo({host:e,anchor:t,render:r,onClose:n}){if(Nt(),!e)return{close(){}};let o=ue("div","ls-dd-layer"),s=ue("div","ls-dd-backdrop"),i=ue("div","ls-dd-menu ls-dd-panel");o.append(s,i),e.appendChild(o);let c=!1;function p(){if(!c){c=!0,document.removeEventListener("keydown",l,!0);try{o.remove()}catch{}me&&me.close===p&&(me=null);try{n==null||n()}catch{}}}function l(m){m.key==="Escape"&&(m.stopPropagation(),p())}s.addEventListener("click",m=>{m.stopPropagation(),p()}),document.addEventListener("keydown",l,!0),r(i,p);let d=e.getBoundingClientRect(),f=t?t.getBoundingClientRect():d,g=i.offsetWidth,a=f.right-d.left-g;return a>d.width-g-4&&(a=d.width-g-4),a<4&&(a=4),i.style.left=a+"px",i.style.top=f.bottom-d.top+2+"px",me={close:p},{close:p,panel:i}}var Di,Ii,me,Gt=T(()=>{Mn();Di="M20 6L9 17l-5-5",Ii="M9 18l6-6-6-6",me=null});async function qi(e){var t;try{if((t=navigator.clipboard)!=null&&t.writeText)await navigator.clipboard.writeText(e);else{let r=document.createElement("textarea");r.value=e,document.body.appendChild(r),r.select(),document.execCommand("copy"),r.remove()}On("URL copied",1500)}catch{On(e||"No URL",2500)}}async function $i(){let{getServerStatus:e}=await Promise.resolve().then(()=>(he(),gt)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function Yo(e,t=38){return e=String(e||""),e.length>t?e.slice(0,t-1)+"\u2026":e}function Fi(e){return{render(t){var l,d;let r=document.createElement("div");r.className="ls-zoomrow";let n=document.createElement("span");n.className="ls-zl",n.textContent="Zoom";let o=document.createElement("button");o.type="button",o.className="ls-ib",o.innerHTML=A(R.minus,14);let s=document.createElement("span");s.className="ls-zv",s.textContent=((d=(l=e.getZoom)==null?void 0:l.call(e))!=null?d:100)+"%";let i=document.createElement("button");i.type="button",i.className="ls-ib",i.innerHTML=A(R.plus,14);let c=document.createElement("button");c.type="button",c.className="ls-ib",c.title="Fullscreen",c.innerHTML=A(R.maximize,14);let p=f=>{var a;let g=(a=e.zoom)==null?void 0:a.call(e,f);g!=null&&(s.textContent=g+"%")};o.addEventListener("click",f=>{f.stopPropagation(),p(-10)}),i.addEventListener("click",f=>{f.stopPropagation(),p(10)}),s.style.cursor="pointer",s.addEventListener("click",f=>{var a;f.stopPropagation();let g=(a=e.zoom)==null?void 0:a.call(e,0,!0);g!=null&&(s.textContent=g+"%")}),c.addEventListener("click",f=>{var g;f.stopPropagation(),(g=e.toggleFullscreen)==null||g.call(e)}),r.append(n,o,s,i,c),t.appendChild(r)}}}function Hn(e,t){var i,c,p,l,d,f,g;let r=((i=e.getVisited)==null?void 0:i.call(e))||[],n=((c=e.getBookmarks)==null?void 0:c.call(e))||[],o=!!((p=e.isBookmarked)!=null&&p.call(e)),s=[{label:"New tab",onClick:()=>{var a;return(a=e.newTab)==null?void 0:a.call(e)}},{label:"Duplicate tab",onClick:()=>{var a;return(a=e.duplicateTab)==null?void 0:a.call(e)}},{separator:!0},{label:"History",children:r.length?[...r.slice(0,15).map(a=>({label:Yo(a.title||a.url),onClick:()=>{var m;return(m=e.navigate)==null?void 0:m.call(e,a.url)}})),{separator:!0},{label:"Clear history",onClick:()=>{var a;return(a=e.clearHistory)==null?void 0:a.call(e)}}]:[{label:"No history yet",disabled:!0}]},{label:"Bookmarks",children:[{label:o?"Remove bookmark for this tab":"Bookmark this tab",onClick:()=>{var a;return(a=e.toggleBookmark)==null?void 0:a.call(e)}},...n.length?[{separator:!0}]:[],...n.map(a=>({label:Yo(a.title||a.url),onClick:()=>{var m;return(m=e.navigate)==null?void 0:m.call(e,a.url)}}))]},{separator:!0},Fi(e),{label:"Print\u2026",onClick:()=>{var a;return(a=e.print)==null?void 0:a.call(e)}},{label:"Find\u2026",onClick:()=>{var a;return(a=e.find)==null?void 0:a.call(e)}},{label:"Developer tools",checked:!!((l=e.isDevtools)!=null&&l.call(e)),onClick:()=>{var a;return(a=e.toggleDevtools)==null?void 0:a.call(e)}},{separator:!0},{label:"More tools",children:[{label:"Device mode (responsive)",checked:!!((d=e.isDeviceMode)!=null&&d.call(e)),onClick:()=>{var a;return(a=e.toggleDeviceMode)==null?void 0:a.call(e)}},{label:"View page source",onClick:()=>{var a;return(a=e.viewSource)==null?void 0:a.call(e)}},{separator:!0},{label:"Zoom in",onClick:()=>{var a;return(a=e.zoom)==null?void 0:a.call(e,10)}},{label:"Zoom out",onClick:()=>{var a;return(a=e.zoom)==null?void 0:a.call(e,-10)}},{label:"Reset zoom",onClick:()=>{var a;return(a=e.zoom)==null?void 0:a.call(e,0,!0)}},{separator:!0},{label:"Open server root",onClick:async()=>{var m;let a=await $i();a?(m=e.navigate)==null||m.call(e,a):On("Server not running",2e3)}},{label:"Copy current URL",onClick:()=>{var a;return qi(((a=e.getUrl)==null?void 0:a.call(e))||"")}},{label:"Open in external browser",onClick:()=>{var a;return(a=e.openExternal)==null?void 0:a.call(e)}},{separator:!0},{label:"Close other tabs",onClick:()=>{var a;return(a=e.closeOtherTabs)==null?void 0:a.call(e)}},{label:"Close current tab",onClick:()=>{var a;return(a=e.closeTab)==null?void 0:a.call(e)}}]},{label:"Opacity\u2026",onClick:()=>{var a;return(a=e.openOpacity)==null?void 0:a.call(e)}},{label:"Preview as overlay",checked:!!((f=e.isOverlay)!=null&&f.call(e)),disabled:!((g=e.canOverlay)!=null&&g.call(e)),onClick:()=>{var a;return(a=e.toggleOverlay)==null?void 0:a.call(e)}},{separator:!0},{label:"Settings",onClick:async()=>{let{openSettingsHub:a}=await Promise.resolve().then(()=>(Xt(),Tr));a()}},{label:"Exit",onClick:()=>{var a;return(a=e.closeBrowser)==null?void 0:a.call(e)}}];return Wt({host:t.host,anchor:t.anchor,items:s})}var On,Ko=T(()=>{Gt();jt();On=acode.require("toast")});function Qe(e){let t=parseFloat(e);return Number.isFinite(t)?Math.min(Bn,Math.max(Rr,Math.round(t*100)/100)):1}function Zo(e){return String(Qe(e)).replace(/(\.\d)0$/,"$1")}function Jo(e,t,r){let n=document.createElement("div");n.className="ls-op-row"+(r?" is-disabled":"");let o=document.createElement("span");o.textContent=e;let s=document.createElement("span");return s.className="ls-switch"+(t?" is-on":""),n.append(o,s),{r:n,sw:s}}function Qo({host:e,anchor:t,get:r,set:n}){return Vo({host:e,anchor:t,render(o){let s=r(),i=document.createElement("div");i.className="ls-op-head";let c=document.createElement("span");c.textContent="Browser opacity";let p=document.createElement("span");p.className="ls-op-val",p.textContent=Zo(s.opacity),i.append(c,p);let l=document.createElement("input");l.type="range",l.className="ls-range",l.min=String(Rr),l.max=String(Bn),l.step="0.05",l.value=String(Qe(s.opacity));let d=()=>{let m=(l.value-Rr)/(Bn-Rr)*100;l.style.setProperty("--ls-fill",m+"%")};d(),l.addEventListener("input",()=>{d(),p.textContent=Zo(l.value),n({opacity:Qe(l.value)})});let f=Jo("Preview as overlay",s.overlay,!s.canOverlay),g=Jo("Auto-save while typing",s.autoSave,!1);g.r.style.display=s.overlay?"":"none",f.r.addEventListener("click",()=>{let m=!f.sw.classList.contains("is-on");f.sw.classList.toggle("is-on",m),g.r.style.display=m?"":"none",n({overlay:m})}),g.r.addEventListener("click",()=>{let m=!g.sw.classList.contains("is-on");g.sw.classList.toggle("is-on",m),n({autoSave:m})});let a=document.createElement("div");a.className="ls-op-hint",a.textContent=s.canOverlay?"Overlay: the preview is see-through and you can keep editing underneath.":"Overlay needs the Acode page display mode.",o.append(i,l,f.r,g.r,a)}})}var Rr,Bn,es=T(()=>{Gt();Rr=.1,Bn=1});function Pr(e){return Ar.find(t=>t.id===e)||Ar[0]}function Ae(e){let t=Math.round(Number(e));return Number.isFinite(t)?Math.min(ji,Math.max(In,t)):null}function ts(e,t,r,n,o){return e!=="fit"?Math.max(.1,Number(e)/100):!n||!o?1:Math.min(1,n/t,o/r)}var Ar,Dn,In,ji,rs=T(()=>{Ar=[{id:"responsive",name:"Responsive",w:390,h:844},{id:"iphone-se",name:"iPhone SE",w:375,h:667},{id:"iphone-xr",name:"iPhone XR",w:414,h:896},{id:"iphone-12-pro",name:"iPhone 12 Pro",w:390,h:844},{id:"iphone-14-pro-max",name:"iPhone 14 Pro Max",w:430,h:932},{id:"pixel-7",name:"Pixel 7",w:412,h:915},{id:"galaxy-s8-plus",name:"Samsung Galaxy S8+",w:360,h:740},{id:"galaxy-s20-ultra",name:"Samsung Galaxy S20 Ultra",w:412,h:915},{id:"galaxy-fold",name:"Galaxy Fold",w:280,h:653},{id:"surface-duo",name:"Surface Duo",w:540,h:720},{id:"ipad-mini",name:"iPad Mini",w:768,h:1024},{id:"ipad-air",name:"iPad Air",w:820,h:1180},{id:"ipad-pro",name:"iPad Pro",w:1024,h:1366},{id:"surface-pro-7",name:"Surface Pro 7",w:912,h:1368},{id:"nest-hub",name:"Nest Hub",w:1024,h:600},{id:"nest-hub-max",name:"Nest Hub Max",w:1280,h:800},{id:"laptop",name:"Laptop 1366",w:1366,h:768},{id:"desktop",name:"Desktop 1920",w:1920,h:1080}],Dn=["fit",25,50,75,100,125,150,200];In=50,ji=9999});function Pe(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.innerHTML=r),n}function ns({shell:e,stage:t,box:r,device:n,bar:o,onChange:s}){let i={on:!1,id:"responsive",w:390,h:844,zoom:"fit"},c=1,p=null,l=Pe("button","ls-dev-btn ls-dev-device");l.type="button";let d=Pe("input","ls-dev-num"),f=Pe("input","ls-dev-num");[d,f].forEach(h=>{h.type="number",h.min=String(In),h.inputMode="numeric"});let g=Pe("span","ls-dev-x","&times;"),a=Pe("button","ls-dev-btn ls-dev-zoom");a.type="button";let m=Pe("button","ls-dev-icon",A(R.rotate,16));m.type="button",m.title="Rotate";let b=Pe("button","ls-dev-icon",A(R.close,16));b.type="button",b.title="Close device mode";let L=Pe("span","ls-dev-spacer");o.append(l,d,g,f,a,m,L,b);function S(){try{s==null||s({...i})}catch{}}function _(){return i.zoom==="fit"?"Fit to window ("+Math.round(c*100)+"%)":i.zoom+"%"}function P(){l.innerHTML="<span>"+Pr(i.id).name+"</span>"+A(R.down,12),document.activeElement!==d&&(d.value=String(i.w)),document.activeElement!==f&&(f.value=String(i.h)),a.innerHTML="<span>"+_()+"</span>"+A(R.down,12)}function C(){if(e.classList.toggle("is-device",i.on),o.hidden=!i.on,!i.on){r.style.width="",r.style.height="",n.style.width="",n.style.height="",n.style.transform="";return}let h=t.clientWidth-24,y=t.clientHeight-24;c=ts(i.zoom,i.w,i.h,h,y),r.style.width=Math.round(i.w*c)+"px",r.style.height=Math.round(i.h*c)+"px",n.style.width=i.w+"px",n.style.height=i.h+"px",n.style.transform="scale("+c+")",P()}function v(h,y,te){let be=Ae(h),Xe=Ae(y);be!=null&&(i.w=be),Xe!=null&&(i.h=Xe),te||(i.id="responsive"),C(),S()}function M(h){let y=Pr(h);i.id=y.id,i.w=y.w,i.h=y.h,C(),S()}l.addEventListener("click",()=>{Wt({host:e,anchor:l,items:Ar.map(h=>({label:h.id==="responsive"?h.name:h.name+"  "+h.w+" x "+h.h,checked:h.id===i.id,onClick:()=>M(h.id)}))})}),a.addEventListener("click",()=>{Wt({host:e,anchor:a,items:Dn.map(h=>({label:h==="fit"?"Fit to window":h+"%",checked:h===i.zoom,onClick:()=>{i.zoom=h,C(),S()}}))})}),m.addEventListener("click",()=>v(i.h,i.w,!0)),b.addEventListener("click",()=>B.toggle(!1));let q=()=>v(d.value,f.value);[d,f].forEach(h=>{h.addEventListener("change",q),h.addEventListener("keydown",y=>{y.key==="Enter"&&(q(),h.blur())})}),["r","b","c"].forEach(h=>{let y=Pe("div","ls-hdl ls-hdl-"+h);r.appendChild(y),y.addEventListener("pointerdown",te=>{te.preventDefault(),te.stopPropagation();let be=te.clientX,Xe=te.clientY,Tt=i.w,ir=i.h;try{y.setPointerCapture(te.pointerId)}catch{}n.style.pointerEvents="none";let Rt=it=>{var V,ie;let u=c||1,x=h==="b"?Tt:Tt+(it.clientX-be)/u,U=h==="r"?ir:ir+(it.clientY-Xe)/u;i.id="responsive",i.w=(V=Ae(x))!=null?V:i.w,i.h=(ie=Ae(U))!=null?ie:i.h,C()},Ve=()=>{y.removeEventListener("pointermove",Rt),y.removeEventListener("pointerup",Ve),y.removeEventListener("pointercancel",Ve),n.style.pointerEvents="",S()};y.addEventListener("pointermove",Rt),y.addEventListener("pointerup",Ve),y.addEventListener("pointercancel",Ve)})}),typeof ResizeObserver=="function"&&(p=new ResizeObserver(()=>{i.on&&i.zoom==="fit"&&C()}),p.observe(t));let B={getState:()=>({...i}),getScale:()=>c,isOn:()=>i.on,setState(h){h&&(typeof h.id=="string"&&(i.id=Pr(h.id).id),Ae(h.w)!=null&&(i.w=Ae(h.w)),Ae(h.h)!=null&&(i.h=Ae(h.h)),h.zoom!=null&&(i.zoom=Dn.includes(h.zoom)?h.zoom:"fit"),i.on=!!h.on,C())},toggle(h){return i.on=h==null?!i.on:!!h,C(),S(),i.on},layout:C,destroy(){try{p==null||p.disconnect()}catch{}}};return P(),B}var os=T(()=>{jt();Gt();rs()});function Vt(e,t){if(!e)return;let r=t==null?!e.classList.contains("is-fullscreen"):!!t;return e.classList.toggle("is-fullscreen",r),document.body.classList.toggle("ls-browser-fs",r),r}function ss(e){return Vt(e,!1)}var is=T(()=>{});function as(e,t={}){var P,C;let r=acode.require("page"),n=acode.require("actionStack"),o="liveserver-browser-page-"+ ++zi,s=document.createElement("span");s.className="icon arrow_back",s.dataset.action="back",s.style.cssText="pointer-events:auto;cursor:pointer;";let i=r(t.title||"Live Preview",{lead:s}),c=i.body||i,p=i.header||((P=i.querySelector)==null?void 0:P.call(i,"header"));p&&(p.style.display="none"),Object.assign(c.style,{position:"absolute",inset:"0",top:"0",left:"0",right:"0",bottom:"0",width:"auto",height:"auto",padding:"0",margin:"0",overflow:"hidden"}),e.classList.add("is-in-page"),typeof i.appendBody=="function"?i.appendBody(e):c.appendChild(e);let l=!1,d=null,f=()=>{var M;let v=!1;try{v=!!((M=t.onBack)!=null&&M.call(t))}catch{}if(v){try{n.remove(o),n.push({id:o,action:f})}catch{}return}a()};function g(){try{n.remove(o),n.push({id:o,action:f})}catch{}}function a(){if(!l){try{n.remove(o)}catch{}try{i.style.display="none"}catch{}}}function m(){var v;if(!l){try{i.style.display="",i.isConnected||(window.app||document.body).append(i),(v=i.show)==null||v.call(i)}catch{}g()}}function b(v){var M,q,B;if(!l){l=!0;try{window.removeEventListener("resize",_)}catch{}try{n.remove(o)}catch{}try{(M=i.hide)==null||M.call(i)}catch{}try{(q=i.remove)==null||q.call(i)}catch{}if(v)try{(B=t.onClose)==null||B.call(t)}catch{}}}s.onclick=v=>{var M,q;try{(M=v==null?void 0:v.preventDefault)==null||M.call(v),(q=v==null?void 0:v.stopPropagation)==null||q.call(v)}catch{}a()};try{i.onhide=()=>{l||a()}}catch{}(window.app||document.body).append(i);try{getComputedStyle(i).position==="static"&&Object.assign(i.style,{position:"absolute",inset:"0",width:"100%",height:"100%"})}catch{}try{(C=i.show)==null||C.call(i)}catch{}g();let L=()=>{var v,M;try{let q=(v=window.editorManager)==null?void 0:v.container,B=(M=q==null?void 0:q.getBoundingClientRect)==null?void 0:M.call(q);if(B&&B.width>0&&B.height>0)return B}catch{}return{left:0,top:0,width:window.innerWidth,height:window.innerHeight}},S=()=>{let v=L();i.style.left=v.left+"px",i.style.top=v.top+"px",i.style.width=v.width+"px",i.style.height=v.height+"px"},_=()=>{d!=null&&S()};return window.addEventListener("resize",_),{page:i,show:m,minimize:a,setAppearance({overlay:v,opacity:M}){v?(d==null&&(d=i.style.cssText),Object.assign(i.style,{position:"fixed",background:"transparent",pointerEvents:"none",opacity:"1"}),S(),c.style.background="transparent"):(d!=null&&(i.style.cssText=d,d=null),c.style.background="",i.style.opacity=M<1?String(M):"")},close:()=>{window.removeEventListener("resize",_),b(!1)},onFullscreen(){}}}var zi,ls=T(()=>{zi=0});function Ni(){for(let e of["editorFile","EditorFile"])try{let t=acode.require(e);if(typeof t=="function")return t}catch{}return null}async function cs(e,t={}){var l;let r=Ni();if(!r)return null;e.classList.add("is-in-tab");let n=t.title||"Live Preview",o="liveserver-preview-"+Date.now()+"-"+ ++Ui,s=null,i=[{type:"custom",content:e,stylesheets:t.css?[t.css]:[],hideQuickTools:!0,id:o,render:!0},{type:"page",content:e,stylesheets:t.css?[t.css]:[],id:o,render:!0}];for(let d of i)try{s=new r(n,d);break}catch(f){console.warn("[LiveServer] EditorFile "+d.type,f),s=null}if(!s)return e.classList.remove("is-in-tab"),null;let c=!1,p=()=>{var d;if(!c){c=!0;try{(d=t.onClose)==null||d.call(t)}catch{}}};try{(l=s.on)==null||l.call(s,"close",p)}catch{}try{s.onclose=p}catch{}return{file:s,show(){var d;if(!c)try{(d=s.makeActive)==null||d.call(s)}catch{}},close(){var d,f;if(!c){c=!0;try{(d=s.remove)==null||d.call(s,!0)}catch{try{(f=s.remove)==null||f.call(s)}catch{}}}},onFullscreen(){},setAppearance(){}}}var Ui,ds=T(()=>{Ui=0});var ps={};xe(ps,{destroyAcodeWebview:()=>Xi,isNativeWebviewSupported:()=>Gi,openInAcodeWebview:()=>qn});function us(e){var t,r,n;try{return(r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open?(window.cordova.InAppBrowser.open(e,"_system"),!0):(n=window.cordova)!=null&&n.exec?(window.cordova.exec(null,null,"System","open-in-browser",[e]),!0):(window.open(e,"_blank","noopener"),!0)}catch{return Wi(e,2500),!1}}function Gi(){try{let e=acode.require("webview");return!!(e&&typeof e.create=="function")}catch{return!1}}async function qn(e,t={}){if(!e||e==="about:blank")return!1;let r=null;try{r=acode.require("webview")}catch{}if(!(r!=null&&r.create))return us(e);if(ge)try{return await ge.loadURL(e),await ge.show(),!0}catch{ge=null}try{let n=await r.create({mode:"fullscreen",title:t.title||e.replace(/^https?:\/\//i,""),allowNavigation:!0,allowDownloads:t.allowDownloads!==!1,visible:!0});return ge=n,n.on("closed",()=>{ge===n&&(ge=null)}),await n.loadURL(e),!0}catch(n){return console.warn("[LiveServer] native webview failed, falling back:",n),ge=null,us(e)}}async function Xi(){if(!ge)return;let e=ge;ge=null;try{await e.destroy()}catch{}}var Wi,ge,$n=T(()=>{Wi=acode.require("toast"),ge=null});var rt={};xe(rt,{createBrowserShell:()=>oa,hideBrowser:()=>_t,openBrowser:()=>zn,openBrowserMenu:()=>Hn});function vs(){return k().browserDisplayMode==="editorTab"?"editorTab":"inPage"}function Zi(e,t){try{return new URL(e).origin===new URL(t).origin}catch{return!1}}function et(){let e=k().browserBookmarks;return Array.isArray(e)?e:[]}async function Ji(){let{getServerStatus:e}=await Promise.resolve().then(()=>(he(),gt)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function hs(e){var t,r,n;if(!(!e||e==="about:blank"))try{if((r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open){window.cordova.InAppBrowser.open(e,"_system");return}if((n=window.cordova)!=null&&n.exec){window.cordova.exec(null,null,"System","open-in-browser",[e]);return}window.open(e,"_blank","noopener")}catch{se(e,2500)}}function Qi(){if(!(Lt||typeof editorManager=="undefined"||!(editorManager!=null&&editorManager.on))){Lt=()=>{k().overlayAutoSave!==!1&&(clearTimeout(Fn),Fn=setTimeout(async()=>{var r;let e=X(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";if(e&&e.isUnsaved&&(e.uri||e.url)&&Yi.test(t))try{await((r=e.save)==null?void 0:r.call(e))}catch(n){console.warn("[LiveServer] overlay auto-save",n)}},700))};try{editorManager.on("update",Lt)}catch{}}}function bs(){var e;if(clearTimeout(Fn),Lt)try{(e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"update",Lt)}catch{}Lt=null}function Or(){return tt==="page"&&!!k().browserOverlay}function jn(){var n,o;if(!z)return;let e=k(),t=Qe((n=e.browserOpacity)!=null?n:1),r=Or();z.classList.toggle("is-overlay",r),z.classList.toggle("no-url",e.showAddressBar===!1),z.style.setProperty("--ls-op",String(t)),tt==="page"?((o=j==null?void 0:j.setAppearance)==null||o.call(j,{overlay:r,opacity:t}),z.style.opacity=""):z.style.opacity=t<1?String(t):"",r?Qi():bs(),Y==null||Y.layout()}function ms(e){if("opacity"in e&&O("browserOpacity",Qe(e.opacity)),"overlay"in e){if(e.overlay&&tt!=="page"){se("Overlay needs the Acode page display mode",2200);return}O("browserOverlay",!!e.overlay)}"autoSave"in e&&O("overlayAutoSave",!!e.autoSave),jn()}function ea(e){var Rt,Ve,it;let t=u=>e.querySelector(u),r=t(".ls-browser-tabs"),n=t(".ls-stage"),o=t(".ls-box"),s=t(".ls-device"),i=t(".ls-ntp"),c=t(".ls-back"),p=t(".ls-fwd"),l=t(".ls-browser-url"),d=t(".ls-reload"),f=t(".ls-star"),g=t(".ls-site"),a=t(".ls-menu-btn"),m=t(".ls-op-btn"),b=t(".ls-dev-toggle"),L=t(".ls-find"),S=L.querySelector("input"),_=!1;Y=ns({shell:e,stage:n,box:o,device:s,bar:t(".ls-devbar"),onChange:u=>O("browserDevice",u)});let P=k().browserDevice;P&&typeof P=="object"&&Y.setState(P);let C=()=>e.getRootNode().activeElement===l,v=async u=>{if(u==="about:blank"){ze("about:blank");return}let x=Je(u);if(!x||x==="about:blank"){ze("about:blank");return}if(!xt(x)){let U=k().externalSiteMode||"proxy";if(U==="acodeWebview"){await qn(x);return}if(U==="systemBrowser"){hs(x);return}}ze(x)},M=()=>{i.innerHTML="";let u=document.createElement("div");u.className="ls-ntp-hero";let x=document.createElement("img");x.className="ls-ntp-logo",x.src=Vi,x.alt="Live Server",x.onerror=()=>{x.style.display="none"},u.appendChild(x);let U=document.createElement("div");U.className="ls-ntp-title",U.textContent="Live Server",u.appendChild(U);let V=document.createElement("div");V.className="ls-ntp-search";let ie=document.createElement("span");ie.className="ls-ntp-search-ico",ie.innerHTML=A(R.search,17);let ae=document.createElement("input");ae.type="text",ae.placeholder="Search or type a URL",ae.setAttribute("enterkeyhint","enter"),ae.setAttribute("inputmode","text"),ae.setAttribute("spellcheck","false"),ae.setAttribute("autocapitalize","off"),ae.setAttribute("autocomplete","off");let Oe=document.createElement("button");Oe.type="button",Oe.className="ls-ntp-search-btn",Oe.textContent="Search";let W=()=>{let w=ae.value.trim();if(!w){ae.focus();return}v(w)};ae.addEventListener("keydown",w=>{w.key==="Enter"&&W()}),Oe.addEventListener("click",W),V.append(ie,ae,Oe);let He=document.createElement("div");He.className="ls-ntp-tiles";let zr=async w=>{let $=et();if(w<0||w>=$.length)return;let G=acode.require("prompt"),Q=acode.require("select"),re=$[w],F=await Q("Shortcut",[["edit","Edit name / URL"],["delete","Remove shortcut"]],{hideOnSelect:!0});if(!F)return;if(F==="delete"){$.splice(w,1),O("browserBookmarks",$),M();return}let at=await G("Bookmark URL",re.url||"https://","text");if(!at)return;let Ye=Je(at),ye=await G("Shortcut name",re.title||Ye.replace(/^https?:\/\//,""),"text")||Ye;$[w]={url:Ye,title:ye},O("browserBookmarks",$),M()},Ur=(w,$)=>{let G=null,Q=!1,re=()=>{G&&clearTimeout(G),G=null};w.addEventListener("touchstart",F=>{Q=!1,re(),G=setTimeout(()=>{G=null,$(F)},480)},{passive:!0}),w.addEventListener("touchmove",()=>{Q=!0,re()},{passive:!0}),w.addEventListener("touchend",re),w.addEventListener("touchcancel",re),w.addEventListener("contextmenu",F=>{F.preventDefault(),$(F)}),w.addEventListener("pointerdown",F=>{F.pointerType==="mouse"&&F.button===2||F.pointerType})},io=(w,$,G,Q,re={})=>{let F=document.createElement("button");F.type="button",F.className="ls-ntp-tile",F.innerHTML='<span class="ls-ntp-dot"></span><span class="ls-ntp-name"></span>';let at=F.querySelector(".ls-ntp-dot");if(Q&&/^https?:/i.test(Q)&&!xt(Q)){let ye=document.createElement("img");ye.src=Q,ye.alt="",ye.onerror=()=>{at.textContent=G},at.appendChild(ye)}else at.textContent=G;F.querySelector(".ls-ntp-name").textContent=w;let Ye=!1;return F.addEventListener("click",async ye=>{if(Ye){Ye=!1,ye.preventDefault();return}let co=typeof $=="function"?await $():$;if(!co)return se("Server not running",2e3);v(co)}),typeof re.onLongPress=="function"&&Ur(F,ye=>{Ye=!0,re.onLongPress(ye)}),F};He.appendChild(io("Server root",Ji,"S",null)),et().forEach((w,$)=>{var re;let G=null;try{let F=new URL(w.url).hostname;F&&F!=="127.0.0.1"&&F!=="localhost"&&(G=`https://www.google.com/s2/favicons?domain=${encodeURIComponent(F)}&sz=64`)}catch{}let Q=((re=(w.title||w.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:re.toUpperCase())||"B";He.appendChild(io(w.title||w.url,w.url,Q,G,{onLongPress:()=>zr($)}))});let At=document.createElement("button");At.type="button",At.className="ls-ntp-tile",At.innerHTML=`<span class="ls-ntp-dot">${A(R.plus,20)}</span><span class="ls-ntp-name">Add shortcut</span>`,At.addEventListener("click",async()=>{let w=acode.require("prompt"),$=await w("Bookmark URL (e.g. https://duckduckgo.com)","https://","text");if(!$)return;let G=Je($),Q=await w("Shortcut name",G.replace(/^https?:\/\//,""),"text")||G,re=et();O("browserBookmarks",[...re,{title:Q.trim(),url:G}]),M()}),He.appendChild(At);let ar=document.createElement("div");ar.className="ls-ntp-recent-wrap";let Nr=Lr(),lr=document.createElement("div");lr.className="ls-ntp-sec-head";let ao=document.createElement("span");if(ao.textContent="Recent",lr.appendChild(ao),Nr.length>0){let w=document.createElement("button");w.type="button",w.className="ls-ntp-more",w.textContent=_?"Less":"More",w.addEventListener("click",()=>{_=!_,M()}),lr.appendChild(w)}ar.appendChild(lr);let cr=document.createElement("div");cr.className="ls-ntp-recent-list";let lo=_?Nr:Nr.slice(0,5);if(lo.length)lo.forEach(w=>{var Q;let $=document.createElement("button");$.type="button",$.className="ls-ntp-recent-row";let G=((Q=(w.title||w.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:Q.toUpperCase())||"W";$.innerHTML=`
          <span class="ls-ntp-recent-ico">${G}</span>
          <span class="ls-ntp-recent-meta">
            <span class="ls-ntp-recent-title"></span>
            <span class="ls-ntp-recent-url"></span>
          </span>
        `,$.querySelector(".ls-ntp-recent-title").textContent=w.title||w.url,$.querySelector(".ls-ntp-recent-url").textContent=w.url,$.addEventListener("click",()=>v(w.url)),cr.appendChild($)});else{let w=document.createElement("div");w.className="ls-ntp-empty",w.textContent="No recent pages yet",cr.appendChild(w)}ar.appendChild(cr),i.append(u,V,He,ar)},q=()=>{let u=I();Tn(r),l&&!C()&&(l.value=u&&u.url!=="about:blank"?u.url:""),e.classList.toggle("is-loading",!!(u!=null&&u.loading)),e.classList.toggle("is-installing",document.body.classList.contains("ls-green-loading")),d.innerHTML=A(u!=null&&u.loading?R.close:R.reload,18),d.title=u!=null&&u.loading?"Stop loading":"Reload",c&&(c.disabled=!fn()),p&&(p.disabled=!hn());let x=/^https:/i.test((u==null?void 0:u.url)||"");g.innerHTML=A(x?R.lock:R.info,16),g.title=x?"Connection is secure":"Not secure";let U=!!u&&et().some(ie=>ie.url===u.url);f.classList.toggle("is-on",U);let V=!u||u.url==="about:blank";V&&M(),i.classList.toggle("is-on",V),yt().length||_t()};Ue==null||Ue(),Ue=mn(q);let B=()=>{var x;let u=Vt(e);(x=j==null?void 0:j.onFullscreen)==null||x.call(j,u)},h=()=>{var u;_=!1,kt(s,"about:blank"),Et((u=I())==null?void 0:u.id)},y=()=>{_=!1;let u=String(k().browserHomeUrl||"").trim();u?v(u):ze("about:blank")},te=(u,x)=>{var U,V;return x>0?(U=fs.find(ie=>ie>u))!=null?U:u:(V=[...fs].reverse().find(ie=>ie<u))!=null?V:u},be=u=>En(S.value,u),Xe=()=>{let u=I();if(!u||u.url==="about:blank")return se("Nothing to bookmark",1500);let x=et(),U=x.some(V=>V.url===u.url);O("browserBookmarks",U?x.filter(V=>V.url!==u.url):[...x,{title:u.title||u.url,url:u.url}]),q(),se(U?"Bookmark removed":"Bookmarked",1200)},Tt=()=>Qo({host:e,anchor:m,get:()=>{var u;return{opacity:Qe((u=k().browserOpacity)!=null?u:1),overlay:Or(),autoSave:k().overlayAutoSave!==!1,canOverlay:tt==="page"}},set:ms}),ir=()=>({newTab:h,duplicateTab:()=>wn(s),closeTab:()=>{let u=I();u&&zt(u.id)},closeOtherTabs:()=>{let u=I();yt().filter(x=>x.id!==(u==null?void 0:u.id)).forEach(x=>zt(x.id))},navigate:u=>v(u),getUrl:()=>{var u;return((u=I())==null?void 0:u.url)||""},getVisited:Lr,clearHistory:()=>{pn(),M(),se("History cleared",1500)},getBookmarks:et,isBookmarked:()=>{let u=I();return!!u&&et().some(x=>x.url===u.url)},toggleBookmark:Xe,getZoom:()=>{var u,x;return(x=(u=I())==null?void 0:u.zoom)!=null?x:100},zoom:(u,x)=>{let U=I();return U?Cn(x?100:te(U.zoom||100,u)):100},toggleFullscreen:B,print:()=>{Ln()||se("Cannot print this page",1800)},find:()=>{L.hidden=!1,S.focus(),S.select()},isDevtools:()=>{var u;return!!((u=I())!=null&&u.devtools)},toggleDevtools:()=>{let u=I();if(!u||u.url==="about:blank")return se("Open a page first",1800);_n()||se("DevTools work on pages served by Live Server",3e3)},isDeviceMode:()=>Y.isOn(),toggleDeviceMode:()=>Y.toggle(),viewSource:async()=>{var ae,Oe;let u=I();if(!u||u.url==="about:blank"||String(u.url).startsWith("view-source:"))return se("No page source here",1800);se("Loading source\u2026",1200);let x="";try{let W=(ae=u.iframe)==null?void 0:ae.contentDocument;W!=null&&W.documentElement&&(x=`<!DOCTYPE html>
`+W.documentElement.outerHTML)}catch{}if(!x)try{let W=(Oe=u.iframe)!=null&&Oe.src&&u.iframe.src!=="about:blank"?u.iframe.src:u.url,He=new AbortController,zr=setTimeout(()=>He.abort(),15e3),Ur=await fetch(W,{signal:He.signal,credentials:"omit"});clearTimeout(zr),x=await Ur.text()}catch(W){se("Could not load source: "+((W==null?void 0:W.message)||W),2800);return}if(!x){se("Empty source",1800);return}let U=String(x).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),V="view-source:"+String(u.url).replace(/^https?:\/\//i,""),ie='<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+V.replace(/[<>]/g,"")+"</title><style>html,body{margin:0;background:#1e1e1e;color:#d4d4d4}pre{margin:12px;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-word}</style></head><body><pre>"+U+"</pre></body></html>";try{Rn(s,V,ie)}catch(W){se("Could not open source tab: "+((W==null?void 0:W.message)||W),2500)}},openExternal:()=>{var x;let u=(x=I())==null?void 0:x.url;u&&u!=="about:blank"&&hs(u)},openOpacity:Tt,isOverlay:Or,canOverlay:()=>tt==="page",toggleOverlay:()=>ms({overlay:!Or()}),closeBrowser:()=>_t()});return(Rt=t(".ls-tab-new"))==null||Rt.addEventListener("click",h),e.querySelectorAll(".ls-close-btn, .ls-ov-close").forEach(u=>u.addEventListener("click",()=>_t())),(Ve=t(".ls-fs-btn"))==null||Ve.addEventListener("click",B),c==null||c.addEventListener("click",()=>Cr(-1)),p==null||p.addEventListener("click",()=>Cr(1)),d.addEventListener("click",()=>{var u;return(u=I())!=null&&u.loading?kn():_r()}),(it=t(".ls-home"))==null||it.addEventListener("click",y),f.addEventListener("click",Xe),m.addEventListener("click",Tt),b.addEventListener("click",()=>{let u=Y.toggle();b.classList.toggle("is-on",u)}),b.classList.toggle("is-on",Y.isOn()),a.addEventListener("click",()=>Hn(ir(),{host:e,anchor:a})),l.addEventListener("keydown",u=>{u.key==="Enter"&&(v(l.value),l.blur())}),l.addEventListener("focus",()=>l.select()),L.querySelector(".ls-find-prev").addEventListener("click",()=>be(!0)),L.querySelector(".ls-find-next").addEventListener("click",()=>be(!1)),L.querySelector(".ls-find-close").addEventListener("click",()=>L.hidden=!0),S.addEventListener("keydown",u=>{u.key==="Enter"&&be(u.shiftKey),u.key==="Escape"&&(L.hidden=!0)}),e._lsDevice=s,e._sync=q,e}function ta(){let e=document.createElement("div");return e.className="ls-browser-shell",e.dataset.theme=Oo(),e.innerHTML=`
    <div class="ls-chrome">
      <div class="ls-tabstrip">
        <div class="ls-browser-tabs"></div>
        <button type="button" class="ls-ib ls-tab-new" title="New tab">${A(R.plus,16)}</button>
        <span class="ls-spacer"></span>
        <div class="ls-win">
          <button type="button" class="ls-ib ls-win-btn ls-fs-btn" title="Fullscreen">${A(R.maximize,14)}</button>
          <button type="button" class="ls-ib ls-win-btn ls-close-btn" title="Close">${A(R.close,14)}</button>
        </div>
      </div>
      <div class="ls-toolbar">
        <button type="button" class="ls-ib ls-back" title="Back" disabled>${A(R.back,18)}</button>
        <button type="button" class="ls-ib ls-fwd" title="Forward" disabled>${A(R.forward,18)}</button>
        <button type="button" class="ls-ib ls-reload" title="Reload">${A(R.reload,18)}</button>
        <button type="button" class="ls-ib ls-home" title="Home">${A(R.home,18)}</button>
        <div class="ls-omni">
          <button type="button" class="ls-site" title="Site information">${A(R.info,16)}</button>
          <input class="ls-browser-url" type="text" spellcheck="false" autocapitalize="off" autocomplete="off" enterkeyhint="enter" inputmode="text" placeholder="Search or type a URL" />
          <button type="button" class="ls-ib ls-star" title="Bookmark this tab">${A(R.star,16)}</button>
        </div>
        <button type="button" class="ls-ib ls-op-btn" title="Opacity">${A(R.drop,18)}</button>
        <button type="button" class="ls-ib ls-dev-toggle" title="Device mode">${A(R.device,18)}</button>
        <button type="button" class="ls-ib ls-menu-btn" title="Customize and control">${A(R.dots,18,3)}</button>
        <button type="button" class="ls-ib ls-ov-close" title="Close">${A(R.close,16)}</button>
        <div class="ls-progress"></div>
        <div class="ls-green-progress"></div>
      </div>
      <div class="ls-devbar" hidden></div>
    </div>
    <div class="ls-stage">
      <div class="ls-ntp"></div>
      <div class="ls-box"><div class="ls-device"></div></div>
    </div>
    <div class="ls-find" hidden>
      <input type="text" placeholder="Find in page" spellcheck="false" />
      <button type="button" class="ls-ib ls-find-prev" title="Previous">${A(R.up,16)}</button>
      <button type="button" class="ls-ib ls-find-next" title="Next">${A(R.down,16)}</button>
      <button type="button" class="ls-ib ls-find-close" title="Close">${A(R.close,16)}</button>
    </div>
  `,ea(e)}function ra(){var t;if(Xo())return Nt(),!0;let e=z==null?void 0:z.querySelector(".ls-find");return e&&!e.hidden?(e.hidden=!0,!0):z!=null&&z.classList.contains("is-fullscreen")?((t=j==null?void 0:j.onFullscreen)==null||t.call(j,Vt(z,!1)),!0):!1}function gs(){Mr||_t({fromHost:!0})}async function na(){var e;return z&&j?((e=j.show)==null||e.call(j),requestAnimationFrame(()=>Y==null?void 0:Y.layout()),z):Yt||(Yt=(async()=>{Bo();let t=ta(),r=null;return tt="page",vs()==="editorTab"&&(r=await cs(t,{title:"Live Preview",css:ln,onClose:gs}),r?tt="tab":se("Editor tab not available, using page",2e3)),r||(r=as(t,{title:"Live Preview",onClose:gs,onBack:ra})),j=r,z=t,yn(),Kt=n=>{var o;Ki.includes((o=n==null?void 0:n.detail)==null?void 0:o.key)&&jn()},window.addEventListener("liveserver-settings",Kt),jn(),requestAnimationFrame(()=>Y==null?void 0:Y.layout()),t})().finally(()=>{Yt=null}),Yt)}async function zn(e,t={}){let r=await na(),n=yt();if(n.length>0&&(t.restoreOnly||!e))return;let o=e||"about:blank";if(t.reuse){let i=n.find(c=>Zi(c.url,o));if(i){Et(i.id),i.url!==o?ze(o):t.forceReload&&_r();return}}let s=I();s&&s.url==="about:blank"&&n.length===1?ze(o):kt(r._lsDevice,o)}function _t(e={}){if(!Mr){Mr=!0;try{Nt(),Ue==null||Ue(),Ue=null,Kt&&window.removeEventListener("liveserver-settings",Kt),Kt=null,bs(),xn();try{Y==null||Y.destroy()}catch{}Y=null,Sn(),ss(z);try{z==null||z.remove()}catch{}e.fromHost||j==null||j.close()}finally{j=null,z=null,document.body.classList.remove("ls-browser-fs"),Mr=!1}}}function oa(e={}){return{open:t=>zn(t||e.initialUrl),addTab:t=>zn(t),setFullscreen:t=>Vt(z,t),dispose:_t,getMode:vs}}var se,Vi,fs,Yi,Ki,z,j,tt,Ue,Yt,Mr,Y,Kt,Lt,Fn,nt=T(()=>{ne();Se();jt();Ho();Do();An();Ko();Gt();es();os();is();ls();ds();$n();se=acode.require("toast"),Vi="https://i.postimg.cc/WpYPQ47b/green-fox.png",fs=[25,33,50,67,75,80,90,100,110,125,150,175,200,250,300,400,500],Yi=/\.(html?|css|js|mjs|json|svg|xml|txt|md)$/i,Ki=["browserOpacity","browserOverlay","overlayAutoSave","showAddressBar"],z=null,j=null,tt="page",Ue=null,Yt=null,Mr=!1,Y=null,Kt=null,Lt=null,Fn=null});var le={};xe(le,{changePortAndRestart:()=>ca,ensureProxyServer:()=>Pn,probeExistingServer:()=>Vn,reapplySetup:()=>da,refreshStatusFromBackend:()=>an,restartServer:()=>la,setProcessBaseUrl:()=>Gn,startServer:()=>er,stopServer:()=>Ir});function Gn(e){Jt=e||""}async function Br(e,t=900){try{let r=new AbortController,n=setTimeout(()=>r.abort(),t),o=await fetch("http://127.0.0.1:"+e+"/check",{signal:r.signal});if(clearTimeout(n),!o||!o.ok)return{alive:!1,proxy:!1};let s=await o.json().catch(()=>({}));return{alive:!0,proxy:(s==null?void 0:s.proxy)===!0}}catch{return{alive:!1,proxy:!1}}}async function Ss(e,t=800){return(await Br(e,t)).alive}async function sa(e){try{let t=await ee("if command -v wget >/dev/null 2>&1; then wget -qO- -T 2 http://127.0.0.1:"+e+"/check 2>/dev/null; elif command -v curl >/dev/null 2>&1; then curl -s --max-time 2 http://127.0.0.1:"+e+"/check 2>/dev/null; else echo NOCLIENT; fi",{timeoutMs:8e3});return/Ready|AcodeLiveServer|"port"/i.test(String(t||""))}catch{return!1}}async function Un(e,t={}){let r=String(parseInt(e,10)||8080);return await Ss(r)?!0:t.deep?sa(r):!1}async function Xn(e){let t=String(parseInt(e,10)||8080);Ne=null;let r=`for pid in $(ps -o pid,args 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; for pid in $(ps 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; pkill -9 -f "node index.js ${t}" 2>/dev/null || true; fuser -k ${t}/tcp 2>/dev/null || true`;try{await ee(r,{timeoutMs:12e3})}catch{}for(let n=0;n<10&&await Ss(t,400);n++)await new Promise(o=>setTimeout(o,200))}function Qt(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=t.match(/^\/storage\/emulated\/0(\/.*)?$/);return r||(r=t.match(/^\/storage\/self\/primary(\/.*)?$/),r)?"/sdcard"+(r[1]||""):t}function ys(e){return Qt(String(e||"").replace(/\/+$/,""))}async function xs(e,t){let r=await ia(e);if(r)return{aroot:r,mirrored:!1};console.warn("[LiveServer] alpine root missing, trying project mirror for",e);try{let{getSettings:n}=await Promise.resolve().then(()=>(ne(),Mt)),s=await sn(e,t||"index.html",n().rootFolderUri||"");if(s)return{aroot:s,mirrored:!0}}catch(n){throw console.warn("[LiveServer] mirror failed",n),n}return{aroot:null,mirrored:!1}}async function ia(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=[],n=f=>{f&&!r.includes(f)&&r.push(f)};n(t);let o=t.match(/^\/storage\/emulated\/0(\/.*)?$/);o&&n("/sdcard"+(o[1]||"")),o=t.match(/^\/sdcard(\/.*)?$/),o&&(n("/storage/emulated/0"+(o[1]||"")),n("/storage/self/primary"+(o[1]||""))),o=t.match(/^\/storage\/self\/primary(\/.*)?$/),o&&(n("/sdcard"+(o[1]||"")),n("/storage/emulated/0"+(o[1]||"")));let s=t.match(/^\/storage\/([0-9A-Fa-f]{4}-[0-9A-Fa-f]{4})(\/.*)?$/);if(s){let f=s[1],g=s[2]||"";n("/storage/"+f+g),n("/mnt/media_rw/"+f+g),n("/mnt/runtime/default/"+f+g),n("/storage/"+f.toUpperCase()+g),n("/storage/"+f.toLowerCase()+g)}let i=(()=>{let f=t.match(/\/(?:storage|sdcard|emulated|media_rw)\/[^/]+(\/.+)$/i);return f?f[1]:""})();!/^\/(sdcard|storage|mnt)(\/|$)/.test(t)&&t.startsWith("/data/");let c=f=>"'"+String(f).replace(/'/g,"'\\''")+"'",p="for d in "+r.map(c).join(" ")+'; do [ -d "$d" ] && { echo "OK:$d"; exit 0; }; done; '+(i?'for base in /storage/* /mnt/media_rw/* /sdcard; do [ -d "$base'+i.replace(/'/g,"'\\''")+'" ] && { echo "OK:$base'+i.replace(/'/g,"'\\''")+'"; exit 0; }; done; ':"")+"echo NONE",l="";try{l=await ee(p,{timeoutMs:12e3})}catch(f){return console.warn("[LiveServer] root probe failed, using path as is",f),Qt(t)}let d=String(l||"").match(/OK:(.+)/);return d?(console.log("[LiveServer] alpine root",d[1].trim()),d[1].trim()):/NONE/.test(String(l||""))?(console.warn("[LiveServer] alpine root not found for",t,"cands=",r),null):Qt(t)}function aa(e){let t={};return String(e||"").split(`
`).forEach(r=>{let n=r.indexOf(":");if(n>0){let o=r.slice(0,n).trim(),s=r.slice(n+1).trim();o&&(t[o]=s)}}),t}function Nn(){let e=X(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";return/\.html?$/i.test(t)?t:"index.html"}function ws(e){try{let t=X(),r=we((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");if(!r||!e)return Nn();let n=ys(e),o=ys(r);if(o===n)return Nn();if(o.startsWith(n+"/"))return o.slice(n.length).replace(/^\/+/,"");let s=o.split("/").pop();if(s&&/\.html?$/i.test(s))return s}catch{}return Nn()}async function Zt(e,t,r){let n=k(),o={path:t,fileName:r||"index.html",port:e,liveReload:n.liveReload!==!1,directoryListing:n.directoryListing!==!1,enableCors:n.enableCors!==!1,charset:n.customCharset||"utf-8",customHeaders:aa(n.customHeaders),ipWhitelist:n.ipWhitelist||"",basicAuthUser:n.basicAuthUser||"",basicAuthPass:n.basicAuthPass||""};try{let s=await fetch(`http://127.0.0.1:${e}/setup`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)});return console.log("[LiveServer] setup",t,r,s&&s.status),!!(s&&(s.ok||s.status===201))}catch(s){return console.warn("[LiveServer] setup",s),!1}}function Wn(){Hr&&(clearInterval(Hr),Hr=null)}function Dr(){Wn();let e=parseInt(k().autoShutdownMinutes,10)||0;if(e<=0)return;let t=e*60*1e3,r=Date.now();Hr=setInterval(async()=>{let n=D();if(!n.running){Wn();return}if(Date.now()-(n.startedAt||r)>t){try{let s=await(await fetch(`http://127.0.0.1:${n.port}/status`)).json();if(s.lastActivity&&Date.now()-s.lastActivity<t)return}catch{}ve("Live Server auto-stopped (inactivity)",2500),Ir()}},3e4)}async function Vn(){let e=mt();try{let t=new AbortController,r=setTimeout(()=>t.abort(),1200),n=await fetch(`http://127.0.0.1:${e}/status`,{signal:t.signal});if(clearTimeout(r),!n||!n.ok)return!1;let o=await n.json().catch(()=>({})),s=o.port||e,i=o.fileName||null,c=qt(s,"127.0.0.1"),p=i&&i!=="index.html"?c.replace(/\/$/,"/")+encodeURI(i):c,l=D();if(oe({running:!0,port:s,root:o.root||l.root||null,url:p,fileName:i,bind:o.bind||"0.0.0.0",startedAt:l.startedAt||(o.uptime?Date.now()-Math.round(Number(o.uptime)*1e3):Date.now()),lastError:null}),Dr(),!l.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:p,port:s,root:o.root||null,fileName:i}}))}catch{}return!0}catch{return!1}}function ks(e,t){let r=lt();if(!(r!=null&&r.execute))throw new Error("Executor not available. Open Acode Terminal once, then retry.");let n='ACODIR=""; for d in "'+String(t||"").replace(/"/g,"")+'" /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels; do [ -n "$d" ] || continue; if [ -f "$d/index.js" ] && [ -d "$d/node_modules" ]; then ACODIR="$d"; break; fi; done; [ -z "$ACODIR" ] && { echo acodels_not_found; exit 1; }; cd "$ACODIR" || exit 1; NODE_PATH="$ACODIR/node_modules" exec node index.js '+String(e)+" 0.0.0.0 >liveserver.log 2>&1",o={};Ne=o,r.execute(Vr(n),!0).then(s=>console.log("[LiveServer] node exited",String(s||"").slice(0,200))).catch(s=>console.warn("[LiveServer] node exited",String((s==null?void 0:s.message)||s).slice(0,200))).finally(()=>{if(Ne===o&&(Ne=null,D().running)){oe({running:!1,lastError:"server process exited"});try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}}})}async function Pn(){let e=mt(),t=await Br(e);if(t.alive&&t.proxy)return e;if(!await fr({baseUrl:Jt}))return null;Ce(!0),Te(t.alive?`$ Updating backend on :${e} with Reverse Proxy...`:`$ node index.js ${e} (starting local proxy)...`,{spin:!0});try{t.alive&&!t.proxy&&await Xn(e);let n=await ft(Jt);await tn(n),ks(e,n);let o=!1;for(let d=0;d<35;d++){await new Promise(g=>setTimeout(g,300));let f=await Br(e,500);if(f.alive&&f.proxy){o=!0;break}if(!Ne)break}if(!o)return Te("Proxy server failed to start",{spin:!1,autoHideMs:3e3}),null;let s=D(),i=s.root||mr()||"/sdcard",c=Qt(i),p=s.fileName||"index.html";await Zt(e,c,p);let l=qt(e,"127.0.0.1");oe({running:!0,port:e,root:c,url:l,fileName:p,bind:"0.0.0.0",startedAt:Date.now(),lastError:null}),Dr();try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:l,port:e,root:c,fileName:p}}))}catch{}return Te(`\u2713 Reverse proxy ready on 127.0.0.1:${e}`,{spin:!1,autoHideMs:2e3}),e}catch(n){return Te(`Proxy error: ${(n==null?void 0:n.message)||n}`,{spin:!1,autoHideMs:3500}),null}finally{Ce(!1)}}async function er(e={}){let t=e.port||mt(),r=e.root||mr(),n=k(),o=e.forceDeps?{alive:!1,proxy:!1}:await Br(t);if(o.alive&&!o.proxy&&(Ce(!0),Te(`$ Upgrading Live Server on :${t}...`,{spin:!0}),await Xn(t),Ce(!1),Ft(0),o.alive=!1),o.alive&&o.proxy){let a=D(),m=r||a.root;if(!m)return ve("Set a root folder or open an HTML file",2500),!1;let b=e.fileName||ws(m),L,S=!1;try{let v=await xs(m,b);L=v.aroot||Qt(m),S=v.mirrored}catch(v){return ve("Cannot serve folder: "+((v==null?void 0:v.message)||v),4e3),!1}(!a.running||a.port!==t||a.root!==L||a.fileName!==b)&&await Zt(t,L,b);let P=qt(t,"127.0.0.1"),C=b&&b!=="index.html"?P.replace(/\/$/,"/")+encodeURI(b):P;if(oe({running:!0,port:t,root:L,url:C,fileName:b,bind:"0.0.0.0",startedAt:a.startedAt||Date.now(),lastError:null}),Dr(),!a.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:C,port:t,root:L,fileName:b}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:v}=await Promise.resolve().then(()=>(nt(),rt));v(C,{reuse:!0})}catch(v){console.warn("[LiveServer] open browser",v)}return!0}if(!await fr({baseUrl:Jt,force:!!e.forceDeps}))return!1;if(!r)return ve("Set a root folder or open an HTML file",2500),!1;let i=e.fileName||ws(r),c,p=!1;try{let a=await xs(r,i);c=a.aroot,p=a.mirrored}catch(a){return oe({running:!1,lastError:String((a==null?void 0:a.message)||a)}),ve("Cannot serve folder: "+((a==null?void 0:a.message)||a),4500),null}if(!c)return oe({running:!1,lastError:"root not reachable"}),ve("Folder not reachable \u2014 mirror also failed. Use internal /sdcard or grant storage access.",4500),!1;try{let a=L=>"'"+String(L).replace(/'/g,"'\\''")+"'",m=String(i||"index.html").replace(/^\/+/,""),b=await ee("f="+a(c+"/"+m)+'; if [ -f "$f" ]; then echo OK; else ls -la '+a(c)+" 2>&1 | head -20; echo MISS; fi",{timeoutMs:8e3});if(console.log("[LiveServer] entry check",String(b||"").slice(0,300)),/MISS/.test(String(b||""))&&!/OK/.test(String(b||""))&&!p)try{let L=await sn(r,m,k().rootFolderUri||"");L&&(c=L,p=!0,await Zt(t,c,m))}catch(L){console.warn("[LiveServer] mirror after miss",L)}}catch(a){console.warn("[LiveServer] entry check failed",a)}let l="0.0.0.0";if(!await Un(t,{deep:!0})){Ce(!0),Te(`$ node index.js ${t} 0.0.0.0`,{spin:!0});let a=await ft(Jt);try{await tn(a)}catch(b){console.warn("[LiveServer] ensure index",b)}try{ks(t,a)}catch(b){return Ce(!1),Ft(0),oe({running:!1,lastError:String((b==null?void 0:b.message)||b)}),ve("Start failed: "+((b==null?void 0:b.message)||b),3e3),!1}let m=!1;for(let b=0;b<40;b++){if(await new Promise(L=>setTimeout(L,300)),await Un(t)){m=!0;break}if(!Ne)break}if(!m&&Ne&&(m=await Un(t,{deep:!0})),Ce(!1),!m){Te("Server failed to start",{spin:!1,autoHideMs:3500});try{let b=await ee("tail -n 40 /root/.acode_liveserver/acodels/liveserver.log 2>/dev/null",{timeoutMs:8e3});console.warn("[LiveServer] start failed, log:",b)}catch{}return ve("Server failed to start \u2014 see console log",3500),oe({running:!1,lastError:"start failed"}),Ne=null,!1}Te(`\u2713 Live Server running on :${t}`,{spin:!1,autoHideMs:2200})}await Zt(t,c,i)||console.warn("[LiveServer] /setup patch failed");let f=qt(t,"127.0.0.1"),g=i&&i!=="index.html"?f.replace(/\/$/,"/")+encodeURI(i):f;oe({running:!0,port:t,root:c,url:g,fileName:i,bind:l,startedAt:Date.now(),lastError:null}),O("port",t),Dr(),ve("Live on "+g,2500);try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:g,port:t,root:r,fileName:i}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:a}=await Promise.resolve().then(()=>(nt(),rt));a(g,{reuse:!0})}catch(a){console.warn("[LiveServer] open browser",a)}return!0}async function Ir(){try{on()}catch{}Wn();let t=D().port||mt();await Xn(t),oe({running:!1,port:null,url:null,fileName:null,startedAt:null}),ve("Server stopped",1500);try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}return!0}async function la(){let e=D(),t=e.root,r=e.fileName;return await Ir(),await new Promise(n=>setTimeout(n,350)),er({root:t||void 0,fileName:r||void 0})}async function ca(){let e=acode.require("prompt"),t=String(mt()),r=await e("Port",t,"number");if(r==null)return!1;let n=parseInt(String(r),10);return!Number.isFinite(n)||n<1||n>65535?(ve("Invalid port",1500),!1):(O("port",n),await Ir(),er({port:n}))}async function da(){let e=D();return!e.running||!e.port||!e.root?!1:Zt(e.port,e.root,e.fileName||"index.html")}var ve,Jt,Hr,Ne,J=T(()=>{ne();ct();ht();wo();Ie();Ro();Ao();he();Se();xr();ve=acode.require("toast"),Jt="",Hr=null,Ne=null});var Qn={};xe(Qn,{onFileSwitch:()=>Zn,registerSideButton:()=>Kn,setLiveDot:()=>ot,unregisterSideButton:()=>Jn});function As(){if(document.getElementById("ls-side-btn-css"))return;let e=document.createElement("style");e.id="ls-side-btn-css",e.textContent=`
    [data-ls-sidebtn="1"] {
      gap: 6px;
    }
    [data-ls-sidebtn="1"] .ls-side-ico {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1.05rem;
      height: 1.05rem;
      flex-shrink: 0;
      margin-right: 4px;
      vertical-align: middle;
    }
    [data-ls-sidebtn="1"] .ls-side-ico svg {
      width: 1.05rem;
      height: 1.05rem;
      display: block;
    }
    [data-ls-sidebtn="1"][data-live="1"] {
      background: #22c55e !important;
      color: #0b1220 !important;
    }
    [data-ls-sidebtn="1"][data-live="0"] {
      background: var(--button-background-color, var(--secondary-color, #3c4043)) !important;
      color: var(--button-text-color, var(--color, #e8eaed)) !important;
    }
  `,document.head.appendChild(e)}function _s(){return'<svg class="ls-side-ico" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M5.63605 5.63603L18.364 18.364M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="#666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'}function Cs(){return'<svg class="ls-side-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>'}function pa(){let e=k();if(e.bindLocalhostOnly!==!1)return"127.0.0.1";let t=String(e.bindAddress||"127.0.0.1").trim();return!t||t==="0.0.0.0"?"127.0.0.1":t}function fa(){let e=D(),t=k(),r=String(t.sideButtonRunningLabel||"{HOST}:{PORT}"),n=pa(),o=e.port||t.port||8080;return r.replace(/\{HOST\}/gi,n).replace(/\{PORT\}/gi,String(o))}function ha(){return String(k().sideButtonOfflineLabel||"Go Live")}function tr(e){return e?fa():ha()}function Ts(){var e;return k().showSideButton!==!1&&Le(X()||((e=window.editorManager)==null?void 0:e.activeFile))}function Ps(){return E?E.$el||E.el||E.root||(E instanceof HTMLElement?E:null):null}function Ms(e,t){var i,c,p;if(!e)return!1;e.setAttribute("data-ls-sidebtn","1"),e.setAttribute("data-live",t?"1":"0");let r=tr(t),n=t?_s():Cs(),o=e.querySelectorAll('.text, .label, .side-button-text, [class*="text"], span, small'),s=!1;for(let l of o)(i=l.classList)!=null&&i.contains("icon")||(c=l.classList)!=null&&c.contains("ls-side-ico")||(p=l.children)!=null&&p.length&&l.querySelector(".icon, svg")||(l.innerHTML=n+r,s=!0);if(!s){let l=e.querySelector(".icon");if(l){l.innerHTML=t?_s():Cs();let d=!1;for(let f of e.childNodes)f.nodeType===3&&f.textContent.trim()&&(f.textContent=" "+r,d=!0);d||(e.setAttribute("aria-label",r),e.title=r)}else e.innerHTML=n+'<span class="ls-side-label">'+r+"</span>"}return e.setAttribute("aria-label",r),e.title=r,!0}function ma(e){return{text:tr(e),icon:e?"block":"public",backgroundColor:e?"#22c55e":void 0,textColor:e?"#0b1220":void 0,onclick:()=>ga()}}function Rs(e){var t;try{(t=E==null?void 0:E.hide)==null||t.call(E)}catch{}if(E=null,!!Es)try{E=Es(ma(e));let r=Ps();r&&Ms(r,e)}catch(r){console.warn("[LiveServer] recreate side",r)}}function ot(e){var t,r,n;try{As();let o=e==null?!!D().running:!!e;if(document.body.classList.toggle("ls-server-live",o),!Ts()){try{(t=E==null?void 0:E.hide)==null||t.call(E)}catch{}Yn=o;return}if(!E)Rs(o);else{try{typeof E.setText=="function"&&E.setText(tr(o)),"text"in E&&(E.text=tr(o)),E.$text&&(E.$text.textContent=tr(o))}catch{}let s=Ps();(!(s?Ms(s,o):!1)||Yn!==o)&&Rs(o)}Ts()?(r=E==null?void 0:E.show)==null||r.call(E):(n=E==null?void 0:E.hide)==null||n.call(E),Yn=o}catch(o){console.warn("[LiveServer] setLiveDot",o)}}async function ga(){let t=D().running?["stop","Stop live server"]:["start","Start live server"],r=await ua("Live Server",[t,["startSelected","Start server on selected path"],["restart","Restart server"],["port","Change port"],["root","Select root folder"],["rootBrowse","Select path (Acode browser)"],["browser","Open browser"],["deps","Check dependencies"],["settings","Settings"]],{hideOnSelect:!0});if(r){try{if(r==="start"){let{startServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="startSelected"){let{startServer:n}=await Promise.resolve().then(()=>(J(),le)),{getSettings:o}=await Promise.resolve().then(()=>(ne(),Mt)),{browseRootFolder:s,getEffectiveRoot:i}=await Promise.resolve().then(()=>(Ie(),Ke)),c=o().rootFolder||i();if(c||(c=await s()),!c){Ls("Select a folder first",2e3);return}await n({root:c})}else if(r==="stop"){let{stopServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="restart"){let{restartServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="port"){let{changePortAndRestart:n}=await Promise.resolve().then(()=>(J(),le));await n()}else if(r==="root"){let{pickRootFolder:n}=await Promise.resolve().then(()=>(Ie(),Ke));await n()}else if(r==="rootBrowse"){let{browseRootFolder:n}=await Promise.resolve().then(()=>(Ie(),Ke));await n()}else if(r==="browser"){let{openBrowser:n}=await Promise.resolve().then(()=>(nt(),rt)),o=D().url||"http://127.0.0.1:"+(D().port||8080)+"/";n(o,{restoreOnly:!0})}else if(r==="deps"){let{checkDependenciesAction:n}=await Promise.resolve().then(()=>(ht(),hr));await n()}else if(r==="settings"){let{openSettingsHub:n}=await Promise.resolve().then(()=>(Xt(),Tr));n()}}catch(n){Ls(String((n==null?void 0:n.message)||n),2500)}ot(D().running)}}function Kn(){if(k().showSideButton!==!1){As();try{ot(D().running)}catch(e){console.warn("[LiveServer] side button",e)}}}function Zn(){ot(D().running)}function Jn(){var e;try{(e=E==null?void 0:E.hide)==null||e.call(E)}catch{}E=null,document.body.classList.remove("ls-server-live")}var Es,ua,Ls,E,Yn,qr=T(()=>{ne();Se();he();Es=acode.require("sideButton"),ua=acode.require("select"),Ls=acode.require("toast"),E=null,Yn=null});function Os(){let e=[];return rr.forEach(t=>{e.includes(t.category)||e.push(t.category)}),e}function Ge(e){let t=k();return t[e]!==void 0?t[e]:Pt[e]}function Hs(e){if(e.checkbox||e.noValue)return"";let t=Ge(e.key);if(e.select){let n=e.select.find(o=>String(Array.isArray(o)?o[0]:o)===String(t));return n?Array.isArray(n)?n[1]:n:String(t!=null?t:"")}if(e.secret)return t?"\u2022\u2022\u2022\u2022\u2022\u2022":"";let r=t==null?"":String(t);return r.length>28?r.slice(0,27)+"\u2026":r}async function ba(e){try{if(e==="start")return(await Promise.resolve().then(()=>(J(),le))).startServer();if(e==="stop")return(await Promise.resolve().then(()=>(J(),le))).stopServer();if(e==="restart")return(await Promise.resolve().then(()=>(J(),le))).restartServer();if(e==="open"){let r=(await Promise.resolve().then(()=>(he(),gt))).getServerStatus();return r.running?(await Promise.resolve().then(()=>(nt(),rt))).openBrowser(r.url||"http://127.0.0.1:"+r.port+"/",{restoreOnly:!0}):We("Server is not running",2e3)}if(e==="root")return(await Promise.resolve().then(()=>(Ie(),Ke))).pickRootFolder();if(e==="status"){let r=(await Promise.resolve().then(()=>(he(),gt))).getServerStatus();return We(r.running?(r.url||"")+" \u2014 port "+r.port:"Not running",3e3)}if(e==="deps")return(await Promise.resolve().then(()=>(ht(),hr))).checkDependenciesAction();if(e==="reinstall")return(await Promise.resolve().then(()=>(ht(),hr))).reinstallDependenciesAction()}catch(t){We(String((t==null?void 0:t.message)||t),3e3)}}async function nr(e,t){var n;if(e==="__action")return await ba(t),!0;if(e==="__browserAction"){try{t==="clearHistory"?((await Promise.resolve().then(()=>(An(),Go))).clearVisited(),We("Browser history cleared",1800)):t==="clearBookmarks"&&(O("browserBookmarks",[]),We("Bookmarks cleared",1800))}catch(o){We(String((o==null?void 0:o.message)||o),2500)}return!0}let r=t;if(e==="port"){let o=parseInt(String(t),10);if(!Number.isFinite(o)||o<1||o>65535)return We("Invalid port",1800),!1;r=o}else if(e==="autoShutdownMinutes"){let o=parseInt(String(t),10);if(!Number.isFinite(o)||o<0)return We("Invalid number",1800),!1;r=o}else if(e==="browserOpacity"){let o=parseFloat(String(t));r=Number.isFinite(o)?Math.min(1,Math.max(.1,Math.round(o*100)/100)):1}if(O(e,r),e==="sideButtonRunningLabel"||e==="sideButtonOfflineLabel")try{let o=await Promise.resolve().then(()=>(qr(),Qn));(n=o.setLiveDot)==null||n.call(o,null)}catch{}if(e==="showSideButton")try{let o=await Promise.resolve().then(()=>(qr(),Qn));r===!1?o.unregisterSideButton():o.registerSideButton()}catch{}return!0}function Bs(){return{list:rr.map(t=>{let r={key:t.key,text:t.text,category:t.category};return t.info&&(r.info=t.info),t.checkbox?(r.checkbox=!0,r.value=!!Ge(t.key)):t.select?(r.select=t.select,t.noValue?(r.value="",r.valueText=()=>"Choose\u2026"):r.value=t.asString?String(Ge(t.key)):Ge(t.key)):t.prompt&&(r.prompt=t.prompt,t.promptType&&(r.promptType=t.promptType),r.value=Ge(t.key),t.secret&&(r.valueText=n=>n?"\u2022\u2022\u2022\u2022\u2022\u2022":"")),r}),cb:(t,r)=>{nr(t,r)}}}var We,va,rr,eo=T(()=>{Gr();ne();We=acode.require("toast"),va=[["start","Start server"],["stop","Stop server"],["restart","Restart server"],["open","Open browser"],["root","Select root folder"],["status","Show server status"],["deps","Check dependencies"],["reinstall","Reinstall dependencies"]],rr=[{key:"__action",category:"Actions",text:"Run action",info:"Start / stop / open browser / dependencies",select:va,noValue:!0},{key:"port",category:"General",text:"Port",info:"Default 8080",prompt:"Port number",promptType:"number"},{key:"bindAddress",category:"General",text:"Bind address",select:[["127.0.0.1","Localhost only (127.0.0.1)"],["0.0.0.0","All interfaces (0.0.0.0)"]]},{key:"rootFolder",category:"General",text:"Root folder",info:"Empty = folder of the active HTML file",prompt:"Absolute folder path",promptType:"text"},{key:"liveReload",category:"General",text:"Live reload on save",checkbox:!0},{key:"openBrowserOnStart",category:"General",text:"Open browser on start",checkbox:!0},{key:"autoShutdownMinutes",category:"General",text:"Auto shutdown (minutes)",info:"0 = off",prompt:"Minutes (0 = off)",promptType:"number"},{key:"browserDisplayMode",category:"Browser",text:"Show browser in",info:"Acode page or editor tab",select:[["inPage","Acode page (default)"],["editorTab","Editor tab"]]},{key:"browserSearchEngine",category:"Browser",text:"Search engine",info:"Used when searching keywords in address bar or New Tab",select:[["google","Google"],["duckduckgo","DuckDuckGo"],["bing","Bing"],["brave","Brave Search"]]},{key:"externalSiteMode",category:"Browser",text:"External websites",info:"Proxy auto-switches to Chromium if slow, or select Chromium directly",select:[["proxy","Local Node.js Reverse Proxy (Default)"],["acodeWebview","Acode Native WebView (Fullscreen)"],["inApp","Direct iframe (without proxy)"],["systemBrowser","Chrome / External system browser"]]},{key:"browserHomeUrl",category:"Browser",text:"Home button URL",info:"Empty = Green Fox Homepage",prompt:"Home URL (leave empty for Green Fox Homepage)",promptType:"text"},{key:"browserOpacity",category:"Browser",text:"Browser opacity",info:"0.1 - 1.0 (page mode)",asString:!0,select:["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1"].map(e=>[e,e])},{key:"browserOverlay",category:"Browser",text:"Preview as overlay",info:"See-through preview over the editor; you can still type in the editor",checkbox:!0},{key:"overlayAutoSave",category:"Browser",text:"Auto-save in overlay mode",info:"Saves the file after you stop typing so the preview updates live",checkbox:!0},{key:"showAddressBar",category:"Browser",text:"Show address bar",checkbox:!0},{key:"showSideButton",category:"Browser",text:"Show side button",checkbox:!0},{key:"sideButtonRunningLabel",category:"Browser",text:"Side button running label",value:"{HOST}:{PORT}",valueText:e=>String(e||"{HOST}:{PORT}"),prompt:"Running label ({HOST} {PORT} tokens)",promptType:"text",info:"Shown when server is live. Tokens: {HOST} {PORT}."},{key:"sideButtonOfflineLabel",category:"Browser",text:"Side button offline label",value:"Go Live",valueText:e=>String(e||"Go Live"),prompt:"Offline label",promptType:"text",info:"Shown when server is stopped."},{key:"__browserAction",category:"Browser",text:"Browser data",info:"Clear recent history or saved bookmarks",select:[["clearHistory","Clear recent history"],["clearBookmarks","Clear all bookmarks"]],noValue:!0},{key:"directoryListing",category:"HTML / static",text:"Enable directory listing",checkbox:!0},{key:"enableCors",category:"HTML / static",text:"Enable CORS",checkbox:!0},{key:"customCharset",category:"HTML / static",text:"Custom charset",prompt:"Charset",promptType:"text"},{key:"customHeaders",category:"HTML / static",text:"Custom response headers",info:'One "Header: value" per line',prompt:"Custom headers",promptType:"textarea"},{key:"bindLocalhostOnly",category:"Security",text:"Prefer localhost bind",checkbox:!0},{key:"ipWhitelist",category:"Security",text:"Client IP whitelist",info:"Comma or newline separated; empty = all",prompt:"IP whitelist",promptType:"textarea"},{key:"basicAuthUser",category:"Security",text:"Basic auth user",prompt:"User name",promptType:"text"},{key:"basicAuthPass",category:"Security",text:"Basic auth password",prompt:"Password",promptType:"text",secret:!0}]});var Tr={};xe(Tr,{openSettingsHub:()=>Ta,registerPluginSettings:()=>js});function Ea(){if(document.getElementById("ls-settings-css"))return;let e=document.createElement("style");e.id="ls-settings-css",e.textContent=ka,document.head.appendChild(e)}function Me(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.textContent=r),n}function $s(e,t,r,n){let o=Me("div","ls-set-row");o.setAttribute("role","button"),o.tabIndex=0;let s=Me("div","ls-set-main");return s.appendChild(Me("div","ls-set-title",e)),t&&s.appendChild(Me("div","ls-set-info",t)),o.appendChild(s),r&&o.appendChild(r),o.addEventListener("click",n),o}function Fs(){let e=Me("span","ls-set-chev");return e.innerHTML=Ut(Sa,16),e}async function La(e,t){let r=Ge(e.key);if(e.checkbox)return await nr(e.key,!r),t();if(e.select){let n=await xa(e.text,e.select,{hideOnSelect:!0,default:e.noValue?void 0:String(r)});n!=null&&(await nr(e.key,n),t());return}if(e.prompt){let n=e.promptType==="number"?"number":e.promptType==="textarea"?"textarea":"text",o=await wa(e.prompt,r==null?"":String(r),n);o!=null&&(await nr(e.key,o),t())}}function _a(e,t){e.textContent="",Os().forEach(r=>{let n=rr.filter(o=>o.category===r).length;e.appendChild($s(r,n+" options",Fs(),()=>t(r)))})}function Ca(e,t,r){e.textContent="",rr.filter(n=>n.category===t).forEach(n=>{let o=null;if(n.checkbox)o=Me("span","ls-set-switch"+(Ge(n.key)?" is-on":""));else{o=Me("span"),o.style.cssText="display:flex;align-items:center;gap:6px;min-width:0;max-width:50%";let s=Hs(n);s&&o.appendChild(Me("span","ls-set-val",s)),o.appendChild(Fs())}e.appendChild($s(n.text,n.info,o,()=>La(n,r)))})}function qs(e,t,r){var p,l;Ea();let n=document.createElement("span");n.className="icon arrow_back",n.dataset.action="back",n.style.cssText="pointer-events:auto;cursor:pointer;";let o=ya(e,{lead:n}),s=Me("div","ls-set-body");try{o.appendBody(s)}catch{(p=o.appendChild)==null||p.call(o,s)}let i=()=>t(s,i),c=()=>{var d,f;try{Ds.remove(r)}catch{}try{(d=o.hide)==null||d.call(o)}catch{}try{(f=o.remove)==null||f.call(o)}catch{}};n.onclick=d=>{var f,g;try{(f=d==null?void 0:d.preventDefault)==null||f.call(d),(g=d==null?void 0:d.stopPropagation)==null||g.call(d)}catch{}c()};try{Ds.push({id:r,action:c})}catch{}i();try{(window.app||document.body).append(o)}catch{document.body.append(o)}try{(l=o.show)==null||l.call(o)}catch{}}function Ta(){qs("Live Server",e=>_a(e,t=>qs(t,(r,n)=>Ca(r,t,n),Is+t)),Is+"hub")}function js(){}var ya,Ds,xa,wa,Is,Sa,ka,Xt=T(()=>{eo();Mn();ya=acode.require("page"),Ds=acode.require("actionStack"),xa=acode.require("select"),wa=acode.require("prompt"),Is="liveserver-settings-",Sa="M9 18l6-6-6-6",ka=`
.ls-set-body{height:100%;overflow:auto;padding:4px 0 24px}
.ls-set-row{display:flex;align-items:center;gap:12px;padding:12px 16px;cursor:pointer;border-bottom:1px solid rgba(128,128,128,.15)}
.ls-set-row:active{background:rgba(128,128,128,.14)}
.ls-set-main{flex:1;min-width:0}
.ls-set-title{font-size:15px}
.ls-set-info{font-size:12px;opacity:.65;margin-top:2px}
.ls-set-val{max-width:45%;font-size:12px;opacity:.75;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ls-set-chev{display:inline-flex;opacity:.55;flex-shrink:0}
.ls-set-switch{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0}
.ls-set-switch::before{content:'';position:absolute;inset:0;border-radius:3px;background:rgba(128,128,128,.45);transition:background .15s}
.ls-set-switch::after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:3px;background:#fff;transition:transform .15s}
.ls-set-switch.is-on::before{background:var(--active-color,#61afef)}
.ls-set-switch.is-on::after{transform:translateX(18px)}
`});var Wr={id:"acode.plugin.sugerserver",name:"Html Server - Devtool",main:"main.js",version:"2.0.0",readme:"readme.md",icon:"icon.png",files:["acodels/","devtool/","icon.png","readme.md"],minVersionCode:290,license:"",changelogs:"changelogs.md",keywords:["Live Server","HTML","HTTP","browser","preview"],price:55,repository:"",author:{name:"Dev.Sourav",email:"devs.sourav@gmail.com",github:"Sou6900"}};Xt();qr();Se();var to=acode.require("toast"),ro=[];function zs(){try{let e=acode.require("commands");if(!(e!=null&&e.add))return;let t=(r,n,o)=>{try{e.add({name:r,description:n,exec:o}),ro.push(r)}catch{}};t("liveserver:run-file","Live Server: Run this file in HTTP server",async()=>{if(!X())return to("Open a file in the editor first",2e3);let{startServer:n}=await Promise.resolve().then(()=>(J(),le));await n()}),t("liveserver:select-root","Live Server: Select root folder",async()=>{let{pickRootFolder:r}=await Promise.resolve().then(()=>(Ie(),Ke));await r()}),t("liveserver:run-selected-root","Live Server: Run HTTP server for selected / saved root",async()=>{let{startServer:r}=await Promise.resolve().then(()=>(J(),le)),{getSettings:n}=await Promise.resolve().then(()=>(ne(),Mt)),{rootFromSelectedFolder:o}=await Promise.resolve().then(()=>(Ie(),Ke)),s=n().rootFolder||o();if(!s)return to("Select a root folder first (command: Select root folder)",3e3);await r({root:s})}),t("liveserver:stop","Live Server: Stop server",async()=>{let{stopServer:r}=await Promise.resolve().then(()=>(J(),le));await r()}),t("liveserver:restart","Live Server: Restart server",async()=>{let{restartServer:r}=await Promise.resolve().then(()=>(J(),le));await r()}),t("liveserver:open-browser","Live Server: Open browser",async()=>{let{getServerStatus:r}=await Promise.resolve().then(()=>(he(),gt)),{openBrowser:n}=await Promise.resolve().then(()=>(nt(),rt)),o=r();if(!o.running)return to("Server is not running",2e3);n(o.url||`http://127.0.0.1:${o.port}/`,{restoreOnly:!0})}),t("liveserver:settings","Live Server: Open settings",async()=>{let{openSettingsHub:r}=await Promise.resolve().then(()=>(Xt(),Tr));r()})}catch(e){console.warn("[LiveServer] commands",e)}}function Us(){try{let e=acode.require("commands");ro.forEach(t=>{var r;try{(r=e==null?void 0:e.remove)==null||r.call(e,t)}catch{}})}catch{}ro=[]}cn();Se();Se();J();var Ns=acode.require("toast"),no=!1;async function Ws(e){var t;if(no)return!1;no=!0;try{let r=e||X();if(!Le(r))return Ns("Open an .html / .htm file first",2e3),!1;if(r.isUnsaved&&(r.uri||r.url))try{await((t=r.save)==null?void 0:t.call(r))}catch(n){console.warn("[LiveServer] save before run",n)}return await er({openBrowser:!0})}catch(r){return Ns(String((r==null?void 0:r.message)||r),3e3),!1}finally{no=!1}}var N=null,$r=null,oo=!1;function Ra(){if(document.getElementById("ls-run-css"))return;let e=document.createElement("style");e.id="ls-run-css",e.textContent=`
    body.ls-html-file #root > header.tile > [action="run"]:not([data-ls-run]) {
      display: none !important;
    }
  `,document.head.appendChild(e)}var Gs="#root > header.tile";function Aa(){return document.querySelector(`${Gs} > span.icon.play_arrow[action="run"]`)||document.querySelector('[action="run"]:not([data-ls-run])')}async function Pa(e){var t;if(e.preventDefault(),e.stopPropagation(),!oo){oo=!0;try{let r=X()||((t=window.editorManager)==null?void 0:t.activeFile);await Ws(r)}catch(r){console.error("[LiveServer] runPreview failed:",r);try{acode.require("toast")((r==null?void 0:r.message)||"Failed to launch Live Server")}catch{}}finally{oo=!1}}}function ke(){var o;Ra();let e=X()||((o=window.editorManager)==null?void 0:o.activeFile),t=Le(e);if(document.body.classList.toggle("ls-html-file",t),!t){N!=null&&N.isConnected&&N.remove();return}N||(N=document.createElement("span"),N.className="icon play_arrow",N.setAttribute("action","run-live-server"),N.setAttribute("data-ls-run","1"),N.setAttribute("title","Run with Live Server"),N.onclick=Pa),N.className="icon play_arrow";let r=Aa(),n=document.querySelector(Gs);r&&r.parentNode?(N.parentNode!==r.parentNode||N.nextSibling!==r)&&r.parentNode.insertBefore(N,r):n&&!N.isConnected&&n.insertBefore(N,n.lastChild)}function Xs(){ke(),window.editorManager&&(editorManager.off("switch-file",ke),editorManager.off("rename-file",ke),editorManager.on("switch-file",ke),editorManager.on("rename-file",ke)),clearInterval($r),$r=setInterval(ke,1500)}function Vs(){var e;clearInterval($r),$r=null,window.editorManager&&(editorManager.off("switch-file",ke),editorManager.off("rename-file",ke));try{N==null||N.remove()}catch{}N=null,document.body.classList.remove("ls-html-file"),(e=document.getElementById("ls-run-css"))==null||e.remove()}ht();J();he();ne();he();Se();var Ct=null;function Ys(){var e;if(!Ct){Ct=async t=>{try{if(k().liveReload===!1)return;let r=D();if(!r.running||!r.port)return;await fetch(`http://127.0.0.1:${r.port}/reload`,{method:"POST"}).catch(()=>{}),(Le(t)||Le(editorManager==null?void 0:editorManager.activeFile))&&console.log("[LiveServer] reload signal after save")}catch(r){console.warn("[LiveServer] save reload",r)}};try{(e=editorManager==null?void 0:editorManager.on)==null||e.call(editorManager,"save-file",Ct)}catch{}}}function Ks(){var e;try{Ct&&((e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"save-file",Ct))}catch{}Ct=null}var so=null;function Zs(){so&&(so(!1),so=null)}xr();var Js=["switch-file","rename-file","file-loaded","new-file"],Fr="",or=null,st=null,sr=null;async function Qs(e){Fr=e||"",Gn(Fr),qo(Fr),en();try{let{getSettings:r,updateSetting:n}=await Promise.resolve().then(()=>(ne(),Mt)),o=r().acodelsPath||"";/^\/public|com\.termux/.test(String(o))&&n("acodelsPath","")}catch{}try{}catch(r){console.warn("[LiveServer] settings",r)}try{Kn()}catch(r){console.warn("[LiveServer] side",r)}try{zs()}catch(r){console.warn("[LiveServer] commands",r)}try{Ys()}catch(r){console.warn("[LiveServer] liveReload",r)}try{Xs()}catch(r){console.warn("[LiveServer] run button",r)}or=()=>{Zn(),ke()},Js.forEach(r=>{var n;try{(n=editorManager==null?void 0:editorManager.on)==null||n.call(editorManager,r,or)}catch{}}),st=()=>ot(D().running);try{window.addEventListener("liveserver-status",st),window.addEventListener("liveserver-started",st),window.addEventListener("liveserver-stopped",st)}catch{}let t=async()=>{let r=await Vn();ot(r)};t(),setTimeout(t,1200),setTimeout(or,400),sr=()=>{document.visibilityState==="visible"&&t()},document.addEventListener("visibilitychange",sr);try{window.addEventListener("liveserver-settings",async()=>{try{let{reapplySetup:r}=await Promise.resolve().then(()=>(J(),le));D().running&&await r()}catch{}})}catch{}console.log("[LiveServer] v2 init",Fr)}function ei(){Js.forEach(e=>{var t;try{or&&((t=editorManager==null?void 0:editorManager.off)==null||t.call(editorManager,e,or))}catch{}});try{Vs()}catch{}try{window.removeEventListener("liveserver-status",st),window.removeEventListener("liveserver-started",st),window.removeEventListener("liveserver-stopped",st)}catch{}sr&&(document.removeEventListener("visibilitychange",sr),sr=null),Zs(),Mo(),Jn(),Us();try{Ks()}catch{}try{Promise.resolve().then(()=>(nt(),rt)).then(e=>{var t;return(t=e.hideBrowser)==null?void 0:t.call(e)})}catch{}try{Promise.resolve().then(()=>($n(),ps)).then(e=>{var t;return(t=e.destroyAcodeWebview)==null?void 0:t.call(e)})}catch{}}eo();var jr=class{constructor(){this.baseUrl=""}async init(t){var r;this.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await Qs(this.baseUrl)}async destroy(){ei()}};if(window.acode){let e=new jr;acode.setPluginInit(Wr.id,async t=>{var r;e.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await e.init(e.baseUrl)},Bs()),acode.setPluginUnmount(Wr.id,()=>{e.destroy()})}var Nc=jr;})();
