(()=>{var Hi=Object.defineProperty;var T=(e,t)=>()=>(e&&(t=e(e=0)),t);var xe=(e,t)=>{for(var r in t)Hi(e,r,{get:t[r],enumerable:!0})};var zt,ln=T(()=>{zt={pluginEnabled:!0,port:8080,bindAddress:"127.0.0.1",rootFolder:"",rootFolderUri:"",lastMirrorRoot:"",mirrorSharedStorage:!0,liveReload:!0,openBrowserOnStart:!0,directoryListing:!0,autoShutdownMinutes:0,browserDisplayMode:"inPage",browserSearchEngine:"brave",externalSiteMode:"proxy",browserHomeUrl:"",showSideButton:!0,sideButtonRunningLabel:"{HOST}:{PORT}",sideButtonOfflineLabel:"Go Live",browserOpacity:1,browserOverlay:!1,enablePinchToZoom:!0,devtoolDownloadOk:!1,overlayAutoSave:!0,browserBookmarks:[],browserDevice:{on:!1,id:"responsive",w:390,h:844,zoom:"fit"},enableCors:!0,customHeaders:"",customCharset:"utf-8",bindLocalhostOnly:!0,ipWhitelist:"",basicAuthUser:"",basicAuthPass:"",dependenciesInstalled:!1,acodelsPath:"",showAddressBar:!0}});var De={};xe(De,{getPluginId:()=>Fi,getSettings:()=>S,saveSettingsPatch:()=>Ui,updateSetting:()=>R});function Fi(){return cn}function S(){var e;try{let t=acode.require("settings"),r=(e=t==null?void 0:t.value)==null?void 0:e[cn];return(!r||typeof r!="object")&&(r={...zt},t!=null&&t.value&&(t.value[cn]=r)),r}catch{return{...zt}}}function R(e,t){let r=S();r[e]=t;try{acode.require("settings").update(!1)}catch{}try{window.dispatchEvent(new CustomEvent("liveserver-settings",{detail:{key:e,value:t}}))}catch{}}function Ui(e){let t=S();Object.assign(t,e);try{acode.require("settings").update(!1)}catch{}}var cn,J=T(()=>{ln();cn="acode.plugin.sugerserver"});function Ce(e){return String(e!=null?e:"").replace(/'/g,`'"'"'`)}function dn(e){let t=String(e||"").trim();return t?/^sh\s+-c\s+/i.test(t)?t:`sh -c '${Ce(t)}'`:"sh -c 'true'"}function Ht(e){return String(e||"").split(`
`).filter(t=>!/proot warning:/i.test(t)).join(`
`)}function Ro(e){if(e==null)return"";if(typeof e=="string")return Ht(e);if(typeof e=="object"){let t=[e.stdout,e.stderr,e.output,e.message].filter(r=>r!=null&&r!=="").map(String);if(t.length)return Ht(t.join(`
`));try{return Ht(JSON.stringify(e))}catch{return Ht(String(e))}}return Ht(String(e))}function un(e){try{return btoa(unescape(encodeURIComponent(e)))}catch{let r=new TextEncoder().encode(e),n="";return r.forEach(o=>{n+=String.fromCharCode(o)}),btoa(n)}}function ft(){try{let e=acode.require("terminal"),t=typeof Executor!="undefined"&&Executor||window.Executor||globalThis.Executor||(e==null?void 0:e.Executor)||null;if(t!=null&&t.execute)return t}catch{}return null}async function ee(e,t={}){let r=typeof t=="number"?t:t.timeoutMs||0,n=typeof t=="object"&&t.alpine!==!1,o=ft();if(!(o!=null&&o.execute))throw console.warn("[LiveServer:exec] no executor",{hasWindow:!!window.Executor,hasGlobal:!!globalThis.Executor,hasTerminal:!!acode.require("terminal")}),new Error("Executor not available. Open Acode Terminal once (or install Executor), then retry.");let s=dn(e),i=async()=>{try{let a=await o.execute(s,n);return Ro(a)}catch(a){let d=Ro(a)||a&&a.message||String(a);return console.warn("[LiveServer:exec] catch \u2192",String(d).slice(0,240)),d}};return r>0?Promise.race([i(),new Promise(a=>setTimeout(()=>{a("")},r))]):i()}async function qt(e,t={}){let r=un(String(e||""));return ee(`echo '${Ce(r)}' | base64 -d | sh`,{timeoutMs:t.timeoutMs||0,alpine:t.alpine!==!1})}async function pn(e){try{let t=await ee(`command -v ${Ce(e)} 2>/dev/null || which ${Ce(e)} 2>/dev/null || echo MISS`,{timeoutMs:2e4}),r=String(t||"").trim();return!r||/MISS|not found/i.test(r)?!1:/\//.test(r)||r.split(`
`).some(n=>n.includes("/"))}catch(t){return console.warn("[LiveServer:exec] commandExists",e,(t==null?void 0:t.message)||t),!1}}var ht=T(()=>{});function Oo(){let e=document.getElementById("ls-deps-picker-css");e&&e.remove();let t=document.createElement("style");t.id="ls-deps-picker-css",t.textContent=`
#ls-deps-picker {
  position: fixed;
  inset: 0;
  z-index: 100005;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  background: rgba(0, 0, 0, 0.56);
  backdrop-filter: blur(3px);
  animation: ls-dp-in 0.18s ease-out;
}
@keyframes ls-dp-in {
  from { opacity: 0; }
  to { opacity: 1; }
}
#ls-deps-picker.ls-dp-leaving {
  opacity: 0;
  transition: opacity 0.16s ease;
}
.ls-dp-backdrop {
  position: absolute;
  inset: 0;
}
.ls-dp-card {
  position: relative;
  z-index: 1;
  width: min(440px, 94vw);
  max-height: min(82vh, 580px);
  display: flex;
  flex-direction: column;
  border-radius: 8px;
  background: var(--popup-background-color, var(--secondary-color, #1e1f22));
  color: var(--popup-text-color, var(--primary-text-color, var(--color, #e8eaed)));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.28));
  box-shadow: 0 18px 48px rgba(0, 0, 0, 0.52);
  overflow: hidden;
  font-family: inherit;
}

/* ---- Linux Window Titlebar ---- */
.ls-dp-titlebar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.24));
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-title-left {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}
.ls-dp-dots {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex-shrink: 0;
}
.ls-dp-dots span {
  width: 9px;
  height: 9px;
  border-radius: 50%;
  display: inline-block;
}
.ls-dp-dots span:nth-child(1) { background: #ef4444; }
.ls-dp-dots span:nth-child(2) { background: #f59e0b; }
.ls-dp-dots span:nth-child(3) { background: #22c55e; }
.ls-dp-title {
  font-weight: 600;
  font-size: 14px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ls-dp-subbar {
  padding: 8px 16px;
  font-size: 12px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.85;
  background: rgba(128, 128, 128, 0.06);
  border-bottom: 1px solid var(--border-color, rgba(128, 128, 128, 0.16));
  flex-shrink: 0;
}

/* ---- Body ---- */
.ls-dp-body {
  flex: 1;
  overflow-y: auto;
  padding: 12px 15px;
  min-height: 90px;
}
.ls-dp-checking {
  display: flex;
  align-items: center;
  gap: 10px;
  justify-content: center;
  padding: 26px 8px;
  font-size: 13px;
}
.ls-dp-spinner {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: 2px solid rgba(128, 128, 128, 0.3);
  border-top-color: var(--active-color, #22c55e);
  animation: ls-spin 0.7s linear infinite;
  flex-shrink: 0;
}
@keyframes ls-spin {
  to { transform: rotate(360deg); }
}

/* ---- Package Rows ---- */
.ls-dp-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 11px;
  border-radius: 6px;
  margin-bottom: 7px;
  background: var(--primary-color, rgba(128, 128, 128, 0.1));
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
  cursor: pointer;
  transition: border-color 0.15s ease;
}
.ls-dp-row:last-child {
  margin-bottom: 0;
}
.ls-dp-row.is-present {
  opacity: 0.78;
  cursor: default;
}
.ls-dp-row input[type="checkbox"] {
  width: 1.12rem;
  height: 1.12rem;
  flex-shrink: 0;
  accent-color: var(--active-color, #22c55e);
}
.ls-dp-row-main {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.ls-dp-name {
  font-weight: 600;
  font-size: 13px;
}
.ls-dp-desc {
  font-size: 11.5px;
  color: var(--secondary-text-color, inherit);
  opacity: 0.75;
  word-break: break-word;
}
.ls-dp-status {
  font-size: 11px;
  flex-shrink: 0;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 4px;
}
.ls-dp-status.ok {
  background: rgba(34, 197, 94, 0.16);
  color: #4ade80;
}
.ls-dp-status.miss {
  background: rgba(239, 68, 68, 0.16);
  color: #f87171;
}
.ls-dp-status.opt {
  background: rgba(128, 128, 128, 0.18);
  color: var(--secondary-text-color, #9aa0a6);
}

/* ---- Linux Installation Progress View ---- */
.ls-dp-progress {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.ls-dp-warn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 11px;
  border-radius: 5px;
  background: rgba(245, 158, 11, 0.14);
  border: 1px solid rgba(245, 158, 11, 0.35);
  color: #fbbf24;
  font-size: 12px;
  font-weight: 500;
}
.ls-dp-prog-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  font-size: 12.5px;
}
.ls-dp-progress-info {
  opacity: 0.92;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ls-dp-pct {
  font-weight: 700;
  font-variant-numeric: tabular-nums;
  color: var(--active-color, #22c55e);
  flex-shrink: 0;
}
.ls-dp-progress-track {
  width: 100%;
  height: 8px;
  border-radius: 99px;
  background: var(--primary-color, rgba(128, 128, 128, 0.25));
  overflow: hidden;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.2));
}
.ls-dp-progress-bar {
  height: 100%;
  width: 0%;
  border-radius: 99px;
  background: var(--active-color, #22c55e);
  transition: width 0.28s ease;
}
.ls-dp-link {
  align-self: flex-start;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  color: var(--active-color, #61afef);
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
  padding: 2px 0;
  font-family: inherit;
}
.ls-dp-log {
  margin: 0;
  max-height: 155px;
  overflow-y: auto;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
  font-size: 11px;
  line-height: 1.4;
  background: #0d1117;
  color: #c9d1d9;
  padding: 10px;
  border-radius: 5px;
  white-space: pre-wrap;
  word-break: break-word;
  border: 1px solid var(--border-color, rgba(128, 128, 128, 0.25));
}

/* ---- Footer ---- */
.ls-dp-footer {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-end;
  padding: 11px 15px;
  background: var(--primary-color, rgba(0, 0, 0, 0.18));
  border-top: 1px solid var(--border-color, rgba(128, 128, 128, 0.22));
  flex-shrink: 0;
}
.ls-dp-btn {
  border: none;
  border-radius: 5px;
  padding: 8px 14px;
  font-size: 12.5px;
  font-weight: 600;
  cursor: pointer;
  background: rgba(128, 128, 128, 0.22);
  color: inherit;
  font-family: inherit;
}
.ls-dp-btn:active {
  opacity: 0.85;
}
.ls-dp-btn.ls-dp-install,
.ls-dp-btn.ls-dp-done {
  background: var(--active-color, #22c55e);
  color: var(--button-text-color, #0b1116);
}
.ls-dp-btn.ls-dp-cancel {
  background: rgba(239, 68, 68, 0.18);
  color: #f87171;
  border: 1px solid rgba(239, 68, 68, 0.38);
}
.ls-dp-empty {
  opacity: 0.7;
  padding: 14px;
  text-align: center;
  font-size: 13px;
}
  `,document.head.appendChild(t)}var _o=T(()=>{});function Ft(e){return String(e!=null?e:"").replace(/&/g,"&").replace(/</g,"<").replace(/>/g,">").replace(/"/g,'"')}function Io(){return!!I}function fn(){return Ut}function Do(){Ut=!1}function zo(e={}){Oo(),Bo(!0),Ut=!1;let t=e.title||"Live Server Dependencies",r=e.subtitle||"Checking Alpine Linux packages...",n=Array.isArray(e.items)?e.items.slice():[];return new Promise(o=>{mt=o,I=document.createElement("div"),I.id="ls-deps-picker",I.innerHTML=`
      <div class="ls-dp-backdrop"></div>
      <div class="ls-dp-card" role="dialog" aria-modal="true">
        <div class="ls-dp-titlebar">
          <div class="ls-dp-title-left">
            <span class="ls-dp-dots"><span></span><span></span><span></span></span>
            <div class="ls-dp-title">${Ft(t)}</div>
          </div>
        </div>
        <div class="ls-dp-subbar ls-dp-subtitle">${Ft(r)}</div>

        <div class="ls-dp-body">
          <div class="ls-dp-checking" style="display:${e.checking?"flex":"none"}">
            <span class="ls-dp-spinner"></span>
            <span>Scanning Alpine environment...</span>
          </div>

          <div class="ls-dp-lists" style="display:${e.checking?"none":"block"}"></div>

          <div class="ls-dp-progress" style="display:none">
            <div class="ls-dp-warn">
              <span>\u26A0</span>
              <span>Don't close Acode while packages are installing.</span>
            </div>

            <div class="ls-dp-prog-top">
              <div class="ls-dp-progress-info">Preparing installation...</div>
              <span class="ls-dp-pct">0%</span>
            </div>

            <div class="ls-dp-progress-track">
              <div class="ls-dp-progress-bar" style="width:0%"></div>
            </div>

            <button type="button" class="ls-dp-link ls-dp-toggle-log">
              <span class="ls-dp-arrow">\u25B8</span>
              <span class="ls-dp-more-label">Show more</span>
            </button>
            <pre class="ls-dp-log" style="display:none"></pre>
          </div>
        </div>

        <div class="ls-dp-footer">
          <button type="button" class="ls-dp-btn ls-dp-notnow">Not now</button>
          <button type="button" class="ls-dp-btn ls-dp-cancel" style="display:none">Cancel installation</button>
          <button type="button" class="ls-dp-btn ls-dp-install">Install selected</button>
          <button type="button" class="ls-dp-btn ls-dp-done" style="display:none">Close</button>
        </div>
      </div>`,document.body.appendChild(I);let s=I.querySelector(".ls-dp-lists"),i=I.querySelector(".ls-dp-checking"),a=I.querySelector(".ls-dp-progress"),d=I.querySelector(".ls-dp-progress-bar"),u=I.querySelector(".ls-dp-pct"),p=I.querySelector(".ls-dp-progress-info"),c=I.querySelector(".ls-dp-log"),g=I.querySelector(".ls-dp-install"),h=I.querySelector(".ls-dp-notnow"),l=I.querySelector(".ls-dp-cancel"),v=I.querySelector(".ls-dp-done"),A=I.querySelector(".ls-dp-toggle-log"),x=I.querySelector(".ls-dp-arrow"),C=I.querySelector(".ls-dp-more-label"),_=I.querySelector(".ls-dp-subtitle"),M=I.querySelector(".ls-dp-backdrop");function b(){if(!s)return;let m="";for(let y of n){let oe=y.present?'<span class="ls-dp-status ok">installed</span>':y.optional?'<span class="ls-dp-status opt">optional</span>':'<span class="ls-dp-status miss">missing</span>',ye=y.checked!=null?!!y.checked:!y.present&&!y.optional;m+=`<label class="ls-dp-row ${y.present?"is-present":"is-missing"}">
          <input type="checkbox" data-id="${Ft(y.id)}" ${ye?"checked":""} ${y.present?"disabled":""}/>
          <span class="ls-dp-row-main">
            <span class="ls-dp-name">${Ft(y.label)}</span>
            <span class="ls-dp-desc">${Ft(y.desc||"")}</span>
          </span>${oe}</label>`}s.innerHTML=m||'<div class="ls-dp-empty">No items</div>'}function B(){let m=[];return I==null||I.querySelectorAll("input[type=checkbox][data-id]:checked:not(:disabled)").forEach(y=>m.push(y.getAttribute("data-id"))),m}function q(m){let y=B(),oe=mt;mt=null,Bo(!1),oe&&oe({action:m,selected:y})}function z(){let m=B();if(!m.length){try{acode.require("toast")("Select at least one item",2e3)}catch{}return}Ut=!1,s&&(s.style.display="none"),i&&(i.style.display="none"),a&&(a.style.display="flex"),g&&(g.style.display="none"),h&&(h.style.display="none"),l&&(l.style.display="inline-block"),v&&(v.style.display="none"),d&&(d.style.width="2%"),u&&(u.textContent="2%"),p&&(p.textContent="Initializing package installer..."),c&&(c.textContent=""),_&&(_.textContent="Installing selected packages in Alpine Linux...");let y=mt;mt=null,y&&y({action:"install",selected:m,keepOpen:!0})}g==null||g.addEventListener("click",()=>z()),h==null||h.addEventListener("click",()=>q("notnow")),l==null||l.addEventListener("click",()=>{Ut=!0,p&&(p.textContent="Cancelled"),q("cancel")}),v==null||v.addEventListener("click",()=>q("done")),M==null||M.addEventListener("click",()=>{a&&a.style.display!=="none"&&(l==null?void 0:l.style.display)!=="none"||q("close")}),A==null||A.addEventListener("click",()=>{if(!c)return;let m=c.style.display!=="none";c.style.display=m?"none":"block",x&&(x.textContent=m?"\u25B8":"\u25BE"),C&&(C.textContent=m?"Show more":"Show less"),m||(c.scrollTop=c.scrollHeight)}),I._lsDpUpdate=m=>{if(m.checking===!1&&i&&s&&(i.style.display="none",s.style.display="block"),m.checking===!0&&i&&s&&(i.style.display="flex",s.style.display="none"),m.subtitle!=null&&_&&(_.textContent=m.subtitle),Array.isArray(m.items)&&(n.length=0,m.items.forEach(y=>n.push({...y,checked:y.checked!=null?!!y.checked:!y.present&&!y.optional})),b()),m.progressMode&&(s&&(s.style.display="none"),i&&(i.style.display="none"),a&&(a.style.display="flex"),g&&(g.style.display="none"),h&&(h.style.display="none"),l&&(l.style.display=m.showDone?"none":"inline-block"),v&&(v.style.display=m.showDone?"inline-block":"none")),typeof m.percent=="number"){let y=Math.max(0,Math.min(100,Math.round(m.percent)));d&&(d.style.width=y+"%"),u&&(u.textContent=y+"%")}m.info&&p&&(p.textContent=m.info),m.logAppend&&c&&(c.textContent+=m.logAppend,c.scrollTop=c.scrollHeight),m.logSet!=null&&c&&(c.textContent=m.logSet)},b()})}function me(e){I&&typeof I._lsDpUpdate=="function"&&I._lsDpUpdate(e)}function Bo(e){if(!I)return;let t=I;I=null,mt=null;try{t.classList.add("ls-dp-leaving")}catch{}let r=()=>{try{t.remove()}catch{}};e?r():setTimeout(r,180)}var I,mt,Ut,Ho=T(()=>{_o();I=null,mt=null,Ut=!1});var Er={};xe(Er,{DEP_CATALOG:()=>wr,checkDependenciesAction:()=>Vi,ensureLiveServerDeps:()=>kr,reinstallDependenciesAction:()=>Yi,resetDepsSession:()=>gn,resolveAcodelsPath:()=>bt,scanAllDeps:()=>mn,showDepsPickerFlow:()=>Sr,verifyDependencies:()=>Nt});async function bt(){let e=S();try{let r=await ee(`for d in /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do
  [ -f "$d/index.js" ] || continue
  if [ -d "$d/node_modules/express" ]; then echo "FULL:$d"; exit 0; fi
  echo "BARE:$d"
done
exit 0`,{timeoutMs:12e3}),n=String(r||"").split(`
`).map(d=>d.trim()).filter(Boolean),o=n.filter(d=>d.startsWith("FULL:")).map(d=>d.slice(5)),s=n.filter(d=>d.startsWith("BARE:")).map(d=>d.slice(5)),i=d=>d.filter(p=>p&&!p.startsWith("/public")).sort((p,c)=>(c.startsWith("/root")?1:0)-(p.startsWith("/root")?1:0))[0]||d.find(p=>p&&!p.startsWith("/public"))||d[0]||null,a=i(o)||i(s);if(a){try{R("acodelsPath",a)}catch{}return a}}catch(r){console.warn("[LiveServer:deps] probe",(r==null?void 0:r.message)||r)}let t=String(e.acodelsPath||"").trim();if(t&&!t.startsWith("/public")&&!t.includes("com.termux"))return t;try{t&&R("acodelsPath","")}catch{}return"/root/.acode_liveserver/acodels"}async function ji(e){try{let t=e?Ce(e):"''",r=await ee("for d in "+t+' /root/.acode_liveserver/acodels "$HOME/.acode_liveserver/acodels"; do [ -d "$d/node_modules/express" ] && [ -d "$d/node_modules/ws" ] && echo OK && exit 0; done; echo MISS',{timeoutMs:1e4});return String(r).includes("OK")}catch{return!1}}async function mn(e){ze=e||ze;let t=await pn("node"),r=await pn("npm"),n=await bt(e),o=t?await ji(n):!1;return[{...wr[0],present:t},{...wr[1],present:r},{...wr[2],present:o,path:n}]}async function Nt(e){let t=await mn(e),r=t.filter(n=>!n.present).map(n=>n.id);return{ok:r.length===0,missing:r,all:t}}function Wi(e){return e.map(t=>({id:t.id,label:t.label,desc:t.desc+(t.path?` \u2014 ${t.path}`:""),present:t.present,optional:!1,checked:!t.present}))}async function Zi(){return qt(`#!/bin/sh
set +e
echo "[pm] detecting..."
if command -v pkg >/dev/null 2>&1; then
  echo "[pm] termux pkg"
  pkg update -y 2>&1
  pkg install -y nodejs 2>&1 || pkg install -y nodejs-lts 2>&1
elif command -v apk >/dev/null 2>&1; then
  echo "[pm] apk"
  apk update 2>&1
  apk add --no-cache nodejs npm 2>&1
elif command -v apt-get >/dev/null 2>&1; then
  echo "[pm] apt"
  apt-get update -y 2>&1
  apt-get install -y nodejs npm 2>&1
else
  echo "[pm] none found"
  exit 1
fi
node -v 2>&1
npm -v 2>&1
echo "[done] node packages"
`,{timeoutMs:0})}async function Gi(e){let t=`#!/bin/sh
set +e
DIR=${Ce(e)}
case "$DIR" in
  '$HOME'/*|$HOME/*) DIR="/root/.acode_liveserver/acodels" ;;
esac
if [ -z "$DIR" ] || echo "$DIR" | grep -q com.termux; then
  DIR="/root/.acode_liveserver/acodels"
fi
mkdir -p "$DIR" 2>&1
cd "$DIR" || { echo "[acodels] cd failed"; exit 1; }
if [ ! -f package.json ]; then
  cat > package.json << 'JSON'
{
  "name": "acodels",
  "version": "1.0.0",
  "main": "index.js",
  "dependencies": {
    "chokidar": "^3.5.3",
    "cors": "^2.8.5",
    "express": "^4.18.2",
    "ws": "^8.11.0"
  }
}
JSON
fi
echo "[acodels] npm install in $DIR"
npm install --omit=dev --no-audit --no-fund 2>&1
echo "[done] acodels"
`;return qt(t,{timeoutMs:0})}async function Sr(e={}){var i,a,d;let t=e.baseUrl||ze||"";if(ze=t,gt)return hn("Install already running...",2e3),!1;if(Io()&&!e.force||!e.force&&!e.fromSettings&&vt)return!1;if(!e.force&&!e.fromSettings&&(await Nt(t)).ok)return R("dependenciesInstalled",!0),!0;(i=ft())!=null&&i.execute||hn("Open Acode Terminal once, then retry Install",3500);let r=zo({title:"Live Server Dependencies",subtitle:"Checking...",items:[],checking:!0}),n;try{n=await mn(t)}catch(u){return me({checking:!1,subtitle:"Check failed \u2014 "+((u==null?void 0:u.message)||u),items:[]}),await r,!1}let o=n.filter(u=>u.required!==!1&&!u.present).length;me({checking:!1,subtitle:o===0?"All required tools present":`${o} required missing \u2014 tick what to install`,items:Wi(n)});let s=await r;if(s.action==="notnow"||s.action==="close"||s.action==="cancel")return vt=!0,!1;if(s.action==="done")return(await Nt(t)).ok;if(s.action==="install"&&((a=s.selected)!=null&&a.length)){if(gt=!0,Do(),!((d=ft())!=null&&d.execute))return me({progressMode:!0,percent:0,info:"Executor not available",logAppend:`Open Acode Terminal once (Alpine/Termux), then open this dialog again.
`,showDone:!0}),gt=!1,!1;me({progressMode:!0,percent:5,info:"Preparing...",logAppend:"Selected: "+s.selected.join(", ")+`
`});try{let u=await bt(t);if(s.selected.includes("node")||s.selected.includes("npm")){if(me({percent:15,info:"Installing Node.js / npm...",logAppend:`
=== node / npm ===
`}),fn())return gt=!1,!1;let c=await Zi();me({percent:48,logAppend:String(c||"").slice(-2500)+`
`})}if(s.selected.includes("acodels")){if(me({percent:58,info:"Installing backend modules in acodels...",logAppend:`
=== acodels @ ${u} ===
`}),fn())return gt=!1,!1;let c=await Gi(u);me({percent:82,logAppend:String(c||"").slice(-3e3)+`
`})}let p=await Nt(t);return me({progressMode:!0,percent:100,info:p.ok?"Done \u2014 all required present":"Finished \u2014 still missing: "+p.missing.join(", "),showDone:!0,logAppend:p.ok?`
OK
`:`
Missing: `+p.missing.join(", ")+`
`}),R("dependenciesInstalled",p.ok),p.ok&&(vt=!0,hn("Dependencies ready",2500)),p.ok}catch(u){return me({progressMode:!0,percent:100,info:"Failed",showDone:!0,logAppend:`
ERROR: `+((u==null?void 0:u.message)||u)+`
`}),!1}finally{gt=!1}}return!1}async function kr(e={}){let t=e.baseUrl||ze||"";ze=t;try{return!e.force&&vt||!e.force&&xr&&S().dependenciesInstalled===!0?!0:(xr=!0,(await Nt(t)).ok?(R("dependenciesInstalled",!0),!0):Sr({...e,baseUrl:t}))}catch(r){return console.warn("[LiveServer:deps]",r),!1}}async function Vi(e){return Sr({force:!0,fromSettings:!0,baseUrl:e||ze})}async function Yi(e){return await Ni("Reinstall dependencies?","Will run pkg/apk install for Node and npm install in acodels.")?(vt=!1,xr=!1,Sr({force:!0,fromSettings:!0,baseUrl:e||ze})):!1}function gn(){vt=!1,xr=!1}var hn,Ni,vt,xr,gt,ze,wr,yt=T(()=>{J();ht();Ho();hn=acode.require("toast"),Ni=acode.require("confirm"),vt=!1,xr=!1,gt=!1,ze="",wr=[{id:"node",label:"node",desc:"Node.js runtime",required:!0},{id:"npm",label:"npm",desc:"Package manager",required:!0},{id:"acodels",label:"acodels modules",desc:"Backend node_modules (express, ws, chokidar)",required:!0}]});var Ji,qo,Fo=T(()=>{ht();Ji=`/**
 * acodels \u2014 Live Server + Local Reverse Proxy Node backend (ls-proxy-v10, ls-bridge-v1)
 */
const http = require('http');
const https = require('https');
const express = require('express');
const path = require('path');
const fs = require('fs');
const net = require('net');
const zlib = require('zlib');
const { URL } = require('url');
const { Server: WebSocketServer } = require('ws');
const chokidar = require('chokidar');

let BASE_DIR = null;
let jsonData = {};
let erudaEnabled = false;
let consoleType = 'suger';
let zoomEnabled = false;
let liveReloadEnabled = true;
let directoryListing = true;
let fileWatcher = null;
let connectedSockets = [];
let customHeaders = {};
let charset = 'utf-8';
let ipWhitelist = [];
let basicAuth = null;
let lastActivity = Date.now();

const args = process.argv.slice(2);
let currentPort = args[0] ? parseInt(args[0], 10) : 8080;
if (!Number.isFinite(currentPort) || currentPort < 1) currentPort = 8080;
const bindHost = args[1] || '0.0.0.0';

function isPortAvailable(port) {
  return new Promise((resolve) => {
    const tester = net
      .createServer()
      .once('error', () => resolve(false))
      .once('listening', () => tester.close(() => resolve(true)))
      .listen(port, bindHost === '0.0.0.0' ? undefined : bindHost);
  });
}

const webSocketScript = \`
<script>
  (function() {
    try {
      var wsUrl = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
      var ws = new WebSocket(wsUrl);
      ws.onmessage = function (event) {
        if (event.data === 'reload') location.reload();
      };
    } catch (e) {}
  })();
<\/script>\`;

const sugerScript = \`<script src="/dt/suger-dev.js"><\/script>\`;
const erudaRealScript = \`
<script src="/eruda.min.js"><\/script>
<script>if (typeof eruda !== 'undefined') eruda.init();<\/script>
\`;
const inspectorScript = \`<script src="/inspector.js"><\/script>\`;

/* ls-bridge-v1: page <-> Acode browser bridge */
const LS_BRIDGE_JS = \`
(function () {
  var P = window.__lsParent || window.parent;
  if (window.__lsBridge || !P || P === window) return;
  window.__lsBridge = 1;
  function post(m) {
    try { m.ls = 1; P.postMessage(m, '*'); } catch (e) {}
  }
  function currentHref() {
    return window.__LS_PROXY_TARGET__ || location.href;
  }
  function fav() {
    var l = document.querySelector('link[rel~="icon"]');
    if (l && l.href) return l.href;
    try { return new URL('/favicon.ico', currentHref()).href; } catch (e) { return ''; }
  }
  function meta() {
    post({ type: 'meta', href: currentHref(), title: document.title || '', favicon: fav() });
  }
  window.__lsPostMeta = meta;
  if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(meta, 0);
  window.addEventListener('load', meta);
  window.addEventListener('popstate', function () { setTimeout(meta, 0); });
  window.addEventListener('hashchange', function () { setTimeout(meta, 0); });
  try {
    var t = document.querySelector('title');
    if (t) new MutationObserver(meta).observe(t, { childList: true, characterData: true, subtree: true });
  } catch (e) {}

  var dtOn = false;
  function devtools(d) {
    try {
      if (d.on) {
        if (!window.suger) {
          if (!d.code) { post({ type: 'need-devtools' }); return; }
          var s = document.createElement('script');
          s.textContent = d.code;
          (document.head || document.documentElement).appendChild(s);
        }
        if (window.suger) {
          if (!window.__lsDtInit) { window.__lsDtInit = 1; window.suger.init(); }
          else window.suger.show();
          dtOn = true;
        }
      } else if (window.suger) {
        window.suger.hide();
        dtOn = false;
      }
    } catch (e) {
      post({ type: 'devtools-error', message: String(e && e.message || e) });
    }
    post({ type: 'devtools', on: dtOn });
  }

  window.addEventListener('message', function (e) {
    var d = e.data;
    if (!d || d.ls !== 1 || e.source !== P) return;
    try {
      if (d.cmd === 'history') history.go(d.dir < 0 ? -1 : 1);
      else if (d.cmd === 'reload') location.reload();
      else if (d.cmd === 'stop') window.stop();
      else if (d.cmd === 'zoom') document.documentElement.style.zoom = String((d.pct || 100) / 100);
      else if (d.cmd === 'print') window.print();
      else if (d.cmd === 'find') post({ type: 'found', ok: !!window.find(d.q, false, !!d.back, true, false, false, false) });
      else if (d.cmd === 'devtools') devtools(d);
      else if (d.cmd === 'ping') meta();
    } catch (err) {}
  });
})();
\`;

const lsBridgeScript = '<script src="/__ls/bridge.js"><\/script>';
/* pinch-zoom engine is embedded: only index.js is written to Alpine, so a separate zoom-handler.js file never existed there */
const LS_ZOOM_JS = "/**\\n * Pinch / pan / double-tap zoom.\\n *\\n * Math is based on the element's *live* bounding rect, so the content point under the\\n * fingers at gesture start stays under the fingers for the whole gesture - even when the\\n * page was scrolled before zooming, scrolls natively while zooming, or the fingers move.\\n *   local focal point  p0 = (finger - rect.topLeft) / scale          (taken at gesture start)\\n *   new translation    T  = finger' - scale' * p0 - (rect.topLeft - T_applied)\\n * (rect.topLeft - T_applied) is \\"element origin minus current scroll\\", re-read every frame.\\n */\\nclass ZoomHandler {\\n  constructor(element) {\\n    this.element = element;\\n    if (!this.element) return;\\n\\n    this.s = 1; // applied scale\\n    this.tx = 0; // applied translation (px, parent space)\\n    this.ty = 0;\\n    this.mode = null; // 'pinch' | 'pan' | null\\n    this.startDist = 1;\\n    this.startScale = 1;\\n    this.focal = { x: 0, y: 0 };\\n    this.panStart = null;\\n    this.lastTap = 0;\\n    this.tapStart = null;\\n\\n    this.onStart = this.onStart.bind(this);\\n    this.onMove = this.onMove.bind(this);\\n    this.onEnd = this.onEnd.bind(this);\\n    this.onDblClick = this.onDblClick.bind(this);\\n\\n    this.element.style.transformOrigin = '0 0';\\n    this.syncTouchAction();\\n    // passive:false is required, otherwise preventDefault() is ignored on <body>/<html>\\n    // and the page keeps scrolling / native-zooming underneath the gesture.\\n    this.element.addEventListener('touchstart', this.onStart, { passive: false });\\n    this.element.addEventListener('touchmove', this.onMove, { passive: false });\\n    this.element.addEventListener('touchend', this.onEnd);\\n    this.element.addEventListener('touchcancel', this.onEnd);\\n    this.element.addEventListener('dblclick', this.onDblClick);\\n  }\\n\\n  destroy() {\\n    if (!this.element) return;\\n    this.element.removeEventListener('touchstart', this.onStart);\\n    this.element.removeEventListener('touchmove', this.onMove);\\n    this.element.removeEventListener('touchend', this.onEnd);\\n    this.element.removeEventListener('touchcancel', this.onEnd);\\n    this.element.removeEventListener('dblclick', this.onDblClick);\\n    this.s = 1;\\n    this.tx = 0;\\n    this.ty = 0;\\n    this.element.style.transform = '';\\n    this.element.style.transformOrigin = '';\\n    this.element.style.touchAction = '';\\n  }\\n\\n  syncTouchAction() {\\n    this.element.style.touchAction = this.s > 1.001 ? 'none' : 'auto';\\n  }\\n\\n  apply(s, tx, ty) {\\n    this.s = s;\\n    this.tx = tx;\\n    this.ty = ty;\\n    this.element.style.transform = 'translate(' + tx + 'px, ' + ty + 'px) scale(' + s + ')';\\n  }\\n\\n  mid(t) {\\n    return { x: (t[0].clientX + t[1].clientX) / 2, y: (t[0].clientY + t[1].clientY) / 2 };\\n  }\\n\\n  dist(t) {\\n    const dx = t[0].clientX - t[1].clientX;\\n    const dy = t[0].clientY - t[1].clientY;\\n    return Math.sqrt(dx * dx + dy * dy) || 1;\\n  }\\n\\n  beginPinch(touches) {\\n    const r = this.element.getBoundingClientRect();\\n    const m = this.mid(touches);\\n    this.mode = 'pinch';\\n    this.startDist = this.dist(touches);\\n    this.startScale = this.s;\\n    this.focal = { x: (m.x - r.left) / this.s, y: (m.y - r.top) / this.s };\\n  }\\n\\n  beginPan(touch) {\\n    this.mode = 'pan';\\n    this.panStart = { x: touch.clientX, y: touch.clientY, tx: this.tx, ty: this.ty };\\n  }\\n\\n  onStart(e) {\\n    if (e.touches.length >= 2) {\\n      if (e.cancelable) e.preventDefault();\\n      this.tapStart = null;\\n      this.beginPinch(e.touches);\\n    } else if (e.touches.length === 1) {\\n      const t = e.touches[0];\\n      this.tapStart = { x: t.clientX, y: t.clientY, at: Date.now() };\\n      if (this.s > 1.001) this.beginPan(t);\\n    }\\n  }\\n\\n  onMove(e) {\\n    if (this.tapStart && e.touches[0]) {\\n      const t = e.touches[0];\\n      if (Math.abs(t.clientX - this.tapStart.x) > 10 || Math.abs(t.clientY - this.tapStart.y) > 10) {\\n        this.tapStart = null;\\n      }\\n    }\\n    if (this.mode === 'pinch' && e.touches.length >= 2) {\\n      if (e.cancelable) e.preventDefault();\\n      const m = this.mid(e.touches);\\n      const s = Math.max(0.5, Math.min(5, (this.startScale * this.dist(e.touches)) / this.startDist));\\n      // element origin in the viewport WITHOUT our translation = (origin - scroll), read live\\n      const r = this.element.getBoundingClientRect();\\n      const baseX = r.left - this.tx;\\n      const baseY = r.top - this.ty;\\n      this.apply(s, m.x - s * this.focal.x - baseX, m.y - s * this.focal.y - baseY);\\n    } else if (this.mode === 'pan' && e.touches.length === 1) {\\n      if (e.cancelable) e.preventDefault();\\n      const t = e.touches[0];\\n      this.apply(\\n        this.s,\\n        this.panStart.tx + (t.clientX - this.panStart.x),\\n        this.panStart.ty + (t.clientY - this.panStart.y)\\n      );\\n    }\\n  }\\n\\n  onEnd(e) {\\n    const left = e.touches ? e.touches.length : 0;\\n    if (this.mode === 'pinch') {\\n      if (left === 1 && this.s > 1.001) this.beginPan(e.touches[0]);\\n      else this.mode = left >= 2 ? 'pinch' : null;\\n      if (left >= 2) this.beginPinch(e.touches);\\n    } else if (left === 0) {\\n      this.mode = null;\\n    }\\n    if (left === 0) {\\n      if (this.s > 0.97 && this.s < 1.03) this.reset(false); // snap back to exactly 1\\n      this.syncTouchAction();\\n      // double tap -> reset\\n      if (this.tapStart && e.type === 'touchend') {\\n        const now = Date.now();\\n        if (now - this.lastTap < 320 && this.s !== 1) this.reset(true);\\n        this.lastTap = now;\\n      }\\n      this.tapStart = null;\\n    } else {\\n      this.syncTouchAction();\\n    }\\n  }\\n\\n  onDblClick() {\\n    if (this.s !== 1) this.reset(true);\\n  }\\n\\n  reset(animate) {\\n    const el = this.element;\\n    this.s = 1;\\n    this.tx = 0;\\n    this.ty = 0;\\n    this.mode = null;\\n    if (animate) {\\n      el.style.transition = 'transform 0.25s ease';\\n      setTimeout(() => {\\n        el.style.transition = '';\\n      }, 300);\\n    }\\n    el.style.transform = 'translate(0px, 0px) scale(1)';\\n    this.syncTouchAction();\\n  }\\n}\\n";

const zoomScript = \`
<script src="/zoom-handler.js"><\/script>
<script>try { new ZoomHandler(document.body); } catch (e) {}<\/script>\`;

const app = express();

// Capture raw body for /__proxy while still parsing JSON for /setup
app.use((req, res, next) => {
  if (req.path === '/__proxy' || req.path === '/_proxy') {
    const chunks = [];
    req.on('data', (c) => chunks.push(c));
    req.on('end', () => {
      req.rawBody = chunks.length ? Buffer.concat(chunks) : null;
      next();
    });
    return;
  }
  express.json({ limit: '2mb' })(req, res, next);
});

// Activity + security middleware
app.use((req, res, next) => {
  lastActivity = Date.now();
  if (ipWhitelist.length) {
    const ip = (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
    if (!ipWhitelist.includes(ip) && ip !== '127.0.0.1' && ip !== '::1') {
      return res.status(403).send('Forbidden');
    }
  }
  if (basicAuth && basicAuth.user && !req.path.startsWith('/__proxy')) {
    const hdr = req.headers.authorization || '';
    const ok = (() => {
      if (!hdr.startsWith('Basic ')) return false;
      try {
        const decoded = Buffer.from(hdr.slice(6), 'base64').toString('utf8');
        const i = decoded.indexOf(':');
        const u = decoded.slice(0, i);
        const p = decoded.slice(i + 1);
        return u === basicAuth.user && p === (basicAuth.pass || '');
      } catch (_) {
        return false;
      }
    })();
    if (!ok) {
      res.setHeader('WWW-Authenticate', 'Basic realm="Live Server"');
      return res.status(401).send('Unauthorized');
    }
  }
  Object.keys(customHeaders).forEach((k) => {
    try { res.setHeader(k, customHeaders[k]); } catch (_) {}
  });
  next();
});

// CORS
app.use((req, res, next) => {
  if (jsonData.enableCors !== false) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
  }
  next();
});

app.get('/check', (req, res) => {
  res.status(200).json({
    message: 'Ready',
    key: 'AcodeLiveServer_NodeJS',
    port: currentPort,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    proxy: true,
    proxyVersion: 6,
  });
});

app.get('/status', (req, res) => {
  res.json({
    port: currentPort,
    bind: bindHost,
    root: BASE_DIR,
    fileName: jsonData.fileName || null,
    liveReload: liveReloadEnabled,
    directoryListing,
    clients: connectedSockets.length,
    lastActivity,
    uptime: process.uptime(),
    proxy: true,
    proxyVersion: 3,
  });
});

app.post('/reload', (req, res) => {
  broadcastReload();
  res.json({ ok: true, clients: connectedSockets.length });
});

app.patch('/setup', (req, res) => {
  const data = req.body || {};
  if (!data.path) return res.status(400).json({ error: 'Missing path' });

  BASE_DIR = data.path;
  jsonData = data;
  erudaEnabled = data.eruda === true;
  if (data.consoleType) consoleType = data.consoleType;
  zoomEnabled = data.zoom === true;
  liveReloadEnabled = data.liveReload !== false;
  directoryListing = data.directoryListing !== false;

  if (typeof data.charset === 'string' && data.charset) charset = data.charset;
  customHeaders = {};
  if (data.customHeaders && typeof data.customHeaders === 'object') {
    customHeaders = data.customHeaders;
  } else if (typeof data.customHeaders === 'string') {
    String(data.customHeaders).split('\\n').forEach((line) => {
      const i = line.indexOf(':');
      if (i > 0) {
        const k = line.slice(0, i).trim();
        const v = line.slice(i + 1).trim();
        if (k) customHeaders[k] = v;
      }
    });
  }

  ipWhitelist = [];
  if (data.ipWhitelist) {
    const raw = Array.isArray(data.ipWhitelist)
      ? data.ipWhitelist
      : String(data.ipWhitelist).split(/[\\n,]+/);
    ipWhitelist = raw.map((s) => String(s).trim()).filter(Boolean);
  }

  if (data.basicAuthUser) {
    basicAuth = { user: String(data.basicAuthUser), pass: String(data.basicAuthPass || '') };
  } else {
    basicAuth = null;
  }

  if (liveReloadEnabled) startFileWatcher(res);
  else {
    if (fileWatcher) {
      try { fileWatcher.close(); } catch (_) {}
      fileWatcher = null;
    }
    res.status(201).json({ message: 'OK', liveReload: false });
  }
});

app.get('/__ls/bridge.js', (req, res) => {
  res.setHeader('Content-Type', 'application/javascript; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.send(LS_BRIDGE_JS);
});

// ============================================================================
// LOCAL REVERSE PROXY (/__proxy?url=...)
// ============================================================================

function buildProxyRuntimeScript(targetUrl) {
  let origin = '';
  try { origin = new URL(targetUrl).origin; } catch (_) {}
  return \`<script>
(function() {
  window.__LS_PROXY_TARGET__ = \${JSON.stringify(targetUrl)};
  window.__LS_PROXY_ORIGIN__ = \${JSON.stringify(origin)};
  var proxyBase = location.origin + '/__proxy?url=';

  function unwrapUrl(u) {
    var s = String(u || '');
    var idx = s.indexOf('/__proxy?url=');
    if (idx !== -1) {
      try {
        return decodeURIComponent(s.slice(idx + '/__proxy?url='.length).split('&')[0]);
      } catch (e) {}
    }
    return s;
  }

  function wrapUrl(raw) {
    if (!raw || typeof raw !== 'string') return raw;
    var s = raw.trim();
    if (!s || s.charAt(0) === '#' || s.indexOf('data:') === 0 || s.indexOf('blob:') === 0 || s.indexOf('javascript:') === 0 || s.indexOf('mailto:') === 0 || s.indexOf('tel:') === 0) {
      return raw;
    }
    if (s.indexOf('/__proxy?url=') !== -1 || s.indexOf('/__ls/') === 0 || s.indexOf('/dt/') === 0) {
      return raw;
    }
    try {
      var resolved = new URL(s, window.__LS_PROXY_TARGET__);
      if (resolved.protocol === 'http:' || resolved.protocol === 'https:') {
        return proxyBase + encodeURIComponent(resolved.href);
      }
    } catch (e) {}
    return raw;
  }

  // Prevent proxied Service Workers from hijacking 127.0.0.1
  try {
    if (navigator.serviceWorker) {
      navigator.serviceWorker.register = function() {
        return Promise.resolve({ scope: '/' });
      };
    }
  } catch (e) {}

  // Patch history.pushState / replaceState so SPAs don't throw cross-origin SecurityError
  try {
    var origPush = history.pushState;
    var origReplace = history.replaceState;
    history.pushState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origPush.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
    history.replaceState = function(state, title, url) {
      if (url != null) {
        var realTarget = unwrapUrl(String(url));
        try { realTarget = new URL(realTarget, window.__LS_PROXY_TARGET__).href; } catch (e) {}
        window.__LS_PROXY_TARGET__ = realTarget;
        url = proxyBase + encodeURIComponent(realTarget);
      }
      var r = origReplace.call(this, state, title, url);
      if (window.__lsPostMeta) setTimeout(window.__lsPostMeta, 0);
      return r;
    };
  } catch (e) {}

  // Patch fetch
  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function(input, init) {
      if (typeof input === 'string') {
        input = wrapUrl(input);
      } else if (input && typeof input.url === 'string') {
        try {
          input = new Request(wrapUrl(input.url), input);
        } catch (e) {}
      }
      return origFetch.call(this, input, init);
    };
  }

  // Patch XMLHttpRequest
  if (window.XMLHttpRequest) {
    var origOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function(method, url) {
      var args = Array.prototype.slice.call(arguments);
      if (typeof url === 'string') args[1] = wrapUrl(url);
      return origOpen.apply(this, args);
    };
  }

  // Patch dynamic DOM element URL setters (fixes dynamically injected CSS <link> and <script>)
  function patchProp(Proto, prop) {
    if (!Proto) return;
    var desc = Object.getOwnPropertyDescriptor(Proto, prop);
    if (!desc || !desc.set) return;
    Object.defineProperty(Proto, prop, {
      get: desc.get,
      set: function(val) {
        return desc.set.call(this, typeof val === 'string' ? wrapUrl(val) : val);
      },
      configurable: true
    });
  }
  try {
    patchProp(window.HTMLScriptElement && HTMLScriptElement.prototype, 'src');
    patchProp(window.HTMLLinkElement && HTMLLinkElement.prototype, 'href');
    patchProp(window.HTMLImageElement && HTMLImageElement.prototype, 'src');
    patchProp(window.HTMLIFrameElement && HTMLIFrameElement.prototype, 'src');
    var origSetAttr = Element.prototype.setAttribute;
    Element.prototype.setAttribute = function(name, val) {
      var lower = String(name || '').toLowerCase();
      if ((lower === 'src' || lower === 'href' || lower === 'action') && typeof val === 'string') {
        val = wrapUrl(val);
      }
      return origSetAttr.call(this, name, val);
    };
  } catch (e) {}

  // Intercept anchor clicks
  document.addEventListener('click', function(e) {
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (!a) return;
    var href = a.getAttribute('href');
    if (!href || href.charAt(0) === '#' || href.indexOf('javascript:') === 0 || href.indexOf('mailto:') === 0 || href.indexOf('tel:') === 0) return;
    e.preventDefault();
    location.href = wrapUrl(href);
  }, true);

  // Helper to submit forms cleanly without losing ?url= on GET forms (fixes Google Search 404)
  function submitProxiedForm(form) {
    var rawAction = form.getAttribute('action') || window.__LS_PROXY_TARGET__;
    var targetAction = unwrapUrl(rawAction);
    try {
      targetAction = new URL(targetAction, window.__LS_PROXY_TARGET__).href;
    } catch (err) {}

    var method = (form.getAttribute('method') || form.method || 'GET').toUpperCase();
    if (method === 'GET') {
      var u = new URL(targetAction);
      var fd = new FormData(form);
      fd.forEach(function(v, k) {
        if (k === '__ls_u') return;
        if (typeof v === 'string') u.searchParams.append(k, v);
      });
      location.href = proxyBase + encodeURIComponent(u.href);
      return true;
    } else {
      origSetAttr.call(form, 'action', proxyBase + encodeURIComponent(targetAction));
      return false;
    }
  }

  document.addEventListener('submit', function(e) {
    var form = e.target;
    if (!form || form.tagName !== 'FORM') return;
    if (submitProxiedForm(form)) {
      e.preventDefault();
    }
  }, true);

  // Also intercept programmatic form.submit() calls (used by Google Search)
  try {
    var origFormSubmit = HTMLFormElement.prototype.submit;
    HTMLFormElement.prototype.submit = function() {
      if (submitProxiedForm(this)) return;
      return origFormSubmit.apply(this, arguments);
    };
  } catch (e) {}

  window.open = function(url) {
    if (url) location.href = wrapUrl(url);
    return window;
  };
})();
<\/script>\`;
}

function rewriteCssForProxy(css, targetUrl) {
  let out = String(css || '');
  // Rewrite url(...)
  out = out.replace(/url\\(\\s*(["']?)([^"')]+)\\1\\s*\\)/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('data:') ||
      s.startsWith('#') ||
      s.startsWith('blob:') ||
      s.includes('/__proxy?url=')
    ) {
      return match;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return 'url(' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote + ')';
      }
    } catch (_) {}
    return match;
  });

  // Rewrite @import "..." or @import '...'
  out = out.replace(/@import\\s+(["'])([^"']+)\\1/gi, (match, quote, raw) => {
    const s = String(raw || '').trim();
    if (!s || s.includes('/__proxy?url=')) return match;
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '@import ' + quote + '/__proxy?url=' + encodeURIComponent(parsed.href) + quote;
      }
    } catch (_) {}
    return match;
  });

  return out;
}

function rewriteHtmlForProxy(html, targetUrl) {
  const toProxy = (raw) => {
    const s = String(raw || '').trim();
    if (
      !s ||
      s.startsWith('#') ||
      s.startsWith('data:') ||
      s.startsWith('blob:') ||
      s.startsWith('javascript:') ||
      s.startsWith('mailto:') ||
      s.startsWith('tel:') ||
      s.includes('/__proxy?url=')
    ) {
      return raw;
    }
    try {
      const parsed = new URL(s, targetUrl);
      if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
        return '/__proxy?url=' + encodeURIComponent(parsed.href);
      }
    } catch (_) {}
    return raw;
  };

  // Rewrite href, src, action, poster attributes
  let out = String(html || '').replace(
    /\\b(href|src|action|poster)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      return attr + '=' + quote + toProxy(val) + quote;
    }
  );

  // Rewrite srcset / imagesrcset
  out = out.replace(
    /\\b(srcset|imagesrcset)\\s*=\\s*(["'])([^"']+)\\2/gi,
    (match, attr, quote, val) => {
      const rewrittenList = val
        .split(',')
        .map((part) => {
          const trimmed = part.trim();
          if (!trimmed) return part;
          const spaceIdx = trimmed.search(/\\s/);
          if (spaceIdx === -1) return toProxy(trimmed);
          const u = trimmed.slice(0, spaceIdx);
          const descriptor = trimmed.slice(spaceIdx);
          return toProxy(u) + descriptor;
        })
        .join(', ');
      return attr + '=' + quote + rewrittenList + quote;
    }
  );

  // GET forms (Google search...): a native submit drops the ?url= of the action and the Referer
  // is often origin-only, so carry the real target inside the form as a hidden field.
  out = out.replace(/<form\\b[^>]*>/gi, (tag) => {
    if (/\\bmethod\\s*=\\s*["']?\\s*post/i.test(tag)) return tag;
    let target = targetUrl;
    const m = tag.match(/\\baction\\s*=\\s*(["'])([^"']*)\\1/i);
    if (m) {
      let a = m[2].replace(/&amp;/g, '&');
      const k = a.indexOf('/__proxy?url=');
      try {
        if (k !== -1) a = decodeURIComponent(a.slice(k + '/__proxy?url='.length).split('&')[0]);
        target = new URL(a || targetUrl, targetUrl).href;
      } catch (_) {}
    }
    let fixed = tag;
    if (!m) fixed = tag.replace(/^<form/i, '<form action="/__proxy?url=' + encodeURIComponent(target) + '"');
    const safe = String(target).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
    return fixed + '<input type="hidden" name="__ls_u" value="' + safe + '">';
  });

  // Rewrite inline <style> blocks
  out = out.replace(
    /(<style[^>]*>)([\\s\\S]*?)(<\\/style>)/gi,
    (match, openTag, cssBody, closeTag) => openTag + rewriteCssForProxy(cssBody, targetUrl) + closeTag
  );

  // Strip SRI integrity, CSP nonces, and CSP meta tags
  out = out.replace(/\\s+(?:integrity|nonce)\\s*=\\s*(["'])[^"']*\\1/gi, '');
  out = out.replace(/<meta[^>]+http-equiv\\s*=\\s*["']?Content-Security-Policy["']?[^>]*>/gi, '');

  // Rewrite meta refresh redirects
  out = out.replace(
    /(<meta[^>]+http-equiv\\s*=\\s*["']?refresh["']?[^>]+content\\s*=\\s*["'][^"']*?url=)([^"'>]+)(["'][^>]*>)/gi,
    (match, prefix, urlVal, suffix) => prefix + toProxy(urlVal.trim()) + suffix
  );

  const injectedHead = buildProxyRuntimeScript(targetUrl) + lsBridgeScript;

  if (/<head[^>]*>/i.test(out)) {
    out = out.replace(/<head[^>]*>/i, (m) => m + '\\n' + injectedHead);
  } else if (/<html[^>]*>/i.test(out)) {
    out = out.replace(/<html[^>]*>/i, (m) => m + '<head>' + injectedHead + '</head>');
  } else {
    out = injectedHead + '\\n' + out;
  }

  return out;
}

function decompressBuffer(buf, encoding) {
  const enc = String(encoding || '').toLowerCase();
  try {
    if (enc.includes('gzip')) return zlib.gunzipSync(buf);
    if (enc.includes('br') && typeof zlib.brotliDecompressSync === 'function') {
      return zlib.brotliDecompressSync(buf);
    }
    if (enc.includes('deflate')) return zlib.inflateSync(buf);
  } catch (_) {}
  return buf;
}

function fetchUpstream(targetUrl, method, reqHeaders, bodyBuf, redirectsLeft = 6) {
  return new Promise((resolve, reject) => {
    let parsed;
    try {
      parsed = new URL(targetUrl);
    } catch (e) {
      return reject(new Error('Invalid target URL'));
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      return reject(new Error('Only HTTP/HTTPS URLs are supported'));
    }

    const client = parsed.protocol === 'https:' ? https : http;
    const upperMethod = (method || 'GET').toUpperCase();
    const headers = {
      'User-Agent':
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
      'Accept':
        reqHeaders['accept'] ||
        'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
      'Accept-Language': reqHeaders['accept-language'] || 'en-US,en;q=0.9',
      'Accept-Encoding': 'gzip, deflate, br',
      'Referer': parsed.origin + '/',
    };
    if (upperMethod !== 'GET' && upperMethod !== 'HEAD') {
      headers['Origin'] = parsed.origin;
    }
    if (reqHeaders['content-type']) headers['Content-Type'] = reqHeaders['content-type'];
    if (reqHeaders['cookie']) headers['Cookie'] = reqHeaders['cookie'];
    if (bodyBuf && bodyBuf.length) headers['Content-Length'] = bodyBuf.length;

    const upstreamReq = client.request(
      {
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method: upperMethod,
        headers,
        timeout: 20000,
        rejectUnauthorized: false,
      },
      (upstreamRes) => {
        const status = upstreamRes.statusCode || 200;
        const loc = upstreamRes.headers['location'];
        if ([301, 302, 303, 307, 308].includes(status) && loc && redirectsLeft > 0) {
          upstreamRes.resume();
          const nextUrl = new URL(loc, parsed.href).href;
          const nextMethod =
            status === 303 || ((status === 301 || status === 302) && upperMethod === 'POST')
              ? 'GET'
              : upperMethod;
          return resolve(
            fetchUpstream(
              nextUrl,
              nextMethod,
              reqHeaders,
              nextMethod === 'GET' ? null : bodyBuf,
              redirectsLeft - 1
            )
          );
        }

        const chunks = [];
        upstreamRes.on('data', (c) => chunks.push(c));
        upstreamRes.on('end', () => {
          resolve({
            status,
            headers: upstreamRes.headers,
            body: Buffer.concat(chunks),
            finalUrl: parsed.href,
          });
        });
      }
    );

    upstreamReq.on('timeout', () => {
      upstreamReq.destroy(new Error('Upstream request timed out'));
    });
    upstreamReq.on('error', reject);
    if (bodyBuf && bodyBuf.length) upstreamReq.write(bodyBuf);
    upstreamReq.end();
  });
}

async function handleProxyRequest(req, res, targetUrl) {
  try {
    const bodyBuf = req.rawBody || null;
    const result = await fetchUpstream(targetUrl, req.method, req.headers, bodyBuf);

    const blockedHeaders = new Set([
      'x-frame-options',
      'content-security-policy',
      'content-security-policy-report-only',
      'cross-origin-opener-policy',
      'cross-origin-embedder-policy',
      'cross-origin-resource-policy',
      'content-length',
      'content-encoding',
      'transfer-encoding',
      'connection',
    ]);

    Object.entries(result.headers || {}).forEach(([k, v]) => {
      const lower = k.toLowerCase();
      if (blockedHeaders.has(lower)) return;
      if (lower === 'set-cookie' && Array.isArray(v)) {
        const cleanCookies = v.map((c) =>
          String(c)
            .replace(/;\\s*Domain=[^;]+/gi, '')
            .replace(/;\\s*Secure/gi, '')
            .replace(/SameSite=None/gi, 'SameSite=Lax')
        );
        res.setHeader('Set-Cookie', cleanCookies);
        return;
      }
      try {
        res.setHeader(k, v);
      } catch (_) {}
    });

    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-LS-Final-Url', result.finalUrl);

    const contentType = String(result.headers['content-type'] || '');
    const rawBuf = decompressBuffer(result.body, result.headers['content-encoding']);

    if (/text\\/html|application\\/xhtml\\+xml/i.test(contentType)) {
      const htmlText = rawBuf.toString('utf8');
      const rewritten = rewriteHtmlForProxy(htmlText, result.finalUrl);
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      return res.status(result.status).send(rewritten);
    }

    if (/text\\/css/i.test(contentType)) {
      const cssText = rawBuf.toString('utf8');
      const rewrittenCss = rewriteCssForProxy(cssText, result.finalUrl);
      res.setHeader('Content-Type', 'text/css; charset=utf-8');
      return res.status(result.status).send(rewrittenCss);
    }

    return res.status(result.status).send(rawBuf);
  } catch (err) {
    const safeUrl = String(targetUrl || '').replace(/</g, '<');
    const safeMsg = String((err && err.message) || err).replace(/</g, '<');
    res.status(502).setHeader('Content-Type', 'text/html; charset=utf-8').send(\`
      <!DOCTYPE html>
      <html>
      <head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
      <style>
        body { font-family: system-ui, sans-serif; background: #1e1e1e; color: #e8eaed; padding: 28px 18px; text-align: center; }
        .card { max-width: 420px; margin: 24px auto; padding: 20px; border-radius: 8px; background: #292a2d; border: 1px solid #3c4043; }
        h3 { margin: 0 0 8px; color: #f87171; }
        p { font-size: 13px; color: #9aa0a6; word-break: break-all; }
        button { margin-top: 12px; padding: 8px 16px; border: 0; border-radius: 5px; background: #22c55e; color: #052e16; font-weight: 600; cursor: pointer; }
      </style></head>
      <body>
        <div class="card">
          <h3>Proxy Could Not Load Page</h3>
          <p>\${safeMsg}</p>
          <p>\${safeUrl}</p>
          <button onclick="location.reload()">Retry</button>
        </div>
      </body></html>
    \`);
  }
}

app.all(['/__proxy', '/_proxy'], (req, res) => {
  if (req.query.url) {
    const target = String(req.query.url);
        return handleProxyRequest(req, res, target);
  }
  // GET form submitted natively: real target travels in the hidden __ls_u field
  if (req.query.__ls_u) {
    try {
      const u = new URL(String(req.query.__ls_u));
      Object.keys(req.query || {}).forEach((k) => {
        if (k === '__ls_u') return;
        const v = req.query[k];
        u.searchParams.delete(k);
        (Array.isArray(v) ? v : [v]).forEach((x) => {
          if (typeof x === 'string') u.searchParams.append(k, x);
        });
      });
      return handleProxyRequest(req, res, u.href);
    } catch (_) {}
  }
  // Fallback when a GET form (like Google Search) strips ?url= and submits ?q=... directly to /__proxy
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (idx !== -1) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const u = new URL('/search', baseTarget);
      Object.entries(req.query || {}).forEach(([k, v]) => {
        if (typeof v === 'string') u.searchParams.set(k, v);
      });
      return handleProxyRequest(req, res, u.href);
    } catch (_) {}
  }
  return res.status(400).send('Missing ?url=');
});

// Referer-based fallback for root-relative assets/APIs requested by proxied pages
app.use((req, res, next) => {
  const ref = req.headers.referer || '';
  const idx = ref.indexOf('/__proxy?url=');
  if (
    idx !== -1 &&
    !req.path.startsWith('/__ls/') &&
    !req.path.startsWith('/dt/') &&
    req.path !== '/__proxy' &&
    req.path !== '/_proxy'
  ) {
    try {
      const encodedBase = ref.slice(idx + '/__proxy?url='.length).split('&')[0];
      const baseTarget = decodeURIComponent(encodedBase);
      const resolved = new URL(req.originalUrl, baseTarget).href;
      return handleProxyRequest(req, res, resolved);
    } catch (_) {}
  }
  next();
});

// ============================================================================
// LOCAL STATIC LIVE SERVER
// ============================================================================

app.get('/dt/suger-dev.js', (req, res) => {
  const p = path.join(__dirname, 'suger-dev.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/zoom-handler.js', (req, res) => {
  res.type('application/javascript').set('Cache-Control', 'no-store').send(LS_ZOOM_JS);
});
app.get('/inspector.js', (req, res) => {
  const p = path.join(__dirname, 'inspector.js');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).end();
});
app.get('/eruda.min.js', (req, res) => {
  const erudaPath = path.join(__dirname, 'eruda.min.js');
  if (fs.existsSync(erudaPath)) res.sendFile(erudaPath);
  else res.status(404).send('Eruda not found');
});

function injectHtml(html) {
  let injected = html;
  if (liveReloadEnabled) {
    injected = injected.replace(/<\\/body>/i, webSocketScript + '</body>');
    if (!/<\\/body>/i.test(html)) injected = injected + webSocketScript;
  }
  if (erudaEnabled) {
    const extra =
      consoleType === 'eruda' ? erudaRealScript + '\\n' + inspectorScript : sugerScript + '\\n' + inspectorScript;
    injected = injected.replace(/<\\/body>/i, extra + '</body>');
  }
  if (zoomEnabled) {
    injected = injected.replace(/<\\/body>/i, zoomScript + '</body>');
  }
  if (/<\\/body>/i.test(injected)) injected = injected.replace(/<\\/body>/i, lsBridgeScript + '</body>');
  else injected += lsBridgeScript;
  return injected;
}

function sendHtmlFile(res, fullPath) {
  fs.readFile(fullPath, 'utf8', (err, html_content) => {
    if (err) return res.status(404).send('Not found');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(injectHtml(html_content));
  });
}


function safeJoinRoot(root, reqPath) {
  const base = path.resolve(String(root || '/'));
  let rel = decodeURIComponent(String(reqPath || ''));
  rel = rel.split('?')[0].split('#')[0];
  // CRITICAL: path.join(root, '/T.html') => '/T.html' on Node \u2014 strip leading slashes
  while (rel.charAt(0) === '/') rel = rel.slice(1);
  if (!rel || rel === '.') return base;
  const full = path.resolve(base, rel);
  const prefix = base.endsWith(path.sep) ? base : base + path.sep;
  if (full !== base && !full.startsWith(prefix)) return null;
  return full;
}

app.get('/', (req, res) => {
  if (!BASE_DIR) return res.status(400).send('Not configured. PATCH /setup first.');
  const fileName = String(jsonData.fileName || 'index.html').split('/').filter(Boolean).join('/');
  const fullPath = safeJoinRoot(BASE_DIR, fileName);
  if (fullPath && fs.existsSync(fullPath) && fs.statSync(fullPath).isFile()) {
    return sendHtmlFile(res, fullPath);
  }
  const indexPath = safeJoinRoot(BASE_DIR, 'index.html');
  if (indexPath && fs.existsSync(indexPath)) return sendHtmlFile(res, indexPath);
  if (directoryListing) return listDir(res, BASE_DIR, '/');
  return res.status(404).send('No index.html in ' + BASE_DIR + ' (wanted ' + fileName + ')');
});

function listDir(res, dirPath, urlPath) {
  fs.readdir(dirPath, { withFileTypes: true }, (err, entries) => {
    if (err) return res.status(500).send('Cannot list directory');
    const rows = entries
      .filter((e) => !e.name.startsWith('.'))
      .map((e) => {
        const href = path.posix.join(urlPath, e.name) + (e.isDirectory() ? '/' : '');
        return \`<li><a href="\${href}">\${e.name}\${e.isDirectory() ? '/' : ''}</a></li>\`;
      })
      .join('\\n');
    res.setHeader('Content-Type', 'text/html; charset=' + charset);
    res.send(
      \`<!DOCTYPE html><html><head><meta charset="\${charset}"/><title>Index of \${urlPath}</title></head><body><h1>Index of \${urlPath}</h1><ul>\${rows}</ul></body></html>\`
    );
  });
}

app.use((req, res, next) => {
  if (!BASE_DIR) return next();
  const rel = decodeURIComponent(req.path || '/');
  if (rel === '/' || rel === '') return next();
  const full = safeJoinRoot(BASE_DIR, rel);
  if (!full) return res.status(403).send('Forbidden path');
  fs.stat(full, (err, st) => {
    if (err) {
      return res.status(404).send('Cannot get ' + rel.replace(/^[/]+/, '') + ' (root ' + BASE_DIR + ')');
    }
    if (st.isDirectory()) {
      if (directoryListing) return listDir(res, full, rel.endsWith('/') ? rel : rel + '/');
      const idx = safeJoinRoot(full, 'index.html');
      if (idx && fs.existsSync(idx)) return sendHtmlFile(res, idx);
      return res.status(404).end();
    }
    if (/.html?$/i.test(full)) return sendHtmlFile(res, full);
    res.sendFile(full, (e) => {
      if (e) res.status(404).send('Cannot get ' + rel.replace(/^[/]+/, ''));
    });
  });
});

app.use(express.static(__dirname));

const server = http.createServer(app);
const wss = new WebSocketServer({ server });

wss.on('connection', (ws) => {
  connectedSockets.push(ws);
  lastActivity = Date.now();
  ws.on('close', () => {
    connectedSockets = connectedSockets.filter((s) => s !== ws);
  });
});

function broadcastReload() {
  for (const ws of connectedSockets) {
    try {
      ws.send('reload');
    } catch (_) {}
  }
}

function startFileWatcher(res) {
  if (fileWatcher) {
    try { fileWatcher.close(); } catch (_) {}
    fileWatcher = null;
  }
  if (!BASE_DIR || !liveReloadEnabled) {
    if (res) res.status(201).json({ message: 'OK' });
    return;
  }
  fileWatcher = chokidar.watch(BASE_DIR, {
    ignored: /(^|[\\/\\\\])\\.\\./,
    persistent: true,
    ignoreInitial: true,
  });
  fileWatcher.on('change', () => {
    lastActivity = Date.now();
    broadcastReload();
  });
  let responseSent = false;
  const done = (code, body) => {
    if (responseSent || !res) return;
    responseSent = true;
    res.status(code).json(body);
  };
  fileWatcher.on('ready', () => done(201, { message: 'OK', liveReload: true }));
  fileWatcher.on('error', (error) => {
    console.error('Watcher Error:', error.message);
    done(500, { error: error.message });
  });
  setTimeout(() => done(201, { message: 'OK', liveReload: true }), 3000);
}

async function main() {
  const ok = await isPortAvailable(currentPort);
  if (!ok) {
    console.error('[acodels] port busy', currentPort);
    process.exit(1);
  }
  server.listen(currentPort, bindHost, () => {
    console.log('[acodels] listening', bindHost + ':' + currentPort);
  });
}

main();
`,qo=un(Ji)});async function vn(e){let t=e||"/root/.acode_liveserver/acodels";try{let o=await ee("D="+Ce(t)+'; if [ ! -f "$D/index.js" ]; then echo NEED; exit 0; fi; if grep -q WebSocket "$D/index.js" 2>/dev/null && grep -q chokidar "$D/index.js" 2>/dev/null && grep -q ls-proxy-v10 "$D/index.js" 2>/dev/null; then echo FULL; else echo NEED; fi',{timeoutMs:8e3});if(String(o).includes("FULL")&&!String(o).includes("NEED"))return!1}catch(o){console.warn("[LiveServer] index check",(o==null?void 0:o.message)||o)}let r=qo,n=["#!/bin/sh","set -e","D="+t.replace(/'/g,""),'mkdir -p "$D"',"echo '"+r+`' | base64 -d > "$D/index.js"`,"echo RESTORED"].join(`
`);try{return await qt(n,{timeoutMs:0}),!0}catch(o){return console.warn("[LiveServer] restore failed",(o==null?void 0:o.message)||o),!1}}var Uo=T(()=>{ht();Fo()});function Xi(e){return/\.html?$/i.test(String(e||""))}function Ae(e){return!!(e&&Xi(e.filename||e.name))}function V(){try{return(editorManager==null?void 0:editorManager.activeFile)||null}catch{return null}}function bn(e){try{return decodeURIComponent(e)}catch{return e}}function No(e){let t=String(e||""),r=t.indexOf(":");if(r<0)return t.startsWith("/")?t:null;let n=t.slice(0,r),o=t.slice(r+1).replace(/^\/+/,""),s=o?"/"+o:"";return n==="primary"?"/sdcard"+s:n==="home"?"/sdcard/Documents"+s:/^[0-9A-F]{4}-[0-9A-F]{4}$/i.test(n)?"/storage/"+n+s:null}function He(e){if(!e||typeof e!="string")return null;let t=e;if(t.startsWith("content://")){if(t.includes("::")){let n=bn(t.split("::").pop());if(n.startsWith("/"))return n;let o=No(n);if(o)return o}let r=t.indexOf("/document/");if(r>=0){let n=bn(t.slice(r+10).split("?")[0]);if(n.startsWith("/"))return n;let o=No(n);if(o)return o}return null}if(t.startsWith("file://")&&(t=bn(t.replace(/^file:\/\//,""))),t.includes("/data/data/com.termux/files/home"))return t.includes("::")?t.split("::").pop():t;if(t.includes("::")){let r=t.split("::").pop();if(r&&r.startsWith("/"))return r}if(/\/(storage|sdcard|emulated)\//i.test(t)){let r=t.match(/(\/(?:storage|sdcard|emulated)\/[^?#]*)/i);if(r)return r[1]}return t.startsWith("/")?t:null}function Lr(e){if(!e)return null;let t=Math.max(e.lastIndexOf("/"),e.lastIndexOf("\\"));return t<=0?e:e.slice(0,t)}var Se=T(()=>{});var Ke={};xe(Ke,{browseRootFolder:()=>Wo,getEffectiveRoot:()=>Cr,getEffectiveRootUri:()=>ea,pickRootFolder:()=>ta,rootFromSelectedFolder:()=>ra});function Qi(e){let t=String(e||"").replace(/\/+$/,"")||"",r=t.match(/^\/storage\/emulated\/0(\/.*)?$/);return r||(r=t.match(/^\/storage\/self\/primary(\/.*)?$/),r)?"/sdcard"+(r[1]||""):t}function jo(e){return Qi(String(e||"").replace(/\/+$/,""))}function Cr(){let e=S(),t=V(),r=He((t==null?void 0:t.uri)||(t==null?void 0:t.url)||""),n=r?Lr(r):null,o=e.rootFolder&&String(e.rootFolder).trim()||"";if(o&&n){let s=jo(o),i=jo(n);return i===s||i.startsWith(s+"/")?o:(console.log("[LiveServer] root: active file outside saved root, using",n,"(saved was",o,")"),n)}return o||n}function ea(){let e=S(),t=V(),r=(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"",n=(()=>{let o=He(r);return o?Lr(o):null})();return e.rootFolderUri&&String(e.rootFolderUri).trim()&&!n?String(e.rootFolderUri).trim():r.includes("::")?r.split("::")[0]:n}async function Wo(){try{let e=acode.require("fileBrowser");if(!e)return qe("File browser not available",2e3),null;let t=await e("folder","Select Live Server root");if(!t)return null;let r=t.url||t.uri||t,n=He(typeof r=="string"?r:(r==null?void 0:r.url)||"")||String(r);R("rootFolder",n);try{R("rootFolderUri",typeof r=="string"?r:(r==null?void 0:r.url)||n)}catch{}return qe("Root: "+n,2500),n}catch(e){return qe(String((e==null?void 0:e.message)||e),2500),null}}async function ta(){try{let e=S().rootFolder||"",t=V(),r=Lr(He((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")||"")||"",n=[["browse","Browse with Acode file browser\u2026"],["active",r?`Use active file folder
${r}`:"Use active file folder"],["type","Type path\u2026"],["clear","Clear (auto from active HTML)"]];e&&n.splice(1,0,["keep",`Keep current
${e}`]);let o=await $i("Select root folder",n,{hideOnSelect:!0});if(!o||o==="keep")return e||null;if(o==="browse")return Wo();if(o==="active"){if(!r)return qe("Open an HTML file first",2e3),null;R("rootFolder",r);try{R("rootFolderUri",(t==null?void 0:t.uri)||(t==null?void 0:t.url)||"")}catch{}return qe("Root: "+r,2200),r}if(o==="clear"){R("rootFolder","");try{R("rootFolderUri","")}catch{}return qe("Root cleared \u2014 will use active file folder",2200),null}if(o==="type"){let s=await Ki("Absolute folder path",e||r||"/sdcard/","text");if(!s)return null;let i=String(s).trim();return R("rootFolder",i),qe("Root: "+i,2200),i}return null}catch(e){return qe(String((e==null?void 0:e.message)||e),2500),null}}function ra(){var e,t,r;try{let n=((e=window.fileBrowser)==null?void 0:e.selectedFolder)||((r=(t=window.addedFolder)==null?void 0:t[0])==null?void 0:r.url)||null;if(n)return He(n)||n}catch{}return null}var qe,$i,Ki,Fe=T(()=>{J();Se();qe=acode.require("toast"),$i=acode.require("select"),Ki=acode.require("prompt")});var Qe={};xe(Qe,{getServerStatus:()=>H,refreshStatusFromBackend:()=>yn,setServerStatus:()=>ie});function H(){return{...Ue}}function ie(e){Object.assign(Ue,e||{});try{window.dispatchEvent(new CustomEvent("liveserver-status",{detail:H()}))}catch{}}async function yn(){if(!Ue.port)return Ue;try{let e=await fetch(`http://127.0.0.1:${Ue.port}/status`);if(!e.ok)return ie({running:!1,lastError:"status "+e.status}),H();let t=await e.json();ie({running:!0,port:t.port||Ue.port,root:t.root||Ue.root,fileName:t.fileName||Ue.fileName})}catch{ie({running:!1})}return H()}var Ue,de=T(()=>{Ue={running:!1,port:null,root:null,url:null,fileName:null,bind:null,startedAt:null,lastError:null}});function Wt(){try{return acode.require("fsOperation")||window.fsOperation}catch{return window.fsOperation}}function ia(e){let t=5381,r=String(e||"");for(let n=0;n<r.length;n++)t=(t<<5)+t+r.charCodeAt(n)|0;return"p"+(t>>>0).toString(36)}function ke(e){return"'"+String(e).replace(/'/g,"'\\''")+"'"}function Pr(e){try{return decodeURIComponent(e)}catch{return e}}function xt(e){let t=e.lastIndexOf("/");return t<0?"":e.slice(0,t)}function aa(e){return e==null?null:e instanceof Uint8Array?e:e instanceof ArrayBuffer?new Uint8Array(e):ArrayBuffer.isView(e)?new Uint8Array(e.buffer,e.byteOffset,e.byteLength):typeof e=="string"?new TextEncoder().encode(e):typeof e=="object"&&typeof e.byteLength=="number"?new Uint8Array(e):null}function la(e){let t="";for(let n=0;n<e.length;n+=32768)t+=String.fromCharCode.apply(null,e.subarray(n,n+32768));return btoa(t)}function ca(e){let t=2166136261;for(let r=0;r<e.length;r++)t^=e[r],t=Math.imul(t,16777619);return(t>>>0).toString(36)+":"+e.length}async function es(e,t,r){let n=new Array(e.length),o=0,s=Array.from({length:Math.min(t,e.length)},async()=>{for(;o<e.length;){let i=o++;try{n[i]=await r(e[i],i)}catch{n[i]=void 0}}});return await Promise.all(s),n}function xn(e){let t=Yo.then(e,e);return Yo=t.catch(()=>{}),t}async function Zt(e){try{let t=await Wt()(e).stat();return t||null}catch{return null}}function Mr(e){return!!(e&&(e.isDirectory===!0||e.type==="dir"||e.type==="directory"))}function ts(e){if(!e)return null;let t=e.length!=null?e.length:e.size,r=e.lastModified!=null?e.lastModified:e.mtime!=null?e.mtime:e.modified;return t==null&&r==null?null:String(t)+"|"+String(r instanceof Date?r.getTime():r)}async function da(e){let t=await Wt()(e).readFile(),r=aa(t);if(!r)throw new Error("unreadable");return r}function Xo(e,t){let r=String(e||"").replace(/\/+$/,""),n=String(t||"").replace(/^\/+/,"");return n?r+"/"+n:r}function rs(e,t){let r=Xo(e,t),n=Xo(e,t.split("/").map(o=>encodeURIComponent(o)).join("/"));return r===n?[r]:[r,n]}async function ns(e,t,r){let n=e,o=t.split("/").filter(Boolean);for(let i=0;i<o.length;i++){let a=r.get(n);if(!a){try{a=await Wt()(n).lsDir()||[]}catch{return null}r.set(n,a)}let d=o[i],u=d.toLowerCase(),p=a.find(c=>(c.name||"")===d)||a.find(c=>Pr(c.name||"")===d)||a.find(c=>(c.name||"").toLowerCase()===u);if(!p||(n=p.url||p.uri||null,!n))return null}let s=await Zt(n);return!s||Mr(s)?null:{uri:n,st:s}}async function Ln(e,t){if(!E)return null;for(let r of rs(E.baseUri,e)){let n=await Zt(r);if(n&&!Mr(n))return{uri:r,st:n};if(n&&Mr(n))return null}return ns(E.baseUri,e,t)}function ua(e){let t=[],r=String(e||"").replace(/\/+$/,"");if(!r.startsWith("/"))return t;let n=r,o=r.match(/^\/sdcard(\/.*)?$/);o&&(n="/storage/emulated/0"+(o[1]||"")),o=r.match(/^\/storage\/self\/primary(\/.*)?$/),o&&(n="/storage/emulated/0"+(o[1]||""));let s=n.split("/").map(i=>encodeURIComponent(i)).join("/");return t.push("file://"+s,"file://"+n),n!==r&&t.push("file://"+r),t}function pa(e,t){let r=[t,encodeURI(t),t.split("/").map(encodeURIComponent).join("/")];for(let o of r)if(e.endsWith("/"+o))return e.slice(0,e.length-o.length-1);let n=encodeURIComponent(t);return e.endsWith("%2F"+n)?e.slice(0,e.length-n.length-3):null}function $o(e){let t=[e],r=e.match(/\/tree\/([^/:]+)$/);return r&&t.push(e+"::"+Pr(r[1])),t}function fa(e,t,r){let n=[],o=u=>{u&&!n.includes(u)&&n.push(u)},s=V(),i=(s==null?void 0:s.uri)||(s==null?void 0:s.url)||"",a=String(i).split("/").pop(),d=t.split("/").pop();if(i&&(Pr(a)===d||a===d)){let u=pa(i,t);u&&$o(u).forEach(o)}return r&&$o(String(r).replace(/\/+$/,"")).forEach(o),ua(e).forEach(o),String(e||"").startsWith("/")&&o(String(e).replace(/\/+$/,"")),n}async function ha(e,t,r){let n=new Map;for(let o of fa(e,t,r)){for(let i of rs(o,t)){let a=await Zt(i);if(a&&!Mr(a))return{base:o,uri:i,st:a}}let s=await ns(o,t,n);if(s)return{base:o,uri:s.uri,st:s.st}}return null}function ma(e){return/^([a-z][a-z0-9+.-]*:|\/\/|#)/i.test(String(e||"").trim())}function ga(e){let t=String(e||"").trim();return!t||ma(t)||(t=t.split("#")[0].split("?")[0],!t||t.endsWith("/"))?null:Pr(t)}function wn(e,t,r){let n=ga(t);if(!n)return null;let o=[];n.startsWith("/")?o=n.slice(1).split("/"):o=(r!=null?r:xt(e)).split("/").filter(Boolean).concat(n.split("/"));let s=[];for(let i of o)if(!(!i||i==="."))if(i===".."){if(!s.length)return null;s.pop()}else s.push(i);return s.length?s.join("/"):null}function Sn(e){let t=[],r=String(e||"").replace(/\/\*[\s\S]*?\*\//g,""),n,o=/url\(\s*(?:"([^"]*)"|'([^']*)'|([^'")\s][^)]*?))\s*\)/gi;for(;n=o.exec(r);)t.push(n[1]||n[2]||n[3]);let s=/@import\s+(?:"([^"]+)"|'([^']+)')/gi;for(;n=s.exec(r);)t.push(n[1]||n[2]);return t}function os(e){let t=[],r=String(e||"").replace(/\/\*[\s\S]*?\*\//g,"").replace(/(^|[^:\\])\/\/[^\n]*/g,"$1"),n,o=/(?:\bfrom|\bimport)\s*\(?\s*(?:"([^"]+)"|'([^']+)'|`([^`$]+)`)/g;for(;n=o.exec(r);)t.push(n[1]||n[2]||n[3]);let s=/importScripts\s*\(([^)]*)\)/g;for(;n=s.exec(r);){let u=/["'`]([^"'`]+)["'`]/g,p;for(;p=u.exec(n[1]);)t.push(p[1])}let i=/new\s+URL\(\s*(?:"([^"]+)"|'([^']+)')/g;for(;n=i.exec(r);)t.push(n[1]||n[2]);let a=new RegExp("[\"'`]((?:\\.{1,2}/|/)?[A-Za-z0-9_@%~+\\-./]+\\.(?:"+sa+"))(?:[?#][^\"'`]*)?[\"'`]","gi");for(;n=a.exec(r);)t.push(n[1]);let d=/["'`](\.{1,2}\/[^"'`\s]+)["'`]/g;for(;n=d.exec(r);)t.push(n[1]);return t}function ba(e){let t=[],r=String(e||"").replace(/<!--[\s\S]*?-->/g,""),n=/<([a-zA-Z][\w:-]*)\b([^>]*)>/g,o;for(;o=n.exec(r);){let d=o[1].toLowerCase(),u=o[2],p=/([A-Za-z_:][\w:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+))/g,c;for(;c=p.exec(u);){let g=c[1].toLowerCase(),h=c[2]!=null?c[2]:c[3]!=null?c[3]:c[4];if(g==="style"){Sn("x{"+h+"}").forEach(l=>t.push(l));continue}if(va.has(g)){if(g==="srcset"||g==="data-srcset"){String(h).split(",").forEach(l=>{let v=l.trim().split(/\s+/)[0];v&&t.push(v)});continue}if(g==="href"&&(d==="a"||d==="area")){/\.html?([?#].*)?$/i.test(h)&&t.push(h);continue}g!=="action"&&t.push(h)}}}let s=/<style\b[^>]*>([\s\S]*?)<\/style>/gi,i;for(;i=s.exec(r);)Sn(i[1]).forEach(d=>t.push(d));let a=/<script\b([^>]*)>([\s\S]*?)<\/script>/gi;for(;i=a.exec(r);)/\bsrc\s*=/.test(i[1])||/type\s*=\s*["']?(?:application\/(?:ld\+)?json|importmap)/i.test(i[1])&&!/importmap/i.test(i[1])||os(i[2]).forEach(d=>t.push(d));return t}function ya(e){return/\.html?$/i.test(e)?"html":/\.css$/i.test(e)?"css":/\.m?js$/i.test(e)?"js":"bin"}function wa(e,t,r,n){let o;try{o=new TextDecoder("utf-8").decode(r)}catch{return[]}let s=[];t==="html"?s=ba(o):t==="css"?s=Sn(o):t==="js"&&(s=os(o));let i=[],a=new Set;for(let d of s){let u=[],p=wn(e,d);if(p&&u.push(p),t==="js"){let c=wn(e,d,xt(n));c&&u.push(c);let g=wn(e,"/"+String(d).replace(/^\.{0,2}\/+/,""));g&&u.push(g)}u.forEach(c=>{a.has(c)||(a.add(c),i.push(c))})}return i}function et(e,t){return ee(e,{timeoutMs:t||2e4})}function xa(){var n,o,s;let e=[],t=i=>{if(!i)return;let a=String(i).replace(/\/+$/,"");e.includes(a)||e.push(a)};try{t((o=(n=window.cordova)==null?void 0:n.file)==null?void 0:o.dataDirectory)}catch{}let r=[];try{(s=window.BuildInfo)!=null&&s.packageName&&r.push(window.BuildInfo.packageName)}catch{}return r.push("com.foxdebug.acode","com.foxdebug.acodefree"),r.forEach(i=>{t("file:///data/user/0/"+i+"/files"),t("file:///data/data/"+i+"/files")}),e}async function Sa(){if(ue)return ue;let e=".probe_"+Math.random().toString(36).slice(2,8),t=await et("mkdir -p "+ke(Ar)+" && echo ok > "+ke(Ar+"/"+e)+" && echo PROBE_OK",2e4);if(!String(t||"").includes("PROBE_OK"))throw new Error("Alpine shell cannot write its cache dir (open the Acode terminal once)");let r=null;for(let n of xa()){for(let o of["/alpine/root","/alpine/home/root"]){let s=n+o+"/.acode_liveserver/cache";if(await Zt(s+"/"+e)){r=s;break}}if(r)break}return et("rm -f "+ke(Ar+"/"+e),8e3).catch(()=>{}),ue=r?{mode:"direct",androidCache:r,verified:!1}:{mode:"shell"},ue}async function ka(e){let t=[...new Set(e.filter(Boolean))];if(!t.length)return;let r="";for(let n of t){let o="mkdir -p "+ke(n)+"; ";r.length+o.length>4e4&&(await et(r,2e4),r=""),r+=o}r&&await et(r,2e4)}async function Ea(e){let t="",r=async()=>{t&&(await et(t,6e4),t="")};for(let n of e){let o=la(n.bytes);if(!o.length){let s=": > "+ke(n.dest)+"; ";t.length+s.length>46e3&&await r(),t+=s;continue}for(let s=0,i=!0;s<o.length;s+=Go,i=!1){let a=o.slice(s,s+Go),d="printf %s "+ke(a)+" | base64 -d "+(i?">":">>")+" "+ke(n.dest)+"; ";t.length+d.length>46e3&&await r(),t+=d}}await r()}async function La(e,t,r){let n=ue.androidCache+"/"+E.id+"/"+e;if(r)await Wt()(n).writeFile(t.buffer.slice(t.byteOffset,t.byteOffset+t.byteLength));else{let o=ue.androidCache+"/"+E.id+(xt(e)?"/"+xt(e):""),s=e.split("/").pop();await Wt()(o).createFile(s,t.buffer.slice(t.byteOffset,t.byteOffset+t.byteLength))}}async function Ca(e){let t=await et("wc -c < "+ke(E.aroot+"/"+e)+" 2>/dev/null || echo NONE",1e4),r=String(t||"").match(/(\d+)/);return r?parseInt(r[1],10):-1}async function Aa(e){if(e.length){if(await ka(e.map(t=>E.aroot+(xt(t.rel)?"/"+xt(t.rel):""))),ue.mode==="direct")try{for(let t of e)await La(t.rel,t.bytes,E.written.has(t.rel)),E.written.add(t.rel);if(!ue.verified){let t=e.find(n=>n.bytes.length>0)||e[0];if(await Ca(t.rel)!==t.bytes.length)throw new Error("direct write not visible in Alpine");ue.verified=!0}return}catch(t){console.warn("[LiveServer:mirror] direct write failed, using shell transport",(t==null?void 0:t.message)||t),ue={mode:"shell"}}await Ea(e.map(t=>({dest:E.aroot+"/"+t.rel,bytes:t.bytes}))),e.forEach(t=>E.written.add(t.rel))}}async function kn(e,t={}){let r=Vo[ue.mode]||Vo.shell,n=new Map,o=e.filter(a=>a),s=0,i=[];for(;o.length;){let a=await es(o,Qo,async c=>{let g=E.files.get(c),h=await Ln(c,n);if(!h)return E.missing.add(c),null;let l=ts(h.st),v=h.st.length!=null?h.st.length:h.st.size;if(v!=null&&v>r.file)return i.push(c+" ("+Math.round(v/1048576)+" MB)"),null;if(!t.force&&g&&l&&g.sig===l&&g.uri===h.uri)return{rel:c,unchanged:!0,known:g};let A=await da(h.uri),x=l||ca(A);return!t.force&&g&&g.sig===x&&E.written.has(c)?{rel:c,unchanged:!0,known:g}:{rel:c,src:h,bytes:A,sig:x}}),d=a.filter(c=>c&&!c.unchanged),u=new Set;for(let c of d){let g=E.files.get(c.rel),h=g&&g.size||0;E.total-h+c.bytes.length>r.total?(i.push(c.rel+" (total limit)"),c.skip=!0):!g&&E.files.size>=r.files&&(i.push(c.rel+" (file count limit)"),c.skip=!0)}let p=d.filter(c=>!c.skip).map(c=>({rel:c.rel,bytes:c.bytes}));await Aa(p);for(let c of d){if(c.skip)continue;let g=E.files.get(c.rel);E.total+=c.bytes.length-(g&&g.size||0);let h=ya(c.rel),l=oa.test(c.rel)?wa(c.rel,h,c.bytes,E.entryRel):[];E.files.set(c.rel,{uri:c.src.uri,sig:c.sig,size:c.bytes.length,deps:new Set(l)}),E.missing.delete(c.rel),s++,l.forEach(v=>{!E.files.has(v)&&!E.missing.has(v)&&u.add(v)})}a.forEach(c=>{c&&c.unchanged&&c.known&&c.known.deps.forEach(g=>{!E.files.has(g)&&!E.missing.has(g)&&u.add(g)})}),o=[...u]}return i.length&&(console.warn("[LiveServer:mirror] skipped",i.slice(0,6).join(", ")),na("Mirror skipped large file , Try from Acode Terminal Storage: "+i[0],3500)),s}function Ta(){clearTimeout(Jo),Jo=setTimeout(async()=>{try{if(S().liveReload===!1)return;let{getServerStatus:e}=await Promise.resolve().then(()=>(de(),Qe)),t=e();if(!t.running||!t.port)return;await fetch("http://127.0.0.1:"+t.port+"/reload",{method:"POST"}).catch(()=>{})}catch{}try{window.dispatchEvent(new CustomEvent("liveserver-mirror-updated"))}catch{}},120)}async function En(e={}){if(!E||!ue)return 0;let t=new Map,r=[...E.files.keys()],n=[];await es(r,Qo,async i=>{let a=E.files.get(i),d=await Zt(a.uri);if(!d){await Ln(i,t)&&n.push(i);return}let u=ts(d);(u==null||u!==a.sig)&&n.push(i)}),E.tick=(E.tick||0)+1;let o=[];(e.retryMissing||E.tick%5===0)&&(o=[...E.missing],E.missing.clear());let s=await kn([...n,...o],{force:!1});return s>0&&!e.silent&&Ta(),s}function Ko(){var t;Cn();let e=async()=>{if(E&&!Tr){Tr=!0;let r=Date.now();try{await xn(()=>En())}catch(o){console.warn("[LiveServer:mirror] poll",(o==null?void 0:o.message)||o)}Tr=!1;let n=Date.now()-r;jt=setTimeout(e,Math.max(Zo,n*1.5))}};if(jt=setTimeout(e,Zo),!wt){wt=()=>{E&&setTimeout(()=>xn(()=>En({retryMissing:!0})).catch(()=>{}),150)};try{(t=editorManager==null?void 0:editorManager.on)==null||t.call(editorManager,"save-file",wt)}catch{}}}function Cn(){jt&&(clearTimeout(jt),jt=null),Tr=!1}function Rr(){var e;Cn();try{wt&&((e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"save-file",wt))}catch{}wt=null}function Ma(e={}){return xn(async()=>{let t=String(e.sourceRoot||"").replace(/\/+$/,""),r=String(e.entryRel||"index.html").replace(/^\/+/,"");if(!t&&!e.sourceRootUri)throw new Error("No source root to mirror");let n=await Sa(),o=ia(t||String(e.sourceRootUri)),s=Ar+"/"+o;if(E&&E.id===o){if(E.entries.add(r),E.entryRel=r,!(E.files.has(r)?!0:!!await Ln(r,new Map)))throw new Error("Cannot read "+r+" from storage");return await En({silent:!0}),await kn([r]),Ko(),s}Cn();let i=await ha(t,r,e.sourceRootUri||S().rootFolderUri||"");if(!i)throw new Error("Acode cannot read "+r+" under "+(t||e.sourceRootUri));E={id:o,aroot:s,rootPath:t,baseUri:i.base,entryRel:r,entries:new Set([r]),files:new Map,written:new Set,missing:new Set,total:0},await et("rm -rf "+ke(s)+" && mkdir -p "+ke(s),2e4);let a=await kn([r]);if(!E.files.has(r)||a===0){let d="Could not copy "+r+" ("+(n.mode||"")+")";throw E=null,new Error(d)}try{R("lastMirrorRoot",s)}catch{}return Ko(),s})}async function Or(e,t,r){return Ma({sourceRoot:e,entryRel:t,sourceRootUri:r})}var na,Ar,Zo,Qo,Go,Vo,oa,sa,E,ue,jt,Tr,Yo,wt,Jo,va,ss=T(()=>{J();Se();ht();na=(...e)=>{try{acode.require("toast")(...e)}catch{}},Ar="/root/.acode_liveserver/cache",Zo=2e3,Qo=4,Go=44e3,Vo={direct:{files:800,file:96*1024*1024,total:400*1024*1024},shell:{files:400,file:8*1024*1024,total:40*1024*1024}},oa=/\.(html?|css|m?js)$/i,sa="js|mjs|json|css|html?|svg|png|jpe?g|gif|webp|avif|ico|bmp|woff2?|ttf|otf|eot|mp3|mp4|webm|ogg|wav|m4a|glb|gltf|wasm|txt|xml|csv|webmanifest|map",E=null,ue=null,jt=null,Tr=!1,Yo=Promise.resolve(),wt=null,Jo=null;va=new Set(["src","href","poster","data","data-src","data-href","data-background","data-bg","manifest","background","srcset","data-srcset"])});function St(){let e=parseInt(S().port,10);return Number.isFinite(e)&&e>0?e:8080}function Gt(e,t){return`http://${t==="0.0.0.0"?"127.0.0.1":t||"127.0.0.1"}:${e}/`}var is=T(()=>{J()});function as(){if(document.getElementById("ls-status-pill-css"))return;let e=document.createElement("style");e.id="ls-status-pill-css",e.textContent=`
    #ls-status-pill {
      position: fixed;
      left: 8px;
      bottom: 8px;
      z-index: 100001;
      max-width: min(82vw, 440px);
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 5px 10px;
      border-radius: 4px;
      background: var(--secondary-color, rgba(28, 30, 34, 0.94));
      color: var(--primary-text-color, var(--color, #e8eaed));
      border: 1px solid var(--border-color, rgba(255, 255, 255, 0.12));
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.45), 0 1px 3px rgba(0, 0, 0, 0.3);
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 11px;
      line-height: 1.3;
      pointer-events: none;
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 0.18s ease, transform 0.18s ease;
    }
    #ls-status-pill.is-visible {
      opacity: 0.96;
      transform: translateY(0);
    }
    .ls-sp-dot {
      width: 7px;
      height: 7px;
      min-width: 7px;
      border-radius: 50%;
      background: #22c55e;
      box-shadow: 0 0 6px rgba(34, 197, 94, 0.9);
    }
    .ls-sp-dot.is-spin {
      animation: ls-sp-pulse 0.9s ease-in-out infinite alternate;
    }
    @keyframes ls-sp-pulse {
      from { opacity: 0.4; transform: scale(0.85); }
      to { opacity: 1; transform: scale(1.15); }
    }
    .ls-sp-text {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* Global top green progress bar (shown when installing in background) */
    #ls-global-green-loader {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: 3px;
      z-index: 100002;
      overflow: hidden;
      pointer-events: none;
      display: none;
      background: rgba(34, 197, 94, 0.15);
    }
    #ls-global-green-loader.is-active {
      display: block;
    }
    #ls-global-green-loader::before {
      content: "";
      position: absolute;
      top: 0;
      bottom: 0;
      width: 35%;
      background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
      box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
      animation: ls-green-slide 1.15s ease-in-out infinite;
    }
    @keyframes ls-green-slide {
      0% { left: -35%; }
      100% { left: 100%; }
    }
  `,document.head.appendChild(e)}function Pa(){return as(),(!ce||!ce.isConnected)&&(ce=document.createElement("div"),ce.id="ls-status-pill",Et=document.createElement("span"),Et.className="ls-sp-dot",kt=document.createElement("span"),kt.className="ls-sp-text",ce.append(Et,kt),document.body.appendChild(ce)),ce}function Te(e,t={}){as();let r=!!e,o=!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")||t.force===!0;if(document.body.classList.toggle("ls-green-loading",r&&o),document.querySelectorAll(".ls-browser-shell").forEach(s=>{s.classList.toggle("is-installing",r)}),!o){pe&&pe.classList.remove("is-active");return}(!pe||!pe.isConnected)&&(pe=document.createElement("div"),pe.id="ls-global-green-loader",document.body.appendChild(pe)),pe.classList.toggle("is-active",r)}function Me(e,t={}){if(!!!document.querySelector("#ls-browser-shell.is-open, .ls-browser-shell.is-open")&&t.force!==!0){Yt(0);return}clearTimeout(Vt);let n=Pa();kt&&(kt.textContent=String(e||"")),Et&&Et.classList.toggle("is-spin",t.spin!==!1),requestAnimationFrame(()=>{n.classList.add("is-visible")}),t.autoHideMs&&t.autoHideMs>0&&(Vt=setTimeout(()=>{Yt(0)},t.autoHideMs))}function Yt(e=0){clearTimeout(Vt);let t=()=>{ce&&ce.classList.remove("is-visible")};e>0?Vt=setTimeout(t,e):t()}function ls(){clearTimeout(Vt),Te(!1);try{ce==null||ce.remove(),pe==null||pe.remove()}catch{}ce=null,kt=null,Et=null,pe=null}var ce,kt,Et,pe,Vt,_r=T(()=>{ce=null,kt=null,Et=null,pe=null,Vt=null});function O(e,t=18,r=2){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${r}" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var P,Jt=T(()=>{P={back:"M19 12H5M12 19l-7-7 7-7",forward:"M5 12h14M12 5l7 7-7 7",reload:"M21 2v6h-6M3 12a9 9 0 0115-6.7L21 8M3 22v-6h6M21 12a9 9 0 01-15 6.7L3 16",close:"M18 6L6 18M6 6l12 12",plus:"M12 5v14M5 12h14",home:"M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2zM9 22V12h6v10",star:"M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",lock:"M5 11h14a2 2 0 012 2v7a2 2 0 01-2 2H5a2 2 0 01-2-2v-7a2 2 0 012-2zM7 11V7a5 5 0 0110 0v4",info:"M12 2a10 10 0 100 20 10 10 0 000-20zM12 16v-4M12 8h.01",device:"M7 2h10a2 2 0 012 2v16a2 2 0 01-2 2H7a2 2 0 01-2-2V4a2 2 0 012-2zM12 18h.01",rotate:"M21 12a9 9 0 11-9-9c2.5 0 4.7 1 6.3 2.7L21 8M21 3v5h-5",dots:"M12 5h.01M12 12h.01M12 19h.01",maximize:"M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3",drop:"M12 2.69l5.66 5.66a8 8 0 11-11.31 0z",down:"M6 9l6 6 6-6",up:"M18 15l-6-6-6 6",search:"M11 3a8 8 0 100 16 8 8 0 000-16zM21 21l-4.35-4.35",globe:"M12 2a10 10 0 100 20 10 10 0 000-20zM2 12h20M12 2a15 15 0 010 20M12 2a15 15 0 000 20",minus:"M5 12h14"}});function Ra(e){let t=String(e||"").trim().match(/^#([0-9a-f]{3,8})$/i),r,n,o;if(t){let s=t[1];s.length===3&&(s=s.split("").map(i=>i+i).join("")),r=parseInt(s.slice(0,2),16),n=parseInt(s.slice(2,4),16),o=parseInt(s.slice(4,6),16)}else{if(t=String(e||"").match(/rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)/i),!t)return null;r=+t[1],n=+t[2],o=+t[3]}return(.299*r+.587*n+.114*o)/255}function cs(){try{let e=getComputedStyle(document.documentElement),t=e.getPropertyValue("--primary-color")||e.getPropertyValue("--secondary-color"),r=Ra(t);if(r!=null)return r>.6?"light":"dark"}catch{}return"dark"}var ds=T(()=>{});function us(){let e=document.getElementById("ls-browser-styles");e&&e.remove();let t=document.createElement("style");t.id="ls-browser-styles",t.textContent=An,document.head.appendChild(t)}var An,ps=T(()=>{An=`
:host { display: block; position: relative; height: 100%; width: 100%; }
.ls-browser-shell {
  --ls-frame: #202124; --ls-toolbar: #35363a; --ls-omni: #202124; --ls-text: #e8eaed; --ls-sub: #9aa0a6;
  --ls-hover: rgba(255,255,255,.10); --ls-press: rgba(255,255,255,.16); --ls-line: #3c4043; --ls-accent: #8ab4f8;
  --ls-menu: #292a2d; --ls-stage: #1b1c1e; --ls-active-tab-text: #e8eaed;
  position: absolute; inset: 0; z-index: 1;
  display: flex; flex-direction: column; box-sizing: border-box;
  background: var(--ls-frame); color: var(--ls-text);
  font: 13px/1.3 Roboto, "Noto Sans", "Segoe UI", system-ui, sans-serif;
}
.ls-browser-shell[data-theme="light"] {
  --ls-frame: #dee1e6; --ls-toolbar: #ffffff; --ls-omni: #f1f3f4; --ls-text: #202124; --ls-sub: #5f6368;
  --ls-hover: rgba(0,0,0,.08); --ls-press: rgba(0,0,0,.14); --ls-line: #dadce0; --ls-accent: #1a73e8;
  --ls-menu: #ffffff; --ls-stage: #e8eaed; --ls-active-tab-text: #202124;
}
.ls-browser-shell *, .ls-browser-shell *::before, .ls-browser-shell *::after { box-sizing: border-box; }
.ls-browser-shell button { font: inherit; color: inherit; }
.ls-browser-shell.is-fullscreen { position: fixed; inset: 0; z-index: 99990; }

/* ---- chrome (tab strip + toolbar) */
.ls-chrome { flex-shrink: 0; display: flex; flex-direction: column; background: var(--ls-frame); }
.ls-tabstrip { display: flex; align-items: flex-end; height: 38px; padding: 6px 6px 0 6px; gap: 2px; }
.ls-browser-tabs { display: flex; flex: 0 1 auto; min-width: 0; overflow: hidden; align-items: flex-end; }
.ls-tab {
  position: relative; display: flex; align-items: center; gap: 6px; flex: 0 1 200px; min-width: 36px; max-width: 220px;
  height: 32px; padding: 0 6px 0 10px; border-radius: 3px 3px 0 0; color: var(--ls-sub); cursor: default; user-select: none;
}
.ls-tab:hover { background: var(--ls-hover); }
.ls-tab.is-active { background: var(--ls-toolbar); color: var(--ls-active-tab-text); }
.ls-tab:not(.is-active)::after { content: ""; position: absolute; right: -1px; top: 8px; height: 16px; width: 1px; background: var(--ls-line); }
.ls-tab:hover::after, .ls-tab.is-active::after, .ls-tab:has(+ .ls-tab.is-active)::after { display: none; }
.ls-fav { width: 16px; height: 16px; flex: none; display: inline-flex; align-items: center; justify-content: center; }
.ls-fav img { width: 16px; height: 16px; }
.ls-fav.is-spin { border: 2px solid var(--ls-line); border-top-color: var(--ls-accent); border-radius: 50%; animation: ls-spin .8s linear infinite; }
.ls-tab-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.ls-tab-x { width: 18px; height: 18px; flex: none; display: inline-flex; align-items: center; justify-content: center; border-radius: 50%; }
.ls-tab-x:hover { background: var(--ls-press); }
.ls-tabstrip .ls-spacer { flex: 1; }
.ls-win { display: flex; align-items: center; align-self: center; gap: 2px; }
.ls-ib {
  width: 32px; height: 32px; flex: none; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub);
  display: inline-flex; align-items: center; justify-content: center; cursor: pointer;
}
.ls-ib:hover { background: var(--ls-hover); }
.ls-ib:active { background: var(--ls-press); }
.ls-ib:disabled { opacity: .4; pointer-events: none; }
.ls-ib.is-on { color: var(--ls-accent); }
.ls-ib.is-on svg { fill: var(--ls-accent); }
.ls-ib.ls-tab-new { width: 28px; height: 28px; margin-left: 2px; align-self: center; }
.ls-ib.ls-win-btn { width: 26px; height: 26px; }

.ls-toolbar { position: relative; display: flex; align-items: center; gap: 2px; height: 40px; padding: 0 6px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); }
/* ---- omnibox focus: nav buttons rise out one after another (each starts at 80% of the previous).
   The url bar growth is ONE continuous width animation of the whole nav group (not per button),
   so it glides instead of moving in steps. */
.ls-nav { display: flex; align-items: center; flex: none; height: 100%; overflow: hidden; width: 136px; transition: width 680ms cubic-bezier(.45, 0, .25, 1); }
.ls-toolbar.is-omni .ls-nav { width: 0; }
.ls-nav .ls-ib {
  --ls-d: 0ms; margin-right: 2px;
  transition:
    transform 200ms cubic-bezier(.3, 0, .2, 1) var(--ls-d),
    opacity 160ms ease var(--ls-d),
    background-color 120ms ease,
    visibility 0s linear var(--ls-d);
}
/* unfocus: reverse order - back comes down first, home last */
.ls-nav .ls-back { --ls-d: 0ms; }
.ls-nav .ls-fwd { --ls-d: 160ms; }
.ls-nav .ls-reload { --ls-d: 320ms; }
.ls-nav .ls-home { --ls-d: 480ms; }
.ls-toolbar.is-omni .ls-nav .ls-ib {
  transform: translateY(-140%); opacity: 0; pointer-events: none; visibility: hidden;
  transition:
    transform 200ms cubic-bezier(.3, 0, .2, 1) var(--ls-d),
    opacity 160ms ease var(--ls-d),
    visibility 0s linear calc(var(--ls-d) + 240ms);
}
/* focus: home rises first, then reload, forward, back */
.ls-toolbar.is-omni .ls-nav .ls-home { --ls-d: 0ms; }
.ls-toolbar.is-omni .ls-nav .ls-reload { --ls-d: 160ms; }
.ls-toolbar.is-omni .ls-nav .ls-fwd { --ls-d: 320ms; }
.ls-toolbar.is-omni .ls-nav .ls-back { --ls-d: 480ms; }
@media (prefers-reduced-motion: reduce) { .ls-nav, .ls-nav .ls-ib, .ls-toolbar.is-omni .ls-nav .ls-ib { transition: none; } }
.ls-omni { flex: 1; min-width: 0; height: 30px; margin: 0 6px; display: flex; align-items: center; gap: 2px; padding: 0 2px 0 4px; border-radius: 3px; background: var(--ls-omni); }
.ls-omni:focus-within { box-shadow: inset 0 0 0 2px var(--ls-accent); }
.ls-site { width: 24px; height: 24px; flex: none; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; padding: 0; }
.ls-site:hover { background: var(--ls-hover); }
.ls-browser-url { flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent; color: var(--ls-text); font: inherit; font-size: 14px; padding: 0 4px; }
.ls-browser-url::placeholder { color: var(--ls-sub); }
.ls-omni .ls-ib { width: 26px; height: 26px; }
.ls-browser-shell.no-url .ls-omni { visibility: hidden; }
.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }
@keyframes ls-bar { 0% { left: -30%; } 100% { left: 100%; } }
@keyframes ls-spin { to { transform: rotate(360deg); } }

/* ---- external site fallback banner */
.ls-ext-bar {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 5px 10px; background: var(--ls-menu); border-bottom: 1px solid var(--ls-line);
  font-size: 12px; color: var(--ls-sub);
}
.ls-ext-bar[hidden] { display: none; }
.ls-ext-open {
  border: 0; border-radius: 3px; padding: 4px 10px; background: #22c55e;
  color: #052e16; font-weight: 600; font-size: 11.5px; cursor: pointer; white-space: nowrap;
}

/* ---- device toolbar */
.ls-devbar { display: flex; align-items: center; gap: 6px; min-height: 34px; padding: 3px 8px; background: var(--ls-toolbar); border-bottom: 1px solid var(--ls-line); overflow-x: auto; scrollbar-width: none; }
.ls-devbar[hidden] { display: none; }
.ls-devbar::-webkit-scrollbar { height: 0; }
.ls-dev-btn { display: inline-flex; align-items: center; gap: 6px; height: 26px; padding: 0 8px; border: 1px solid var(--ls-line); border-radius: 3px; background: transparent; white-space: nowrap; cursor: pointer; }
.ls-dev-btn:hover { background: var(--ls-hover); }
.ls-dev-num { width: 58px; height: 26px; padding: 0 6px; border: 1px solid var(--ls-line); border-radius: 3px; background: var(--ls-omni); color: var(--ls-text); font: inherit; text-align: center; outline: 0; -moz-appearance: textfield; }
.ls-dev-num:focus { border-color: var(--ls-accent); }
.ls-dev-num::-webkit-outer-spin-button, .ls-dev-num::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }
.ls-dev-x { color: var(--ls-sub); }
.ls-dev-spacer { flex: 1; }
.ls-dev-icon { width: 26px; height: 26px; padding: 0; border: 0; border-radius: 50%; background: transparent; color: var(--ls-sub); display: inline-flex; align-items: center; justify-content: center; cursor: pointer; }
.ls-dev-icon:hover { background: var(--ls-hover); }

/* ---- stage (page area) */
.ls-stage { position: relative; flex: 1; min-height: 0; overflow: hidden; background: #fff; }
.ls-browser-shell.is-device .ls-stage { overflow: auto; display: flex; padding: 12px; background: var(--ls-stage); }
.ls-box { position: relative; width: 100%; height: 100%; }
.ls-browser-shell.is-device .ls-box { flex: none; margin: auto; background: #fff; box-shadow: 0 0 0 1px var(--ls-line), 0 2px 12px rgba(0,0,0,.35); }
.ls-device { position: relative; width: 100%; height: 100%; transform-origin: 0 0; }
.ls-browser-frame { position: absolute; inset: 0; width: 100%; height: 100%; border: 0; background: #fff; }
.ls-hdl { display: none; position: absolute; z-index: 3; background: transparent; touch-action: none; }
.ls-browser-shell.is-device .ls-hdl { display: block; }
.ls-hdl-r { top: 0; bottom: 0; right: -12px; width: 12px; cursor: ew-resize; }
.ls-hdl-b { left: 0; right: 0; bottom: -12px; height: 12px; cursor: ns-resize; }
.ls-hdl-c { right: -12px; bottom: -12px; width: 12px; height: 12px; cursor: nwse-resize; }
.ls-hdl::after { content: ""; position: absolute; background: var(--ls-sub); border-radius: 3px; opacity: .8; }
.ls-hdl-r::after { top: calc(50% - 14px); left: 4px; width: 4px; height: 28px; }
.ls-hdl-b::after { left: calc(50% - 14px); top: 4px; height: 4px; width: 28px; }
.ls-hdl-c::after { left: 4px; top: 4px; width: 4px; height: 4px; border-radius: 50%; }

/* ---- new tab page (Mozilla Firefox style: large Green Fox top-center + search bar + round bookmarks + recent) */
.ls-ntp {
  position: absolute; inset: 0; z-index: 2; display: none; flex-direction: column;
  align-items: center; justify-content: flex-start; gap: 20px; padding: 26px 16px 28px;
  overflow-y: auto; background: var(--ls-toolbar); color: var(--ls-text);
}
.ls-ntp.is-on { display: flex; }
.ls-ntp-hero {
  display: flex; flex-direction: column; align-items: center; justify-content: center;
  gap: 10px; margin-top: 6px;
}
.ls-ntp-logo {
  width: 92px; height: 92px; object-fit: contain; display: block;
  filter: drop-shadow(0 6px 16px rgba(34, 197, 94, 0.25));
}
.ls-ntp-title {
  font-size: 22px; font-weight: 600; letter-spacing: .3px;
}
.ls-ntp-search {
  width: min(480px, 95%); height: 44px; border-radius: 8px;
  background: var(--ls-omni); border: 1px solid var(--ls-line);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
  display: flex; align-items: center; gap: 8px; padding: 0 6px 0 12px; color: var(--ls-sub);
}
.ls-ntp-search:focus-within {
  border-color: #22c55e;
  box-shadow: 0 0 0 2px rgba(34, 197, 94, 0.28);
}
.ls-ntp-search-ico {
  display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.ls-ntp-search input {
  flex: 1; min-width: 0; height: 100%; border: 0; outline: 0; background: transparent;
  color: var(--ls-text); font: inherit; font-size: 14px;
}
.ls-ntp-search-btn {
  height: 32px; padding: 0 14px; border: 0; border-radius: 6px;
  background: #22c55e; color: #052e16; font-weight: 600; font-size: 12.5px;
  cursor: pointer; flex-shrink: 0;
}
.ls-ntp-search-btn:active { opacity: 0.85; }
.ls-ntp-tiles {
  display: flex; flex-wrap: wrap; gap: 12px; justify-content: center;
  width: min(480px, 100%);
}
.ls-ntp-tile {
  width: 78px; display: flex; flex-direction: column; align-items: center; gap: 6px;
  padding: 8px 4px; border: 0; border-radius: 6px; background: transparent; cursor: pointer;
}
.ls-ntp-tile:hover { background: var(--ls-hover); }
.ls-ntp-dot {
  width: 48px; height: 48px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); color: var(--ls-text);
  display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600;
  overflow: hidden; flex-shrink: 0;
}
.ls-ntp-dot img { width: 24px; height: 24px; border-radius: 50%; object-fit: contain; }
.ls-ntp-name {
  max-width: 74px; font-size: 11.5px; overflow: hidden; text-overflow: ellipsis;
  white-space: nowrap; color: var(--ls-text);
}
.ls-ntp-recent-wrap {
  width: min(480px, 100%); display: flex; flex-direction: column; gap: 6px;
  border-top: 1px solid var(--ls-line); padding-top: 12px;
}
.ls-ntp-sec-head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 4px 4px; font-size: 12px; font-weight: 600; color: var(--ls-sub);
}
.ls-ntp-more {
  border: 0; background: transparent; color: #22c55e; font-size: 12px;
  font-weight: 600; cursor: pointer; padding: 2px 6px; border-radius: 3px;
}
.ls-ntp-more:hover { background: var(--ls-hover); }
.ls-ntp-recent-list { display: flex; flex-direction: column; gap: 2px; }
.ls-ntp-recent-row {
  display: flex; align-items: center; gap: 10px; width: 100%; text-align: left;
  padding: 8px 8px; border: 0; border-radius: 4px; background: transparent; cursor: pointer;
}
.ls-ntp-recent-row:hover { background: var(--ls-hover); }
.ls-ntp-recent-ico {
  width: 28px; height: 28px; border-radius: 50%; background: var(--ls-omni);
  border: 1px solid var(--ls-line); display: inline-flex; align-items: center;
  justify-content: center; font-size: 12px; font-weight: 600; flex-shrink: 0;
}
.ls-ntp-recent-meta { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 1px; }
.ls-ntp-recent-title {
  font-size: 13px; color: var(--ls-text); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-recent-url {
  font-size: 11px; color: var(--ls-sub); overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.ls-ntp-empty { font-size: 12px; color: var(--ls-sub); padding: 8px 4px; }

/* ---- find bar */
.ls-find { position: absolute; top: 80px; right: 10px; z-index: 40; display: flex; align-items: center; gap: 2px; padding: 4px 6px; background: var(--ls-menu); border: 1px solid var(--ls-line); border-radius: 3px; box-shadow: 0 4px 14px rgba(0,0,0,.35); }
.ls-find[hidden] { display: none; }
.ls-find input { width: 150px; height: 26px; border: 0; border-bottom: 2px solid var(--ls-accent); background: transparent; color: var(--ls-text); outline: 0; font: inherit; padding: 0 4px; }
.ls-find .ls-ib { width: 26px; height: 26px; }

/* ---- overlay preview (page see-through, editor underneath stays usable) */
.ls-browser-shell.is-overlay { pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-tabstrip { display: none; }
.ls-ov-close { display: none !important; }
.ls-browser-shell.is-overlay .ls-ov-close { display: inline-flex !important; }
.ls-browser-shell.is-overlay .ls-chrome { pointer-events: auto; }
.ls-browser-shell.is-overlay .ls-stage { opacity: var(--ls-op, 1); pointer-events: none; background: transparent; }
.ls-browser-shell.is-overlay .ls-stage * { pointer-events: none; }
.ls-browser-shell.is-overlay .ls-dd-layer, .ls-browser-shell.is-overlay .ls-find { pointer-events: auto; }

/* ---- dropdown menu (desktop style) */
.ls-dd-layer { position: absolute; inset: 0; z-index: 60; }
.ls-dd-backdrop { position: absolute; inset: 0; background: transparent; }
.ls-dd-menu {
  position: absolute; min-width: 220px; max-width: calc(100% - 8px); padding: 6px 0;
  background: var(--ls-menu, #292a2d); color: var(--ls-text, #e8eaed);
  border: 1px solid var(--ls-line, #3c4043); border-radius: 3px;
  box-shadow: 0 4px 16px rgba(0,0,0,.4); font-size: 13px; overflow: auto;
}
.ls-dd-item { display: flex; align-items: center; gap: 8px; min-height: 32px; padding: 6px 14px 6px 8px; cursor: pointer; white-space: nowrap; user-select: none; }
.ls-dd-item:hover, .ls-dd-item.is-active { background: var(--ls-hover, rgba(128,128,128,.22)); }
.ls-dd-item.is-disabled { opacity: .45; pointer-events: none; }
.ls-dd-check { width: 14px; height: 14px; display: inline-flex; flex-shrink: 0; }
.ls-dd-label { flex: 1; }
.ls-dd-arrow { opacity: .7; display: inline-flex; }
.ls-dd-sep { height: 1px; margin: 6px 0; background: var(--ls-line, rgba(128,128,128,.3)); }
.ls-dd-custom { padding: 2px 8px 2px 22px; }
.ls-zoomrow { display: flex; align-items: center; gap: 4px; min-height: 32px; }
.ls-zoomrow .ls-zl { flex: 1; }
.ls-zoomrow .ls-zv { min-width: 44px; text-align: center; }
.ls-zoomrow .ls-ib { width: 26px; height: 26px; color: var(--ls-text); }

/* ---- opacity panel */
.ls-dd-panel { width: 250px; padding: 12px 14px; }
.ls-op-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px; }
.ls-op-val { color: var(--ls-accent); font-variant-numeric: tabular-nums; }
.ls-range { -webkit-appearance: none; appearance: none; width: 100%; height: 18px; margin: 0; background: transparent; outline: 0; }
.ls-range::-webkit-slider-runnable-track { height: 4px; border-radius: 3px; background: linear-gradient(to right, var(--ls-accent) var(--ls-fill, 100%), var(--ls-line) var(--ls-fill, 100%)); }
.ls-range::-webkit-slider-thumb { -webkit-appearance: none; width: 16px; height: 16px; margin-top: -6px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-range::-moz-range-track { height: 4px; border-radius: 3px; background: var(--ls-line); }
.ls-range::-moz-range-progress { height: 4px; border-radius: 3px; background: var(--ls-accent); }
.ls-range::-moz-range-thumb { width: 16px; height: 16px; border-radius: 50%; background: var(--ls-accent); border: 0; }
.ls-op-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-top: 12px; cursor: pointer; }
.ls-op-row.is-disabled { opacity: .45; pointer-events: none; }
.ls-op-hint { margin-top: 8px; font-size: 11px; color: var(--ls-sub); }
.ls-switch { position: relative; flex: none; width: 36px; height: 20px; }
.ls-switch::before { content: ""; position: absolute; inset: 0; border-radius: 3px; background: var(--ls-line); transition: background .15s; }
.ls-switch::after { content: ""; position: absolute; top: 3px; left: 3px; width: 14px; height: 14px; border-radius: 3px; background: var(--ls-text); transition: transform .15s; }
.ls-switch.is-on::before { background: var(--ls-accent); }
.ls-switch.is-on::after { transform: translateX(16px); background: #fff; }

 #ls-deps-picker{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center}
.ls-dp-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.45)}
.ls-dp-card{position:relative;width:min(420px,92vw);max-height:min(72vh,540px);display:flex;flex-direction:column;border-radius:3px;background:var(--secondary-color,#1e1e1e);color:var(--color,#e0e0e0);overflow:hidden;box-shadow:0 12px 40px rgba(0,0,0,.4)}
.ls-dp-header{padding:12px 14px 8px;border-bottom:1px solid rgba(128,128,128,.25)}
.ls-dp-title{font-weight:600}
.ls-dp-subtitle{font-size:.75rem;opacity:.75;margin-top:4px}
.ls-dp-body{flex:1;overflow:auto;padding:8px 12px}
.ls-dp-row{display:flex;align-items:center;gap:10px;padding:8px 6px;border-radius:3px;margin-bottom:4px;background:rgba(128,128,128,.08)}
.ls-dp-status.ok{color:#66bb6a}.ls-dp-status.miss{color:#f48771}
.ls-dp-footer{display:flex;gap:8px;justify-content:flex-end;padding:10px 12px;border-top:1px solid rgba(128,128,128,.25)}
.ls-dp-btn{border:none;border-radius:3px;padding:8px 12px;background:rgba(128,128,128,.2);color:inherit}
.ls-dp-btn.ls-dp-install{background:var(--active-color,#61afef);color:#111;font-weight:600}
.ls-dp-progress-track{height:3px;border-radius:3px;background:rgba(128,128,128,.25);overflow:hidden}
.ls-dp-progress-bar{height:100%;background:var(--active-color,#61afef);transition:width .25s}
.ls-dp-spinner{width:16px;height:16px;border-radius:50%;border:2px solid rgba(128,128,128,.35);border-top-color:var(--active-color,#61afef);animation:ls-spin .7s linear infinite}
@keyframes ls-spin{to{transform:rotate(360deg)}}



.ls-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 2px; overflow: hidden; display: none; }
.ls-browser-shell.is-loading .ls-progress { display: block; }
.ls-progress::before { content: ""; position: absolute; top: 0; bottom: 0; width: 30%; background: var(--ls-accent); animation: ls-bar 1.1s ease-in-out infinite; }

.ls-green-progress { position: absolute; left: 0; right: 0; bottom: -1px; height: 3px; overflow: hidden; display: none; background: rgba(34, 197, 94, 0.16); }
.ls-browser-shell.is-installing .ls-green-progress { display: block; }
.ls-green-progress::before {
  content: ""; position: absolute; top: 0; bottom: 0; width: 35%;
  background: linear-gradient(90deg, #16a34a, #4ade80, #22c55e);
  box-shadow: 0 0 8px rgba(34, 197, 94, 0.85);
  animation: ls-bar 1.1s ease-in-out infinite;
}
`});var fs,Br,hs,ms=T(()=>{fs="https://raw.githubusercontent.com/Sou6900/suger-devtool/main/dist/suger-dev.embed.min.js",Br="e3623347981cb6c84d061ac4b7479e7cf17da186bbfebd9c2dee07656a1af7a7",hs="github.com/Sou6900/suger-devtool"});function gs(){return new Promise((e,t)=>{try{let r=indexedDB.open(_a,1);r.onupgradeneeded=()=>r.result.createObjectStore(Lt),r.onsuccess=()=>e(r.result),r.onerror=()=>t(r.error)}catch(r){t(r)}})}async function Ba(){try{let e=await gs();return await new Promise(t=>{let r=e.transaction(Lt).objectStore(Lt).get(Br);r.onsuccess=()=>t(typeof r.result=="string"?r.result:null),r.onerror=()=>t(null)})}catch{return null}}async function Ia(e){try{let t=await gs();await new Promise(r=>{let n=t.transaction(Lt,"readwrite");n.objectStore(Lt).clear(),n.objectStore(Lt).put(e,Br),n.oncomplete=()=>r(),n.onerror=()=>r(),n.onabort=()=>r()})}catch{}}async function Da(e){let t=await crypto.subtle.digest("SHA-256",e);return Array.from(new Uint8Array(t)).map(r=>r.toString(16).padStart(2,"0")).join("")}async function za(){if(S().devtoolDownloadOk===!0)return!0;let e=!1;try{e=await acode.require("confirm")("Download Developer Tools?","Suger DevTool (2.7 MB) will be downloaded once from "+hs+", checked against a fixed SHA-256 and saved on this device. It runs only inside the page you are previewing and sends nothing anywhere.")}catch{}if(e)try{R("devtoolDownloadOk",!0)}catch{}return!!e}async function Ha(){Xt("Downloading Suger DevTool\u2026",2500);let e;try{e=await fetch(fs,{cache:"no-store"})}catch{return Xt("DevTool download failed: no internet connection",3500),null}if(!e.ok)return Xt("DevTool download failed (HTTP "+e.status+")",3500),null;let t=await e.arrayBuffer(),r=await Da(t);if(r!==Br)return console.warn("[LiveServer] DevTool hash mismatch",r),Xt("DevTool file does not match the pinned SHA-256. Not used. Update the plugin.",4500),null;let n=new TextDecoder("utf-8").decode(t);return await Ia(n),Xt("Developer tools ready",1800),n}async function vs(){return Ir||$t||($t=(async()=>{try{let e=await Ba();if(e&&e.length>1e3)return Ir=e;if(!await za())return null;let t=await Ha();return t?Ir=t:null}finally{$t=null}})(),$t)}var Xt,_a,Lt,Ir,$t,bs=T(()=>{ms();J();Xt=(...e)=>{try{acode.require("toast")(...e)}catch{}},_a="liveserver-devtool",Lt="engine",Ir=null,$t=null});var Dr,ys=T(()=>{Dr=class{constructor(t){this.element=t,this.element&&(this.s=1,this.tx=0,this.ty=0,this.mode=null,this.startDist=1,this.startScale=1,this.focal={x:0,y:0},this.panStart=null,this.lastTap=0,this.tapStart=null,this.onStart=this.onStart.bind(this),this.onMove=this.onMove.bind(this),this.onEnd=this.onEnd.bind(this),this.onDblClick=this.onDblClick.bind(this),this.element.style.transformOrigin="0 0",this.syncTouchAction(),this.element.addEventListener("touchstart",this.onStart,{passive:!1}),this.element.addEventListener("touchmove",this.onMove,{passive:!1}),this.element.addEventListener("touchend",this.onEnd),this.element.addEventListener("touchcancel",this.onEnd),this.element.addEventListener("dblclick",this.onDblClick))}destroy(){this.element&&(this.element.removeEventListener("touchstart",this.onStart),this.element.removeEventListener("touchmove",this.onMove),this.element.removeEventListener("touchend",this.onEnd),this.element.removeEventListener("touchcancel",this.onEnd),this.element.removeEventListener("dblclick",this.onDblClick),this.s=1,this.tx=0,this.ty=0,this.element.style.transform="",this.element.style.transformOrigin="",this.element.style.touchAction="")}syncTouchAction(){this.element.style.touchAction=this.s>1.001?"none":"auto"}apply(t,r,n){this.s=t,this.tx=r,this.ty=n,this.element.style.transform="translate("+r+"px, "+n+"px) scale("+t+")"}mid(t){return{x:(t[0].clientX+t[1].clientX)/2,y:(t[0].clientY+t[1].clientY)/2}}dist(t){let r=t[0].clientX-t[1].clientX,n=t[0].clientY-t[1].clientY;return Math.sqrt(r*r+n*n)||1}beginPinch(t){let r=this.element.getBoundingClientRect(),n=this.mid(t);this.mode="pinch",this.startDist=this.dist(t),this.startScale=this.s,this.focal={x:(n.x-r.left)/this.s,y:(n.y-r.top)/this.s}}beginPan(t){this.mode="pan",this.panStart={x:t.clientX,y:t.clientY,tx:this.tx,ty:this.ty}}onStart(t){if(t.touches.length>=2)t.cancelable&&t.preventDefault(),this.tapStart=null,this.beginPinch(t.touches);else if(t.touches.length===1){let r=t.touches[0];this.tapStart={x:r.clientX,y:r.clientY,at:Date.now()},this.s>1.001&&this.beginPan(r)}}onMove(t){if(this.tapStart&&t.touches[0]){let r=t.touches[0];(Math.abs(r.clientX-this.tapStart.x)>10||Math.abs(r.clientY-this.tapStart.y)>10)&&(this.tapStart=null)}if(this.mode==="pinch"&&t.touches.length>=2){t.cancelable&&t.preventDefault();let r=this.mid(t.touches),n=Math.max(.5,Math.min(5,this.startScale*this.dist(t.touches)/this.startDist)),o=this.element.getBoundingClientRect(),s=o.left-this.tx,i=o.top-this.ty;this.apply(n,r.x-n*this.focal.x-s,r.y-n*this.focal.y-i)}else if(this.mode==="pan"&&t.touches.length===1){t.cancelable&&t.preventDefault();let r=t.touches[0];this.apply(this.s,this.panStart.tx+(r.clientX-this.panStart.x),this.panStart.ty+(r.clientY-this.panStart.y))}}onEnd(t){let r=t.touches?t.touches.length:0;if(this.mode==="pinch"?(r===1&&this.s>1.001?this.beginPan(t.touches[0]):this.mode=r>=2?"pinch":null,r>=2&&this.beginPinch(t.touches)):r===0&&(this.mode=null),r===0){if(this.s>.97&&this.s<1.03&&this.reset(!1),this.syncTouchAction(),this.tapStart&&t.type==="touchend"){let n=Date.now();n-this.lastTap<320&&this.s!==1&&this.reset(!0),this.lastTap=n}this.tapStart=null}else this.syncTouchAction()}onDblClick(){this.s!==1&&this.reset(!0)}reset(t){let r=this.element;this.s=1,this.tx=0,this.ty=0,this.mode=null,t&&(r.style.transition="transform 0.25s ease",setTimeout(()=>{r.style.transition=""},300)),r.style.transform="translate(0px, 0px) scale(1)",this.syncTouchAction()}}});var Yn={};xe(Yn,{activateTab:()=>Pt,addSourceTab:()=>Vn,addTab:()=>Mt,applyPinchAll:()=>Fr,applyZoom:()=>In,canGoBack:()=>Rn,canGoForward:()=>On,clearVisited:()=>Pn,closeAllTabs:()=>Fn,closeTab:()=>Kt,disposeBridge:()=>Hn,duplicateActive:()=>qn,findInActive:()=>Nn,getActiveTab:()=>D,getTabs:()=>Ct,getVisited:()=>qr,historyActive:()=>Nr,initBridge:()=>zn,isLocalUrl:()=>rt,isPinchEnabled:()=>Ur,navigateActive:()=>We,normalizeUrl:()=>nt,onTabsChange:()=>_n,printActive:()=>jn,reloadActive:()=>Qt,renderTabStrip:()=>Gn,sendToTab:()=>Pe,setZoomActive:()=>Zn,stopActive:()=>Un,toDisplayUrl:()=>At,toggleDevtoolsActive:()=>Wn});function Ct(){return K.slice()}function D(){return K.find(e=>e.id===Ne)||null}function qr(){return tt.slice()}function Pn(){tt=[],te()}function Rn(){let e=D();return!!(e&&e.historyIndex>0)}function On(){let e=D();return!!(e&&e.historyIndex<e.history.length-1)}function _n(e){return zr.push(e),()=>{zr=zr.filter(t=>t!==e)}}function te(){zr.forEach(e=>{try{e(Ct(),D())}catch{}})}function Bn(e,t){let r=At(e);!r||r==="about:blank"||r.startsWith("blob:")||(tt=tt.filter(n=>n.url!==r),tt.unshift({url:r,title:t||r.replace(/^https?:\/\//i,""),ts:Date.now()}),tt.length>50&&(tt.length=50))}function rt(e){let t=At(e);return/^https?:\/\/(127\.0\.0\.1|localhost|0\.0\.0\.0|192\.168\.|10\.)/i.test(String(t||""))}function At(e){let t=String(e||"").trim();if(!t)return"about:blank";let r="/__proxy?url=",n=t.indexOf(r);if(n!==-1)try{let o=t.slice(n+r.length).split("&")[0];return decodeURIComponent(o)}catch{}return t}function nt(e){let t=At(e);if(!t||t==="about:blank")return"about:blank";if(/^(about:|blob:|data:|https?:\/\/)/i.test(t))return t;if(/^(localhost|127\.0\.0\.1|0\.0\.0\.0|\d{1,3}(\.\d{1,3}){3})(:\d+)?(\/.*)?$/i.test(t))return"http://"+t;if(!/\s/.test(t)&&/^[a-z0-9-]+(\.[a-z0-9-]+)+([/?#].*)?$/i.test(t))return"https://"+t;let r=S().browserSearchEngine||"google",n=encodeURIComponent(t);return r==="duckduckgo"?`https://duckduckgo.com/?q=${n}`:r==="bing"?`https://www.bing.com/search?q=${n}`:r==="brave"?`https://search.brave.com/search?q=${n}`:`https://www.google.com/search?q=${n}`}async function Ua(e,t={}){if(!e||e==="about:blank"||e.startsWith("blob:"))return e||"about:blank";if(rt(e))return e;if((S().externalSiteMode||"proxy")==="proxy"){let n=H(),o=n.running&&n.port?n.port:await Jn();if(o)return`http://127.0.0.1:${o}/__proxy?url=${encodeURIComponent(e)}`}return e}function je(){Tn&&(clearTimeout(Tn),Tn=null)}function ws(e,t,r){je()}function Pe(e,t,r){try{return e.iframe.contentWindow.postMessage({ls:1,cmd:t,...r||{}},"*"),!0}catch{return!1}}function Tt(e){var t;try{let r=(t=e.iframe)==null?void 0:t.contentWindow;return r.document,r}catch{return null}}function In(e){if(!e)return;let t=e.zoom||100,r=t/100;try{e.iframe&&(e.iframe.style.zoom=String(r),e.iframe.style.transformOrigin="0 0")}catch{}let n=Tt(e);if(n)try{n.document.documentElement.style.zoom=String(r)}catch{}Pe(e,"zoom",{pct:t})}function Na(e){return K.find(t=>{try{return t.iframe.contentWindow===e}catch{return!1}})}function Dn(e,t){!e||!t||e.history[e.historyIndex]===t||(e.history=e.history.slice(0,e.historyIndex+1),e.history.push(t),e.historyIndex=e.history.length-1)}function xs(e){let t=e.data;if(!t||t.ls!==1)return;let r=Na(e.source);if(r)if(r.bridge=!0,t.type==="meta"){if(je(),r.loading=!1,t.href&&t.href!=="about:blank"){let n=At(t.href);n!==r.url&&(r.url=n,Dn(r,n))}r.pinTitle||(r.title=String(t.title||r.url.replace(/^https?:\/\//,"")).slice(0,60)),t.favicon&&(r.favicon=t.favicon),(r.zoom||100)!==100&&Pe(r,"zoom",{pct:r.zoom}),Bn(r.url,r.title),te()}else t.type==="devtools"?(r.devtools=!!t.on,te()):t.type==="need-devtools"?vs().then(n=>{n&&Pe(r,"devtools",{on:!0,code:n})}):t.type==="devtools-error"&&qa("DevTool: "+t.message,3e3)}function Ss(e){var t,r;if(e!=null&&e.iframe)try{let n=S().enablePinchToZoom!==!1;n&&!e.zoomHandler?e.zoomHandler=new Dr(e.iframe):!n&&e.zoomHandler&&((r=(t=e.zoomHandler).destroy)==null||r.call(t),e.zoomHandler=null)}catch(n){console.warn("[LiveServer] ZoomHandler",n)}}function Fr(){K.forEach(Ss)}function Ur(){return S().enablePinchToZoom!==!1}function zn(){window.addEventListener("message",xs),window.addEventListener("liveserver-settings",ks)}function Hn(){je(),window.removeEventListener("message",xs),window.removeEventListener("liveserver-settings",ks)}function Mn(e,t){!String(t||"").includes("/__proxy?url=")&&(rt(t)||t==="about:blank"||t.startsWith("blob:"))?e.setAttribute("sandbox","allow-scripts allow-same-origin allow-forms allow-modals allow-popups allow-popups-to-escape-sandbox allow-downloads"):e.removeAttribute("sandbox")}async function Hr(e,t,r={}){je();let n=S().externalSiteMode||"proxy";e.useChromium=!1;let o=nt(t);if(r.pushHistory!==!1&&Dn(e,o),e.url=o,e.devtools=!1,e.useChromium=!1,o==="about:blank"){e.loading=!1,e.title="New tab",e.favicon=null,Mn(e.iframe,"about:blank"),e.iframe.src="about:blank",te();return}e.loading=!0,e.pinTitle||(e.title=o.replace(/^https?:\/\//i,"")),te(),ws(e,o,e.useChromium);let s=await Ua(o,{useChromium:e.useChromium});Mn(e.iframe,s),e.iframe.src=s,Bn(o,e.title),te()}function Mt(e,t,r){let n=Fa++,o=document.createElement("iframe");o.className="ls-browser-frame",o.setAttribute("allow","fullscreen; clipboard-read; clipboard-write");let s=t?nt(t):"about:blank",i={id:n,url:s,title:r||(s==="about:blank"?"New tab":s.replace(/^https?:\/\//i,"")),iframe:o,loading:s!=="about:blank",favicon:null,zoom:100,pinTitle:!!r,useChromium:!1,history:[s],historyIndex:0};return e.appendChild(o),Ss(i),K.push(i),K.forEach(a=>{a.iframe&&(a.iframe.style.display=a.id===n?"block":"none")}),Ne=n,o.addEventListener("load",()=>{je(),i.loading=!1,i.devtools=!1;let a=Tt(i);if(a)try{let u=a.__LS_PROXY_TARGET__||At(a.location.href);u&&u!=="about:blank"&&u!==i.url&&(i.url=u,Dn(i,u)),i.pinTitle||(a.document.title?i.title=a.document.title.slice(0,60):i.url!=="about:blank"&&(i.title=i.url.replace(/^https?:\/\//,"")));let p=a.document.querySelector('link[rel~="icon"]');p!=null&&p.href&&(i.favicon=p.href)}catch{}else!i.pinTitle&&i.url!=="about:blank"&&(i.title=i.url.replace(/^https?:\/\//,""));if(!i.favicon&&/^https?:/i.test(i.url))try{i.favicon=new URL("/favicon.ico",i.url).href}catch{}In(i),Bn(i.url,i.title),te()}),s==="about:blank"?(Mn(o,"about:blank"),o.src="about:blank",te()):Hr(i,s,{pushHistory:!1}),i}function qn(e){let t=D();return t?Mt(e,t.url,t.title):null}function Pt(e){K.some(t=>t.id===e)&&(Ne=e,K.forEach(t=>{t.iframe&&(t.iframe.style.display=t.id===e?"block":"none")}),te())}function Kt(e){var n;let t=K.findIndex(o=>o.id===e);if(t<0)return K.length;let[r]=K.splice(t,1);r.id===Ne&&je();try{(n=r.iframe)==null||n.remove()}catch{}if(Ne===e)if(K.length){let o=K[Math.min(t,K.length-1)];Pt(o.id)}else Ne=null,te();else te();return K.length}function Fn(){je(),K.forEach(e=>{var t;try{(t=e.iframe)==null||t.remove()}catch{}}),K=[],Ne=null,te()}function We(e,t={}){let r=D();r!=null&&r.iframe&&Hr(r,e,{pushHistory:!0,useChromium:!1})}function Qt(){let e=D();if(!(e!=null&&e.iframe))return;if(e.url==="about:blank"){te();return}e.loading=!0,ws(e,e.url,e.useChromium);let t=Tt(e),r=!1;if(t)try{t.location.reload(),r=!0}catch{}!r&&!(e.bridge&&Pe(e,"reload"))&&(e.iframe.src=e.iframe.src),te()}function Un(){je();let e=D();if(!(e!=null&&e.iframe))return;let t=Tt(e);if(t)try{t.stop()}catch{}else Pe(e,"stop");e.loading=!1,te()}function Nr(e){let t=D();if(t){if(e<0&&t.historyIndex>0){t.historyIndex-=1;let r=t.history[t.historyIndex];Hr(t,r,{pushHistory:!1});return}if(e>0&&t.historyIndex<t.history.length-1){t.historyIndex+=1;let r=t.history[t.historyIndex];Hr(t,r,{pushHistory:!1});return}}}function Nn(e,t){var o;let r=D();if(!r||!e)return;let n=Tt(r);if(n)try{(o=n.find)==null||o.call(n,e,!1,!!t,!0,!1,!1,!1);return}catch{}Pe(r,"find",{q:e,back:!!t})}function jn(){let e=D();if(!e)return!1;let t=Tt(e);if(t)try{return t.print(),!0}catch{}return Pe(e,"print")}function Wn(){let e=D();return!e||!e.bridge?!1:Pe(e,"devtools",{on:!e.devtools})}function Zn(e){let t=D();return t?(t.zoom=Math.min(500,Math.max(25,Math.round(e))),In(t),te(),t.zoom):100}function Gn(e){e&&(e.innerHTML="",K.forEach(t=>{let r=document.createElement("div");r.className="ls-tab"+(t.id===Ne?" is-active":"")+(t.loading?" is-loading":""),r.setAttribute("role","tab"),r.title=t.title||"";let n=document.createElement("span");if(n.className="ls-fav",t.loading)n.classList.add("is-spin");else if(t.favicon){let i=document.createElement("img");i.src=t.favicon,i.alt="",i.addEventListener("error",()=>{n.innerHTML=O(P.globe,14)}),n.appendChild(i)}else n.innerHTML=O(P.globe,14);r.appendChild(n);let o=document.createElement("span");o.className="ls-tab-label",o.textContent=t.title||"Tab",r.appendChild(o);let s=document.createElement("span");s.className="ls-tab-x",s.setAttribute("role","button"),s.title="Close tab",s.innerHTML=O(P.close,12),s.addEventListener("click",i=>{i.stopPropagation(),Kt(t.id)}),r.appendChild(s),r.addEventListener("click",()=>Pt(t.id)),e.appendChild(r)}))}function Vn(e,t,r){let n=Mt(e,"about:blank",t||"view-source");n.pinTitle=!0,n.loading=!1,n.url=t||"view-source";try{n.iframe.removeAttribute("sandbox")}catch{}try{n.iframe.srcdoc=r}catch{let s=new Blob([r],{type:"text/html;charset=utf-8"});n.iframe.src=URL.createObjectURL(s)}return n.loading=!1,te(),n}var qa,K,Ne,Fa,zr,tt,Tn,ks,jr=T(()=>{Jt();bs();J();Q();de();_r();ys();qa=acode.require("toast"),K=[],Ne=null,Fa=1,zr=[],tt=[],Tn=null;ks=e=>{var t;((t=e==null?void 0:e.detail)==null?void 0:t.key)==="enablePinchToZoom"&&Fr()}});function er(e,t=20){return`<svg xmlns="http://www.w3.org/2000/svg" width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="${e}"/></svg>`}var Xn=T(()=>{});function fe(e,t){let r=document.createElement(e);return t&&(r.className=t),r}function tr(){ge&&ge.close()}function Es(){return!!ge}function rr({host:e,anchor:t,items:r,onClose:n}){if(tr(),!e||!(r!=null&&r.length))return{close(){}};let o=fe("div","ls-dd-layer"),s=fe("div","ls-dd-backdrop");o.appendChild(s),e.appendChild(o);let i=[],a=!1;function d(l){for(;i.length>l;)i.pop().remove()}function u(){if(!a){a=!0,document.removeEventListener("keydown",p,!0);try{o.remove()}catch{}ge&&ge.close===u&&(ge=null);try{n==null||n()}catch{}}}function p(l){l.key==="Escape"&&(l.stopPropagation(),u())}function c(l,v,A){let x=e.getBoundingClientRect(),C=l.offsetWidth,_=l.offsetHeight,M,b;v===0?(b=A.bottom-x.top+2,M=A.right-x.left-C,M<4&&(M=A.left-x.left)):(b=A.top-x.top-4,M=A.right-x.left-2,M+C>x.width-4&&(M=A.left-x.left-C+2)),M+C>x.width-4&&(M=x.width-C-4),M<4&&(M=4);let B=x.height-b-4;_>B&&x.height&&(v>0&&x.height-_-4>0?b=x.height-_-4:l.style.maxHeight=Math.max(B,80)+"px"),b<4&&(b=4),l.style.left=M+"px",l.style.top=b+"px"}function g(l,v,A){d(v);let x=fe("div","ls-dd-menu");return x.setAttribute("role","menu"),x.style.visibility="hidden",l.forEach(C=>{if(C.separator){x.appendChild(fe("div","ls-dd-sep"));return}if(C.render){let z=fe("div","ls-dd-custom");C.render(z,u),x.appendChild(z);return}let _=fe("div","ls-dd-item"+(C.disabled?" is-disabled":""));_.setAttribute("role","menuitem");let M=fe("span","ls-dd-check");C.checked&&(M.innerHTML=er(ja,14)),_.appendChild(M);let b=fe("span","ls-dd-label");if(b.textContent=C.label,_.appendChild(b),C.children){let z=fe("span","ls-dd-arrow");z.innerHTML=er(Wa,14),_.appendChild(z)}let B=()=>{x.querySelectorAll(".ls-dd-item.is-active").forEach(z=>z.classList.remove("is-active")),_.classList.add("is-active"),g(C.children,v+1,_.getBoundingClientRect())},q=()=>{d(v+1),_.classList.remove("is-active")};_.addEventListener("pointerenter",z=>{z.pointerType&&z.pointerType!=="mouse"||(C.children?B():(d(v+1),x.querySelectorAll(".ls-dd-item.is-active").forEach(m=>m.classList.remove("is-active"))))}),_.addEventListener("click",z=>{var m;if(z.stopPropagation(),!C.disabled){if(C.children){_.classList.contains("is-active")&&i.length>v+1?q():B();return}u();try{(m=C.onClick)==null||m.call(C)}catch(y){console.warn("[LiveServer] menu item",y)}}}),x.appendChild(_)}),o.appendChild(x),i.push(x),c(x,v,A),x.style.visibility="",x}s.addEventListener("click",l=>{l.stopPropagation(),u()}),s.addEventListener("contextmenu",l=>{l.preventDefault(),u()}),document.addEventListener("keydown",p,!0);let h=t?t.getBoundingClientRect():e.getBoundingClientRect();return g(r,0,h),ge={close:u},{close:u}}function Ls({host:e,anchor:t,render:r,onClose:n}){if(tr(),!e)return{close(){}};let o=fe("div","ls-dd-layer"),s=fe("div","ls-dd-backdrop"),i=fe("div","ls-dd-menu ls-dd-panel");o.append(s,i),e.appendChild(o);let a=!1;function d(){if(!a){a=!0,document.removeEventListener("keydown",u,!0);try{o.remove()}catch{}ge&&ge.close===d&&(ge=null);try{n==null||n()}catch{}}}function u(l){l.key==="Escape"&&(l.stopPropagation(),d())}s.addEventListener("click",l=>{l.stopPropagation(),d()}),document.addEventListener("keydown",u,!0),r(i,d);let p=e.getBoundingClientRect(),c=t?t.getBoundingClientRect():p,g=i.offsetWidth,h=c.right-p.left-g;return h>p.width-g-4&&(h=p.width-g-4),h<4&&(h=4),i.style.left=h+"px",i.style.top=c.bottom-p.top+2+"px",ge={close:d},{close:d,panel:i}}var ja,Wa,ge,nr=T(()=>{Xn();ja="M20 6L9 17l-5-5",Wa="M9 18l6-6-6-6",ge=null});async function Za(e){var t;try{if((t=navigator.clipboard)!=null&&t.writeText)await navigator.clipboard.writeText(e);else{let r=document.createElement("textarea");r.value=e,document.body.appendChild(r),r.select(),document.execCommand("copy"),r.remove()}$n("URL copied",1500)}catch{$n(e||"No URL",2500)}}async function Ga(){let{getServerStatus:e}=await Promise.resolve().then(()=>(de(),Qe)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function Cs(e,t=38){return e=String(e||""),e.length>t?e.slice(0,t-1)+"\u2026":e}function Va(e){return{render(t){var u,p;let r=document.createElement("div");r.className="ls-zoomrow";let n=document.createElement("span");n.className="ls-zl",n.textContent="Zoom";let o=document.createElement("button");o.type="button",o.className="ls-ib",o.innerHTML=O(P.minus,14);let s=document.createElement("span");s.className="ls-zv",s.textContent=((p=(u=e.getZoom)==null?void 0:u.call(e))!=null?p:100)+"%";let i=document.createElement("button");i.type="button",i.className="ls-ib",i.innerHTML=O(P.plus,14);let a=document.createElement("button");a.type="button",a.className="ls-ib",a.title="Fullscreen",a.innerHTML=O(P.maximize,14);let d=c=>{var h;let g=(h=e.zoom)==null?void 0:h.call(e,c);g!=null&&(s.textContent=g+"%")};o.addEventListener("click",c=>{c.stopPropagation(),d(-10)}),i.addEventListener("click",c=>{c.stopPropagation(),d(10)}),s.style.cursor="pointer",s.addEventListener("click",c=>{var h;c.stopPropagation();let g=(h=e.zoom)==null?void 0:h.call(e,0,!0);g!=null&&(s.textContent=g+"%")}),a.addEventListener("click",c=>{var g;c.stopPropagation(),(g=e.toggleFullscreen)==null||g.call(e)}),r.append(n,o,s,i,a),t.appendChild(r)}}}function Kn(e,t){var i,a,d,u,p,c,g,h;let r=((i=e.getVisited)==null?void 0:i.call(e))||[],n=((a=e.getBookmarks)==null?void 0:a.call(e))||[],o=!!((d=e.isBookmarked)!=null&&d.call(e)),s=[{label:"New tab",onClick:()=>{var l;return(l=e.newTab)==null?void 0:l.call(e)}},{label:"Duplicate tab",onClick:()=>{var l;return(l=e.duplicateTab)==null?void 0:l.call(e)}},{separator:!0},{label:"History",children:r.length?[...r.slice(0,15).map(l=>({label:Cs(l.title||l.url),onClick:()=>{var v;return(v=e.navigate)==null?void 0:v.call(e,l.url)}})),{separator:!0},{label:"Clear history",onClick:()=>{var l;return(l=e.clearHistory)==null?void 0:l.call(e)}}]:[{label:"No history yet",disabled:!0}]},{label:"Bookmarks",children:[{label:o?"Remove bookmark for this tab":"Bookmark this tab",onClick:()=>{var l;return(l=e.toggleBookmark)==null?void 0:l.call(e)}},...n.length?[{separator:!0}]:[],...n.map(l=>({label:Cs(l.title||l.url),onClick:()=>{var v;return(v=e.navigate)==null?void 0:v.call(e,l.url)}}))]},{separator:!0},Va(e),{label:"Pinch to zoom",checked:!!((u=e.isPinch)!=null&&u.call(e)),onClick:()=>{var l;return(l=e.togglePinch)==null?void 0:l.call(e)}},{label:"Print\u2026",onClick:()=>{var l;return(l=e.print)==null?void 0:l.call(e)}},{label:"Find\u2026",onClick:()=>{var l;return(l=e.find)==null?void 0:l.call(e)}},{label:"Developer tools",checked:!!((p=e.isDevtools)!=null&&p.call(e)),onClick:()=>{var l;return(l=e.toggleDevtools)==null?void 0:l.call(e)}},{separator:!0},{label:"More tools",children:[{label:"Device mode (responsive)",checked:!!((c=e.isDeviceMode)!=null&&c.call(e)),onClick:()=>{var l;return(l=e.toggleDeviceMode)==null?void 0:l.call(e)}},{label:"View page source",onClick:()=>{var l;return(l=e.viewSource)==null?void 0:l.call(e)}},{separator:!0},{label:"Zoom in",onClick:()=>{var l;return(l=e.zoom)==null?void 0:l.call(e,10)}},{label:"Zoom out",onClick:()=>{var l;return(l=e.zoom)==null?void 0:l.call(e,-10)}},{label:"Reset zoom",onClick:()=>{var l;return(l=e.zoom)==null?void 0:l.call(e,0,!0)}},{separator:!0},{label:"Open server root",onClick:async()=>{var v;let l=await Ga();l?(v=e.navigate)==null||v.call(e,l):$n("Server not running",2e3)}},{label:"Copy current URL",onClick:()=>{var l;return Za(((l=e.getUrl)==null?void 0:l.call(e))||"")}},{label:"Open in external browser",onClick:()=>{var l;return(l=e.openExternal)==null?void 0:l.call(e)}},{separator:!0},{label:"Close other tabs",onClick:()=>{var l;return(l=e.closeOtherTabs)==null?void 0:l.call(e)}},{label:"Close current tab",onClick:()=>{var l;return(l=e.closeTab)==null?void 0:l.call(e)}}]},{label:"Opacity\u2026",onClick:()=>{var l;return(l=e.openOpacity)==null?void 0:l.call(e)}},{label:"Preview as overlay",checked:!!((g=e.isOverlay)!=null&&g.call(e)),disabled:!((h=e.canOverlay)!=null&&h.call(e)),onClick:()=>{var l;return(l=e.toggleOverlay)==null?void 0:l.call(e)}},{separator:!0},{label:"Settings",onClick:async()=>{let{openSettingsHub:l}=await Promise.resolve().then(()=>(or(),Wr));l()}},{label:"Exit",onClick:()=>{var l;return(l=e.closeBrowser)==null?void 0:l.call(e)}}];return rr({host:t.host,anchor:t.anchor,items:s})}var $n,As=T(()=>{nr();Jt();$n=acode.require("toast")});function ot(e){let t=parseFloat(e);return Number.isFinite(t)?Math.min(Qn,Math.max(Zr,Math.round(t*100)/100)):1}function Ts(e){return String(ot(e)).replace(/(\.\d)0$/,"$1")}function Ms(e,t,r){let n=document.createElement("div");n.className="ls-op-row"+(r?" is-disabled":"");let o=document.createElement("span");o.textContent=e;let s=document.createElement("span");return s.className="ls-switch"+(t?" is-on":""),n.append(o,s),{r:n,sw:s}}function Ps({host:e,anchor:t,get:r,set:n}){return Ls({host:e,anchor:t,render(o){let s=r(),i=document.createElement("div");i.className="ls-op-head";let a=document.createElement("span");a.textContent="Browser opacity";let d=document.createElement("span");d.className="ls-op-val",d.textContent=Ts(s.opacity),i.append(a,d);let u=document.createElement("input");u.type="range",u.className="ls-range",u.min=String(Zr),u.max=String(Qn),u.step="0.05",u.value=String(ot(s.opacity));let p=()=>{let l=(u.value-Zr)/(Qn-Zr)*100;u.style.setProperty("--ls-fill",l+"%")};p(),u.addEventListener("input",()=>{p(),d.textContent=Ts(u.value),n({opacity:ot(u.value)})});let c=Ms("Preview as overlay",s.overlay,!s.canOverlay),g=Ms("Auto-save while typing",s.autoSave,!1);g.r.style.display=s.overlay?"":"none",c.r.addEventListener("click",()=>{let l=!c.sw.classList.contains("is-on");c.sw.classList.toggle("is-on",l),g.r.style.display=l?"":"none",n({overlay:l})}),g.r.addEventListener("click",()=>{let l=!g.sw.classList.contains("is-on");g.sw.classList.toggle("is-on",l),n({autoSave:l})});let h=document.createElement("div");h.className="ls-op-hint",h.textContent=s.canOverlay?"Overlay: the preview is see-through and you can keep editing underneath.":"Overlay needs the Acode page display mode.",o.append(i,u,c.r,g.r,h)}})}var Zr,Qn,Rs=T(()=>{nr();Zr=.1,Qn=1});function Vr(e){return Gr.find(t=>t.id===e)||Gr[0]}function Re(e){let t=Math.round(Number(e));return Number.isFinite(t)?Math.min(Ya,Math.max(to,t)):null}function Os(e,t,r,n,o){return e!=="fit"?Math.max(.1,Number(e)/100):!n||!o?1:Math.min(1,n/t,o/r)}var Gr,eo,to,Ya,_s=T(()=>{Gr=[{id:"responsive",name:"Responsive",w:390,h:844},{id:"iphone-se",name:"iPhone SE",w:375,h:667},{id:"iphone-xr",name:"iPhone XR",w:414,h:896},{id:"iphone-12-pro",name:"iPhone 12 Pro",w:390,h:844},{id:"iphone-14-pro-max",name:"iPhone 14 Pro Max",w:430,h:932},{id:"pixel-7",name:"Pixel 7",w:412,h:915},{id:"galaxy-s8-plus",name:"Samsung Galaxy S8+",w:360,h:740},{id:"galaxy-s20-ultra",name:"Samsung Galaxy S20 Ultra",w:412,h:915},{id:"galaxy-fold",name:"Galaxy Fold",w:280,h:653},{id:"surface-duo",name:"Surface Duo",w:540,h:720},{id:"ipad-mini",name:"iPad Mini",w:768,h:1024},{id:"ipad-air",name:"iPad Air",w:820,h:1180},{id:"ipad-pro",name:"iPad Pro",w:1024,h:1366},{id:"surface-pro-7",name:"Surface Pro 7",w:912,h:1368},{id:"nest-hub",name:"Nest Hub",w:1024,h:600},{id:"nest-hub-max",name:"Nest Hub Max",w:1280,h:800},{id:"laptop",name:"Laptop 1366",w:1366,h:768},{id:"desktop",name:"Desktop 1920",w:1920,h:1080}],eo=["fit",25,50,75,100,125,150,200];to=50,Ya=9999});function Oe(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.innerHTML=r),n}function Bs({shell:e,stage:t,box:r,device:n,bar:o,onChange:s}){let i={on:!1,id:"responsive",w:390,h:844,zoom:"fit"},a=1,d=null,u=Oe("button","ls-dev-btn ls-dev-device");u.type="button";let p=Oe("input","ls-dev-num"),c=Oe("input","ls-dev-num");[p,c].forEach(m=>{m.type="number",m.min=String(to),m.inputMode="numeric"});let g=Oe("span","ls-dev-x","&times;"),h=Oe("button","ls-dev-btn ls-dev-zoom");h.type="button";let l=Oe("button","ls-dev-icon",O(P.rotate,16));l.type="button",l.title="Rotate";let v=Oe("button","ls-dev-icon",O(P.close,16));v.type="button",v.title="Close device mode";let A=Oe("span","ls-dev-spacer");o.append(u,p,g,c,h,l,A,v);function x(){try{s==null||s({...i})}catch{}}function C(){return i.zoom==="fit"?"Fit to window ("+Math.round(a*100)+"%)":i.zoom+"%"}function _(){u.innerHTML="<span>"+Vr(i.id).name+"</span>"+O(P.down,12),document.activeElement!==p&&(p.value=String(i.w)),document.activeElement!==c&&(c.value=String(i.h)),h.innerHTML="<span>"+C()+"</span>"+O(P.down,12)}function M(){if(e.classList.toggle("is-device",i.on),o.hidden=!i.on,!i.on){r.style.width="",r.style.height="",n.style.width="",n.style.height="",n.style.transform="";return}let m=t.clientWidth-24,y=t.clientHeight-24;a=Os(i.zoom,i.w,i.h,m,y),r.style.width=Math.round(i.w*a)+"px",r.style.height=Math.round(i.h*a)+"px",n.style.width=i.w+"px",n.style.height=i.h+"px",n.style.transform="scale("+a+")",_()}function b(m,y,oe){let ye=Re(m),Je=Re(y);ye!=null&&(i.w=ye),Je!=null&&(i.h=Je),oe||(i.id="responsive"),M(),x()}function B(m){let y=Vr(m);i.id=y.id,i.w=y.w,i.h=y.h,M(),x()}u.addEventListener("click",()=>{rr({host:e,anchor:u,items:Gr.map(m=>({label:m.id==="responsive"?m.name:m.name+"  "+m.w+" x "+m.h,checked:m.id===i.id,onClick:()=>B(m.id)}))})}),h.addEventListener("click",()=>{rr({host:e,anchor:h,items:eo.map(m=>({label:m==="fit"?"Fit to window":m+"%",checked:m===i.zoom,onClick:()=>{i.zoom=m,M(),x()}}))})}),l.addEventListener("click",()=>b(i.h,i.w,!0)),v.addEventListener("click",()=>z.toggle(!1));let q=()=>b(p.value,c.value);[p,c].forEach(m=>{m.addEventListener("change",q),m.addEventListener("keydown",y=>{y.key==="Enter"&&(q(),m.blur())})}),["r","b","c"].forEach(m=>{let y=Oe("div","ls-hdl ls-hdl-"+m);r.appendChild(y),y.addEventListener("pointerdown",oe=>{oe.preventDefault(),oe.stopPropagation();let ye=oe.clientX,Je=oe.clientY,Bt=i.w,gr=i.h;try{y.setPointerCapture(oe.pointerId)}catch{}n.style.pointerEvents="none";let Le=ut=>{var U,Y;let It=a||1,f=m==="b"?Bt:Bt+(ut.clientX-ye)/It,w=m==="r"?gr:gr+(ut.clientY-Je)/It;i.id="responsive",i.w=(U=Re(f))!=null?U:i.w,i.h=(Y=Re(w))!=null?Y:i.h,M()},Xe=()=>{y.removeEventListener("pointermove",Le),y.removeEventListener("pointerup",Xe),y.removeEventListener("pointercancel",Xe),n.style.pointerEvents="",x()};y.addEventListener("pointermove",Le),y.addEventListener("pointerup",Xe),y.addEventListener("pointercancel",Xe)})}),typeof ResizeObserver=="function"&&(d=new ResizeObserver(()=>{i.on&&i.zoom==="fit"&&M()}),d.observe(t));let z={getState:()=>({...i}),getScale:()=>a,isOn:()=>i.on,setState(m){m&&(typeof m.id=="string"&&(i.id=Vr(m.id).id),Re(m.w)!=null&&(i.w=Re(m.w)),Re(m.h)!=null&&(i.h=Re(m.h)),m.zoom!=null&&(i.zoom=eo.includes(m.zoom)?m.zoom:"fit"),i.on=!!m.on,M())},toggle(m){return i.on=m==null?!i.on:!!m,M(),x(),i.on},layout:M,destroy(){try{d==null||d.disconnect()}catch{}}};return _(),z}var Is=T(()=>{Jt();nr();_s()});function sr(e,t){if(!e)return;let r=t==null?!e.classList.contains("is-fullscreen"):!!t;return e.classList.toggle("is-fullscreen",r),document.body.classList.toggle("ls-browser-fs",r),r}function Ds(e){return sr(e,!1)}var zs=T(()=>{});function Hs(e,t={}){var _,M;let r=acode.require("page"),n=acode.require("actionStack"),o="liveserver-browser-page-"+ ++Ja,s=document.createElement("span");s.className="icon arrow_back",s.dataset.action="back",s.style.cssText="pointer-events:auto;cursor:pointer;";let i=r(t.title||"Live Preview",{lead:s}),a=i.body||i,d=i.header||((_=i.querySelector)==null?void 0:_.call(i,"header"));d&&(d.style.display="none"),Object.assign(a.style,{position:"absolute",inset:"0",top:"0",left:"0",right:"0",bottom:"0",width:"auto",height:"auto",padding:"0",margin:"0",overflow:"hidden"}),e.classList.add("is-in-page"),typeof i.appendBody=="function"?i.appendBody(e):a.appendChild(e);let u=!1,p=null,c=()=>{var B;let b=!1;try{b=!!((B=t.onBack)!=null&&B.call(t))}catch{}if(b){try{n.remove(o),n.push({id:o,action:c})}catch{}return}h()};function g(){try{n.remove(o),n.push({id:o,action:c})}catch{}}function h(){if(!u){try{n.remove(o)}catch{}try{i.style.display="none"}catch{}}}function l(){var b;if(!u){try{i.style.display="",i.isConnected||(window.app||document.body).append(i),(b=i.show)==null||b.call(i)}catch{}g()}}function v(b){var B,q,z;if(!u){u=!0;try{window.removeEventListener("resize",C)}catch{}try{n.remove(o)}catch{}try{(B=i.hide)==null||B.call(i)}catch{}try{(q=i.remove)==null||q.call(i)}catch{}if(b)try{(z=t.onClose)==null||z.call(t)}catch{}}}s.onclick=b=>{var B,q;try{(B=b==null?void 0:b.preventDefault)==null||B.call(b),(q=b==null?void 0:b.stopPropagation)==null||q.call(b)}catch{}h()};try{i.onhide=()=>{u||h()}}catch{}(window.app||document.body).append(i);try{getComputedStyle(i).position==="static"&&Object.assign(i.style,{position:"absolute",inset:"0",width:"100%",height:"100%"})}catch{}try{(M=i.show)==null||M.call(i)}catch{}g();let A=()=>{var b,B;try{let q=(b=window.editorManager)==null?void 0:b.container,z=(B=q==null?void 0:q.getBoundingClientRect)==null?void 0:B.call(q);if(z&&z.width>0&&z.height>0)return z}catch{}return{left:0,top:0,width:window.innerWidth,height:window.innerHeight}},x=()=>{let b=A();i.style.left=b.left+"px",i.style.top=b.top+"px",i.style.width=b.width+"px",i.style.height=b.height+"px"},C=()=>{p!=null&&x()};return window.addEventListener("resize",C),{page:i,show:l,minimize:h,setAppearance({overlay:b,opacity:B}){b?(p==null&&(p=i.style.cssText),Object.assign(i.style,{position:"fixed",background:"transparent",pointerEvents:"none",opacity:"1"}),x(),a.style.background="transparent"):(p!=null&&(i.style.cssText=p,p=null),a.style.background="",i.style.opacity=B<1?String(B):"")},close:()=>{window.removeEventListener("resize",C),v(!1)},onFullscreen(){}}}var Ja,qs=T(()=>{Ja=0});function $a(){for(let e of["editorFile","EditorFile"])try{let t=acode.require(e);if(typeof t=="function")return t}catch{}return null}async function Fs(e,t={}){var u;let r=$a();if(!r)return null;e.classList.add("is-in-tab");let n=t.title||"Live Preview",o="liveserver-preview-"+Date.now()+"-"+ ++Xa,s=null,i=[{type:"custom",content:e,stylesheets:t.css?[t.css]:[],hideQuickTools:!0,id:o,render:!0},{type:"page",content:e,stylesheets:t.css?[t.css]:[],id:o,render:!0}];for(let p of i)try{s=new r(n,p);break}catch(c){console.warn("[LiveServer] EditorFile "+p.type,c),s=null}if(!s)return e.classList.remove("is-in-tab"),null;let a=!1,d=()=>{var p;if(!a){a=!0;try{(p=t.onClose)==null||p.call(t)}catch{}}};try{(u=s.on)==null||u.call(s,"close",d)}catch{}try{s.onclose=d}catch{}return{file:s,show(){var p;if(!a)try{(p=s.makeActive)==null||p.call(s)}catch{}},close(){var p,c;if(!a){a=!0;try{(p=s.remove)==null||p.call(s,!0)}catch{try{(c=s.remove)==null||c.call(s)}catch{}}}},onFullscreen(){},setAppearance(){}}}var Xa,Us=T(()=>{Xa=0});var js={};xe(js,{destroyAcodeWebview:()=>el,isNativeWebviewSupported:()=>Qa,openInAcodeWebview:()=>ro});function Ns(e){var t,r,n;try{return(r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open?(window.cordova.InAppBrowser.open(e,"_system"),!0):(n=window.system)!=null&&n.openInBrowser?(window.system.openInBrowser(e),!0):(window.open(e,"_blank","noopener"),!0)}catch{return Ka(e,2500),!1}}function Qa(){try{let e=acode.require("webview");return!!(e&&typeof e.create=="function")}catch{return!1}}async function ro(e,t={}){if(!e||e==="about:blank")return!1;let r=null;try{r=acode.require("webview")}catch{}if(!(r!=null&&r.create))return Ns(e);if(ve)try{return await ve.loadURL(e),await ve.show(),!0}catch{ve=null}try{let n=await r.create({mode:"fullscreen",title:t.title||e.replace(/^https?:\/\//i,""),allowNavigation:!0,allowDownloads:t.allowDownloads!==!1,visible:!0});return ve=n,n.on("closed",()=>{ve===n&&(ve=null)}),await n.loadURL(e),!0}catch(n){return console.warn("[LiveServer] native webview failed, falling back:",n),ve=null,Ns(e)}}async function el(){if(!ve)return;let e=ve;ve=null;try{await e.destroy()}catch{}}var Ka,ve,no=T(()=>{Ka=acode.require("toast"),ve=null});var Ws,Zs=T(()=>{Ws="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAhcklEQVR42u19d3hc5Znv7/1OmRnNqFfLRS5yb8LYgE0xmF4TYkZANoHgBBySJSQkLNm7ux6P949kl2z25m4KBEwLTwDJlBBCJ7YI2GAw2AbLvci2rF6nn/K9949zRhoVc10oJlfv8+iRi+Z85+39EzACIzACIzACIzACIzACIzACIzACIzACIzACIzACIzACI/ClBRrB6YsCZiIigPnvhwlEafKLU/tFQ6H0C4pBf//ySr0jSAQg59TGyX2x/ImzZ0/75reeLTrjvHMBAMGg8mUlfsjFqXLp0ntmLr91Q8G4yhmnJhNcIufNrJo7+wffr1/03z/jBT+6c1/p6Wee+SVlAoVCLABgwjVfvWv+v95tnvNfq3juD763PXfGgqpPEyflU5H83/5WFk2cPnnMZefWesaNmpFMJMysvEChvzDvEtukDbHXXz2EYFBBfT1/KYjPTOELSFZcc+2PCuZOuVfJ0tVkyrQ8hfkl/sKc8+NtxmvG22vbEQoJ1NXxF+fZQyFBq1ZJb8GY8knVVzzjnzjqzGTKtAmkEJlS6B5hNnUebF638frWDza+AwaBwKe0zSdiMGPCNV+9K2/utP9UsjSFTZNZKMQMW/PqSu++po0NNWuvTXbuOsIrVgiEw/KLYAAxM4goMG3ZLTWBaeMvswzDdrSKAWJIllL3+oR1uL2hdeMHNx7ZsH4D5CnMBGaaMXOmZk6bcUfO9En/Ab9XgWUyBBEDcL9sxaMrsR0Nr+xY/VA1M0ecsA8nxARx4sIfIiLiidXXh7OmjLvMNFM2wA7x0w8nIZLJhJVVUV5ROmvOg2AUQ4BPyZg6FBIg4oaEmBaoGLXSkx9QpGnaLIikS10XM8U2DDtryphLJ1x/fZiIOBQKfc4+IBQSdeGwrLj4shtyq6b8HBqBbBZwJKFPuSQkq5qqWO29kci+xpWdu7a/2y9Ipxg4tpzM7tYOT0Fpo9efdZGWneW1bZt5AF4AIEkKsJ6bvcDrzd3zp9UPfnSi/uBEGCDozTdlYcWsaaUXVP1BL8jJY9NikBikTVJ6NE2gOxZr2fjxsoZX/vI4CBI45ZMu2bN752ZSA7uziguuVP1e3Za2dLIxuLJDBClZ92mK5tcXmu2JlxLPrmlzLQp/liaIwMzMLAouOC2sjioZY6RMyYOIz8ysKCrZkZTZvmnnHY1/fa0WNTUKvgwxEDOhpkZprHttTeum+n9MRROmVHUCM4sMBAhCWClTqmXF5YXnzl8JZgHm4zav4jhND4GIx51/ybW+caOWpixTghRipJNF50sogtmwqWPz7n9pePWlh1ETVFBdLY/iS8QXkdiEOCRCw5/LqK6WqAkqh1578ZGOzTv/FxspIkUweCCegEKWZUvvmLKlo5dcvBREjFCIPqsoiMCMQHZ5YeW3vvKGWlE2J5VKSQUk+iI4AAyWuu4RPR/teWznH/5wS4gZ4f4gYpCwMZHzf44TPIlw7gSiNx7yDsPlA0SovOnGh/JnTb1ZGpZkSOEg45BOMktV9wjrUPNHWx95bgkiRzpca8WfqgaE2JH+siVnfVMvK55jp4wM4vfbfVXXRfRQ85ZDT798DwmS4aO8TBrxiVcuuXbU2Wefg3BYBms+84y5j/hzvn3VD6bdcOmNRMQhHl4TwkQgQbLp6TfuSRxs2ix0RTCzpD5fwBAEIc2U9JUVz56wZOFNcJ5Hn7YJorAISyC7UJlQ/h1LVxnMEK4XVwAIliyESrInmuza9PE/xeNtzfxvK8Rw8XGIQ4KIeNY/XLF89u1zn1zw/aonKs4++6za6lr7M2QChVymz731mh/NvGHqr6r+YfpDp910xfIwhSUPX72V/G8rRCzW2tK5adtPrN5oQqgqgQcJFEtYHmLPhLJbkZ1dGBar5LFal2NjAIcIDFRcteR6vTh/hmUYAEhQv9UEEVhTBMUPND3WtP5vr4Yck8LDET9MYTnn5su/W/X1Kb8uGKXppdPzxiy69bSayjQTPv3aUdqcyNO+c81ds6+bcm8gX+OCUV5v1Q1TflN1y5W3H1UTwmEOhULiyIa33ojtb35UEYIGajQDRMI2DHhL8qaNu+CiG8Ds0OxTYgDB4Wh2VkX5MkXXwMwMUN9rMLFUNJUSrR0Hm956/2cgINwfs2UyUoQpLCuvvSw4denUXwZKPaqVkByNGzIwN3/sjO/OrilftGBhbW2tfRSzcMJmJ0wkq267+sfTgpPu9RXpIpay0JsyZVapV0xbWvnLKUsvrQ5TWGLouRx2MKHWNz74ebKlo4F0lRgsB9tUTVeRPa50GYBsHKMWiGOodAowo3zJxeerBTlV0jCZQEMebDMocrBldU/DzgOQwzhUBpEIy+Kqqrlzl07+n7yx2b5kgqUQghQiEYvHZd6c/LELbl/w5Oh5885yiPEpZMyuzZ9727U/nHpt5X/mFOlkJQ2QIIJQRSwhOTA22zvnusr/KZ47t4rEMOeGwxIIUXfz9obeg80PQkqivh9xIyIWZBkWqwU5VaPOv3QJmB3anSwDuKZGAkBgwtjrlJwsxXVClGElWdFUkWrrOtz45tbHwEyg8FApBIMZgfnfmvur0tm5pVY0JSGEABMUBjQSwo4ZdtGs/HHn/XjRMxPPP+tsCPDJMCHklhfmfOPq22cGp/+3r8gPI2EDgkhjgsoEFoowI4YsmZFXMv87Vb9iLg64Jp4GeUGAmZrfrn/MbOs6qGiaYB6QGJBkSBHwC/+kUV/LpN3JMICIiH0Fk0d78/znEyQESaIM68KCpCQg2dL5RKpl54EQVg4pTIXYqRvNW37td4vnly1OJhOSFBKDTakCIguMuGHFFHit4azY8UB45UoGAWZvclv3oe4tLGwBRQ52oRCkiEQiJUsXlJw3/3tnp/3BYMbLEFZSsqn+YKy56wkJAjllosw4nZht+HKyLygoqBzjhrd04gxwVai4atIiPSd7LFs2BEgIYhABDGZShGJ2ReKdW/c+7SA9WAwhwiIssydOnzxu8egfK1ka2wYRmN1ggvv9iE8XLetbNvzpzhcu371u3btO5ZT4JMoKDAna/vxrb7647OmvtrzT/Lbq08UQ+y0kpA0SHpXHnjvqruyJVZPDIiwRGkgfFzfq2rbvGaMnGiNFKG722/cktmzoOYExOfMmLcqk4QkxIFRTwwCQWzHqPDXLSyzZzpR+ELOmCljdsY2dW9/dDCIMjnxCK0MAA6fdMPe2oqn5ZXbcZAhlAFWZWeo+j2h5r23ry3e98HXqPbwnGAwqJ1C2puHSx2AwqBC1HFh714vfOLKxY6snSxPMUnKfFQUIgmTc5MIp+WVVN0xfDnbffVBEBCLu3PLOZtnZu1FRVcfJZB4v2Vb9XgqMGXVeJg1PhAEUFiQB+CjgPYOJB006MAQBZNow23peAJAKrVgxsBjlSr+nYu744tnFNyoCTO4zuC+EZtY8KnXvi3RseXDLcqRaDpwXWqzW1tbaA73cMWXwHAoNxam2tta+7qmgkkq1HNhy/0e3RnZHOrI8KsGW7ISM7PBaglQwl84svDF33JwJw2gBB6+7TgFg2G29f1ZMC0IIDBBKMDEAEfCdCcDn0pCOnwEhJ/YvmDxzPHk9k03L7su/2ZEaZqGLZMRIdTe2bQD6Qs9+CzYzSGBgxhXjr86tyBltpUwmkZEaMyAEwUpK2v96w72NGze+E6wJKnXhOmtA/IS+HgK5vdghUlVZWZADQA+HITNqS32Ip5O8w5ve2bjntcP/YcYlCQVQWCJdJSQBsg2T88bnlE+5ctJVw2lB7YwZDACxQ00bUpFYkoQiCDLzfciyLYgsb2VBZdUEsEvL42ZAfT0BgD5mzHTp9eRZtuS05SfX/EhVgW2m9rZt+GD7MOaH1tywxgaglc8uvVoPKGxL5sx2AIOl5teofUfnpk2/+9N9zEy11bUy891Gzxw9t3xa0ZQ+Rjia4alYXOHtj/NBhpH0n3XWqNsWXjLhKoTDEjOgZzAuzQTJzLTx92/ef2RH5/uqXyWGlJnzP5YkVrIULpldeA0AbZUyKJ53zBAaN27eYabMvVAVyAECQSRtyfDqub6KUdMzaXlcDAi6372FuZXweYil5IHtFmKNLJidPZuBni6WclCGGCKWjILJMyv1MnW+YVskWIo+m8IACaJkj4HD7zQ9AKCnurY6bcLI7TJRYVXJzwrnlv+0dE6pv7S01F9x4/xbJlTPexhx5MEtWxABBw/FmzxFeNIsyP7h9K/P+0mpVXjOuHMnzRvEBHbO6Oxt3NDygNFtIq2RGfGyMKRFapnv9ILKqsksGcAACWYH155uqzv2IUOAQUzkzm8RwJAsfB7yFORUAkDI1ZrjYkCNG8PqAc8kUglE5DoAxxIwBGwmmIn4DgBwidfPwBqH69MWT5pXmJ+VzymbHa+BPunXfSpFDkcbdv9p6/NEQG11bd+LhletkgAQU5Xi1Jj8W5Szx2+lpRM/tMfmPZSy8XbDew3NqK61+zTjOih1LzS1H24xv53Kz10lqiYt8ZcGflC8uDgwwIRU1zIRsPupLX+ONkQbNK9ONpOUQoGEAlsIEqbN5Xm+/BlLxs/LxCUNaVwT0eROlnKYtFQwVAWa3zMJAFauXHncDCChKAwAarZvtCKUfkfVFzuzkAkDqd5Ug4PZIAYGHa6Xjg/MK8j1Q0hIFoOCZlKQaErUxdsPNknJ/flDyCl95589aUYyxzu1WyFO5vkmpvJ8k6MqZLTEf+XoO5bcM+7mRUv7Stm1sCsvq/Q0r93eFIP+uFVeuDwa8F+o5pZeDIAR7Ov+SSmZ4vGDTfHW+Don+yDmjL4vSci8PA9KxvnnZeLSz0X3ezTWYCdTQ+noZN9QA97RAODSko7PBzjRlRekFjqfzYiAmFkIIiRSltmbOJDpnPphJQMgf553vKqR+zju0yFVIbLiBtp3d60fokHrFgsA8EzM/SZla9mmLa2UIWXKtGXSksylOZdbPv3nZm9ybJ+NDYXEnpf3mKMvnn2Ntad1j6WqubHRhWOMktyrAQAzFtNgCW7b27PejBlQBIjYNSaOdkJoAv5c7wTndQdKcBpXMxo5IFMpi4QYVCF1rDULpQCAd0CkOgjUo9LfeV4WEwXSnba0DhAcDjNLQ5rcNbwGCQaQlRXQRzsRt8PAdB8EQohkT9JqP9C+c5AGEdats0EkFJ+yiCWDJRORIGZIxacqdnest3NL8xJz7Y5NzqxRre1KuJ1SPTHVqy2OSW6THr0cmj4DgIpVb1ou7zl9Vvv+9p2pWNzyFXhVxcpoJzITS4YvoI0GkCUUEev7bGZqbNpdZCNJQgTYloM7twAhG0AWg5PHHwUxABTrAHkHJ45ubQ0sZcqOxY1P0CBPVpaS6/zZ+WICbGbYKiHZK3si27taHamqHWDfAHhM286xWIKZCZIZJIgNq5VjqfvNtTs2LV4bUrFyseKaIOfzhrHXLC9aZJEoNk0Ji8kLQM+kXfqs9u1drfGI1W1qDMkDKxTMjKyAmgPAczQJtrviBkmZosHWhRz8BQkPUOT5pHRS/YSMkn0+j0KC1GFbzUSwbZm0WtsNNzwbhv5QhU/3mpL6lBsAdBA8ROi17VRni5XAcEkEAAsMISWYJUCwyatrdkv0b8kH3vknAKi7IOzmC3VACAJhUKIz6WWNckxBxBZDOJI5kATuWdHmaAIWp7JZRVzakKJPQ+FogOIF/CpzbHBG7H6+LSWlnUxX5jMiDGIwQNB8Po+SSPTT9JhN0PBl3eOfqDKZIJD+IIEYEMx92aMHQGp4/ltCkMmCYIPYJlI5aUrkeK/w3TT/Z1qC/6r5AosDBUUX24fbHz9cX/JboFbKyuJzpaYL2zYNEpouyWMBsI+CPxzLLwCy+4YiMgn5WTeoxScZoEQiZbNki2g4fjBICK9aUqS7kciQnQYAlhU3kzpJkKsSzIBBQIJtCAUef6nqcyOf/rOfuk4BYMKmHQyFpRAsiSDBJFXy0biCn+qzx7yqji35l0QileRc317U1to4bWw5FxX+WBIxSWKCwszKHgCG+0zOPCtQFvCRIjwRSFjk9pjS0iyARMxOALGh+Lu4BsqKPSSE1xH2QRGeo0ZmIpGy8QllXfHJZa02A5BJQQzFdcEDMhJF9fj8WfpRt0qAlJkwe9T+8B/pSirZBE+Onps/vbgEAIL1QRoc5llNsaeEyUQkhFM7ZWYCm7FUa2JH088jdTvmt97/wuLG1S+/6L/y9PN9C2a+LAOeCbZhSrBQYYHEkd41AIDftPY/3z2raEpBsSeg5KmWMzU8MJ8lxKNmL4AUaHhFUPKzdAjhcQMf9I2tuLNbzJwC2lOfpEfqJ4wJg8FxYjuqECAhASiZRTSANN3SKH84DZK2JCJKJGNGo9M9JgbYnc0FSUlSy85Sc8YXTAWwDsGMSKi21gYzdRO9UliWs14tzV5kGoYFkEK2zeyhQitHudI7Oz+/8LQLv28n7Gl2lm+h7fXCTqYkQzC8uspd0c1yZ/OfHbtCdn+VHaitBQomFk71ZntVslkKQKB/wolJCCRiViOAuIvLEAkWmjefBHlZDq63SYAEmEUEQNyl5XFGQQ7Xk2B0OK8lOP0YSUQsJateRdVyfOMdCR5c71hJADjSlWgwTQkh+mtjEgKWzaxlaSiqzF3kJDuDukcrVxIA09zXfqeIpGKqqqmQsFmCpGRhF3pnG8W+5clc7RajJGthUgMbZsqWxBKqolDKMJXGjjuxZ08K1dUDqrTps0or8xZpfh22ZCbq124igmUyYt3GfudzKwfglsZVC2jjFY+uQkqGQIbzIHbkTXYCSB5Ngz7RB0jbKf1bkVSjlE5qkWmA3FICPAGHAX3Fo75kx3nJtkOJDzp7kpCCRFqGKB1rw4a/zL84q2jcKPdfxYA+bCgkeuv2vc+NXTfpSSuh67oKW9gw2bYTlpWKp4x40jTiKdOwWFoMBjy6CltaONR2m/XihjcRDCroL227ZxCysorLPKW+C0A2ZEaZnRmAgIh2p9B6MPJBJi6DC2VKtn+c8HnghGkZhVsiSClhRxNHAMCl5fH5gGpHamBE43ulE8oNiYFIENSsrKnDSXBttZMt7lx36P3OrkQXawqRTLsrCQEIK2lyToW/YvLVs68mAgdrgkOb4cGg0vPctmfsvV2X6t2JD32Komq6VxWqrrJQdaiaDl3X4fVqQvMqFEltEfvbrpDP/O2RYYiPYE2QiMCTb1h4daAip8JIWEwgkfZwksCsC2rrinXX//XAB5m4DNYg3eefRkLpM9j9GsTEUiIVTe5xa0HHXw1Nm2Ors3c3J1IMEgMaoAyQwSo8hdlVQG4eCTEoWwgzCULHrk17jebEJl1RmYXDgnTQzFKyP0/BhEWltwEFOS5iNKibYiMUEtG/fPS37t+9vVAcaF+mdcT+rHfE92m9qU61J96utEV2UFv8Gd7XerP83Qtn2c+/9bqTnA0kPgByzijMLjur7FY9VwO7VfZ0oRxEEqrC3a2JDzr3bN7t+K+BZXYX11wt33+aUyVggpQZzTFBMp5is7NrDwCET6QcDbfeET/UsgNJo5sUQczpBigDTKRYNnRNnVS+aO50MA9uPPB1TzrhZPNHbc/bMZMUMThaEyIZs7h4RsnpZyw/97tExMGamuGGo9KdqVTPmi0PRx9cf42+ZsPp6v62WVp9w2z7wTfPkA+8tlSuefsxAEkEg8pwc6bBmqAgIl64/Lzl5dMKF5hxJ8QaIFVg4qikzs0dzwMwV9iDu3whAjNK5p09XXi0SWxbrjl1DRAzk1CIE2ZPT0Pr9kxaHh8DwmEGAZ27PzzAieRuRVHA6WAeBCIQS0Nq2V6Pv7xk0XCOuHZbLYOAj/+y/4Xe/ZEjmkchdsKnvrBNSgHhJZ5w8Zi7R59+5pm11dXDjyeGIfs6YhwSPT3ojr+yoyle19AMIAIOCbdbRsNIPoI1QaW2utYec/pZZ0y6aMw9WhYYthw8iMi6R6NIQ2/T7pf2PQ8aOmSQxjFvUtlCf77PC3ZCJGc53ZlUUBUViCf3RPds3g8ChpsQPJaeMIecAnKCo8mNTjdgYCgmJcPWNGjF+VcB8NSuWWMP7B5BhmRIpA5u3d+8rfWPFoMgBhZWBIFSCYuzJ+UWzV0+5/fwVIxfc/1RxxOdjhiFHWaEIFzNIFBYuoTnocMdQWXN9bU2vGUVVbfNuT8wKacokbJ4cDMGKkmGoOaPOp7oObh1f2jogBm5OOqisOBKU9GcGlJmp5yE0z6PJDcCSLg05BPakKmrrxeor2dvQVnAN6roOqkKMWRYBiAoKLZ61FcTLQePIBSizFWdOtQR3gR3tmsHymaVBP2j/AE2bQhit8NDAIgs05aBiuyy0hklZ+x58chf6+s3doFBw9WI+l8QjLr/x+QEAfXb6hnesopL7r3y8fKzSs8wEykJIgE4ZRJn/stmkeWhjp3drRv+96Z/NHpaOuq4jgY8PxQSWLcOhVXz5+XMnvKvUtd0khLUl/gTQEIgZaJn295fdO/bvS1NwxObC6p1+rNtm/euNyLRQ6RqGDBTQ0TSlraWm+MvnF3xNQAcWjnUdIRkSES2b959qK7xl3bCJlVNa0F/f5hYCDthyFFnly26YvXSZ2YFr1rcV5w54bFEEK6DMuWqxedc/n++8szoc8rOkYmUJCJBRH0rbUQAVGYradGht5p+Gdm/dZcj/YMGzBzcOG/GlK95crP9wrJsZ3DJjaDAEqqKVG/0cO8Hu9Zn0vBEJ+OYmSnRubsx0RNd5/z4QDNEzIKY4CnLv9E7asa4sNO8GDjQRGFmZnr/vrd/1/5+65s+r1eAbZnZYSMCVBbCTsEsnj/utMCYnJsGVQeOfyxLgFGLwOizx//X2HPL51mxlMkg0d/dSJtSSI/PL1reb/3bpl+vu4+ZKUxD7LYIYyV7R00cp5eWfJ0dJygGFM/g1FlSvbG1nZ17Drsj73xSs6Hk5gPxfU1Py2hUCidqyKQc2ZYp1aKCsWWLZt7sLDoPWdtkAoGoLfru6o/vbNnW3eoJeASxLdO5P7GEpsBWFaHtfXH7M++sfvNud5nixMdyJYgIPY3vHvhx08bmA16/R0vXtsHkdOBhS09AF+0f97Z98PuP7gR19hJouMlugIhLFy74pl6cO05ahsyc0AfAQpCQ0ZiM7T38NADQJ8T/xz4dXVsrQYQja19ZK7simxVNcyOZwZVR4kBF2bdzS6eOhwjLIXtfBGYZEm1b3tv80dO77+g8GE+STxMsbcmwYaksDVVRDrze8Nxb//zoMkQOd9LJDocSWErQrufq3vrgN5tubPuo66An4BUsWbp5iBQ+hboORZLbn91+R/vW9z8MyZAYMpEXCglgJeeVTa/IrSi6VVMk09DpdFY0lWRXz5amda+sHW5K8ET3AxhyhQAQiRxoX20bFmgg50EgIQ2DPSX5FcUXnv5TcF/Fd/CEsQxxSGx/+pWa7c/suaunxbI8PiFUxbZY84i9rx98bu0//+EWEtQDhjipudB+08bBYFBp3Ljxnffuf//65q2dB13tszSfKnpabbl9za6fbK999Sl3eYSHLHe46W3pkrn3+MryKthMsQCJfj4xQCDbNBE/2LoaQK9LM/60lvTcOxSyC6b/4BtvecYUT+OUMSCJYWYmRYGMJZPNb7x3Tes7da8fbfEuvR826+bLvzt36ZRfZFfk+Le/tP/Zup8+vowEdfO/8RAHeLKQzgNGn3PmmWcsn/fkmPkl4zt2d0U/fnrf3VsffeG+oy/rhQQQlqVnnLuk/KIFLygBr9ddG6b0sh5BSvJ4Kd7YunPH6j+cg2i0A8dg/49nR4xDcoUAejvjB5oeEKY9ZEeDiIilzZ7cLF/p/Gn3+v0lpfTvq+RwZ6TXgT5+9KX7tj21+9YdT+99qO6njy8D4TMhfuZoYuNb77676f4Pv7Hv5YPr65/ctWzroy/cl95ZG3YpXaySfn9pSdH8Gb/Q8rJ9UkpmEiQz3DiRgGowJfe3rEYk0hE6Ruk/oTVVZJcXzvnWV95Qx5XNsYyUFIM2JRWw1HVVdHy899Fdj/1x2TGvqVJfC5A/8zshHK30A4gdw5oqT/7m11fnzZp2izQNKd011cyqsNerC6Oh9ePdDz+7JBppav9M1lQBMFauJESb2rs/2vvvRiRuQxFDDmJAGLYlcyrH3Tzpqq/cFSaSwZqgGI7ZRMTMTE6f63MgfrquxEwk6BOJj5qgCBPJiquu/aF38vhbLNuUYBb93WwCMzELBUYkYXds27MqGm1uc/sY/FldV+NoARFVfuvmJ3JnTay2kwkJ9F9VINzWoaKq4GjSan23/rZDr734CGpq0tvyfLQpDOBzvwVx2HcJ1tSI2upqe/yFl9xUcNbsB2S2XyPTBBEGmB5mKXWfR0S2Hajd+fAjNzD33etxzLioOO7ckgSIZNf6j0OBwtyztdL80aZhOD24DNk2TSk92Vla6enTfi2NZLSxunqN2xo86hDA5wx8tOmPWiJ7zHkXX1t4xsxfq9lZumGaEkTCubbGYQCxLTWPJqym9iNtb70XIiLpBiXys74vSGLFCtGxa9OOri177k5FkharSt8kUN8LEoRpWKzkBfyjFs55ePxlV97sNqrp1L2ngwlEPP7CS24qWTTzMc7LzU4akkEkOHNShZmlqiEVNayuLXvv7ty9bTuvWCFO5NImcaJ2NBQKiYbXX3wisuvArxVSBDsCkmmrQERkpExW8nIDBVXTHi4649wr3AuOxKl3X5MTCY276PLvFC6c+4jICwTMlHNbluwby3Qv+xIkFRIisuvAbxpef+mPoZO45+JkpFG4Ni972reX1QSmVlxqGSk7XWEV/YNPti5UJbL34J9a395ye/uOTc1uS4xPuWtqBPHo8y48P3/+rMe0koKxtpGSAxo2TtRjqx6vEt25/9VdDz4c/MKuLAMgaeVKIqLehufeXpbY37hR9+gKmG3Rv9glVVVVIrsOPFu/+qGb23dsauqbGsApd1ETQ4Ia695Yd+TVDdXmkY5DmkcTgC375J/Z1j1eJb6/8b1Dz7y1jIh63XqP/GKurayrY4RCwnrp6d5kZ7wuu6zkIl9Rfok0LVsRxIqqKz07Dj6745GHlxFRz4ncKPW5Qti5DzSx9rVDMHmDrzDvEj0/J09atk0Ae30+JXWoeUfLX9ZX9zZtP/BpXLGjfCp3rQWDivF2XbuM4O2sgtwL/IV5xYJJ9OxsSBO/m5nFyUjK5wb19YxgUIm98dohGPo7vqKcS/T8QL5QVBE/1Lazue69G9t3fLgNwaCC3/5WnnJXFwcqZk6f873bN89atuzPAHLdsPPLd4e02xItPf3MM+fcdcfh2XfcvrmgYub0L8X90UBhOYD8T8HPnBL4FFXOOS1nzKTKL8uF5OLv6vcIDCD4l+c2ePq7+iUODhP+Hn8pxQiMwAiMwAiMwAiMwAiMwAiMwAiMwAiMwAiMwAiMwAj8/wH/F2fRH3lyxfLEAAAAAElFTkSuQmCC"});var at={};xe(at,{createBrowserShell:()=>dl,hideBrowser:()=>Ot,openBrowser:()=>io,openBrowserMenu:()=>Kn});function Xs(){return S().browserDisplayMode==="editorTab"?"editorTab":"inPage"}function nl(e,t){try{return new URL(e).origin===new URL(t).origin}catch{return!1}}function st(){let e=S().browserBookmarks;return Array.isArray(e)?e:[]}async function ol(){let{getServerStatus:e}=await Promise.resolve().then(()=>(de(),Qe)),t=e();return t.url?t.url.replace(/\/[^/]*$/,"/"):t.port?"http://127.0.0.1:"+t.port+"/":null}function Vs(e){var t,r,n;if(!(!e||e==="about:blank"))try{if((r=(t=window.cordova)==null?void 0:t.InAppBrowser)!=null&&r.open){window.cordova.InAppBrowser.open(e,"_system");return}if((n=window.system)!=null&&n.openInBrowser){window.system.openInBrowser(e);return}window.open(e,"_blank","noopener")}catch{ne(e,2500)}}function sl(){if(!(Rt||typeof editorManager=="undefined"||!(editorManager!=null&&editorManager.on))){Rt=()=>{S().overlayAutoSave!==!1&&(clearTimeout(oo),oo=setTimeout(async()=>{var r;let e=V(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";if(e&&e.isUnsaved&&(e.uri||e.url)&&tl.test(t))try{await((r=e.save)==null?void 0:r.call(e))}catch(n){console.warn("[LiveServer] overlay auto-save",n)}},700))};try{editorManager.on("update",Rt)}catch{}}}function $s(){var e;if(clearTimeout(oo),Rt)try{(e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"update",Rt)}catch{}Rt=null}function Jr(){return it==="page"&&!!S().browserOverlay}function so(){var n,o;if(!j)return;let e=S(),t=ot((n=e.browserOpacity)!=null?n:1),r=Jr();j.classList.toggle("is-overlay",r),j.classList.toggle("no-url",e.showAddressBar===!1),j.style.setProperty("--ls-op",String(t)),it==="page"?((o=N==null?void 0:N.setAppearance)==null||o.call(N,{overlay:r,opacity:t}),j.style.opacity=""):j.style.opacity=t<1?String(t):"",r?sl():$s(),X==null||X.layout()}function Ys(e){if("opacity"in e&&R("browserOpacity",ot(e.opacity)),"overlay"in e){if(e.overlay&&it!=="page"){ne("Overlay needs the Acode page display mode",2200);return}R("browserOverlay",!!e.overlay)}"autoSave"in e&&R("overlayAutoSave",!!e.autoSave),so()}function il(e){var Xe,ut,It;let t=f=>e.querySelector(f),r=t(".ls-browser-tabs"),n=t(".ls-stage"),o=t(".ls-box"),s=t(".ls-device"),i=t(".ls-ntp"),a=t(".ls-back"),d=t(".ls-fwd"),u=t(".ls-browser-url"),p=t(".ls-reload"),c=t(".ls-star"),g=t(".ls-site"),h=t(".ls-menu-btn"),l=t(".ls-op-btn"),v=t(".ls-dev-toggle"),A=t(".ls-find"),x=A.querySelector("input"),C=!1;X=Bs({shell:e,stage:n,box:o,device:s,bar:t(".ls-devbar"),onChange:f=>R("browserDevice",f)});let _=S().browserDevice;_&&typeof _=="object"&&X.setState(_);let M=()=>e.getRootNode().activeElement===u,b=async f=>{if(f==="about:blank"){We("about:blank");return}let w=nt(f);if(!w||w==="about:blank"){We("about:blank");return}if(!rt(w)){let U=S().externalSiteMode||"proxy";if(U==="acodeWebview"){await ro(w);return}if(U==="systemBrowser"){Vs(w);return}}We(w)},B=()=>{i.innerHTML="";let f=document.createElement("div");f.className="ls-ntp-hero";let w=document.createElement("img");w.className="ls-ntp-logo",w.src=Ws,w.alt="Live Server",w.onerror=()=>{w.style.display="none"},f.appendChild(w);let U=document.createElement("div");U.className="ls-ntp-title",U.textContent="Live Server",f.appendChild(U);let Y=document.createElement("div");Y.className="ls-ntp-search";let he=document.createElement("span");he.className="ls-ntp-search-ico",he.innerHTML=O(P.search,17);let le=document.createElement("input");le.type="text",le.placeholder="Search or type a URL",le.setAttribute("enterkeyhint","enter"),le.setAttribute("inputmode","text"),le.setAttribute("spellcheck","false"),le.setAttribute("autocapitalize","off"),le.setAttribute("autocomplete","off");let Be=document.createElement("button");Be.type="button",Be.className="ls-ntp-search-btn",Be.textContent="Search";let Z=()=>{let k=le.value.trim();if(!k){le.focus();return}b(k)};le.addEventListener("keydown",k=>{k.key==="Enter"&&Z()}),Be.addEventListener("click",Z),Y.append(he,le,Be);let Ie=document.createElement("div");Ie.className="ls-ntp-tiles";let nn=async k=>{let F=st();if(k<0||k>=F.length)return;let $=acode.require("prompt"),re=acode.require("select"),se=F[k],G=await re("Shortcut",[["edit","Edit name / URL"],["delete","Remove shortcut"]],{hideOnSelect:!0});if(!G)return;if(G==="delete"){F.splice(k,1),R("browserBookmarks",F),B();return}let pt=await $("Bookmark URL",se.url||"https://","text");if(!pt)return;let $e=nt(pt),we=await $("Shortcut name",se.title||$e.replace(/^https?:\/\//,""),"text")||$e;F[k]={url:$e,title:we},R("browserBookmarks",F),B()},on=(k,F)=>{let $=null,re=!1,se=()=>{$&&clearTimeout($),$=null};k.addEventListener("touchstart",G=>{re=!1,se(),$=setTimeout(()=>{$=null,F(G)},480)},{passive:!0}),k.addEventListener("touchmove",()=>{re=!0,se()},{passive:!0}),k.addEventListener("touchend",se),k.addEventListener("touchcancel",se),k.addEventListener("contextmenu",G=>{G.preventDefault(),F(G)}),k.addEventListener("pointerdown",G=>{G.pointerType==="mouse"&&G.button===2||G.pointerType})},Ao=(k,F,$,re,se={})=>{let G=document.createElement("button");G.type="button",G.className="ls-ntp-tile",G.innerHTML='<span class="ls-ntp-dot"></span><span class="ls-ntp-name"></span>';let pt=G.querySelector(".ls-ntp-dot");if(re&&/^https?:/i.test(re)&&!rt(re)){let we=document.createElement("img");we.src=re,we.alt="",we.onerror=()=>{pt.textContent=$},pt.appendChild(we)}else pt.textContent=$;G.querySelector(".ls-ntp-name").textContent=k;let $e=!1;return G.addEventListener("click",async we=>{if($e){$e=!1,we.preventDefault();return}let Po=typeof F=="function"?await F():F;if(!Po)return ne("Server not running",2e3);b(Po)}),typeof se.onLongPress=="function"&&on(G,we=>{$e=!0,se.onLongPress(we)}),G};Ie.appendChild(Ao("Server root",ol,"S",null)),st().forEach((k,F)=>{var se;let re=((se=(k.title||k.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:se.toUpperCase())||"B";Ie.appendChild(Ao(k.title||k.url,k.url,re,null,{onLongPress:()=>nn(F)}))});let Dt=document.createElement("button");Dt.type="button",Dt.className="ls-ntp-tile",Dt.innerHTML=`<span class="ls-ntp-dot">${O(P.plus,20)}</span><span class="ls-ntp-name">Add shortcut</span>`,Dt.addEventListener("click",async()=>{let k=acode.require("prompt"),F=await k("Bookmark URL (e.g. https://duckduckgo.com)","https://","text");if(!F)return;let $=nt(F),re=await k("Shortcut name",$.replace(/^https?:\/\//,""),"text")||$,se=st();R("browserBookmarks",[...se,{title:re.trim(),url:$}]),B()}),Ie.appendChild(Dt);let vr=document.createElement("div");vr.className="ls-ntp-recent-wrap";let sn=qr(),br=document.createElement("div");br.className="ls-ntp-sec-head";let To=document.createElement("span");if(To.textContent="Recent",br.appendChild(To),sn.length>0){let k=document.createElement("button");k.type="button",k.className="ls-ntp-more",k.textContent=C?"Less":"More",k.addEventListener("click",()=>{C=!C,B()}),br.appendChild(k)}vr.appendChild(br);let yr=document.createElement("div");yr.className="ls-ntp-recent-list";let Mo=C?sn:sn.slice(0,5);if(Mo.length)Mo.forEach(k=>{var re;let F=document.createElement("button");F.type="button",F.className="ls-ntp-recent-row";let $=((re=(k.title||k.url||"?").replace(/^https?:\/\//,"")[0])==null?void 0:re.toUpperCase())||"W";F.innerHTML=`
          <span class="ls-ntp-recent-ico">${$}</span>
          <span class="ls-ntp-recent-meta">
            <span class="ls-ntp-recent-title"></span>
            <span class="ls-ntp-recent-url"></span>
          </span>
        `,F.querySelector(".ls-ntp-recent-title").textContent=k.title||k.url,F.querySelector(".ls-ntp-recent-url").textContent=k.url,F.addEventListener("click",()=>b(k.url)),yr.appendChild(F)});else{let k=document.createElement("div");k.className="ls-ntp-empty",k.textContent="No recent pages yet",yr.appendChild(k)}vr.appendChild(yr),i.append(f,Y,Ie,vr)},q=()=>{let f=D();Gn(r),u&&!M()&&(u.value=f&&f.url!=="about:blank"?f.url:""),e.classList.toggle("is-loading",!!(f!=null&&f.loading)),e.classList.toggle("is-installing",document.body.classList.contains("ls-green-loading")),p.innerHTML=O(f!=null&&f.loading?P.close:P.reload,18),p.title=f!=null&&f.loading?"Stop loading":"Reload",a&&(a.disabled=!Rn()),d&&(d.disabled=!On());let w=/^https:/i.test((f==null?void 0:f.url)||"");g.innerHTML=O(w?P.lock:P.info,16),g.title=w?"Connection is secure":"Not secure";let U=!!f&&st().some(he=>he.url===f.url);c.classList.toggle("is-on",U);let Y=!f||f.url==="about:blank";Y&&B(),i.classList.toggle("is-on",Y),Ct().length||Ot()};Ze==null||Ze(),Ze=_n(q);let z=()=>{var w;let f=sr(e);(w=N==null?void 0:N.onFullscreen)==null||w.call(N,f)},m=()=>{var f;C=!1,Mt(s,"about:blank"),Pt((f=D())==null?void 0:f.id)},y=()=>{C=!1;let f=String(S().browserHomeUrl||"").trim();f?b(f):We("about:blank")},oe=(f,w)=>{var U,Y;return w>0?(U=Gs.find(he=>he>f))!=null?U:f:(Y=[...Gs].reverse().find(he=>he<f))!=null?Y:f},ye=f=>Nn(x.value,f),Je=()=>{let f=D();if(!f||f.url==="about:blank")return ne("Nothing to bookmark",1500);let w=st(),U=w.some(Y=>Y.url===f.url);R("browserBookmarks",U?w.filter(Y=>Y.url!==f.url):[...w,{title:f.title||f.url,url:f.url}]),q(),ne(U?"Bookmark removed":"Bookmarked",1200)},Bt=()=>Ps({host:e,anchor:l,get:()=>{var f;return{opacity:ot((f=S().browserOpacity)!=null?f:1),overlay:Jr(),autoSave:S().overlayAutoSave!==!1,canOverlay:it==="page"}},set:Ys}),gr=()=>({newTab:m,duplicateTab:()=>qn(s),closeTab:()=>{let f=D();f&&Kt(f.id)},closeOtherTabs:()=>{let f=D();Ct().filter(w=>w.id!==(f==null?void 0:f.id)).forEach(w=>Kt(w.id))},navigate:f=>b(f),getUrl:()=>{var f;return((f=D())==null?void 0:f.url)||""},getVisited:qr,clearHistory:()=>{Pn(),B(),ne("History cleared",1500)},getBookmarks:st,isBookmarked:()=>{let f=D();return!!f&&st().some(w=>w.url===f.url)},toggleBookmark:Je,getZoom:()=>{var f,w;return(w=(f=D())==null?void 0:f.zoom)!=null?w:100},zoom:(f,w)=>{let U=D();return U?Zn(w?100:oe(U.zoom||100,f)):100},toggleFullscreen:z,print:()=>{jn()||ne("Cannot print this page",1800)},find:()=>{A.hidden=!1,x.focus(),x.select()},isPinch:()=>Ur(),togglePinch:async()=>{let f=!Ur();R("enablePinchToZoom",f),Fr(),ne("Pinch to zoom "+(f?"on":"off"),1400);try{let{reapplySetup:U}=await Promise.resolve().then(()=>(Q(),ae));await U()}catch{}let w=D();w&&w.url!=="about:blank"&&rt(w.url)&&Qt()},isDevtools:()=>{var f;return!!((f=D())!=null&&f.devtools)},toggleDevtools:()=>{let f=D();if(!f||f.url==="about:blank")return ne("Open a page first",1800);Wn()||ne("DevTools work on pages served by Live Server",3e3)},isDeviceMode:()=>X.isOn(),toggleDeviceMode:()=>X.toggle(),viewSource:async()=>{var le,Be;let f=D();if(!f||f.url==="about:blank"||String(f.url).startsWith("view-source:"))return ne("No page source here",1800);ne("Loading source\u2026",1200);let w="";try{let Z=(le=f.iframe)==null?void 0:le.contentDocument;Z!=null&&Z.documentElement&&(w=`<!DOCTYPE html>
`+Z.documentElement.outerHTML)}catch{}if(!w)try{let Z=(Be=f.iframe)!=null&&Be.src&&f.iframe.src!=="about:blank"?f.iframe.src:f.url,Ie=new AbortController,nn=setTimeout(()=>Ie.abort(),15e3),on=await fetch(Z,{signal:Ie.signal,credentials:"omit"});clearTimeout(nn),w=await on.text()}catch(Z){ne("Could not load source: "+((Z==null?void 0:Z.message)||Z),2800);return}if(!w){ne("Empty source",1800);return}let U=String(w).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),Y="view-source:"+String(f.url).replace(/^https?:\/\//i,""),he='<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+Y.replace(/[<>]/g,"")+"</title><style>html,body{margin:0;background:#1e1e1e;color:#d4d4d4}pre{margin:12px;font:12px/1.45 ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;white-space:pre-wrap;word-break:break-word}</style></head><body><pre>"+U+"</pre></body></html>";try{Vn(s,Y,he)}catch(Z){ne("Could not open source tab: "+((Z==null?void 0:Z.message)||Z),2500)}},openExternal:()=>{var w;let f=(w=D())==null?void 0:w.url;f&&f!=="about:blank"&&Vs(f)},openOpacity:Bt,isOverlay:Jr,canOverlay:()=>it==="page",toggleOverlay:()=>Ys({overlay:!Jr()}),closeBrowser:()=>Ot()});(Xe=t(".ls-tab-new"))==null||Xe.addEventListener("click",m),e.querySelectorAll(".ls-close-btn, .ls-ov-close").forEach(f=>f.addEventListener("click",()=>Ot())),(ut=t(".ls-fs-btn"))==null||ut.addEventListener("click",z),a==null||a.addEventListener("click",()=>Nr(-1)),d==null||d.addEventListener("click",()=>Nr(1)),p.addEventListener("click",()=>{var f;return(f=D())!=null&&f.loading?Un():Qt()}),(It=t(".ls-home"))==null||It.addEventListener("click",y),c.addEventListener("click",Je),l.addEventListener("click",Bt),v.addEventListener("click",()=>{let f=X.toggle();v.classList.toggle("is-on",f)}),v.classList.toggle("is-on",X.isOn()),h.addEventListener("click",()=>Kn(gr(),{host:e,anchor:h})),u.addEventListener("keydown",f=>{f.key==="Enter"&&(b(u.value),u.blur())});let Le=t(".ls-toolbar");return u.addEventListener("focus",()=>{u.select(),Le==null||Le.classList.add("is-omni")}),u.addEventListener("blur",()=>Le==null?void 0:Le.classList.remove("is-omni")),A.querySelector(".ls-find-prev").addEventListener("click",()=>ye(!0)),A.querySelector(".ls-find-next").addEventListener("click",()=>ye(!1)),A.querySelector(".ls-find-close").addEventListener("click",()=>A.hidden=!0),x.addEventListener("keydown",f=>{f.key==="Enter"&&ye(f.shiftKey),f.key==="Escape"&&(A.hidden=!0)}),e._lsDevice=s,e._sync=q,e}function al(){let e=document.createElement("div");return e.className="ls-browser-shell",e.dataset.theme=cs(),e.innerHTML=`
    <div class="ls-chrome">
      <div class="ls-tabstrip">
        <div class="ls-browser-tabs"></div>
        <button type="button" class="ls-ib ls-tab-new" title="New tab">${O(P.plus,16)}</button>
        <span class="ls-spacer"></span>
        <div class="ls-win">
          <button type="button" class="ls-ib ls-win-btn ls-fs-btn" title="Fullscreen">${O(P.maximize,14)}</button>
          <button type="button" class="ls-ib ls-win-btn ls-close-btn" title="Close">${O(P.close,14)}</button>
        </div>
      </div>
      <div class="ls-toolbar">
        <div class="ls-nav">
          <button type="button" class="ls-ib ls-back" title="Back" disabled>${O(P.back,18)}</button>
          <button type="button" class="ls-ib ls-fwd" title="Forward" disabled>${O(P.forward,18)}</button>
          <button type="button" class="ls-ib ls-reload" title="Reload">${O(P.reload,18)}</button>
          <button type="button" class="ls-ib ls-home" title="Home">${O(P.home,18)}</button>
        </div>
        <div class="ls-omni">
          <button type="button" class="ls-site" title="Site information">${O(P.info,16)}</button>
          <input class="ls-browser-url" type="text" spellcheck="false" autocapitalize="off" autocomplete="off" enterkeyhint="enter" inputmode="text" placeholder="Search or type a URL" />
          <button type="button" class="ls-ib ls-star" title="Bookmark this tab">${O(P.star,16)}</button>
        </div>
        <button type="button" class="ls-ib ls-op-btn" title="Opacity">${O(P.drop,18)}</button>
        <button type="button" class="ls-ib ls-dev-toggle" title="Device mode">${O(P.device,18)}</button>
        <button type="button" class="ls-ib ls-menu-btn" title="Customize and control">${O(P.dots,18,3)}</button>
        <button type="button" class="ls-ib ls-ov-close" title="Close">${O(P.close,16)}</button>
        <div class="ls-progress"></div>
        <div class="ls-green-progress"></div>
      </div>
      <div class="ls-devbar" hidden></div>
    </div>
    <div class="ls-stage">
      <div class="ls-ntp"></div>
      <div class="ls-box"><div class="ls-device"></div></div>
    </div>
    <div class="ls-find" hidden>
      <input type="text" placeholder="Find in page" spellcheck="false" />
      <button type="button" class="ls-ib ls-find-prev" title="Previous">${O(P.up,16)}</button>
      <button type="button" class="ls-ib ls-find-next" title="Next">${O(P.down,16)}</button>
      <button type="button" class="ls-ib ls-find-close" title="Close">${O(P.close,16)}</button>
    </div>
  `,il(e)}function ll(){var t;if(Es())return tr(),!0;let e=j==null?void 0:j.querySelector(".ls-find");return e&&!e.hidden?(e.hidden=!0,!0):j!=null&&j.classList.contains("is-fullscreen")?((t=N==null?void 0:N.onFullscreen)==null||t.call(N,sr(j,!1)),!0):!1}function Js(){Yr||Ot({fromHost:!0})}async function cl(){var e;return j&&N?((e=N.show)==null||e.call(N),requestAnimationFrame(()=>X==null?void 0:X.layout()),j):ir||(ir=(async()=>{us();let t=al(),r=null;return it="page",Xs()==="editorTab"&&(r=await Fs(t,{title:"Live Preview",css:An,onClose:Js}),r?it="tab":ne("Editor tab not available, using page",2e3)),r||(r=Hs(t,{title:"Live Preview",onClose:Js,onBack:ll})),N=r,j=t,zn(),ar=n=>{var o;rl.includes((o=n==null?void 0:n.detail)==null?void 0:o.key)&&so()},window.addEventListener("liveserver-settings",ar),so(),requestAnimationFrame(()=>X==null?void 0:X.layout()),t})().finally(()=>{ir=null}),ir)}async function io(e,t={}){let r=await cl(),n=Ct();if(n.length>0&&(t.restoreOnly||!e))return;let o=e||"about:blank";if(t.reuse){let i=n.find(a=>nl(a.url,o));if(i){Pt(i.id),i.url!==o?We(o):t.forceReload&&Qt();return}}let s=D();s&&s.url==="about:blank"&&n.length===1?We(o):Mt(r._lsDevice,o)}function Ot(e={}){if(!Yr){Yr=!0;try{tr(),Ze==null||Ze(),Ze=null,ar&&window.removeEventListener("liveserver-settings",ar),ar=null,$s(),Hn();try{X==null||X.destroy()}catch{}X=null,Fn(),Ds(j);try{j==null||j.remove()}catch{}e.fromHost||N==null||N.close()}finally{N=null,j=null,document.body.classList.remove("ls-browser-fs"),Yr=!1}}}function dl(e={}){return{open:t=>io(t||e.initialUrl),addTab:t=>io(t),setFullscreen:t=>sr(j,t),dispose:Ot,getMode:Xs}}var ne,Gs,tl,rl,j,N,it,Ze,ir,Yr,X,ar,Rt,oo,lt=T(()=>{J();Se();Jt();ds();ps();jr();As();nr();Rs();Is();zs();qs();Us();no();Zs();ne=acode.require("toast"),Gs=[25,33,50,67,75,80,90,100,110,125,150,175,200,250,300,400,500],tl=/\.(html?|css|js|mjs|json|svg|xml|txt|md)$/i,rl=["browserOpacity","browserOverlay","overlayAutoSave","showAddressBar"],j=null,N=null,it="page",Ze=null,ir=null,Yr=!1,X=null,ar=null,Rt=null,oo=null});var ae={};xe(ae,{changePortAndRestart:()=>vl,ensureProxyServer:()=>Jn,probeExistingServer:()=>ho,reapplySetup:()=>bl,refreshStatusFromBackend:()=>yn,restartServer:()=>gl,setProcessBaseUrl:()=>uo,startServer:()=>dr,stopServer:()=>Qr});function uo(e){lr=e||""}async function $r(e,t=900){try{let r=new AbortController,n=setTimeout(()=>r.abort(),t),o=await fetch("http://127.0.0.1:"+e+"/check",{signal:r.signal});if(clearTimeout(n),!o||!o.ok)return{alive:!1,proxy:!1};let s=await o.json().catch(()=>({}));return{alive:!0,proxy:(s==null?void 0:s.proxy)===!0&&((s==null?void 0:s.proxyVersion)||0)>=6}}catch{return{alive:!1,proxy:!1}}}async function ni(e,t=800){return(await $r(e,t)).alive}async function ul(e){try{let t=await ee("if command -v wget >/dev/null 2>&1; then wget -qO- -T 2 http://127.0.0.1:"+e+"/check 2>/dev/null; elif command -v curl >/dev/null 2>&1; then curl -s --max-time 2 http://127.0.0.1:"+e+"/check 2>/dev/null; else echo NOCLIENT; fi",{timeoutMs:8e3});return/Ready|AcodeLiveServer|"port"/i.test(String(t||""))}catch{return!1}}async function ao(e,t={}){let r=String(parseInt(e,10)||8080);return await ni(r)?!0:t.deep?ul(r):!1}async function po(e){let t=String(parseInt(e,10)||8080);Ge=null;let r=`for pid in $(ps -o pid,args 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; for pid in $(ps 2>/dev/null | grep "node index.js ${t}" | grep -v grep | awk '{print $1}'); do kill -9 "$pid" 2>/dev/null; done; pkill -9 -f "node index.js ${t}" 2>/dev/null || true; fuser -k ${t}/tcp 2>/dev/null || true`;try{await ee(r,{timeoutMs:12e3})}catch{}for(let n=0;n<10&&await ni(t,400);n++)await new Promise(o=>setTimeout(o,200))}function fo(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=t.match(/^\/storage\/emulated\/0(\/.*)?$/);return r||(r=t.match(/^\/storage\/self\/primary(\/.*)?$/),r)?"/sdcard"+(r[1]||""):t}function Ks(e){return fo(String(e||"").replace(/\/+$/,""))}async function pl(e,t){let r=s=>"'"+String(s).replace(/'/g,"'\\''")+"'",n=String(t||"index.html").replace(/^\/+/,""),o=e.replace(/\/+$/,"")+"/"+n;try{let s=await ee("[ -f "+r(o)+" ] && [ -r "+r(o)+" ] && head -c 1 "+r(o)+" >/dev/null 2>&1 && echo ENTRY_OK || echo ENTRY_NO",{timeoutMs:8e3});return String(s||"").includes("ENTRY_OK")}catch{return!1}}async function ei(e,t,r={}){let n=t||"index.html",o=await fl(e),s=Qs.test(String(e||""))||Qs.test(String(o||"")),i=!!r.forceMirror;try{let{getSettings:a}=await Promise.resolve().then(()=>(J(),De));s&&a().mirrorSharedStorage!==!1&&(i=!0)}catch{}if(i)try{let{getSettings:a}=await Promise.resolve().then(()=>(J(),De)),d=await Or(e,n,a().rootFolderUri||"");if(d)return{aroot:d,mirrored:!0}}catch(a){if(console.warn("[LiveServer] mirror failed, falling back to direct Alpine path:",(a==null?void 0:a.message)||a),!o)throw a}if(o){if(await pl(o,n)){try{Rr()}catch{}return{aroot:o,mirrored:!1}}try{if(await oi(o,n)){try{Rr()}catch{}return{aroot:o,mirrored:!1}}}catch{}console.warn("[LiveServer] alpine sees",o,"but not",n,"-> mirroring through Acode fs")}else console.warn("[LiveServer] alpine cannot see",e,"-> mirroring");try{let{getSettings:a}=await Promise.resolve().then(()=>(J(),De)),d=await Or(e,n,a().rootFolderUri||"");if(d)return{aroot:d,mirrored:!0}}catch(a){if(console.warn("[LiveServer] mirror failed",a),o)return{aroot:o,mirrored:!1};throw a}return{aroot:o||null,mirrored:!1}}async function fl(e){let t=String(e||"").replace(/\/+$/,"")||"/",r=a=>"'"+String(a).replace(/'/g,"'\\''")+"'";try{let a=await ee("[ -d "+r(t)+" ] && echo OK || echo NO",{timeoutMs:8e3});if(String(a||"").includes("OK"))return t}catch(a){console.warn("[LiveServer] root direct check",a)}let n=[],o=a=>{a&&!n.includes(a)&&n.push(a)};o(t);let s=t.match(/^\/storage\/emulated\/0(\/.*)?$/);s&&o("/sdcard"+(s[1]||"")),s=t.match(/^\/sdcard(\/.*)?$/),s&&(o("/storage/emulated/0"+(s[1]||"")),o("/storage/self/primary"+(s[1]||""))),s=t.match(/^\/storage\/self\/primary(\/.*)?$/),s&&(o("/sdcard"+(s[1]||"")),o("/storage/emulated/0"+(s[1]||"")));let i=t.match(/^\/storage\/([0-9A-Fa-f]{4}-[0-9A-Fa-f]{4})(\/.*)?$/);if(i){let a=i[1],d=i[2]||"";o("/storage/"+a+d),o("/mnt/media_rw/"+a+d)}if(!/^\/(sdcard|storage|mnt)(\/|$)/.test(t))return console.warn("[LiveServer] alpine root not found (non-storage)",t),null;try{let a=await ee("for d in "+n.map(r).join(" ")+'; do [ -d "$d" ] && { echo "OK:$d"; exit 0; }; done; echo NONE',{timeoutMs:1e4}),d=String(a||"").match(/OK:(.+)/);if(d)return d[1].trim()}catch(a){console.warn("[LiveServer] root probe failed",a)}return null}async function oi(e,t){let r=s=>"'"+String(s).replace(/'/g,"'\\''")+"'",n=String(t||"index.html").replace(/^.*\//,"")||"index.html",o="R="+r(e)+"; F="+r(String(t||"").replace(/^\/+/,""))+"; B="+r(n)+'; if [ -f "$R/$F" ]; then echo "HIT:$R|$F"; exit 0; fi; if [ -f "$R/$B" ]; then echo "HIT:$R|$B"; exit 0; fi; found=$(find "$R" -maxdepth 4 -type f -name "$B" 2>/dev/null | head -1); if [ -n "$found" ]; then dir=$(dirname "$found"); echo "HIT:$dir|$B"; exit 0; fi; echo MISS; ls -la "$R" 2>&1 | head -15';try{let s=await ee(o,{timeoutMs:12e3}),i=String(s||"").match(/HIT:([^|]+)\|([^\n]+)/);if(i)return{root:i[1].trim(),fileName:i[2].trim()}}catch(s){console.warn("[LiveServer] locateEntry",s)}return null}function hl(e){let t={};return String(e||"").split(`
`).forEach(r=>{let n=r.indexOf(":");if(n>0){let o=r.slice(0,n).trim(),s=r.slice(n+1).trim();o&&(t[o]=s)}}),t}function lo(){let e=V(),t=(e==null?void 0:e.filename)||(e==null?void 0:e.name)||"";return/\.html?$/i.test(t)?t:"index.html"}function ti(e){try{let t=V(),r=He((t==null?void 0:t.uri)||(t==null?void 0:t.url)||"");if(!r||!e)return lo();let n=Ks(e),o=Ks(r);if(o===n)return lo();if(o.startsWith(n+"/"))return o.slice(n.length).replace(/^\/+/,"");let s=o.split("/").pop();if(s&&/\.html?$/i.test(s))return s}catch{}return lo()}async function cr(e,t,r){let n=S(),o={path:t,fileName:r||"index.html",port:e,liveReload:n.liveReload!==!1,zoom:n.enablePinchToZoom!==!1,directoryListing:n.directoryListing!==!1,enableCors:n.enableCors!==!1,charset:n.customCharset||"utf-8",customHeaders:hl(n.customHeaders),ipWhitelist:n.ipWhitelist||"",basicAuthUser:n.basicAuthUser||"",basicAuthPass:n.basicAuthPass||""};try{let s=await fetch(`http://127.0.0.1:${e}/setup`,{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify(o)});return!!(s&&(s.ok||s.status===201))}catch(s){return console.warn("[LiveServer] setup",s),!1}}async function ml(e,t){let r=t&&t!=="index.html"?encodeURI(t):"";try{let n=new AbortController,o=setTimeout(()=>n.abort(),4e3),s=await fetch("http://127.0.0.1:"+e+"/"+r,{cache:"no-store",signal:n.signal});return clearTimeout(o),s.status}catch{return 0}}async function ri(e,t,r,n){if(await ml(e,n)!==404)return{aroot:r,mirrored:!1,healed:!1};console.warn("[LiveServer] server answered 404 for",n,"from",r,"-> trying storage mirror");try{let{getSettings:s}=await Promise.resolve().then(()=>(J(),De)),i=await Or(t,n||"index.html",s().rootFolderUri||"");if(i)return await cr(e,i,n),{aroot:i,mirrored:!0,healed:!0}}catch(s){console.warn("[LiveServer] heal mirror failed",(s==null?void 0:s.message)||s)}return{aroot:r,mirrored:!1,healed:!1}}function co(){Xr&&(clearInterval(Xr),Xr=null)}function Kr(){co();let e=parseInt(S().autoShutdownMinutes,10)||0;if(e<=0)return;let t=e*60*1e3,r=Date.now();Xr=setInterval(async()=>{let n=H();if(!n.running){co();return}if(Date.now()-(n.startedAt||r)>t){try{let s=await(await fetch(`http://127.0.0.1:${n.port}/status`)).json();if(s.lastActivity&&Date.now()-s.lastActivity<t)return}catch{}be("Live Server auto-stopped (inactivity)",2500),Qr()}},3e4)}async function ho(){let e=St();try{let t=new AbortController,r=setTimeout(()=>t.abort(),1200),n=await fetch(`http://127.0.0.1:${e}/status`,{signal:t.signal});if(clearTimeout(r),!n||!n.ok)return!1;let o=await n.json().catch(()=>({})),s=o.port||e,i=o.fileName||null,a=Gt(s,"127.0.0.1"),d=i&&i!=="index.html"?a.replace(/\/$/,"/")+encodeURI(i):a,u=H();if(ie({running:!0,port:s,root:o.root||u.root||null,url:d,fileName:i,bind:o.bind||"0.0.0.0",startedAt:u.startedAt||(o.uptime?Date.now()-Math.round(Number(o.uptime)*1e3):Date.now()),lastError:null}),Kr(),!u.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:d,port:s,root:o.root||null,fileName:i}}))}catch{}return!0}catch{return!1}}function si(e,t){let r=ft();if(!(r!=null&&r.execute))throw new Error("Executor not available. Open Acode Terminal once, then retry.");let n='ACODIR=""; for d in "'+String(t||"").replace(/"/g,"")+'" /root/.acode_liveserver/acodels /home/root/.acode_liveserver/acodels; do [ -n "$d" ] || continue; if [ -f "$d/index.js" ] && [ -d "$d/node_modules" ]; then ACODIR="$d"; break; fi; done; [ -z "$ACODIR" ] && { echo acodels_not_found; exit 1; }; cd "$ACODIR" || exit 1; NODE_PATH="$ACODIR/node_modules" exec node index.js '+String(e)+" 0.0.0.0 >liveserver.log 2>&1",o={};Ge=o,r.execute(dn(n),!0).then(s=>console.log("[LiveServer] node exited",String(s||"").slice(0,200))).catch(s=>console.warn("[LiveServer] node exited",String((s==null?void 0:s.message)||s).slice(0,200))).finally(()=>{if(Ge===o&&(Ge=null,H().running)){ie({running:!1,lastError:"server process exited"});try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}}})}async function Jn(){let e=St(),t=await $r(e);if(t.alive&&t.proxy)return e;if(!await kr({baseUrl:lr}))return null;Te(!0),Me(t.alive?`$ Updating backend on :${e} with Reverse Proxy...`:`$ node index.js ${e} (starting local proxy)...`,{spin:!0});try{t.alive&&!t.proxy&&await po(e);let n=await bt(lr);await vn(n),si(e,n);let o=!1;for(let p=0;p<35;p++){await new Promise(g=>setTimeout(g,300));let c=await $r(e,500);if(c.alive&&c.proxy){o=!0;break}if(!Ge)break}if(!o)return Me("Proxy server failed to start",{spin:!1,autoHideMs:3e3}),null;let s=H(),i=s.root||Cr()||"/sdcard",a=fo(i),d=s.fileName||"index.html";await cr(e,a,d);let u=Gt(e,"127.0.0.1");ie({running:!0,port:e,root:a,url:u,fileName:d,bind:"0.0.0.0",startedAt:Date.now(),lastError:null}),Kr();try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:u,port:e,root:a,fileName:d}}))}catch{}return Me(`\u2713 Reverse proxy ready on 127.0.0.1:${e}`,{spin:!1,autoHideMs:2e3}),e}catch(n){return Me(`Proxy error: ${(n==null?void 0:n.message)||n}`,{spin:!1,autoHideMs:3500}),null}finally{Te(!1)}}async function dr(e={}){let t=e.port||St(),r=e.root||Cr(),n=S(),o=e.forceDeps?{alive:!1,proxy:!1}:await $r(t);if(o.alive&&!o.proxy&&(Te(!0),Me(`$ Upgrading Live Server on :${t}...`,{spin:!0}),await po(t),Te(!1),Yt(0),o.alive=!1),o.alive&&o.proxy){let h=H(),l=r||h.root;if(!l)return be("Set a root folder or open an HTML file",2500),!1;let v=e.fileName||ti(l),A,x=!1;try{let b=await ei(l,v);A=b.aroot||fo(l),x=b.mirrored}catch(b){return be("Cannot serve folder: "+((b==null?void 0:b.message)||b),4e3),!1}let C=!h.running||h.port!==t||h.root!==A||h.fileName!==v;if(C&&await cr(t,A,v),C&&!x){let b=await ri(t,l,A,v);b.healed&&(A=b.aroot,x=!0)}let _=Gt(t,"127.0.0.1"),M=v&&v!=="index.html"?_.replace(/\/$/,"/")+encodeURI(v):_;if(ie({running:!0,port:t,root:A,url:M,fileName:v,bind:"0.0.0.0",startedAt:h.startedAt||Date.now(),lastError:null}),Kr(),!h.running)try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:M,port:t,root:A,fileName:v}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:b}=await Promise.resolve().then(()=>(lt(),at));b(M,{reuse:!0})}catch(b){console.warn("[LiveServer] open browser",b)}return!0}if(!await kr({baseUrl:lr,force:!!e.forceDeps}))return!1;if(!r)return be("Set a root folder or open an HTML file",2500),!1;let i=e.fileName||ti(r),a,d=!1;try{let h=await ei(r,i);a=h.aroot,d=h.mirrored}catch(h){return ie({running:!1,lastError:String((h==null?void 0:h.message)||h)}),be("Cannot serve folder: "+((h==null?void 0:h.message)||h),4500),null}if(!a)return ie({running:!1,lastError:"root not reachable"}),be("Folder not reachable \u2014 mirror also failed. Use internal /sdcard or grant storage access.",4500),!1;try{let h=await oi(a,i);h?(h.root!==a||h.fileName!==i)&&(a=h.root,i=h.fileName):d||console.warn("[LiveServer] entry missing under",a,i)}catch(h){console.warn("[LiveServer] locate failed",h)}let u="0.0.0.0";if(!await ao(t,{deep:!0})){Te(!0),Me(`$ node index.js ${t} 0.0.0.0`,{spin:!0});let h=await bt(lr);try{await vn(h)}catch(v){console.warn("[LiveServer] ensure index",v)}try{si(t,h)}catch(v){return Te(!1),Yt(0),ie({running:!1,lastError:String((v==null?void 0:v.message)||v)}),be("Start failed: "+((v==null?void 0:v.message)||v),3e3),!1}let l=!1;for(let v=0;v<40;v++){if(await new Promise(A=>setTimeout(A,300)),await ao(t)){l=!0;break}if(!Ge)break}if(!l&&Ge&&(l=await ao(t,{deep:!0})),Te(!1),!l){Me("Server failed to start",{spin:!1,autoHideMs:3500});try{let v=await ee("tail -n 40 /root/.acode_liveserver/acodels/liveserver.log 2>/dev/null",{timeoutMs:8e3});console.warn("[LiveServer] start failed, log:",v)}catch{}return be("Server failed to start \u2014 see console log",3500),ie({running:!1,lastError:"start failed"}),Ge=null,!1}Me(`\u2713 Live Server running on :${t}`,{spin:!1,autoHideMs:2200})}let p=await cr(t,a,i);if(p||console.warn("[LiveServer] /setup patch failed"),p&&!d){let h=await ri(t,r,a,i);h.healed&&(a=h.aroot,d=!0)}let c=Gt(t,"127.0.0.1"),g=i&&i!=="index.html"?c.replace(/\/$/,"/")+encodeURI(i):c;ie({running:!0,port:t,root:a,url:g,fileName:i,bind:u,startedAt:Date.now(),lastError:null}),R("port",t),Kr(),be("Live on "+g,2500);try{window.dispatchEvent(new CustomEvent("liveserver-started",{detail:{url:g,port:t,root:r,fileName:i}}))}catch{}if(e.openBrowser===!0||e.openBrowser!==!1&&n.openBrowserOnStart!==!1)try{let{openBrowser:h}=await Promise.resolve().then(()=>(lt(),at));h(g,{reuse:!0})}catch(h){console.warn("[LiveServer] open browser",h)}return!0}async function Qr(){try{Rr()}catch{}co();let t=H().port||St();await po(t),ie({running:!1,port:null,url:null,fileName:null,startedAt:null}),be("Server stopped",1500);try{window.dispatchEvent(new CustomEvent("liveserver-stopped"))}catch{}return!0}async function gl(){let e=H(),t=e.root,r=e.fileName;return await Qr(),await new Promise(n=>setTimeout(n,350)),dr({root:t||void 0,fileName:r||void 0})}async function vl(){let e=acode.require("prompt"),t=String(St()),r=await e("Port",t,"number");if(r==null)return!1;let n=parseInt(String(r),10);return!Number.isFinite(n)||n<1||n>65535?(be("Invalid port",1500),!1):(R("port",n),await Qr(),dr({port:n}))}async function bl(){let e=H();return!e.running||!e.port||!e.root?!1:cr(e.port,e.root,e.fileName||"index.html")}var be,lr,Xr,Ge,Qs,Q=T(()=>{J();ht();yt();Uo();Fe();ss();is();de();Se();_r();be=acode.require("toast"),lr="",Xr=null,Ge=null;Qs=/^\/(sdcard|storage|mnt)(\/|$)/});var yo={};xe(yo,{onFileSwitch:()=>vo,registerSideButton:()=>go,setLiveDot:()=>ct,unregisterSideButton:()=>bo});function pi(){if(document.getElementById("ls-side-btn-css"))return;let e=document.createElement("style");e.id="ls-side-btn-css",e.textContent=`
    [data-ls-sidebtn="1"] {
      gap: 6px;
    }
    [data-ls-sidebtn="1"] .ls-side-ico {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1.05rem;
      height: 1.05rem;
      flex-shrink: 0;
      margin-right: 4px;
      vertical-align: middle;
    }
    [data-ls-sidebtn="1"] .ls-side-ico svg {
      width: 1.05rem;
      height: 1.05rem;
      display: block;
    }
    [data-ls-sidebtn="1"][data-live="1"] {
      background: #22c55e !important;
      color: #0b1220 !important;
    }
    [data-ls-sidebtn="1"][data-live="0"] {
      background: var(--button-background-color, var(--secondary-color, #3c4043)) !important;
      color: var(--button-text-color, var(--color, #e8eaed)) !important;
    }
  `,document.head.appendChild(e)}function li(){return'<svg class="ls-side-ico" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M5.63605 5.63603L18.364 18.364M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="#666" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'}function ci(){return'<svg class="ls-side-ico" viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>'}function wl(){let e=S();if(e.bindLocalhostOnly!==!1)return"127.0.0.1";let t=String(e.bindAddress||"127.0.0.1").trim();return!t||t==="0.0.0.0"?"127.0.0.1":t}function xl(){let e=H(),t=S(),r=String(t.sideButtonRunningLabel||"{HOST}:{PORT}"),n=wl(),o=e.port||t.port||8080;return r.replace(/\{HOST\}/gi,n).replace(/\{PORT\}/gi,String(o))}function Sl(){return String(S().sideButtonOfflineLabel||"Go Live")}function ur(e){return e?xl():Sl()}function di(){var e;return S().showSideButton!==!1&&Ae(V()||((e=window.editorManager)==null?void 0:e.activeFile))}function fi(){return L?L.$el||L.el||L.root||(L instanceof HTMLElement?L:null):null}function hi(e,t){var i,a,d;if(!e)return!1;e.setAttribute("data-ls-sidebtn","1"),e.setAttribute("data-live",t?"1":"0");let r=ur(t),n=t?li():ci(),o=e.querySelectorAll('.text, .label, .side-button-text, [class*="text"], span, small'),s=!1;for(let u of o)(i=u.classList)!=null&&i.contains("icon")||(a=u.classList)!=null&&a.contains("ls-side-ico")||(d=u.children)!=null&&d.length&&u.querySelector(".icon, svg")||(u.innerHTML=n+r,s=!0);if(!s){let u=e.querySelector(".icon");if(u){u.innerHTML=t?li():ci();let p=!1;for(let c of e.childNodes)c.nodeType===3&&c.textContent.trim()&&(c.textContent=" "+r,p=!0);p||(e.setAttribute("aria-label",r),e.title=r)}else e.innerHTML=n+'<span class="ls-side-label">'+r+"</span>"}return e.setAttribute("aria-label",r),e.title=r,!0}function kl(e){return{text:ur(e),icon:e?"block":"public",backgroundColor:e?"#22c55e":void 0,textColor:e?"#0b1220":void 0,onclick:()=>El()}}function ui(e){var t;try{(t=L==null?void 0:L.hide)==null||t.call(L)}catch{}if(L=null,!!ii)try{L=ii(kl(e));let r=fi();r&&hi(r,e)}catch(r){console.warn("[LiveServer] recreate side",r)}}function ct(e){var t,r,n;try{pi();let o=e==null?!!H().running:!!e;if(document.body.classList.toggle("ls-server-live",o),!di()){try{(t=L==null?void 0:L.hide)==null||t.call(L)}catch{}mo=o;return}if(!L)ui(o);else{try{typeof L.setText=="function"&&L.setText(ur(o)),"text"in L&&(L.text=ur(o)),L.$text&&(L.$text.textContent=ur(o))}catch{}let s=fi();(!(s?hi(s,o):!1)||mo!==o)&&ui(o)}di()?(r=L==null?void 0:L.show)==null||r.call(L):(n=L==null?void 0:L.hide)==null||n.call(L),mo=o}catch(o){console.warn("[LiveServer] setLiveDot",o)}}async function El(){let t=H().running?["stop","Stop live server"]:["start","Start live server"],r=await yl("Live Server",[t,["startSelected","Start server on selected path"],["restart","Restart server"],["port","Change port"],["root","Select root folder"],["rootBrowse","Select path (Acode browser)"],["browser","Open browser"],["deps","Check dependencies"],["settings","Settings"]],{hideOnSelect:!0});if(r){try{if(r==="start"){let{startServer:n}=await Promise.resolve().then(()=>(Q(),ae));await n()}else if(r==="startSelected"){let{startServer:n}=await Promise.resolve().then(()=>(Q(),ae)),{getSettings:o}=await Promise.resolve().then(()=>(J(),De)),{browseRootFolder:s,getEffectiveRoot:i}=await Promise.resolve().then(()=>(Fe(),Ke)),a=o().rootFolder||i();if(a||(a=await s()),!a){ai("Select a folder first",2e3);return}await n({root:a})}else if(r==="stop"){let{stopServer:n}=await Promise.resolve().then(()=>(Q(),ae));await n()}else if(r==="restart"){let{restartServer:n}=await Promise.resolve().then(()=>(Q(),ae));await n()}else if(r==="port"){let{changePortAndRestart:n}=await Promise.resolve().then(()=>(Q(),ae));await n()}else if(r==="root"){let{pickRootFolder:n}=await Promise.resolve().then(()=>(Fe(),Ke));await n()}else if(r==="rootBrowse"){let{browseRootFolder:n}=await Promise.resolve().then(()=>(Fe(),Ke));await n()}else if(r==="browser"){let{openBrowser:n}=await Promise.resolve().then(()=>(lt(),at)),o=H().url||"http://127.0.0.1:"+(H().port||8080)+"/";n(o,{restoreOnly:!0})}else if(r==="deps"){let{checkDependenciesAction:n}=await Promise.resolve().then(()=>(yt(),Er));await n()}else if(r==="settings"){let{openSettingsHub:n}=await Promise.resolve().then(()=>(or(),Wr));n()}}catch(n){ai(String((n==null?void 0:n.message)||n),2500)}ct(H().running)}}function go(){if(S().showSideButton!==!1){pi();try{ct(H().running)}catch(e){console.warn("[LiveServer] side button",e)}}}function vo(){ct(H().running)}function bo(){var e;try{(e=L==null?void 0:L.hide)==null||e.call(L)}catch{}L=null,document.body.classList.remove("ls-server-live")}var ii,yl,ai,L,mo,en=T(()=>{J();Se();de();ii=acode.require("sideButton"),yl=acode.require("select"),ai=acode.require("toast"),L=null,mo=null});function mi(){let e=[];return pr.forEach(t=>{e.includes(t.category)||e.push(t.category)}),e}function Ye(e){let t=S();return t[e]!==void 0?t[e]:zt[e]}function gi(e){if(e.checkbox||e.noValue)return"";let t=Ye(e.key);if(e.select){let n=e.select.find(o=>String(Array.isArray(o)?o[0]:o)===String(t));return n?Array.isArray(n)?n[1]:n:String(t!=null?t:"")}if(e.secret)return t?"\u2022\u2022\u2022\u2022\u2022\u2022":"";let r=t==null?"":String(t);return r.length>28?r.slice(0,27)+"\u2026":r}async function Cl(e){try{if(e==="start")return(await Promise.resolve().then(()=>(Q(),ae))).startServer();if(e==="stop")return(await Promise.resolve().then(()=>(Q(),ae))).stopServer();if(e==="restart")return(await Promise.resolve().then(()=>(Q(),ae))).restartServer();if(e==="open"){let r=(await Promise.resolve().then(()=>(de(),Qe))).getServerStatus();return r.running?(await Promise.resolve().then(()=>(lt(),at))).openBrowser(r.url||"http://127.0.0.1:"+r.port+"/",{restoreOnly:!0}):Ve("Server is not running",2e3)}if(e==="root")return(await Promise.resolve().then(()=>(Fe(),Ke))).pickRootFolder();if(e==="status"){let r=(await Promise.resolve().then(()=>(de(),Qe))).getServerStatus();return Ve(r.running?(r.url||"")+" \u2014 port "+r.port:"Not running",3e3)}if(e==="deps")return(await Promise.resolve().then(()=>(yt(),Er))).checkDependenciesAction();if(e==="reinstall")return(await Promise.resolve().then(()=>(yt(),Er))).reinstallDependenciesAction()}catch(t){Ve(String((t==null?void 0:t.message)||t),3e3)}}async function fr(e,t){var n,o;if(e==="__action")return await Cl(t),!0;if(e==="__browserAction"){try{t==="clearHistory"?((await Promise.resolve().then(()=>(jr(),Yn))).clearVisited(),Ve("Browser history cleared",1800)):t==="clearBookmarks"&&(R("browserBookmarks",[]),Ve("Bookmarks cleared",1800))}catch(s){Ve(String((s==null?void 0:s.message)||s),2500)}return!0}let r=t;if(e==="port"){let s=parseInt(String(t),10);if(!Number.isFinite(s)||s<1||s>65535)return Ve("Invalid port",1800),!1;r=s}else if(e==="autoShutdownMinutes"){let s=parseInt(String(t),10);if(!Number.isFinite(s)||s<0)return Ve("Invalid number",1800),!1;r=s}else if(e==="browserOpacity"){let s=parseFloat(String(t));r=Number.isFinite(s)?Math.min(1,Math.max(.1,Math.round(s*100)/100)):1}if(R(e,r),e==="sideButtonRunningLabel"||e==="sideButtonOfflineLabel")try{let s=await Promise.resolve().then(()=>(en(),yo));(n=s.setLiveDot)==null||n.call(s,null)}catch{}if(e==="enablePinchToZoom")try{let s=await Promise.resolve().then(()=>(jr(),Yn));(o=s.applyPinchAll)==null||o.call(s)}catch{}if(e==="showSideButton")try{let s=await Promise.resolve().then(()=>(en(),yo));r===!1?s.unregisterSideButton():s.registerSideButton()}catch{}return!0}function vi(){return{list:pr.map(t=>{let r={key:t.key,text:t.text,category:t.category};return t.info&&(r.info=t.info),t.checkbox?(r.checkbox=!0,r.value=!!Ye(t.key)):t.select?(r.select=t.select,t.noValue?(r.value="",r.valueText=()=>"Choose\u2026"):r.value=t.asString?String(Ye(t.key)):Ye(t.key)):t.prompt&&(r.prompt=t.prompt,t.promptType&&(r.promptType=t.promptType),r.value=Ye(t.key),t.secret&&(r.valueText=n=>n?"\u2022\u2022\u2022\u2022\u2022\u2022":"")),r}),cb:(t,r)=>{fr(t,r)}}}var Ve,Ll,pr,wo=T(()=>{ln();J();Ve=acode.require("toast"),Ll=[["start","Start server"],["stop","Stop server"],["restart","Restart server"],["open","Open browser"],["root","Select root folder"],["status","Show server status"],["deps","Check dependencies"],["reinstall","Reinstall dependencies"]],pr=[{key:"__action",category:"Actions",text:"Run action",info:"Start / stop / open browser / dependencies",select:Ll,noValue:!0},{key:"port",category:"General",text:"Port",info:"Default 8080",prompt:"Port number",promptType:"number"},{key:"bindAddress",category:"General",text:"Bind address",select:[["127.0.0.1","Localhost only (127.0.0.1)"],["0.0.0.0","All interfaces (0.0.0.0)"]]},{key:"rootFolder",category:"General",text:"Root folder",info:"Empty = folder of the active HTML file",prompt:"Absolute folder path",promptType:"text"},{key:"liveReload",category:"General",text:"Live reload on save",checkbox:!0},{key:"openBrowserOnStart",category:"General",text:"Open browser on start",checkbox:!0},{key:"mirrorSharedStorage",category:"General",text:"Serve sdcard via safe copy",info:"Copy the HTML + its dependencies from sdcard / SD card into Alpine cache and keep them synced",checkbox:!0},{key:"autoShutdownMinutes",category:"General",text:"Auto shutdown (minutes)",info:"0 = off",prompt:"Minutes (0 = off)",promptType:"number"},{key:"browserDisplayMode",category:"Browser",text:"Show browser in",info:"Acode page or editor tab",select:[["inPage","Acode page (default)"],["editorTab","Editor tab"]]},{key:"browserSearchEngine",category:"Browser",text:"Search engine",info:"Used when searching keywords in address bar or New Tab",select:[["google","Google"],["duckduckgo","DuckDuckGo"],["bing","Bing"],["brave","Brave Search"]]},{key:"externalSiteMode",category:"Browser",text:"External websites",info:"Proxy auto-switches to Chromium if slow, or select Chromium directly",select:[["proxy","Local Node.js Reverse Proxy (Default)"],["acodeWebview","Acode Native WebView (Fullscreen)"],["inApp","Direct iframe (without proxy)"],["systemBrowser","Chrome / External system browser"]]},{key:"browserHomeUrl",category:"Browser",text:"Home button URL",info:"Empty = Green Fox Homepage",prompt:"Home URL (leave empty for Green Fox Homepage)",promptType:"text"},{key:"browserOpacity",category:"Browser",text:"Browser opacity",info:"0.1 - 1.0 (page mode)",asString:!0,select:["0.1","0.2","0.3","0.4","0.5","0.6","0.7","0.8","0.9","1"].map(e=>[e,e])},{key:"enablePinchToZoom",category:"Browser",text:"Pinch to zoom",info:"Two-finger zoom, drag to pan, double-tap to reset (served pages reload when toggled)",checkbox:!0},{key:"browserOverlay",category:"Browser",text:"Preview as overlay",info:"See-through preview over the editor; you can still type in the editor",checkbox:!0},{key:"overlayAutoSave",category:"Browser",text:"Auto-save in overlay mode",info:"Saves the file after you stop typing so the preview updates live",checkbox:!0},{key:"showAddressBar",category:"Browser",text:"Show address bar",checkbox:!0},{key:"showSideButton",category:"Browser",text:"Show side button",checkbox:!0},{key:"sideButtonRunningLabel",category:"Browser",text:"Side button running label",value:"{HOST}:{PORT}",valueText:e=>String(e||"{HOST}:{PORT}"),prompt:"Running label ({HOST} {PORT} tokens)",promptType:"text",info:"Shown when server is live. Tokens: {HOST} {PORT}."},{key:"sideButtonOfflineLabel",category:"Browser",text:"Side button offline label",value:"Go Live",valueText:e=>String(e||"Go Live"),prompt:"Offline label",promptType:"text",info:"Shown when server is stopped."},{key:"__browserAction",category:"Browser",text:"Browser data",info:"Clear recent history or saved bookmarks",select:[["clearHistory","Clear recent history"],["clearBookmarks","Clear all bookmarks"]],noValue:!0},{key:"directoryListing",category:"HTML / static",text:"Enable directory listing",checkbox:!0},{key:"enableCors",category:"HTML / static",text:"Enable CORS",checkbox:!0},{key:"customCharset",category:"HTML / static",text:"Custom charset",prompt:"Charset",promptType:"text"},{key:"customHeaders",category:"HTML / static",text:"Custom response headers",info:'One "Header: value" per line',prompt:"Custom headers",promptType:"textarea"},{key:"bindLocalhostOnly",category:"Security",text:"Prefer localhost bind",checkbox:!0},{key:"ipWhitelist",category:"Security",text:"Client IP whitelist",info:"Comma or newline separated; empty = all",prompt:"IP whitelist",promptType:"textarea"},{key:"basicAuthUser",category:"Security",text:"Basic auth user",prompt:"User name",promptType:"text"},{key:"basicAuthPass",category:"Security",text:"Basic auth password",prompt:"Password",promptType:"text",secret:!0}]});var Wr={};xe(Wr,{openSettingsHub:()=>Dl,registerPluginSettings:()=>ki});function Ol(){if(document.getElementById("ls-settings-css"))return;let e=document.createElement("style");e.id="ls-settings-css",e.textContent=Rl,document.head.appendChild(e)}function _e(e,t,r){let n=document.createElement(e);return t&&(n.className=t),r!=null&&(n.textContent=r),n}function xi(e,t,r,n){let o=_e("div","ls-set-row");o.setAttribute("role","button"),o.tabIndex=0;let s=_e("div","ls-set-main");return s.appendChild(_e("div","ls-set-title",e)),t&&s.appendChild(_e("div","ls-set-info",t)),o.appendChild(s),r&&o.appendChild(r),o.addEventListener("click",n),o}function Si(){let e=_e("span","ls-set-chev");return e.innerHTML=er(Pl,16),e}async function _l(e,t){let r=Ye(e.key);if(e.checkbox)return await fr(e.key,!r),t();if(e.select){let n=await Tl(e.text,e.select,{hideOnSelect:!0,default:e.noValue?void 0:String(r)});n!=null&&(await fr(e.key,n),t());return}if(e.prompt){let n=e.promptType==="number"?"number":e.promptType==="textarea"?"textarea":"text",o=await Ml(e.prompt,r==null?"":String(r),n);o!=null&&(await fr(e.key,o),t())}}function Bl(e,t){e.textContent="",mi().forEach(r=>{let n=pr.filter(o=>o.category===r).length;e.appendChild(xi(r,n+" options",Si(),()=>t(r)))})}function Il(e,t,r){e.textContent="",pr.filter(n=>n.category===t).forEach(n=>{let o=null;if(n.checkbox)o=_e("span","ls-set-switch"+(Ye(n.key)?" is-on":""));else{o=_e("span"),o.style.cssText="display:flex;align-items:center;gap:6px;min-width:0;max-width:50%";let s=gi(n);s&&o.appendChild(_e("span","ls-set-val",s)),o.appendChild(Si())}e.appendChild(xi(n.text,n.info,o,()=>_l(n,r)))})}function wi(e,t,r){var d,u;Ol();let n=document.createElement("span");n.className="icon arrow_back",n.dataset.action="back",n.style.cssText="pointer-events:auto;cursor:pointer;";let o=Al(e,{lead:n}),s=_e("div","ls-set-body");try{o.appendBody(s)}catch{(d=o.appendChild)==null||d.call(o,s)}let i=()=>t(s,i),a=()=>{var p,c;try{bi.remove(r)}catch{}try{(p=o.hide)==null||p.call(o)}catch{}try{(c=o.remove)==null||c.call(o)}catch{}};n.onclick=p=>{var c,g;try{(c=p==null?void 0:p.preventDefault)==null||c.call(p),(g=p==null?void 0:p.stopPropagation)==null||g.call(p)}catch{}a()};try{bi.push({id:r,action:a})}catch{}i();try{(window.app||document.body).append(o)}catch{document.body.append(o)}try{(u=o.show)==null||u.call(o)}catch{}}function Dl(){wi("Live Server",e=>Bl(e,t=>wi(t,(r,n)=>Il(r,t,n),yi+t)),yi+"hub")}function ki(){}var Al,bi,Tl,Ml,yi,Pl,Rl,or=T(()=>{wo();Xn();Al=acode.require("page"),bi=acode.require("actionStack"),Tl=acode.require("select"),Ml=acode.require("prompt"),yi="liveserver-settings-",Pl="M9 18l6-6-6-6",Rl=`
.ls-set-body{height:100%;overflow:auto;padding:4px 0 24px}
.ls-set-row{display:flex;align-items:center;gap:12px;padding:12px 16px;cursor:pointer;border-bottom:1px solid rgba(128,128,128,.15)}
.ls-set-row:active{background:rgba(128,128,128,.14)}
.ls-set-main{flex:1;min-width:0}
.ls-set-title{font-size:15px}
.ls-set-info{font-size:12px;opacity:.65;margin-top:2px}
.ls-set-val{max-width:45%;font-size:12px;opacity:.75;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ls-set-chev{display:inline-flex;opacity:.55;flex-shrink:0}
.ls-set-switch{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0}
.ls-set-switch::before{content:'';position:absolute;inset:0;border-radius:3px;background:rgba(128,128,128,.45);transition:background .15s}
.ls-set-switch::after{content:'';position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:3px;background:#fff;transition:transform .15s}
.ls-set-switch.is-on::before{background:var(--active-color,#61afef)}
.ls-set-switch.is-on::after{transform:translateX(18px)}
`});var an={id:"acode.plugin.sugerserver",name:"Html Server Pro - Devtool",main:"main.js",version:"2.0.0",readme:"readme.md",icon:"icon.png",files:["acodels/","icon.png","readme.md"],minVersionCode:1011,license:"Proprietary",changelogs:"changelogs.md",keywords:["Live Server Pro","HTML","HTTP","browser","preview"],price:70,repository:"",author:{name:"Dev.Sourav",email:"devs.sourav@gmail.com",github:"Sou6900"}};or();en();Se();var xo=acode.require("toast"),So=[];function Ei(){try{let e=acode.require("commands");if(!(e!=null&&e.add))return;let t=(r,n,o)=>{try{e.add({name:r,description:n,exec:o}),So.push(r)}catch{}};t("liveserver:run-file","Live Server: Run this file in HTTP server",async()=>{if(!V())return xo("Open a file in the editor first",2e3);let{startServer:n}=await Promise.resolve().then(()=>(Q(),ae));await n()}),t("liveserver:select-root","Live Server: Select root folder",async()=>{let{pickRootFolder:r}=await Promise.resolve().then(()=>(Fe(),Ke));await r()}),t("liveserver:run-selected-root","Live Server: Run HTTP server for selected / saved root",async()=>{let{startServer:r}=await Promise.resolve().then(()=>(Q(),ae)),{getSettings:n}=await Promise.resolve().then(()=>(J(),De)),{rootFromSelectedFolder:o}=await Promise.resolve().then(()=>(Fe(),Ke)),s=n().rootFolder||o();if(!s)return xo("Select a root folder first (command: Select root folder)",3e3);await r({root:s})}),t("liveserver:stop","Live Server: Stop server",async()=>{let{stopServer:r}=await Promise.resolve().then(()=>(Q(),ae));await r()}),t("liveserver:restart","Live Server: Restart server",async()=>{let{restartServer:r}=await Promise.resolve().then(()=>(Q(),ae));await r()}),t("liveserver:open-browser","Live Server: Open browser",async()=>{let{getServerStatus:r}=await Promise.resolve().then(()=>(de(),Qe)),{openBrowser:n}=await Promise.resolve().then(()=>(lt(),at)),o=r();if(!o.running)return xo("Server is not running",2e3);n(o.url||`http://127.0.0.1:${o.port}/`,{restoreOnly:!0})}),t("liveserver:settings","Live Server: Open settings",async()=>{let{openSettingsHub:r}=await Promise.resolve().then(()=>(or(),Wr));r()})}catch(e){console.warn("[LiveServer] commands",e)}}function Li(){try{let e=acode.require("commands");So.forEach(t=>{var r;try{(r=e==null?void 0:e.remove)==null||r.call(e,t)}catch{}})}catch{}So=[]}var zl="";function Ci(e){zl=e?String(e).endsWith("/")?String(e):e+"/":""}Se();Se();Q();var Ai=acode.require("toast"),ko=!1;async function Ti(e){var t;if(ko)return!1;ko=!0;try{let r=e||V();if(!Ae(r))return Ai("Open an .html / .htm file first",2e3),!1;if(r.isUnsaved&&(r.uri||r.url))try{await((t=r.save)==null?void 0:t.call(r))}catch(n){console.warn("[LiveServer] save before run",n)}return await dr({openBrowser:!0})}catch(r){return Ai(String((r==null?void 0:r.message)||r),3e3),!1}finally{ko=!1}}var W=null,tn=null,Eo=!1;function Hl(){if(document.getElementById("ls-run-css"))return;let e=document.createElement("style");e.id="ls-run-css",e.textContent=`
    body.ls-html-file #root > header.tile > [action="run"]:not([data-ls-run]) {
      display: none !important;
    }
  `,document.head.appendChild(e)}var Mi="#root > header.tile";function ql(){return document.querySelector(`${Mi} > span.icon.play_arrow[action="run"]`)||document.querySelector('[action="run"]:not([data-ls-run])')}async function Fl(e){var t;if(e.preventDefault(),e.stopPropagation(),!Eo){Eo=!0;try{let r=V()||((t=window.editorManager)==null?void 0:t.activeFile);await Ti(r)}catch(r){console.error("[LiveServer] runPreview failed:",r);try{acode.require("toast")((r==null?void 0:r.message)||"Failed to launch Live Server")}catch{}}finally{Eo=!1}}}function Ee(){var o;Hl();let e=V()||((o=window.editorManager)==null?void 0:o.activeFile),t=Ae(e);if(document.body.classList.toggle("ls-html-file",t),!t){W!=null&&W.isConnected&&W.remove();return}W||(W=document.createElement("span"),W.className="icon play_arrow",W.setAttribute("action","run-live-server"),W.setAttribute("data-ls-run","1"),W.setAttribute("title","Run with Live Server"),W.onclick=Fl),W.className="icon play_arrow";let r=ql(),n=document.querySelector(Mi);r&&r.parentNode?(W.parentNode!==r.parentNode||W.nextSibling!==r)&&r.parentNode.insertBefore(W,r):n&&!W.isConnected&&n.insertBefore(W,n.lastChild)}function Pi(){Ee(),window.editorManager&&(editorManager.off("switch-file",Ee),editorManager.off("rename-file",Ee),editorManager.on("switch-file",Ee),editorManager.on("rename-file",Ee)),clearInterval(tn),tn=setInterval(Ee,1500)}function Ri(){var e;clearInterval(tn),tn=null,window.editorManager&&(editorManager.off("switch-file",Ee),editorManager.off("rename-file",Ee));try{W==null||W.remove()}catch{}W=null,document.body.classList.remove("ls-html-file"),(e=document.getElementById("ls-run-css"))==null||e.remove()}yt();Q();de();J();de();Se();var _t=null;function Oi(){var e;if(!_t){_t=async t=>{try{if(S().liveReload===!1)return;let r=H();if(!r.running||!r.port)return;await fetch(`http://127.0.0.1:${r.port}/reload`,{method:"POST"}).catch(()=>{}),(Ae(t)||Ae(editorManager==null?void 0:editorManager.activeFile))&&console.log("[LiveServer] reload signal after save")}catch(r){console.warn("[LiveServer] save reload",r)}};try{(e=editorManager==null?void 0:editorManager.on)==null||e.call(editorManager,"save-file",_t)}catch{}}}function _i(){var e;try{_t&&((e=editorManager==null?void 0:editorManager.off)==null||e.call(editorManager,"save-file",_t))}catch{}_t=null}var Lo=null;function Bi(){Lo&&(Lo(!1),Lo=null)}_r();var Ii=["switch-file","rename-file","file-loaded","new-file"],Co="",hr=null,dt=null,mr=null;async function Di(e){Co=e||"",uo(Co),Ci(Co),gn();try{let{getSettings:r,updateSetting:n}=await Promise.resolve().then(()=>(J(),De)),o=r().acodelsPath||"";/^\/public|com\.termux/.test(String(o))&&n("acodelsPath","")}catch{}try{}catch(r){console.warn("[LiveServer] settings",r)}try{go()}catch(r){console.warn("[LiveServer] side",r)}try{Ei()}catch(r){console.warn("[LiveServer] commands",r)}try{Oi()}catch(r){console.warn("[LiveServer] liveReload",r)}try{Pi()}catch(r){console.warn("[LiveServer] run button",r)}hr=()=>{vo(),Ee()},Ii.forEach(r=>{var n;try{(n=editorManager==null?void 0:editorManager.on)==null||n.call(editorManager,r,hr)}catch{}}),dt=()=>ct(H().running);try{window.addEventListener("liveserver-status",dt),window.addEventListener("liveserver-started",dt),window.addEventListener("liveserver-stopped",dt)}catch{}let t=async()=>{let r=await ho();ct(r)};t(),setTimeout(t,1200),setTimeout(hr,400),mr=()=>{document.visibilityState==="visible"&&t()},document.addEventListener("visibilitychange",mr);try{window.addEventListener("liveserver-settings",async()=>{try{let{reapplySetup:r}=await Promise.resolve().then(()=>(Q(),ae));H().running&&await r()}catch{}})}catch{}}function zi(){Ii.forEach(e=>{var t;try{hr&&((t=editorManager==null?void 0:editorManager.off)==null||t.call(editorManager,e,hr))}catch{}});try{Ri()}catch{}try{window.removeEventListener("liveserver-status",dt),window.removeEventListener("liveserver-started",dt),window.removeEventListener("liveserver-stopped",dt)}catch{}mr&&(document.removeEventListener("visibilitychange",mr),mr=null),Bi(),ls(),bo(),Li();try{_i()}catch{}try{Promise.resolve().then(()=>(lt(),at)).then(e=>{var t;return(t=e.hideBrowser)==null?void 0:t.call(e)})}catch{}try{Promise.resolve().then(()=>(no(),js)).then(e=>{var t;return(t=e.destroyAcodeWebview)==null?void 0:t.call(e)})}catch{}}wo();var rn=class{constructor(){this.baseUrl=""}async init(t){var r;this.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await Di(this.baseUrl)}async destroy(){zi()}};if(window.acode){let e=new rn;acode.setPluginInit(an.id,async t=>{var r;e.baseUrl=(r=t==null?void 0:t.endsWith)!=null&&r.call(t,"/")?t:`${t||""}/`,await e.init(e.baseUrl)},vi()),acode.setPluginUnmount(an.id,()=>{e.destroy()})}var nu=rn;})();
